# Escudos

Gerados por `tools/fetch-teams.mjs` a partir do TheSportsDB (WebP, 128 px, fundo transparente): `<id do clube ou código FIFA da seleção>.webp`.
Seleções usam o escudo da federação. Equipe sem arquivo aparece com a sigla sobre a cor do uniforme.
