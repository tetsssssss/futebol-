# Fotos de atletas

Geradas por `tools/fetch-faces.mjs` e `tools/fetch-faces-extra.mjs` (WebP, ~120 px). O índice fica em `data/media.json` / `src/media-index.js`.

- `ea/<id SoFIFA>.webp`: rosto do atleta na base EA FC 26 / SoFIFA (e, quando a SoFIFA não tem, imagem de TheSportsDB ou Wikipédia/Commons; procedência em `data/media-sources.json`).
- `fifa/<uuid>.webp`: retrato oficial das listas da Copa de 2026 (FIFA Digital Hub).
- `club/<id do atleta>.webp`: atletas dos clubes cadastrados (Wikimedia Commons, TheSportsDB, Wikipédia).

Atleta sem arquivo aparece com avatar (iniciais); nenhum rosto é inventado nem trocado por outra pessoa.
