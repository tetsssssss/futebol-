# Uniformes

Gerados por `tools/fetch-teams.mjs` a partir do TheSportsDB (WebP, 160 px): imagem do uniforme principal de cada equipe.
Cores e padrão (liso, listras, faixas horizontais, metades, faixa diagonal) são extraídos dessa imagem e gravados em `data/media.json` (`c`, `p`);
o campo 2D usa essas cores e troca a camisa da visitante quando as duas se confundem.
