// Mídia local de atletas e equipes: fotos, escudos e uniformes baixados por tools/fetch-faces.mjs e tools/fetch-teams.mjs.
// Só devolve caminho quando o arquivo existe no índice, para não gerar requisição perdida; sem arquivo, quem chama usa o avatar.
import {MEDIA_INDEX} from './media-index.js';
const EA=new Set(MEDIA_INDEX.faces.ea),FIFA=new Set(MEDIA_INDEX.faces.fifa),BY_PLAYER=MEDIA_INDEX.faces.byPlayer||{},TEAMS=MEDIA_INDEX.teams||{};
/** Pasta `assets/` relativa à página: os três HTMLs ficam em /, /copa/ e /treinador/ (e o mesmo em dist/). */
export const assetBase=()=>typeof location!=='undefined'&&/\/(treinador|copa)\//.test(location.pathname||'')?'../assets/':'assets/';
const eaId=url=>{const m=/\/players\/(\d{1,3})\/(\d{3})\/\d+_\d+\.png/.exec(url||'');return m?Number(m[1]+m[2]):null};
const fifaId=url=>{const m=/\/transform\/([0-9a-f-]{36})\//.exec(url||'');return m?m[1]:null};
const urlOf=player=>typeof player?.photo==='string'?player.photo:player?.photo?.url||null;
/** Caminho (sem extensão) da foto local do atleta, na ordem: arquivo do próprio atleta, retrato da lista FIFA, rosto EA FC 26. */
export function faceFile(player){
 if(!player)return null;
 if(player.id&&BY_PLAYER[player.id])return BY_PLAYER[player.id];
 const url=urlOf(player),fifa=fifaId(url);if(fifa&&FIFA.has(fifa))return 'fifa/'+fifa;
 const ea=eaId(url)||(/^ea-(\d+)$/.test(player.id||'')?Number(player.id.slice(3)):null);if(ea&&EA.has(ea))return 'ea/'+ea;
 return null;
}
export const faceURL=player=>{const f=faceFile(player);return f?`${assetBase()}faces/${f}.webp`:null};
export const teamMedia=id=>TEAMS[id]||null;
export const badgeURL=id=>TEAMS[id]?.b?`${assetBase()}badges/${id}.webp`:null;
export const kitURL=id=>TEAMS[id]?.k?`${assetBase()}kits/${id}.webp`:null;
/** Uniforme principal reconhecido na imagem do uniforme: cores (#rrggbb) e padrão (solid|stripes|hoops|halves|sash|checks). */
export function kitOf(id,fallback='#8dcbb8'){
 const t=TEAMS[id],colors=t?.c?.length?t.c:t?.o?.length?t.o:[fallback];
 return {colors:[colors[0],colors[1]||colors[0]],pattern:t?.c?.length>1?t.p||'solid':'solid'};
}
export const mediaCounts=()=>({ea:EA.size,fifa:FIFA.size,byPlayer:Object.keys(BY_PLAYER).length,teams:Object.keys(TEAMS).length,badges:Object.values(TEAMS).filter(t=>t.b).length,kits:Object.values(TEAMS).filter(t=>t.k).length});
