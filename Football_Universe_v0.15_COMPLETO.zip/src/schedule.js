// Calendário de pontos corridos em ida e volta (circle method), usado pelo Manager.
export function validDate(value){
 if(typeof value!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(value))return false;
 const d=new Date(value+'T12:00:00Z');return Number.isFinite(d.valueOf())&&d.toISOString().slice(0,10)===value;
}
export const LEAGUE_COMPETITION='Brasileirão Série A (calendário gerado pelo simulador)';
// Calendário paramétrico de ida e volta, com descanso e todos os pares de clubes.
export function makeLeagueSchedule(clubIds,season,firstDate){
 if(clubIds.length<2||clubIds.length%2!==0||new Set(clubIds).size!==clubIds.length||!validDate(firstDate))throw Error('Liga requer número par de clubes únicos e data válida.');
 const rotations=[...clubIds],rounds=[],count=rotations.length;
 for(let round=0;round<count-1;round++){
  const pairs=[];
  for(let i=0;i<count/2;i++){
   const first=rotations[i],second=rotations[count-1-i];
   pairs.push((round+i)%2===0?[first,second]:[second,first]);
  }
  rounds.push(pairs);rotations.splice(1,0,rotations.pop());
 }
 const all=[];for(let leg=0;leg<2;leg++)for(let round=0;round<rounds.length;round++){
  const date=new Date(firstDate+'T12:00:00Z');date.setUTCDate(date.getUTCDate()+(leg*(count-1)+round)*7);const day=date.toISOString().slice(0,10);
  for(let game=0;game<rounds[round].length;game++){
   let [home,away]=rounds[round][game];if(leg){[home,away]=[away,home];}
   all.push({id:`s${season}-r${leg*(count-1)+round+1}-m${game+1}`,date:day,home,away,competition:LEAGUE_COMPETITION,status:'agendado'});
  }
 }
 return all;
}
