import { ATTRIBUTE_KEYS,ATTRIBUTE_GROUPS,CLUBS,SCHEMA_VERSION,createInitialWorld } from './data.js';
export const STORAGE_KEY='football-universe-v01';
export function clamp(v,min=0,max=100){return Math.max(min,Math.min(max,Number(v)||0));}
export function clubFor(world,id){return world.clubs.find(c=>c.id===id);}
export function playersFor(world,clubId){return world.players.filter(p=>p.clubId===clubId);}
export function scorePlayer(p){
 const keys=p.position==='GK'?['reflexes','handling','oneOnOnes','aerialReach','distribution','decisions','composure']:p.position==='ST'?['finishing','firstTouch','offBall','composure','acceleration','strength','decisions']:p.position==='CB'?['marking','tackling','heading','positioning','strength','anticipation','defensiveCover']:['firstTouch','shortPass','decisions','positioning','stamina','pace','teamwork'];
 return Math.round(keys.reduce((s,k)=>s+(p.attrs[k]||0),0)/keys.length);
}
export function playerPotential(p){return Math.min(99,scorePlayer(p)+Math.max(2,Math.round((29-(p.age??27))*.85))+Math.round(p.attrs.determination/30));}
export function scoutingVisible(world,p){return p.clubId===world.clubId||p.scoutDays>=21;}
export function scoutingRange(p,key){const v=p.attrs[key],span=Math.max(3,Math.round(22-p.scoutDays*.6));return `${Math.max(0,v-span)}–${Math.min(100,v+span)}`;}
export function formationSlots(formation){
 const formations={
 '4-2-3-1':[{p:'GK',x:50,y:89},{p:'RB',x:81,y:72},{p:'CB',x:62,y:76},{p:'CB',x:38,y:76},{p:'LB',x:19,y:72},{p:'DM',x:39,y:56},{p:'DM',x:61,y:56},{p:'RW',x:81,y:37},{p:'AM',x:50,y:40},{p:'LW',x:19,y:37},{p:'ST',x:50,y:17}],
 '4-3-3':[{p:'GK',x:50,y:89},{p:'RB',x:81,y:72},{p:'CB',x:62,y:76},{p:'CB',x:38,y:76},{p:'LB',x:19,y:72},{p:'DM',x:50,y:58},{p:'CM',x:33,y:49},{p:'CM',x:67,y:49},{p:'RW',x:79,y:28},{p:'LW',x:21,y:28},{p:'ST',x:50,y:16}],
 '3-5-2':[{p:'GK',x:50,y:89},{p:'CB',x:27,y:74},{p:'CB',x:50,y:78},{p:'CB',x:73,y:74},{p:'LB',x:15,y:53},{p:'RB',x:85,y:53},{p:'DM',x:50,y:58},{p:'CM',x:35,y:43},{p:'AM',x:65,y:43},{p:'ST',x:40,y:19},{p:'ST',x:60,y:19}]
 };return formations[formation]||formations['4-2-3-1'];
}
const fit=(p,position)=>p.position===position?1:p.secondaryPositions?.includes(position)?.82:((p.position==='DM'&&position==='CM')||(p.position==='CM'&&position==='DM')||(p.position==='AM'&&position==='CM')||(p.position==='RW'&&position==='RM')||(p.position==='LW'&&position==='LM')||(p.position==='RB'&&position==='LB')||(p.position==='LB'&&position==='RB'))?.7:.44;
export function lineup(world,clubId){
 const tactic=world.tactics[clubId],slots=formationSlots(tactic.formation),players=playersFor(world,clubId),used=new Set(),picked=Array(slots.length).fill(null);
 // Primeiro reservar trocas explícitas, para que o titular automático de outra posição não ocupe essa vaga.
 for(const [i] of slots.entries()){
  const target=tactic.overrides?.[i];const p=players.find(p=>p.id===target);
  if(p&&!used.has(p.id)){picked[i]=p;used.add(p.id);}
 }
 for(const [i,slot] of slots.entries()){
  if(picked[i])continue;
  const next=players.filter(p=>!used.has(p.id)).sort((a,b)=>(fit(b,slot.p)*scorePlayer(b)+b.condition*.06)-(fit(a,slot.p)*scorePlayer(a)+a.condition*.06))[0];
  if(next){picked[i]=next;used.add(next.id);}
 }
 return slots.map((slot,i)=>({...slot,player:picked[i],index:i,fit:picked[i]?Math.round(fit(picked[i],slot.p)*100):0}));
}
export function tacticalScore(world,clubId){const l=lineup(world,clubId),t=world.tactics[clubId];return Math.round(l.reduce((s,x)=>s+(x.player?scorePlayer(x.player)*x.fit/100:0),0)/11-(t.pressing>78?3:0));}
// Validação sem efeitos colaterais: rejeita corrupção antes de substituir um save.
const ID_RE=/^[a-z0-9-]+$/;
const VALID_POS=['GK','RB','LB','CB','DM','CM','AM','RW','LW','ST'];
const VALID_FOCUS=['Condicionamento','Técnica','Defesa','Ataque','Tática'];
const VALID_INTENSITY=['Leve','Moderada','Alta'];
const SCOUT_PRICE=30000;
export const SCOUT_COST=SCOUT_PRICE;
export {validDate} from './schedule.js';
import {validDate,makeLeagueSchedule} from './schedule.js';
export {makeLeagueSchedule};
const textOk=(v,max=180)=>typeof v==='string'&&v.trim().length>0&&v.length<=max;
const ratingOk=v=>Number.isInteger(v)&&v>=0&&v<=100;
const nonnegative=v=>Number.isFinite(v)&&v>=0;
export function validateWorld(world){
 if(!world||world.schemaVersion!==SCHEMA_VERSION||!Array.isArray(world.players)||!Array.isArray(world.clubs)||!world.tactics||!Array.isArray(world.fixtures))throw Error('Save incompatível ou incompleto.');
 if(world.clubs.length<2||world.clubs.length>1000||world.players.length>45000||world.fixtures.length>100000)throw Error('Dimensões do universo excedem os limites seguros.');
 if(!validDate(world.date)||!Number.isInteger(world.season)||world.season<1900||world.season>2300||!Number.isInteger(world.week)||world.week<0)throw Error('Data/temporada inválida.');
 if(!Array.isArray(world.news)||world.news.length>15000||!Array.isArray(world.favoriteIds)||!Array.isArray(world.scoutReports)||!Array.isArray(world.scoutAssignments)||!Array.isArray(world.log)||world.log.length>250000)throw Error('Registro do universo inválido.');
 if(!world.training||!VALID_FOCUS.includes(world.training.focus)||!VALID_INTENSITY.includes(world.training.intensity)||!ratingOk(world.scoutQuality)||!world.training.individual||typeof world.training.individual!=='object'||Array.isArray(world.training.individual))throw Error('Configuração de treino/scouting inválida.');
 if(!Array.isArray(world.seasonHistory)||world.seasonHistory.length>40)throw Error('Histórico de temporadas inválido.');
 const clubIds=new Set(),players=new Set(),fixtures=new Set(),calendar=new Set();
 for(const c of world.clubs){
  if(!textOk(c.id,70)||!ID_RE.test(c.id)||clubIds.has(c.id)||!textOk(c.name,120)||!textOk(c.short,12)||!Array.isArray(c.colors)||c.colors.length!==2||c.colors.some(v=>typeof v!=='string'||!/^#[0-9a-f]{6}$/i.test(v))||!nonnegative(c.budget)||!ratingOk(c.reputation)||!textOk(c.manager,100))throw Error('Clube inconsistente ou duplicado: '+String(c.id));
  clubIds.add(c.id);
 }
 if(!clubIds.has(world.clubId))throw Error('Clube do save inexistente.');
 for(const p of world.players){
  if(!textOk(p.id,90)||!ID_RE.test(p.id)||players.has(p.id)||!clubIds.has(p.clubId)||!textOk(p.name,120)||!VALID_POS.includes(p.position)||!Array.isArray(p.secondaryPositions)||p.secondaryPositions.some(pos=>!VALID_POS.includes(pos))||!(p.born===null||validDate(p.born))||!(p.contractEnd===null||validDate(p.contractEnd)))throw Error('Jogador ou referência inválida: '+String(p.id));
  if(!Number.isInteger(p.number)||p.number<1||p.number>99||!(p.age===null||(Number.isInteger(p.age)&&p.age>=15&&p.age<=60))||!(p.height===null||(Number.isInteger(p.height)&&p.height>=135&&p.height<=225))||!(p.weight===null||(Number.isInteger(p.weight)&&p.weight>=45&&p.weight<=150))||!nonnegative(p.value)||!nonnegative(p.wage)||!ratingOk(p.condition)||!ratingOk(p.morale)||!ratingOk(p.form)||!Number.isInteger(p.scoutDays)||p.scoutDays<0||p.scoutDays>21)throw Error('Dados do jogador fora dos limites.');
  if(!p.attrs||Object.keys(p.attrs).length!==ATTRIBUTE_KEYS.length||ATTRIBUTE_KEYS.some(k=>!ratingOk(p.attrs[k])))throw Error('Atributos inválidos em '+p.id);
  if(!p.stats||['appearances','goals','assists','rating'].some(k=>!nonnegative(Number(p.stats[k])))||!Array.isArray(p.history)||!Array.isArray(p.injuries)||!Array.isArray(p.transfers)||!Array.isArray(p.awards)||!Array.isArray(p.relations)||!Array.isArray(p.callups))throw Error('Histórico de jogador inválido.');
  players.add(p.id);
 }
 for(const [id,focus] of Object.entries(world.training.individual)){if(!players.has(id)||!VALID_FOCUS.includes(focus))throw Error('Treino individual inválido.');}
 const pastSeasons=new Set();for(const archive of world.seasonHistory){if(!Number.isInteger(archive.season)||archive.season>=world.season||pastSeasons.has(archive.season)||!clubIds.has(archive.championId)||!validDate(archive.dateFinished)||!Array.isArray(archive.fixtures)||!Array.isArray(archive.table)||archive.fixtures.some(f=>f.status!=='finalizado'))throw Error('Arquivo de temporada inválido.');pastSeasons.add(archive.season);}
 for(const c of world.clubs){
  const t=world.tactics[c.id];
  if(!t||!['4-2-3-1','4-3-3','3-5-2'].includes(t.formation)||!ratingOk(t.pressing)||!ratingOk(t.tempo)||!['Defensiva','Equilibrada','Ofensiva'].includes(t.mentality))throw Error('Tática inválida.');
  const used=new Set();for(const [slot,id] of Object.entries(t.overrides||{})){
   if(!/^\d+$/.test(slot)||Number(slot)>=11||used.has(id)||!world.players.some(p=>p.id===id&&p.clubId===c.id))throw Error('Escalação inválida para '+c.id);used.add(id);
  }
 }
 for(const f of world.fixtures){
  if(!textOk(f.id,75)||!ID_RE.test(f.id)||fixtures.has(f.id)||!clubIds.has(f.home)||!clubIds.has(f.away)||f.home===f.away||!validDate(f.date)||!textOk(f.competition,130)||!['agendado','finalizado'].includes(f.status))throw Error('Compromisso inválido ou duplicado: '+String(f.id));
  for(const cid of [f.home,f.away]){const key=f.date+':'+cid;if(calendar.has(key))throw Error('Clube escalado duas vezes no mesmo dia: '+cid);calendar.add(key);}
  if(f.status==='finalizado'&&(!Number.isInteger(f.homeGoals)||!Number.isInteger(f.awayGoals)||f.homeGoals<0||f.awayGoals<0||!Array.isArray(f.events)||!f.stats||f.events.filter(e=>e.type==='goal').length!==f.homeGoals+f.awayGoals))throw Error('Resultado incompleto.');
  if(f.participants){if(!Array.isArray(f.participants.home)||!Array.isArray(f.participants.away)||[...f.participants.home,...f.participants.away].some(id=>!players.has(id)))throw Error('Participantes inválidos na partida.');}
  fixtures.add(f.id);
 }
 for(const id of [...world.favoriteIds,...world.scoutAssignments])if(!players.has(id))throw Error('Referência inexistente a jogador: '+id);
 if(new Set(world.scoutAssignments).size!==world.scoutAssignments.length||world.scoutAssignments.length>3)throw Error('Fila de observação inválida.');
 for(const r of world.scoutReports)if(!players.has(r.playerId)||!validDate(r.date))throw Error('Relatório de scout inválido.');
 for(const n of world.news)if(!textOk(n.id,180)||!validDate(n.date)||!textOk(n.title,300)||!textOk(n.text,1500))throw Error('Notícia inválida.');
 return true;
}

// Liga fictícia: resultados vêm de ações/atributos individuais, não de um placar sorteado.
function rngFrom(seed){let h=2166136261;for(const ch of seed){h^=ch.charCodeAt(0);h=Math.imul(h,16777619);}return ()=>{h+=0x6D2B79F5;let t=h;t=Math.imul(t^(t>>>15),t|1);t^=t+Math.imul(t^(t>>>7),t|61);return ((t^(t>>>14))>>>0)/4294967296;};}
const mean=arr=>arr.reduce((sum,v)=>sum+v,0)/(arr.length||1);
const limit=(n,lo,hi)=>Math.max(lo,Math.min(hi,n));
export function simulateFixture(world,f){
 if(f.status==='finalizado')return f;
 if(!clubFor(world,f.home)||!clubFor(world,f.away))throw Error('Partida sem clubes válidos.');
 const rand=rngFrom(`${world.season}|${f.id}|${f.date}`);
 const sides=[f.home,f.away].map(id=>{
  const selected=lineup(world,id).map(slot=>slot.player).filter(Boolean);const tactic=world.tactics[id];
  const att=mean(selected.filter(p=>p.position!=='GK').map(p=>mean([p.attrs.finishing,p.attrs.offBall,p.attrs.firstTouch,p.form])));
  const def=mean(selected.map(p=>mean([p.attrs.marking,p.attrs.positioning,p.attrs.tackling,p.condition])));
  const morale=mean(selected.map(p=>p.morale));const stamina=mean(selected.map(p=>p.condition));
  const keeper=selected.find(p=>p.position==='GK');
  return {id,selected,tactic,att,def,morale,stamina,keeper,goals:0,shots:0,onTarget:0,xG:0};
 });
 const events=[];
 for(let i=0;i<2;i++){
  const side=sides[i],opp=sides[1-i];const pressing=(side.tactic.pressing-50)*.08;const tempo=(side.tactic.tempo-50)*.065;
  const mentality=side.tactic.mentality==='Ofensiva'?1.2:side.tactic.mentality==='Defensiva'?-1.5:0;
  const base=11.2+(side.att-opp.def)*.105+pressing+tempo+mentality+(i===0?1.3:-.8);
  const attempts=limit(Math.round(base+(rand()-.5)*5),4,22);
  for(let shot=0;shot<attempts;shot++){
   const candidates=side.selected.filter(p=>p.position!=='GK');
   const weights=candidates.map(p=>({p,w:(p.position==='ST'?5:p.position==='RW'||p.position==='LW'?3.2:p.position==='AM'?2.7:p.position==='CB'?0.65:1.4)*(p.attrs.offBall/70)}));
   let target=rand()*weights.reduce((a,b)=>a+b.w,0);let shooter=candidates[0];for(const x of weights){target-=x.w;if(target<=0){shooter=x.p;break;}}
   const keeper=opp.keeper?.attrs.reflexes||60;
   const shotXG=limit(.07+(shooter.attrs.finishing-55)*.0022+(shooter.attrs.offBall-55)*.0011+(side.att-opp.def)*.001+(side.morale-65)*.0005-(keeper-60)*.00055+(rand()-.5)*.10,.025,.38);
   side.shots++;side.xG+=shotXG;
   const onTarget=rand()<limit(.42+(shooter.attrs.technique-50)*.003, .24,.78);
   if(onTarget)side.onTarget++;
   // O acerto do alvo e a finalização efetiva são ambos necessários para o gol.
   const goal=onTarget&&rand()<limit(shotXG/(.42+(shooter.attrs.technique-50)*.003),.035,.72);
   if(goal){side.goals++;const helpers=side.selected.filter(p=>p.id!==shooter.id&&p.position!=='GK');const assister=rand()<.77?helpers[Math.floor(rand()*helpers.length)]:null;events.push({minute:Math.min(90,Math.floor(2+rand()*88)),type:'goal',clubId:side.id,playerId:shooter.id,assistId:assister?.id||null,description:`Gol de ${shooter.name}${assister?' (assistência de '+assister.name+')':''}`});}
  }
 }
 f.status='finalizado';f.homeGoals=sides[0].goals;f.awayGoals=sides[1].goals;
 f.stats={home:{shots:sides[0].shots,onTarget:sides[0].onTarget,xG:Number(sides[0].xG.toFixed(2))},away:{shots:sides[1].shots,onTarget:sides[1].onTarget,xG:Number(sides[1].xG.toFixed(2))}};
 f.events=events.sort((a,b)=>a.minute-b.minute);
 f.participants={home:sides[0].selected.map(p=>p.id),away:sides[1].selected.map(p=>p.id)};
 for(const side of sides){const outcome=side.goals>sides.find(s=>s!==side).goals?2:side.goals===sides.find(s=>s!==side).goals?0:-2;
  for(const p of side.selected){p.stats.appearances+=1;p.condition=clamp(p.condition-(3+Math.floor(rand()*6))-(side.tactic.pressing>75?2:0));p.morale=clamp(p.morale+outcome);p.form=clamp(p.form+outcome);}
 }
 for(const e of events){const shooter=world.players.find(p=>p.id===e.playerId);shooter.stats.goals+=1;if(e.assistId)world.players.find(p=>p.id===e.assistId).stats.assists+=1;}
 const title=`${clubFor(world,f.home).short} ${f.homeGoals} × ${f.awayGoals} ${clubFor(world,f.away).short}`;
 world.news.unshift({id:`match-${f.id}`,date:f.date,type:'partida',title,text:`${f.competition}. ${f.stats.home.shots} a ${f.stats.away.shots} finalizações; ${events.length} gols registrados com autoria.`});
 world.log.unshift({date:f.date,type:'partida',detail:`${title} · ${f.events.length} eventos de gol; origem: motor demonstrativo.`});
 return f;
}
export function standings(world){
 const rows=new Map(world.clubs.map(c=>[c.id,{clubId:c.id,points:0,played:0,won:0,drawn:0,lost:0,gf:0,ga:0,gd:0}]));
 for(const f of world.fixtures.filter(f=>f.status==='finalizado')){
  const h=rows.get(f.home),a=rows.get(f.away);if(!h||!a)continue;h.played++;a.played++;h.gf+=f.homeGoals;h.ga+=f.awayGoals;a.gf+=f.awayGoals;a.ga+=f.homeGoals;
  if(f.homeGoals>f.awayGoals){h.won++;h.points+=3;a.lost++;}else if(f.homeGoals<f.awayGoals){a.won++;a.points+=3;h.lost++;}else{h.drawn++;a.drawn++;h.points++;a.points++;}
 }
 return [...rows.values()].map(r=>({...r,gd:r.gf-r.ga})).sort((a,b)=>b.points-a.points||b.gd-a.gd||b.gf-a.gf||a.clubId.localeCompare(b.clubId));
}

export function completeSeason(world){
 if(world.fixtures.length===0||world.fixtures.some(f=>f.status!=='finalizado'))throw Error('Encerre todas as partidas antes de concluir a temporada.');
 if(world.seasonHistory.some(a=>a.season===world.season))throw Error('Temporada já arquivada.');
 const matchesExpected=world.clubs.length*(world.clubs.length-1);
 const pairSet=new Set(world.fixtures.map(f=>`${f.home}:${f.away}`));
 if(world.fixtures.length!==matchesExpected||pairSet.size!==matchesExpected)throw Error('A temporada exige ida e volta completos antes do encerramento.');
 const original=world;world=structuredClone(world);
 const table=standings(world);const winner=table[0].clubId;const season=world.season;
 const goals=new Map();const stats=new Map();for(const fixture of world.fixtures){for(const [side,clubId] of [['home',fixture.home],['away',fixture.away]]){
  for(const id of fixture.participants?.[side]||[]){const a=stats.get(id)||{games:0,goals:0,assists:0};a.games++;stats.set(id,a);}
 }for(const e of fixture.events||[]){if(e.type!=='goal')continue;goals.set(e.playerId,(goals.get(e.playerId)||0)+1);if(e.playerId&&stats.has(e.playerId))stats.get(e.playerId).goals++;if(e.assistId&&stats.has(e.assistId))stats.get(e.assistId).assists++;}}
 const leaders=[...goals.entries()].sort((a,b)=>b[1]-a[1]).slice(0,5).map(([playerId,goals])=>({playerId,goals}));
 // O arquivo guarda placar e gols (sem estatísticas de finalização, escalações e texto), para a temporada de 380 jogos caber no save.
 const archived=world.fixtures.map(f=>({id:f.id,date:f.date,home:f.home,away:f.away,competition:f.competition,status:f.status,homeGoals:f.homeGoals,awayGoals:f.awayGoals,events:(f.events||[]).filter(e=>e.type==='goal').map(e=>({minute:e.minute,type:e.type,clubId:e.clubId,playerId:e.playerId,assistId:e.assistId}))}));
 world.seasonHistory.push({season,championId:winner,dateFinished:world.date,table:structuredClone(table),fixtures:archived,leaders});
 for(const p of world.players){const st=stats.get(p.id)||{games:0,goals:0,assists:0};p.history.unshift({year:season,club:clubFor(world,p.clubId).name,appearances:st.games,goals:st.goals,assists:st.assists});if(p.age!==null)p.age+=1;p.morale=clamp(p.morale+(p.clubId===winner?5:0));}
 const next=season+1;let start=`${next}-01-09`;if(start<=world.date){const day=new Date(world.date+'T12:00:00Z');day.setUTCDate(day.getUTCDate()+14);start=day.toISOString().slice(0,10);}
 world.season=next;world.date=start;world.week=0;world.fixtures=makeLeagueSchedule(world.clubs.map(c=>c.id),next,start);
 world.news.unshift({id:`season-${season}-champion`,date:world.date,type:'temporada',title:`${clubFor(world,winner).name} conquista a liga ${season}`,text:`Campanha de ${table[0].points} pontos em ${table[0].played} jogos. A temporada ${next} começou com nova tabela e histórico preservado.`});
 world.log.unshift({date:world.date,type:'temporada',detail:`Temporada ${season} concluída; campeão ${clubFor(world,winner).short}; início de ${next}.`});
 validateWorld(world);Object.assign(original,world);return winner;
}
export function cancelObservation(world,playerId){
 const index=world.scoutAssignments.indexOf(playerId);if(index<0)throw Error('Observação não está ativa.');
 world.scoutAssignments.splice(index,1);world.log.unshift({date:world.date,type:'scouting',detail:`Observação de ${world.players.find(p=>p.id===playerId).name} cancelada, sem reembolso.`});
 return true;
}
export function setIndividualTraining(world,playerId,focus){
 const player=world.players.find(p=>p.id===playerId&&p.clubId===world.clubId);if(!player)throw Error('Treino individual disponível apenas para o próprio clube.');
 if(focus!=='Padrão'&&!VALID_FOCUS.includes(focus))throw Error('Foco individual inválido.');
 if(focus==='Padrão')delete world.training.individual[playerId];else world.training.individual[playerId]=focus;
 world.log.unshift({date:world.date,type:'treino',detail:`${player.name}: treino ${focus}.`});return player;
}
export function rescheduleFixture(world,id,newDate){
 const f=world.fixtures.find(f=>f.id===id);if(!f||f.status!=='agendado')throw Error('Só é possível reagendar jogos futuros.');
 if(!validDate(newDate)||newDate<world.date)throw Error('Data inválida ou anterior ao calendário atual.');
 const copy=structuredClone(world);copy.fixtures.find(x=>x.id===id).date=newDate;
 validateWorld(copy);f.date=newDate;world.log.unshift({date:world.date,type:'calendário',detail:`Jogo ${id} reagendado para ${newDate}.`});return f;
}

export function updatePlayerIdentity(world,id,changes){
 const p=world.players.find(p=>p.id===id);if(!p)throw Error('Atleta inexistente.');
 const allowed=['name','number','wage','value','contractEnd','position'];const clone=structuredClone(world);const target=clone.players.find(x=>x.id===id);
 for(const [key,val] of Object.entries(changes)){if(!allowed.includes(key))throw Error('Campo de atleta não editável.');target[key]=key==='number'||key==='wage'||key==='value'?Number(val):key==='contractEnd'&&!val?null:String(val).trim();}
 validateWorld(clone);Object.assign(p,Object.fromEntries(allowed.filter(k=>k in changes).map(k=>[k,target[k]])));
 world.log.unshift({date:world.date,type:'editor',detail:`Ficha de ${p.name} editada: ${Object.keys(changes).join(', ')}`});return p;
}
export function updateClub(world,id,changes){
 const c=clubFor(world,id);if(!c)throw Error('Clube inexistente.');const allowed=['name','manager','budget','philosophy'];const clone=structuredClone(world),target=clubFor(clone,id);
 for(const [k,v] of Object.entries(changes)){if(!allowed.includes(k))throw Error('Campo de clube não editável.');target[k]=k==='budget'?Number(v):String(v).trim();}
 validateWorld(clone);Object.assign(c,Object.fromEntries(allowed.filter(k=>k in changes).map(k=>[k,target[k]])));
 world.log.unshift({date:world.date,type:'editor',detail:`Clube ${c.short} editado: ${Object.keys(changes).join(', ')}`});return c;
}
export function mutateAttribute(world,id,key,value){
 if(!ATTRIBUTE_KEYS.includes(key)||!Number.isInteger(Number(value))||Number(value)<0||Number(value)>100)throw Error('Atributo deve ser inteiro entre 0 e 100.');
 const p=world.players.find(x=>x.id===id);if(!p)throw Error('Jogador não encontrado.');
 const before=p.attrs[key];p.attrs[key]=Number(value);p.overall=scorePlayer(p);world.log.unshift({date:world.date,type:'editor',detail:`${p.name}: ${key} ${before} → ${value}`});return p;
}
export function observe(world,playerId){
 const p=world.players.find(p=>p.id===playerId);if(!p)throw Error('Jogador não encontrado.');
 if(p.clubId===world.clubId)throw Error('Você já conhece este atleta.');
 if(p.scoutDays>=21)throw Error('Observação já concluída.');
 if(world.scoutAssignments.length>=3&&!world.scoutAssignments.includes(playerId))throw Error('Capacidade de scouting ocupada: até 3 observações simultâneas.');
 world.scoutAssignments ||= [];
 if(world.scoutAssignments.includes(playerId))return 'Em andamento';
 const club=clubFor(world,world.clubId);if(club.budget<SCOUT_PRICE)throw Error('Orçamento insuficiente para a observação.');
 club.budget-=SCOUT_PRICE;world.scoutAssignments.push(playerId);
 world.log.unshift({date:world.date,type:'scouting',detail:`Observação de ${p.name}: custo R$ ${SCOUT_PRICE}.`});
 world.news.unshift({id:`scout-start-${playerId}-${world.date}`,date:world.date,type:'scouting',title:`Observação de ${p.name} iniciada`,text:`Investimento de R$ ${SCOUT_PRICE} confirmado. Conhecimento progride conforme a qualidade da equipe. Observações canceladas não são reembolsadas.`});
 return 'Iniciada';
}
export function advanceWeek(world){
 const oldDate=world.date;world.week=(world.week||0)+1;const d=new Date(`${world.date}T12:00:00Z`);d.setUTCDate(d.getUTCDate()+7);world.date=d.toISOString().slice(0,10);
 // Datas vencidas devem produzir resultados uma única vez, preservando a causalidade da simulação.
 const due=world.fixtures.filter(f=>f.status==='agendado'&&f.date<=world.date).sort((a,b)=>a.date.localeCompare(b.date)||a.id.localeCompare(b.id));
 for(const fixture of due)simulateFixture(world,fixture);
 const attrFor={Condicionamento:'stamina',Técnica:'firstTouch',Defesa:'marking',Ataque:'finishing',Tática:'positioning'};
 const focus=world.training?.focus||'Condicionamento',intensity=world.training?.intensity||'Moderada';
 const recovery=intensity==='Leve'?13:intensity==='Alta'?5:9;
 const weight=intensity==='Alta'?3:intensity==='Leve'?1:2;
 let improved=0;
 for(const p of world.players){
  // Apenas o treino do clube controlado é configurável; os outros clubes usam rotina equilibrada.
  const own=p.clubId===world.clubId;
  const t=world.tactics[p.clubId];const adjustment=t.pressing>75?3:0;
  p.condition=clamp(p.condition+(own?recovery:9)-adjustment-(own&&intensity==='Alta'?4:0));
  const individual=own?world.training.individual?.[p.id]:undefined;
  const attr=own?attrFor[individual||focus]:'stamina';
  if((world.week+parseInt(p.id.match(/\d+$/)?.[0]||'0',10))%Math.max(2,5-weight)===0&&(p.age??27)<=29&&p.attrs.professionalism>=50&&p.condition>=58){
   p.attrs[attr]=clamp(p.attrs[attr]+1);p.overall=scorePlayer(p);improved++;
  }
 }
 const completed=[];
 for(const playerId of world.scoutAssignments){const p=world.players.find(p=>p.id===playerId);if(!p){completed.push(playerId);continue;}
  const gain=world.scoutQuality>=85?9:world.scoutQuality>=60?7:5;
  p.scoutDays=clamp(p.scoutDays+gain,0,21);
  world.scoutReports.unshift({playerId:p.id,date:world.date,days:p.scoutDays,confidence:p.scoutDays>=21?'completo':'parcial',quality:world.scoutQuality});
  if(p.scoutDays>=21){completed.push(playerId);world.news.unshift({id:`scout-finish-${playerId}-${world.date}`,date:world.date,type:'scouting',title:`Observação de ${p.name} concluída`,text:`Conhecimento consolidado após ${p.scoutDays} dias de análise.`});}
 }
 world.scoutAssignments=world.scoutAssignments.filter(id=>!completed.includes(id));
 world.news.unshift({id:`week-${world.season}-${world.week}`,date:world.date,type:'treino',title:`Semana ${world.week}: ${improved} evoluções, ${due.length} partidas`,text:`Treino ${focus.toLowerCase()} (${intensity.toLowerCase()}); ${due.length} confrontos fictícios resolvidos pelo motor demonstrativo, ${improved} melhorias de atributo.`});
 world.log.unshift({date:world.date,type:'calendário',detail:`${oldDate} → ${world.date}: ${due.length} partidas, ${improved} melhorias. Foco: ${focus}.`});
 // Com 380 jogos por temporada, só o histórico recente de notícias e registros fica no save.
 if(world.news.length>500)world.news.length=500;if(world.log.length>800)world.log.length=800;
 return world.date;
}
export function readSlots(){try{const raw=JSON.parse(localStorage.getItem(STORAGE_KEY)||'{}');return raw&&typeof raw==='object'?raw:{}}catch{return {}}}
// Nos slots, os 70 atributos de cada atleta vão como lista na ordem de ATTRIBUTE_KEYS: com ~670 atletas o save cai de ~1,5 MB para ~1 MB (a cota do navegador é de ~5 MB).
export function packWorld(world){const copy=structuredClone(world);copy.players=copy.players.map(p=>({...p,attrs:ATTRIBUTE_KEYS.map(k=>p.attrs[k])}));copy.packedAttrs=true;return copy;}
export function unpackWorld(world){if(!world?.packedAttrs)return world;const copy=structuredClone(world);delete copy.packedAttrs;copy.players=copy.players.map(p=>Array.isArray(p.attrs)?{...p,attrs:Object.fromEntries(ATTRIBUTE_KEYS.map((k,i)=>[k,p.attrs[i]]))}:p);return copy;}
export function saveSlot(slot,world){validateWorld(world);const all=readSlots();all[slot]={savedAt:new Date().toISOString(),world:packWorld(world)};localStorage.setItem(STORAGE_KEY,JSON.stringify(all));return all[slot];}
export function loadSlot(slot){const rec=readSlots()[slot];if(!rec)throw Error('Slot vazio.');return migrateWorld(unpackWorld(rec.world));}
export function migrateWorld(payload){
 if(!payload||typeof payload!=='object')throw Error('Backup inválido.');
 if(payload.schemaVersion===SCHEMA_VERSION){validateWorld(payload);return structuredClone(payload);}
 if(![1,2].includes(payload.schemaVersion))throw Error('Versão de save incompatível.');
 const v=structuredClone(payload),previous=v.schemaVersion;v.schemaVersion=SCHEMA_VERSION;
 if(previous===1){v.training={focus:'Condicionamento',intensity:'Moderada'};v.scoutQuality=72;}
 v.training.individual={...(v.training.individual||{})};v.seasonHistory=[];
 // A v0.2 possuía somente o turno; adicionamos o returno agendado, sem fabricar placares.
 if(v.fixtures.length===v.clubs.length*(v.clubs.length-1)/2){
  const originals=[...v.fixtures].sort((a,b)=>a.date.localeCompare(b.date));
  const days=[...new Set(originals.map(f=>f.date))];
  const last=originals.at(-1).date;const anchor=last>v.date?last:v.date;
  for(let i=0;i<days.length;i++){const d=new Date(anchor+'T12:00:00Z');d.setUTCDate(d.getUTCDate()+(i+1)*7);const day=d.toISOString().slice(0,10);
   const matches=originals.filter(f=>f.date===days[i]);for(let j=0;j<matches.length;j++){const f=matches[j];v.fixtures.push({id:`s${v.season}-return-${i+1}-${j+1}`,date:day,home:f.away,away:f.home,competition:f.competition,status:'agendado'});}
  }
 }
 // Preserva os placares anteriores; novos jogos ficam explicitamente agendados.
 validateWorld(v);return v;
}
export function createWorld(){return createInitialWorld();}
export const SCHEMA_SUMMARY={version:SCHEMA_VERSION,attributes:ATTRIBUTE_KEYS.length,groups:ATTRIBUTE_GROUPS.length,clubs:CLUBS.length};
