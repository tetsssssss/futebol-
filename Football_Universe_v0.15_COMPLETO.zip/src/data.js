/** Football Universe v0.4: identidades reais verificadas; atributos esportivos provisórios e simulados. */
export const SCHEMA_VERSION = 3;

export {ATTRIBUTE_GROUPS,ATTRIBUTE_KEYS,ATTRIBUTE_LABELS} from './attributes.js';
import {ATTRIBUTE_GROUPS,ATTRIBUTE_KEYS} from './attributes.js';

import {LEAGUE_CLUBS,LEAGUE_PLAYERS} from './league-data.js';
import {makeLeagueSchedule} from './schedule.js';
export const CLUBS=LEAGUE_CLUBS.map(({id,name,short,city,region,colors,budget,reputation,manager,ground,verifiedRosterSource})=>({id,name,short,city,region,colors,budget,philosophy:'A definir pelo treinador',reputation,manager,ground,verifiedRosterSource}));
const BASIS_TEXT={ea:'Avaliação real do EA/FIFA (edição {ed}) evoluída até 2026 pela idade e combinada com o valor de mercado atual.',est:'Sem avaliação real publicada: estimada pelo valor de mercado atual (Transfermarkt), posição e idade.'};
function makePlayer(row){
 const [id,clubId,name,number,provisional,position,born,age,nationality,height,foot,contractEnd,value,overall,basis,edition,tm,vals]=row;
 const club=LEAGUE_CLUBS.find(c=>c.id===clubId),attrs=Object.fromEntries(ATTRIBUTE_KEYS.map((k,i)=>[k,vals[i]]));
 return {id,name,clubId,number,numberProvisional:Boolean(provisional),position,secondaryPositions:[],nationality,born,age,height,weight:null,foot,contractEnd,value,wage:0,condition:95,morale:70,form:70,overall,attrs,scoutDays:clubId==='flamengo'?21:0,
  profile:`Atleta do elenco de 2026 (Transfermarkt). ${BASIS_TEXT[basis].replace('{ed}',String(2000+Number(edition)))} Os atributos comportamentais são estimativas do simulador.`,
  stats:{appearances:0,goals:0,assists:0,rating:'0'},history:[],injuries:[],relations:[],awards:[],callups:[],transfers:[],faceAsset:null,photo:null,
  dataProvenance:{identity:'verified',rosterSource:club.verifiedRosterSource,abilities:basis==='ea'?'ea-fifa-evoluido':'estimado-valor-de-mercado',bio:'transfermarkt',salary:'unverified',number:provisional?'provisional':'verified',photo:'transfermarkt',transfermarkt:tm}};
}
export const INITIAL_PLAYERS=LEAGUE_PLAYERS.map(makePlayer);
export const INITIAL_FIXTURES=makeLeagueSchedule(CLUBS.map(c=>c.id),2026,'2026-10-10');
const LABEL_POSITIONS={GK:'Goleiro',RB:'Lateral direito',LB:'Lateral esquerdo',CB:'Zagueiro',DM:'Volante',CM:'Meio-campista',AM:'Meia ofensivo',RW:'Ponta direita',LW:'Ponta esquerda',ST:'Centroavante'};
export const POSITION_LABELS=LABEL_POSITIONS;
export function createInitialWorld(){
 return {schemaVersion:SCHEMA_VERSION,mode:'real-2026-snapshot',date:'2026-10-09',season:2026,clubId:'flamengo',players:structuredClone(INITIAL_PLAYERS),clubs:structuredClone(CLUBS),fixtures:structuredClone(INITIAL_FIXTURES),scoutReports:[],scoutAssignments:[],scoutQuality:72,training:{focus:'Condicionamento',intensity:'Moderada',individual:{}},seasonHistory:[],favoriteIds:[],tactics:Object.fromEntries(CLUBS.map(c=>[c.id,{formation:'4-2-3-1',pressing:56,tempo:53,mentality:'Equilibrada',overrides:{}}])),news:[{id:'welcome',date:'2026-10-09',type:'sistema',title:'Bem-vindo ao Football Universe',text:'Elencos reais de 2026 importados de fontes oficiais. Atributos esportivos e partidas ainda são simulações experimentais.'}],log:[],week:0};
}
