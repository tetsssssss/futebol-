// Catálogo dos ~70 atributos. Separado de data.js para as ferramentas de dados não dependerem dos elencos gerados.
export const ATTRIBUTE_GROUPS = [
  {id:'technical',label:'Técnicos',entries:[['firstTouch','Primeiro toque'],['shortPass','Passe curto'],['longPass','Passe longo'],['finishing','Finalização'],['dribbling','Drible'],['crossing','Cruzamento'],['heading','Cabeceio'],['tackling','Desarme'],['marking','Marcação'],['technique','Técnica'],['ballControl','Controle de bola'],['volleys','Voleio'],['weakFoot','Pé não dominante']]},
  {id:'physical',label:'Físicos',entries:[['pace','Velocidade'],['acceleration','Arranque'],['agility','Agilidade'],['balance','Equilíbrio'],['strength','Força'],['stamina','Resistência'],['jumping','Impulsão'],['coordination','Coordenação'],['naturalFitness','Condição natural']]},
  {id:'mental',label:'Mentais',entries:[['decisions','Decisões'],['anticipation','Antecipação'],['composure','Frieza'],['concentration','Concentração'],['vision','Visão de jogo'],['offBall','Movimentação'],['workRate','Dedicação'],['bravery','Coragem'],['determination','Determinação'],['leadership','Liderança']]},
  {id:'tactical',label:'Táticos',entries:[['positioning','Posicionamento'],['pressing','Pressão'],['transition','Transições'],['compactness','Compactação'],['spaceReading','Leitura de espaços'],['overlapping','Ultrapassagem'],['defensiveCover','Cobertura'],['tempoControl','Controle de ritmo'],['roleDiscipline','Disciplina de função']]},
  {id:'behavioral',label:'Comportamentais',entries:[['ambition','Ambição'],['professionalism','Profissionalismo'],['discipline','Disciplina'],['loyalty','Lealdade'],['temperament','Temperamento'],['teamwork','Cooperação'],['competitive','Competitividade']]},
  {id:'goalkeeper',label:'Goleiro',entries:[['reflexes','Reflexos'],['handling','Segurança'],['oneOnOnes','Um contra um'],['aerialReach','Alcance aéreo'],['command','Comando da área'],['distribution','Reposição'],['kicking','Chute longo']]},
  {id:'setpieces',label:'Bola parada',entries:[['freeKicks','Faltas'],['penalties','Pênaltis'],['corners','Escanteios'],['longThrows','Laterais longos']]},
  {id:'relationships',label:'Relacionamento',entries:[['charisma','Carisma'],['lockerRoom','Influência no grupo'],['coachTrust','Confiança do técnico']]},
  {id:'adaptation',label:'Adaptabilidade',entries:[['language','Idiomas'],['adaptability','Adaptação'],['cultural','Adaptação cultural']]},
  {id:'reputation',label:'Reputação',entries:[['domestic','Nacional'],['international','Internacional']]},
  {id:'condition',label:'Lesão / condição',entries:[['injuryResistance','Resistência a lesões'],['consistency','Regularidade'],['pressureHandling','Reação à pressão']]}
];
export const ATTRIBUTE_KEYS = ATTRIBUTE_GROUPS.flatMap(g=>g.entries.map(e=>e[0]));
export const ATTRIBUTE_LABELS = Object.fromEntries(ATTRIBUTE_GROUPS.flatMap(g=>g.entries));
