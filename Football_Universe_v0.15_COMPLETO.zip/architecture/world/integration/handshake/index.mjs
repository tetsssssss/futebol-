/** No connector to Claude is assumed. This manifest is a contract for future integration. */
export function buildHandoff({plan,baseline,packageVersion='0.2.0'}={}){
  if(!plan?.ok || plan?.mode!=='DRY_RUN_ONLY'||!baseline?.sha256)throw new Error('Plan and immutable baseline fingerprint required');
  return {format:'football-universe-handoff-v1',packageVersion,createdAt:new Date().toISOString(),
    baseFingerprint:baseline.sha256,mode:'REVIEW_ONLY',autoApply:false,
    summary:plan.summary,issues:[...(plan.warnings??[]),...(plan.referenceAudit?.issues??[])],
    aliasMap:plan.aliases??{},
    gates:{claudeSourceAudited:false,saveBackupVerified:false,conflictsReviewed:plan.summary.CONFLITO===0,gameRegressionPassed:false,androidPassed:false},
    instructions:'Require actual Claude source, reviewed mapping, backups and game regression. Never apply this file directly to saved careers.'};
}
export function evaluateHandoffGates(handoff){
  const blockers=Object.entries(handoff?.gates??{}).filter(([,passed])=>passed!==true).map(([key])=>key);
  if(handoff?.autoApply!==false)blockers.push('autoApply-must-be-false');
  if(handoff?.mode!=='REVIEW_ONLY')blockers.push('mode-must-be-review-only');
  return {readyForHumanReview:!!handoff?.baseFingerprint,automaticMergeAllowed:false,blockers};
}
