export function checkCompatibility({current,legacyIndex}) {
  const issues=[];
  if (!current || !Array.isArray(current.clubs) || !Array.isArray(current.players)) issues.push('Código atual não contém arrays reconhecíveis de clubes e jogadores');
  if (legacyIndex?.source?.apkVersion!=='v0.15') issues.push('Índice do APK sem versão legível');
  const currentIds=new Set(current?.clubs?.map(x=>x.id)??[]);
  const overlaps=(legacyIndex?.clubs??[]).filter(x=>currentIds.has(x.id)).length;
  return {compatibleForPlanning:issues.length===0,compatibleForAutomaticMerge:false,legacyClubsMatching:overlaps,issues,saveMigrationRequired:'a determinar após auditoria do código atual'};
}
