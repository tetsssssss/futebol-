import {createHash} from 'node:crypto';
import {readFile,stat} from 'node:fs/promises';
function normalize(value) {
  if(Array.isArray(value))return value.map(normalize);
  if(value && typeof value==='object')return Object.fromEntries(Object.keys(value).sort().map(k=>[k,normalize(value[k])]));
  if(typeof value==='number' && !Number.isFinite(value))throw new Error('Invalid numeric snapshot value');
  return value;
}
export function sha256(value) {return createHash('sha256').update(value).digest('hex');}
export function snapshotObject(value,{label='snapshot'}={}){
  if(!value || typeof value!=='object')throw new Error('Object snapshot required');
  const normalized=JSON.stringify(normalize(value));
  return {label,sha256:sha256(normalized),bytes:Buffer.byteLength(normalized),entityCounts:{clubs:value.clubs?.length??null,players:value.players?.length??null,competitions:value.competitions?.length??null},readOnly:true};
}
export function compareSnapshots(before,after){
  if(!before?.sha256||!after?.sha256)throw new Error('Snapshot hashes required');
  return {unchanged:before.sha256===after.sha256,beforeSha256:before.sha256,afterSha256:after.sha256};
}
export async function snapshotFile(path){
  const s=await stat(path);if(!s.isFile())throw new Error('File required');
  const bytes=await readFile(path);
  return {path,bytes:bytes.length,sha256:sha256(bytes),readOnly:true};
}
