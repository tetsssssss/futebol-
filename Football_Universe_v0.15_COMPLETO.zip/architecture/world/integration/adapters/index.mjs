/** Base Claude: leitura, nunca escrita em save. Preserva todos os campos nativos. */
export function inspectCurrentWorld(input){
  if(input===null||typeof input!=='object'||Array.isArray(input))throw new Error('Universo inválido');
  const clubs=input.clubs??input.teams;
  const players=input.players;
  const hasRecords=Array.isArray(clubs)&&Array.isArray(players);
  return {hasRecords,version:input.schemaVersion??input.version??null,clubs:hasRecords?clubs.length:null,players:hasRecords?players.length:null,collections:Object.keys(input).sort(),safeToWrite:false,warning:'É necessária inspeção da versão atual do Claude e backup antes de aplicar migrações.'};
}
export function mapLegacyClub(c,season=2026){
  return {id:c.id,name:c.name,shortName:c.short,city:c.city,region:c.region,country:'BRA',season,stadium:c.ground??null,budget:c.budget??null,reputation:c.reputation??null,externalIds:c.tm?{transfermarkt:String(c.tm)}:{},provenance:{source:'APK v0.15 2026-10-14 (somente referência)',retrievedAt:'2026-10-14',season:String(season)}};
}
export function mapLegacyPlayer(row,season=2026){
  const [id,clubId,name,number,,position,born,,nationality,,,,,overall,,,,tm]=row;
  const country={Brasil:'BRA','Argentina':'ARG','Colômbia':'COL','Uruguai':'URY','Paraguai':'PRY','Chile':'CHL','Equador':'ECU','Bolívia':'BOL','Venezuela':'VEN','Peru':'PER','Portugal':'PRT','Espanha':'ESP'};
  return {id,clubId,name,number,position,born,nationality:country[nationality]??'UNK',overall,season,externalIds:tm?{transfermarkt:String(tm)}:{},provenance:{source:'APK v0.15 2026-10-14 (somente referência)',retrievedAt:'2026-10-14',season:String(season)}};
}
