import {readFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {dirname,resolve} from 'node:path';
import {snapshotObject} from '../snapshots/index.mjs';
import {validateWorldSnapshot} from '../../core/validation/index.mjs';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'../../../../');
const nationalityCodes={'Brasil':'BRA','Colômbia':'COL','Argentina':'ARG','Equador':'ECU','Guinea':'GIN','Uruguai':'URY','Espanha':'ESP','Venezuela':'VEN','Angola':'AGO','Marrocos':'MAR','Panamá':'PAN','DR Congo':'COD','Peru':'PER','Inglaterra':'ENG','Países Baixos':'NED','Portugal':'POR','Paraguai':'PAR','Chile':'CHI','Itália':'ITA','México':'MEX','Croácia':'CRO','Ghana':'GHA','Cabo Verde':'CPV','Denmark':'DEN','Sweden':'SWE','Cameroon':'CMR','Bolívia':'BOL'};
const provenance=(source,season)=>({source,retrievedAt:'2026-10-14',season:String(season)});
export async function snapshotV015({projectRoot=root}={}){
 const raw=JSON.parse(await readFile(resolve(projectRoot,'data/brasileirao-2026.json'),'utf8'));
 const keys=raw.keys;
 const clubs=raw.clubs.map(c=>({id:c.id,name:c.name,country:'BRA',season:2026,city:c.city,region:c.region,shortName:c.short,stadium:c.ground,playerIds:raw.players.filter(p=>p.clubId===c.id).map(p=>p.id),externalIds:Number.isInteger(c.tm)?{transfermarkt:c.tm}:{},provenance:provenance('data/brasileirao-2026.json',2026)}));
 const players=raw.players.map(p=>{
  const nationality=nationalityCodes[p.nationality];
  if(!nationality)throw new Error(`Unsupported v0.15 nationality: ${p.nationality}`);
  if(!Array.isArray(p.attrs)||p.attrs.length!==70)throw new Error(`Invalid 70-attribute vector for ${p.id}`);
  return {id:p.id,name:p.name,clubId:p.clubId,nationality,born:p.born??null,position:p.position,season:2026,attributes:Object.fromEntries(keys.map((k,i)=>[k,p.attrs[i]])),overall:p.overall,photo:p.img?{path:p.img,source:'v0.15-catalog'}:undefined,externalIds:p.tm?{transfermarkt:p.tm}:undefined,provenance:provenance('data/brasileirao-2026.json',2026)};
 });
 const snapshot={schemaVersion:'1.0.0',clubs,players,competitions:[{id:'brasileirao-serie-a-2026',name:'Campeonato Brasileiro Série A',season:2026,format:'round_robin',participantIds:clubs.map(c=>c.id),provenance:provenance('data/brasileirao-2026.json',2026)}]};
 const report=validateWorldSnapshot(snapshot);if(!report.valid)throw new Error(`Invalid adapted v0.15 snapshot: ${JSON.stringify(report.errors.slice(0,5))}`);
 return snapshot;
}
export function hashSnapshot(snapshot){return snapshotObject(snapshot,{label:'v0.15-public-catalog'}).sha256;}
