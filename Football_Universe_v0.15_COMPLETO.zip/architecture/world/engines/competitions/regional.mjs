import {roundRobin} from '../calendar/index.mjs';
import {REGIONAL_EDITION_VERIFICATION} from './edition-verification-2026.mjs';
export {REGIONAL_EDITION_VERIFICATION};

/** Diretório estrutural, sem clubes/elencos ou regulamentos oficiais presumidos. */
export const REGIONAL_COUNTRIES=Object.freeze([
 {id:'ARG',name:'Argentina',region:'south-america',competitionId:'argentina-primera-division',competitionName:'Primera División'},
 {id:'BOL',name:'Bolívia',region:'south-america',competitionId:'bolivia-primera-division',competitionName:'División Profesional'},
 {id:'CHI',name:'Chile',region:'south-america',competitionId:'chile-primera-division',competitionName:'Primera División'},
 {id:'COL',name:'Colômbia',region:'south-america',competitionId:'colombia-primera-division',competitionName:'Categoría Primera A'},
 {id:'ECU',name:'Equador',region:'south-america',competitionId:'ecuador-primera-division',competitionName:'Liga Pro Serie A'},
 {id:'PAR',name:'Paraguai',region:'south-america',competitionId:'paraguay-primera-division',competitionName:'Primera División'},
 {id:'PER',name:'Peru',region:'south-america',competitionId:'peru-primera-division',competitionName:'Liga 1'},
 {id:'URU',name:'Uruguai',region:'south-america',competitionId:'uruguay-primera-division',competitionName:'Primera División'},
 {id:'VEN',name:'Venezuela',region:'south-america',competitionId:'venezuela-primera-division',competitionName:'Liga FUTVE'},
 {id:'GER',name:'Alemanha',region:'europe',competitionId:'germany-bundesliga',competitionName:'Bundesliga'},
 {id:'ENG',name:'Inglaterra',region:'europe',competitionId:'england-premier-league',competitionName:'Premier League'},
 {id:'ITA',name:'Itália',region:'europe',competitionId:'italy-serie-a',competitionName:'Serie A'},
 {id:'NED',name:'Países Baixos',region:'europe',competitionId:'netherlands-eredivisie',competitionName:'Eredivisie'},
 {id:'FRA',name:'França',region:'europe',competitionId:'france-ligue-1',competitionName:'Ligue 1'},
 {id:'POR',name:'Portugal',region:'europe',competitionId:'portugal-primeira-liga',competitionName:'Primeira Liga'},
 {id:'ESP',name:'Espanha',region:'europe',competitionId:'spain-la-liga',competitionName:'La Liga'}
].map(Object.freeze));

const countryById=new Map(REGIONAL_COUNTRIES.map(x=>[x.id,x]));
export const REGIONAL_COMPETITIONS=Object.freeze(REGIONAL_COUNTRIES.map(country=>{
 const edition=REGIONAL_EDITION_VERIFICATION.find(x=>x.competitionId===country.competitionId);
 return Object.freeze({id:country.competitionId,name:country.competitionName,countryId:country.id,
  region:country.region,level:1,kind:'national-league',season:edition.season,
  participantStatus:'official-count-verified',participantCount:edition.participantCount,participantIds:Object.freeze([]),
  rulesStatus:edition.regulations.status,calendarStatus:edition.calendar.status,
  rosterStatus:edition.rosters.status,rosterImported:edition.rosters.imported,
  formatTemplate:'generic-double-round-robin',officialFormat:edition.formatSummary,
  sources:Object.freeze({regulations:edition.regulations.sourceUrl,calendar:edition.calendar.sourceUrl,rosters:edition.rosters.sourceUrl})
 });
}));

/** Gera calendário neutro apenas após receber participantes válidos de uma edição. */
export function createRegionalSeason(competitionId,participants,{season,startDate='2026-01-01',daysBetweenRounds=7}={}){
 const competition=REGIONAL_COMPETITIONS.find(x=>x.id===competitionId);
 if(!competition)throw new Error(`Competição regional desconhecida: ${competitionId}`);
 if(!Array.isArray(participants)||participants.length<2)throw new Error('Dois ou mais participantes explícitos são obrigatórios');
 const ids=participants.map(x=>x?.id);
 if(ids.some(x=>typeof x!=='string'||!x)||new Set(ids).size!==ids.length)throw new Error('IDs de participantes únicos são obrigatórios');
 if(participants.some(x=>x.country!==competition.countryId))throw new Error('Todos os participantes devem pertencer ao país da competição');
 if(!Number.isInteger(season))throw new Error('Temporada explícita obrigatória');
 const fixtures=roundRobin(ids,{doubleRound:true,season,startDate,daysBetweenRounds});
 return Object.freeze({competitionId,season,format:'generic-double-round-robin',sourceStatus:'generated-from-explicit-input',
  officialRulesApplied:false,participantIds:Object.freeze(ids),fixtures:Object.freeze(fixtures.map(Object.freeze))});
}

export function getRegionalCompetition(id){return REGIONAL_COMPETITIONS.find(x=>x.id===id)??null;}
export function getCountry(id){return countryById.get(id)??null;}
