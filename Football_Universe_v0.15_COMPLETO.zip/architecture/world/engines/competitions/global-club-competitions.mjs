const officialSources = Object.freeze({
  fifa2025Teams: 'https://www.fifa.com/en/tournaments/mens/club-world-cup/usa-2025/articles/how-teams-qualify?searchOverlay=1',
  fifa2025Groups: 'https://www.fifa.com/en/tournaments/mens/club-world-cup/usa-2025/articles/teams-dates-venue-groups-draw-matches',
  fifa2029CruzAzul: 'https://www.fifa.com/de/tournaments/mens/fifa-club-world-cup/articles/cruz-azul-win-champions-cup-nordamerika',
  fifa2029Pyramids: 'https://www.fifa.com/en/tournaments/mens/club-world-cup/usa-2025/articles/mamelodi-sundowns-pyramids-report-reaction?searchOverlay=1',
  fifa2029Flamengo: 'https://www.fifa.com/pt/articles/filipe-luis-campeao-libertadores-flamengo-jogador-tecnico-2025',
  fifa2029AlAhli: 'https://www.fifa.com/pt/articles/liga-campeoes-afc-asia-ah-ahli-campeao-2026',
  fifa2029Mamelodi: 'https://www.fifa.com/pt/tournaments/mens/fifa-club-world-cup/articles/resumo-final-liga-dos-campeoes-caf-2026-asfar-mamelodi-sundowns',
  fifa2029Toluca: 'https://www.fifa.com/es/articles/toluca-clasifica-a-la-copa-intercontinental-y-mundial-de-clubes',
  fifaIntercontinental2026: 'https://www.fifa.com/en/tournaments/mens/fifa-club-world-cup/articles/al-ahli-and-auckland-fc-to-kick-off-in-jeddah',
  fifaIntercontinentalDates: 'https://www.fifa.com/en/tournaments/mens/intercontinentalcup/2026/articles/qatar-appointed-host-final-three-matches',
  cbfCopaBrasil2026: 'https://www.cbf.com.br/futebol-brasileiro/noticias/undefined/cuiaba-saf-x-fluminense/cbf-divulga-tabela-basica-plano-geral-de-acoes-e-regulamento-especifico-da-copa-do-brasil-2026',
  cbfCopaBrasilSemis: 'https://www.cbf.com.br/futebol-brasileiro/noticias/copa-brasil-masculino/a/brasilia-recebe-final-da-copa-do-brasil-2026',
  cbfSupercopa2026: 'https://www.cbf.com.br/futebol-brasileiro/noticias/campeonato-brasileiro/serie-a/corinthians-vence-flamengo-e-conquista-supercopa-rei-superbet-2026',
  conmebolRecopa2026: 'https://gol.conmebol.com/sudamericana/pt-br/news/lanus-e-campeao-da-conmebol-recopa-de-2026',
  conmebolRecopaRegulations: 'https://cdn.conmebol.com/wp-content/uploads/2026/02/Reglamento-CONMEBOL-Recopa-2026.pdf'
});

const cwc2025Rows = [
  ['palmeiras','SE Palmeiras','BRA','CONMEBOL','continental-champion','A'],
  ['porto','FC Porto','POR','UEFA','confederation-ranking','A'],
  ['al-ahly','Al Ahly FC','EGY','CAF','continental-champion','A'],
  ['inter-miami','Inter Miami CF','USA','Concacaf','host-nation','A'],
  ['psg','Paris Saint-Germain','FRA','UEFA','confederation-ranking','B'],
  ['atletico-madrid','Atlético de Madrid','ESP','UEFA','confederation-ranking','B'],
  ['botafogo','Botafogo','BRA','CONMEBOL','continental-champion','B'],
  ['seattle-sounders','Seattle Sounders FC','USA','Concacaf','continental-champion','B'],
  ['bayern-munich','FC Bayern München','GER','UEFA','confederation-ranking','C'],
  ['auckland-city','Auckland City FC','NZL','OFC','confederation-ranking','C'],
  ['ar-boca-juniors','Boca Juniors','ARG','CONMEBOL','confederation-ranking','C'],
  ['benfica','SL Benfica','POR','UEFA','confederation-ranking','C'],
  ['flamengo','Flamengo','BRA','CONMEBOL','continental-champion','D'],
  ['esperance-tunis','Espérance Sportive de Tunis','TUN','CAF','confederation-ranking','D'],
  ['chelsea','Chelsea FC','ENG','UEFA','continental-champion','D'],
  ['lafc','Los Angeles FC','USA','Concacaf','play-in-winner','D'],
  ['ar-river-plate','River Plate','ARG','CONMEBOL','confederation-ranking','E'],
  ['urawa-red-diamonds','Urawa Red Diamonds','JPN','AFC','continental-champion','E'],
  ['monterrey','CF Monterrey','MEX','Concacaf','continental-champion','E'],
  ['inter-milan','FC Internazionale Milano','ITA','UEFA','confederation-ranking','E'],
  ['fluminense','Fluminense','BRA','CONMEBOL','continental-champion','F'],
  ['borussia-dortmund','Borussia Dortmund','GER','UEFA','confederation-ranking','F'],
  ['ulsan-hd','Ulsan HD','KOR','AFC','confederation-ranking','F'],
  ['mamelodi-sundowns','Mamelodi Sundowns FC','RSA','CAF','confederation-ranking','F'],
  ['manchester-city','Manchester City','ENG','UEFA','continental-champion','G'],
  ['wydad','Wydad AC','MAR','CAF','continental-champion','G'],
  ['al-ain','Al Ain FC','UAE','AFC','continental-champion','G'],
  ['juventus','Juventus FC','ITA','UEFA','confederation-ranking','G'],
  ['real-madrid','Real Madrid','ESP','UEFA','continental-champion','H'],
  ['al-hilal','Al Hilal','KSA','AFC','continental-champion','H'],
  ['pachuca','CF Pachuca','MEX','Concacaf','continental-champion','H'],
  ['salzburg','FC Salzburg','AUT','UEFA','confederation-ranking','H']
];

const cwc2025Groups = Object.freeze([
  { id:'A', teamIds:['palmeiras','porto','al-ahly','inter-miami'] },
  { id:'B', teamIds:['psg','atletico-madrid','botafogo','seattle-sounders'] },
  { id:'C', teamIds:['bayern-munich','auckland-city','ar-boca-juniors','benfica'] },
  { id:'D', teamIds:['flamengo','esperance-tunis','chelsea','lafc'] },
  { id:'E', teamIds:['ar-river-plate','urawa-red-diamonds','monterrey','inter-milan'] },
  { id:'F', teamIds:['fluminense','borussia-dortmund','ulsan-hd','mamelodi-sundowns'] },
  { id:'G', teamIds:['manchester-city','wydad','al-ain','juventus'] },
  { id:'H', teamIds:['real-madrid','al-hilal','pachuca','salzburg'] }
].map(group=>Object.freeze({...group,teamIds:Object.freeze(group.teamIds)})));

export const FIFA_CLUB_WORLD_CUP_2025 = Object.freeze({
  id:'fifa-club-world-cup-2025', name:'Mundial de Clubes FIFA 2025', season:2025,
  status:'completed', format:'32 clubs; 8 groups of 4; top two advance to round of 16',
  startDate:'2025-06-14',endDate:'2025-07-13',
  participantIds:Object.freeze(cwc2025Rows.map(([id])=>id)),
  clubs:Object.freeze(cwc2025Rows.map(([id,name,countryCode,confederation,qualificationPath,group])=>Object.freeze({id,name,countryCode,confederation,qualificationPath,group}))),
  groups:cwc2025Groups, slots:Object.freeze({AFC:4,CAF:4,Concacaf:4,CONMEBOL:6,OFC:1,UEFA:12,host:1}),
  matchCount:63, sourceUrl:officialSources.fifa2025Groups,
  sources:Object.freeze([officialSources.fifa2025Groups,officialSources.fifa2025Teams])
});

export const FIFA_CLUB_WORLD_CUP_2029 = Object.freeze({
  id:'fifa-club-world-cup-2029', name:'Mundial de Clubes FIFA 2029', season:2029,
  status:'qualification-in-progress', format:'32 clubs; qualification-cycle information only where officially confirmed',
  participantIds:Object.freeze(['al-ahli','pyramids','mamelodi-sundowns','cruz-azul','toluca','psg','flamengo']),
  clubs:Object.freeze([
    {id:'al-ahli',name:'Al Ahli',countryCode:'KSA',confederation:'AFC',qualifiedBy:'AFC Champions League Elite 2024/25'},
    {id:'pyramids',name:'Pyramids FC',countryCode:'EGY',confederation:'CAF',qualifiedBy:'CAF Champions League 2024/25'},
    {id:'mamelodi-sundowns',name:'Mamelodi Sundowns',countryCode:'RSA',confederation:'CAF',qualifiedBy:'CAF Champions League 2025/26'},
    {id:'cruz-azul',name:'Cruz Azul',countryCode:'MEX',confederation:'Concacaf',qualifiedBy:'Concacaf Champions Cup 2025'},
    {id:'toluca',name:'Toluca',countryCode:'MEX',confederation:'Concacaf',qualifiedBy:'Concacaf Champions Cup 2026'},
    {id:'psg',name:'Paris Saint-Germain',countryCode:'FRA',confederation:'UEFA',qualifiedBy:'UEFA Champions League 2024/25'},
    {id:'flamengo',name:'Flamengo',countryCode:'BRA',confederation:'CONMEBOL',qualifiedBy:'CONMEBOL Libertadores 2025'}
  ].map(club=>Object.freeze(club))),
  slots:null, sourceUrl:officialSources.fifa2025Teams,
  sources:Object.freeze([officialSources.fifa2029CruzAzul,officialSources.fifa2029Pyramids,officialSources.fifa2029Flamengo,officialSources.fifa2029AlAhli,officialSources.fifa2029Mamelodi,officialSources.fifa2029Toluca])
});

const intercontinental2026Matches = Object.freeze([
  {id:'ic-2026-1',stage:'African-Asian-Pacific play-off',date:'2026-08-26',home:'al-ahli',away:'auckland-fc',score:[1,0],status:'played'},
  {id:'ic-2026-2',stage:'African-Asian-Pacific Cup',date:'2026-09-19',home:'mamelodi-sundowns',away:'al-ahli',score:[2,1],status:'played'},
  {id:'ic-2026-3',stage:'FIFA Derby of the Americas',date:'2026-12-09',home:'toluca',away:'tbd-conmebol-libertadores-2026',score:null,status:'scheduled'},
  {id:'ic-2026-4',stage:'FIFA Challenger Cup',date:'2026-12-12',home:'tbd-derby-winner',away:'mamelodi-sundowns',score:null,status:'scheduled'},
  {id:'ic-2026-5',stage:'FIFA Intercontinental Cup final',date:'2026-12-16',home:'tbd-challenger-winner',away:'psg',score:null,status:'scheduled'}
].map(match=>Object.freeze({...match,score:match.score?Object.freeze(match.score):null})));

export const GLOBAL_CLUB_COMPETITIONS = Object.freeze([
  FIFA_CLUB_WORLD_CUP_2025,
  FIFA_CLUB_WORLD_CUP_2029,
  Object.freeze({
    id:'fifa-intercontinental-cup-2026',name:'Copa Intercontinental FIFA 2026',season:2026,status:'in-progress',
    participantIds:Object.freeze(['al-ahli','auckland-fc','mamelodi-sundowns','toluca','psg','tbd-conmebol-libertadores-2026']),
    matchesPlanned:5,matches:intercontinental2026Matches,
    sourceUrl:officialSources.fifaIntercontinental2026,sources:Object.freeze([officialSources.fifaIntercontinental2026,officialSources.fifaIntercontinentalDates])
  }),
  Object.freeze({
    id:'copa-do-brasil-2026',name:'Copa do Brasil 2026',season:2026,status:'in-progress',
    participantCount:126,phaseCount:9,matchCount:155,finalFormat:'single-match',firstMatchDate:'2026-02-17',finalDate:'2026-12-06',
    phases:Object.freeze([
      {name:'1ª fase',entrants:28,ties:14,legs:1},{name:'2ª fase',entrants:88,ties:44,legs:1},{name:'3ª fase',entrants:48,ties:24,legs:1},{name:'4ª fase',entrants:24,ties:12,legs:1},
      {name:'5ª fase',entrants:32,ties:16,legs:2},{name:'Oitavas de final',entrants:16,ties:8,legs:2},{name:'Quartas de final',entrants:8,ties:4,legs:2},{name:'Semifinais',entrants:4,ties:2,legs:2},{name:'Final',entrants:2,ties:1,legs:1}
    ].map(phase=>Object.freeze({...phase,matches:phase.ties*phase.legs}))),
    semifinalistIds:Object.freeze(['atletico-mg','gremio','palmeiras','vasco']),
    sourceUrl:officialSources.cbfCopaBrasil2026,sources:Object.freeze([officialSources.cbfCopaBrasil2026,officialSources.cbfCopaBrasilSemis])
  }),
  Object.freeze({
    id:'supercopa-rei-2026',name:'Supercopa Rei 2026',season:2026,status:'completed',format:'single-match',
    participantIds:Object.freeze(['flamengo','corinthians']),date:'2026-02-01',scoreByClub:Object.freeze({flamengo:0,corinthians:2}),championId:'corinthians',
    sourceUrl:officialSources.cbfSupercopa2026,sources:Object.freeze([officialSources.cbfSupercopa2026])
  }),
  Object.freeze({
    id:'conmebol-recopa-2026',name:'CONMEBOL Recopa 2026',season:2026,status:'completed',format:'two-legged final',
    participantIds:Object.freeze(['lanus','flamengo']),matches:Object.freeze([
      Object.freeze({leg:1,date:'2026-02-19',home:'lanus',away:'flamengo',score:Object.freeze([1,0])}),
      Object.freeze({leg:2,date:'2026-02-26',home:'flamengo',away:'lanus',score:Object.freeze([2,3]),afterExtraTime:true})
    ]),aggregate:Object.freeze({lanus:4,flamengo:2}),championId:'lanus',
    sourceUrl:officialSources.conmebolRecopa2026,sources:Object.freeze([officialSources.conmebolRecopa2026,officialSources.conmebolRecopaRegulations])
  })
]);

export function getGlobalCompetition(id) {
  return GLOBAL_CLUB_COMPETITIONS.find(competition=>competition.id===id) ?? null;
}
