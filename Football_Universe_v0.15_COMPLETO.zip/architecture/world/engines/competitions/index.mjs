export * from './global-club-competitions.mjs';

export function createSuperWorldCupStructure(participantIds, {season, seed=0}={}) {
  if(!Number.isInteger(season)||participantIds?.length!==32||new Set(participantIds).size!==32) throw new Error('Super Mundial exige 32 clubes distintos e temporada');
  if(!Number.isInteger(seed)) throw new Error('Seed inválida');
  // Entrada na ordem aprovada pelo sorteio externo. Não simula sorteio como se fosse oficial.
  const groups=Array.from({length:8},(_,idx)=>{
    const ids=participantIds.slice(idx*4,idx*4+4),matches=[];
    for(let a=0;a<ids.length;a++)for(let b=a+1;b<ids.length;b++)matches.push({id:`${season}-g${idx+1}-m${matches.length+1}`,home:ids[a],away:ids[b],status:'scheduled'});
    return {id:String.fromCharCode(65+idx),teams:ids,matches};
  });
  const bracket={roundOf16:8,quarterfinals:4,semifinals:2,final:1};
  return {competition:'super-world-cup',season,groups,bracket,thirdPlaceMatch:false,participantIds:[...participantIds],drawStatus:'externally-supplied'};
}
export function calculateTable(teams,matches,completedStatuses=['played']) {
  const rows=new Map(teams.map(id=>[id,{id,played:0,w:0,d:0,l:0,gf:0,ga:0,gd:0,points:0}]));
  for(const match of matches){
    if(!completedStatuses.includes(match.status)) continue;
    if(!rows.has(match.home)||!rows.has(match.away)||!Number.isInteger(match.homeGoals)||!Number.isInteger(match.awayGoals)||match.homeGoals<0||match.awayGoals<0) throw new Error('Partida inválida na tabela');
    const h=rows.get(match.home),a=rows.get(match.away);
    h.played++;a.played++;h.gf+=match.homeGoals;h.ga+=match.awayGoals;a.gf+=match.awayGoals;a.ga+=match.homeGoals;
    if(match.homeGoals>match.awayGoals){h.w++;a.l++;h.points+=3;}
    else if(match.homeGoals<match.awayGoals){a.w++;h.l++;a.points+=3;}
    else {h.d++;a.d++;h.points++;a.points++;}
  }
  return [...rows.values()].map(x=>({...x,gd:x.gf-x.ga})).sort((a,b)=>b.points-a.points||b.gd-a.gd||b.gf-a.gf||a.id.localeCompare(b.id));
}
