/** Regras versionadas. Não inventa campeões nem atribui vagas aleatórias. */
export function rankEligibleTeams({candidates, slots, maxPerCountry=Infinity, qualifiedWinners=[]}) {
  if(!Number.isInteger(slots)||slots<0||!Array.isArray(candidates))throw new Error('Vagas/candidatos inválidos');
  const selected=[], countryCount=new Map(), byId=new Map(candidates.map(x=>[x.id,x]));
  for(const id of qualifiedWinners) {
    const t=byId.get(id);
    if(!t) throw new Error(`Campeão ${id} ausente`);
    if(!selected.some(x=>x.id===id)){selected.push(t);countryCount.set(t.country,(countryCount.get(t.country)??0)+1);}
  }
  if(selected.length>slots)throw new Error('Campeões excedem as vagas');
  const sorted=[...candidates].filter(x=>Number.isFinite(x.coefficient)).sort((a,b)=>b.coefficient-a.coefficient||a.id.localeCompare(b.id));
  for(const t of sorted) {
    if(selected.length>=slots)break;
    if(selected.some(s=>s.id===t.id)||((countryCount.get(t.country)??0)>=maxPerCountry))continue;
    selected.push(t);countryCount.set(t.country,(countryCount.get(t.country)??0)+1);
  }
  return {selected,unfilled:slots-selected.length,mode:'verified-ranking-or-winner',provisional:slots-selected.length>0};
}
export function allocateQualifiedSlots(candidates,rule){
  if(!rule?.season||!rule?.source||!Array.isArray(rule?.confederations))throw new Error('Regulamento versionado obrigatório');
  const reports=[],chosen=[];
  for(const conf of rule.confederations){
    const local=candidates.filter(x=>x.confederation===conf.code);
    const result=rankEligibleTeams({candidates:local,slots:conf.slots,maxPerCountry:conf.maxPerCountry??Infinity,qualifiedWinners:conf.winners??[]});
    reports.push({confederation:conf.code,unfilled:result.unfilled});chosen.push(...result.selected);
  }
  if(new Set(chosen.map(x=>x.id)).size!==chosen.length)throw new Error('Clube classificado duas vezes');
  return {clubs:chosen,validation:reports};
}
