/** Edition-specific rules, explicit only: no made-up FIFA/continental regulations. */
export function validateEdition(edition) {
  const issues=[];
  if(!edition || typeof edition!=='object'||Array.isArray(edition))return ['edition must be object'];
  if(typeof edition.competitionId!=='string'||!edition.competitionId.trim())issues.push('competitionId required');
  if(!Number.isInteger(edition.season)||edition.season<1900||edition.season>2300)issues.push('season invalid');
  if(typeof edition.ruleVersion!=='string'||!edition.ruleVersion.trim())issues.push('ruleVersion required');
  if(typeof edition.source!=='string'||!edition.source.trim())issues.push('source required');
  if(!['draft','verified'].includes(edition.verification))issues.push('verification must be draft or verified');
  if(!edition.format || typeof edition.format!=='object'||Array.isArray(edition.format))issues.push('format required');
  else {
    if(!['round_robin','knockout','group_knockout','custom'].includes(edition.format.kind))issues.push('format.kind invalid');
    for(const k of ['teams','groups','groupSize'])if(edition.format[k]!==undefined && (!Number.isInteger(edition.format[k])||edition.format[k]<1))issues.push(`format.${k} invalid`);
    if(edition.format.groups && edition.format.groupSize && edition.format.teams && edition.format.groups*edition.format.groupSize!==edition.format.teams)issues.push('groups x groupSize must equal teams');
  }
  return issues;
}
export function resolveEdition(editions,competitionId,season,{requireVerified=false}={}){
  if(!Array.isArray(editions))throw new Error('Edition list required');
  const candidates=editions.filter(x=>x?.competitionId===competitionId&&x?.season===season);
  if(candidates.length!==1)throw new Error(`Exact unique edition unavailable: ${competitionId} ${season}`);
  const match=candidates[0],issues=validateEdition(match);
  if(issues.length)throw new Error(`Invalid edition: ${issues.join('; ')}`);
  if(requireVerified && match.verification!=='verified')throw new Error('Edition regulations pending source verification');
  return structuredClone(match);
}
/** Reservations are intentionally abstract and not date-official; overlap is an error. */
export function auditCalendarConflicts(events){
  if(!Array.isArray(events))throw new Error('Event list required');
  const occupied=new Map(),issues=[];
  for(const ev of events){
    if(!ev?.id||!ev?.date||!Array.isArray(ev.clubIds)||new Set(ev.clubIds).size!==ev.clubIds.length){issues.push({event:ev?.id??null,reason:'invalid-event'});continue;}
    for(const clubId of ev.clubIds){
      const key=`${ev.date}|${clubId}`;
      if(occupied.has(key))issues.push({event:ev.id,other:occupied.get(key),clubId,date:ev.date,reason:'same-day-double-booking'});
      else occupied.set(key,ev.id);
    }
  }
  return {ok:issues.length===0,issues};
}
