import {calculateTable} from '../competitions/index.mjs';
/** Does not silently invent head-to-head tiebreakers or results. */
export function resolveGroupsToRoundOf16(world){
  if(!world || !Array.isArray(world.groups)||world.groups.length!==8)throw new Error('8 groups required');
  const standings=[],issues=[];
  const globalIds=new Set();
  for(const group of world.groups){
    if(!Array.isArray(group.teams)||group.teams.length!==4||new Set(group.teams).size!==4){issues.push(`${group.id}: invalid teams`);continue;}
    for(const id of group.teams){if(globalIds.has(id))issues.push(`${group.id}: repeated club ${id}`);globalIds.add(id);}
    if(!Array.isArray(group.matches)||group.matches.length!==6){issues.push(`${group.id}: 6 matches required`);continue;}
    const games=new Set();
    for(const m of group.matches){
      if(!group.teams.includes(m.home)||!group.teams.includes(m.away)||m.home===m.away)issues.push(`${group.id}: invalid fixture`);
      const key=[m.home,m.away].sort().join(':');
      if(games.has(key))issues.push(`${group.id}: duplicated fixture`);games.add(key);
    }
    if(group.matches.some(m=>m.status!=='played')){issues.push(`${group.id}: incomplete results`);continue;}
    try{
      const table=calculateTable(group.teams,group.matches);
      // A tied rank boundary involving two or more teams cannot be assumed solved solely by GD/GF.
      // The simulation needs the edition-specific tiebreaker, potentially head-to-head/fair-play.
      if(table[1].points===table[2].points && table[1].gd===table[2].gd && table[1].gf===table[2].gf){issues.push(`${group.id}: unresolved second-place tiebreak`);continue;}
      if(table[0].points===table[1].points && table[0].gd===table[1].gd && table[0].gf===table[1].gf){issues.push(`${group.id}: unresolved first-place tiebreak`);continue;}
      standings.push({groupId:group.id,table,winner:table[0].id,runnerUp:table[1].id});
    } catch(error){issues.push(`${group.id}: ${error.message}`);}
  }
  if(issues.length || standings.length!==8)return {ready:false,issues,standings};
  const groups=new Map(standings.map(s=>[s.groupId,s]));
  const pairings=[['A','B'],['C','D'],['E','F'],['G','H']];
  const roundOf16=[];
  for(const [g,h] of pairings){
    if(!groups.has(g)||!groups.has(h))return {ready:false,issues:['Groups A-H required'],standings};
    roundOf16.push({home:groups.get(g).winner,away:groups.get(h).runnerUp});
    roundOf16.push({home:groups.get(h).winner,away:groups.get(g).runnerUp});
  }
  if(new Set(roundOf16.flatMap(m=>[m.home,m.away])).size!==16)throw new Error('Duplicated qualifiers');
  return {ready:true,issues:[],standings,roundOf16:roundOf16.map((m,i)=>({...m,slot:i+1,status:'scheduled'})),requiresEditionTiebreaker:true};
}
