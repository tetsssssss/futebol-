/** Calendário genérico matemático; não representa automaticamente datas oficiais. */
export function roundRobin(teamIds, {doubleRound=true, startDate='2026-01-01', daysBetweenRounds=7, season=2026}={}) {
  if(!Array.isArray(teamIds)||teamIds.length<2 || new Set(teamIds).size!==teamIds.length || teamIds.some(x=>!x||typeof x!=='string')) throw new Error('Clubes únicos obrigatórios');
  if(!/^\d{4}-\d{2}-\d{2}$/.test(startDate)||Number.isNaN(Date.parse(startDate+'T00:00:00Z'))||!Number.isInteger(daysBetweenRounds)||daysBetweenRounds<1) throw new Error('Configuração de datas inválida');
  const teams=[...teamIds];if(teams.length%2) teams.push(null);
  const n=teams.length,rounds=[],rot=[...teams];
  for(let i=0;i<n-1;i++) {
    const matches=[];
    for(let j=0;j<n/2;j++){
      const a=rot[j],b=rot[n-1-j];if(a===null||b===null)continue;
      matches.push((i+j)%2===0?[a,b]:[b,a]);
    }
    rounds.push(matches);rot.splice(1,0,rot.pop());
  }
  const result=[];
  for(let leg=0;leg<(doubleRound?2:1);leg++) for(let round=0;round<rounds.length;round++) {
    const roundNum=leg*rounds.length+round+1;
    const date=new Date(startDate+'T12:00:00Z');date.setUTCDate(date.getUTCDate()+(roundNum-1)*daysBetweenRounds);
    for(let index=0;index<rounds[round].length;index++){
      let [home,away]=rounds[round][index];if(leg===1)[home,away]=[away,home];
      result.push({id:`${season}-r${roundNum}-m${index+1}`,season,round:roundNum,date:date.toISOString().slice(0,10),home,away,status:'scheduled'});
    }
  }
  return result;
}
export function validateRoundRobin(matches,teams,{doubleRound=true}={}) {
  const expected=doubleRound?2:1,seen=new Map(),errors=[];
  for(const m of matches){if(m.home===m.away)errors.push('time contra si mesmo');
    if(!teams.includes(m.home)||!teams.includes(m.away))errors.push('time não cadastrado');
    const k=[m.home,m.away].sort().join('|');const count=seen.get(k)??{games:0,home:new Set()};count.games++;count.home.add(m.home);seen.set(k,count);
  }
  for(let i=0;i<teams.length;i++) for(let j=i+1;j<teams.length;j++){
    const pair=seen.get([teams[i],teams[j]].sort().join('|'));
    if(pair?.games!==expected) errors.push(`confronto ${teams[i]}/${teams[j]}: quantidade inválida`);
    if(doubleRound&&pair?.home.size!==2)errors.push(`confronto ${teams[i]}/${teams[j]}: mando incorreto`);
  }
  return errors;
}
