# CP001–CP016 — integração no v0.15

O pacote expõe uma camada ESM opcional para validar snapshots, inspecionar referências, registrar IDs, comparar inclusões e produzir relatórios. O catálogo do jogo continua sendo a fonte canônica. Nenhum comando aplica alterações no jogo ou nos saves.

## Estado da integração

- `integration/adapters/v015.mjs` lê apenas `data/brasileirao-2026.json` e expõe 20 clubes, 673 atletas, 70 atributos nomeados e a edição Série A 2026. Os IDs de clube e atleta são preservados.
- `core/validation/` valida o envelope versionado, registros e links; `core/id_registry/api.mjs` resolve IDs e aliases explícitos, mantendo ambiguidade como conflito.
- `core/data_merger/api.mjs` prepara relatório dry-run. `autoApply` é sempre falso e `fixtureOnly` bloqueia conjuntos demonstrativos.
- `engines/edition_rules/`, `engines/tournament/` e `core/asset_registry/` são módulos de auditoria. Regras sem fonte ou partidas completas ficam pendentes; imagens só são auditadas como arquivos locais com hash fornecido.
- `tools/cli.mjs` oferece `snapshot`, `validate`, `merge-plan`, `edition-check`, `asset-audit` e `handoff`; arquivos de relatório são criados exclusivamente, sem sobrescrever saídas.

## Limites explícitos

As bases regionais e exemplos do pacote de arquitetura são fixtures/planos, não elencos adicionais aprovados. Não foram importados no jogo. O snapshot não lê histórico de carreira, save, partidas, contratos, condição ou estatísticas. A adaptação não confirma calendário ou regulamento oficial de 2026. `handoff` é um manifesto para revisão futura e não executa importação.

## Estruturas nacionais adicionadas

`engines/competitions/regional.mjs` registra 9 países sul-americanos e 7 europeus, associados às competições de primeira divisão e à edição verificada (América do Sul 2026; Europa 2026/27). `edition-verification-2026.mjs` armazena contagens e formatos confirmados em fontes oficiais, com links por regulamento, calendário e clubes/plantéis. Calendários oficiais são mutáveis e não foram copiados jogo a jogo. As páginas oficiais de plantéis foram localizadas em parte das ligas, mas nenhum plantel foi importado nesta verificação; `rosterImported` permanece falso. `createRegionalSeason()` continua sendo explicitamente genérico e não reproduz os formatos oficiais descritos. As ligas brasileiras já existentes não são duplicadas aqui.

## Uso

```sh
npm run architecture:snapshot -- --output snapshot.json
npm run architecture:validate -- --input snapshot.json
npm run architecture:merge-plan -- --base base.json --additions additions.json --output merge-plan.json
npm run architecture:edition-check -- --input edition.json
npm run architecture:asset-audit -- --input media-manifest.json --root assets
npm run architecture:handoff -- --input merge-plan.json --sha256 BASE_SHA256 --output handoff.json
```

Use `npm run test:architecture` para rodar as verificações dos módulos world e actions.
