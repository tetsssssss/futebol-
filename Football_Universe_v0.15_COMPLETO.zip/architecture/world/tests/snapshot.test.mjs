import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {dirname,resolve} from 'node:path';
import {snapshotV015,hashSnapshot} from '../integration/adapters/v015.mjs';
test('adapts canonical v0.15 league without private fields',async()=>{
 const s=await snapshotV015();
 assert.equal(s.clubs.length,20); assert.equal(s.players.length,673);
 assert.equal(Object.keys(s.players[0].attributes).length,70);
 assert.equal(s.competitions.length,1); assert.equal(s.competitions[0].participantIds.length,20);
 assert.equal('career' in s.players[0],false); assert.equal('saves' in s,false);
});
test('snapshot hashing is stable and source data remains untouched',async()=>{
 const projectRoot=resolve(dirname(fileURLToPath(import.meta.url)),'../../../');
 const source=resolve(projectRoot,'data/brasileirao-2026.json');const before=await readFile(source);
 const a=await snapshotV015(),b=await snapshotV015(); assert.equal(hashSnapshot(a),hashSnapshot(b));
 assert.deepEqual(await readFile(source),before);
});
