import test from 'node:test';
import assert from 'node:assert/strict';
import {createIdRegistry,resolveId} from '../core/id_registry/api.mjs';
test('indexes canonical IDs and explicit aliases; ambiguous aliases remain conflicts',()=>{
 const r=createIdRegistry([{id:'a',name:'Alpha'},{id:'b',name:'Beta'}],[{alias:'old',target:'a'},{alias:'legacy',target:'a'},{alias:'legacy',target:'b'}]);
 assert.deepEqual(resolveId(r,'a'),{status:'EXISTENTE',id:'a'});
 assert.deepEqual(resolveId(r,'old'),{status:'EXISTENTE',id:'a'});
 assert.equal(resolveId(r,'legacy').status,'CONFLITO');
});
test('rejects duplicate stable IDs',()=>assert.throws(()=>createIdRegistry([{id:'a'},{id:'a'}]),/duplicate/i));
