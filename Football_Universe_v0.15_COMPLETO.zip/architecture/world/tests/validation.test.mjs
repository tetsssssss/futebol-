import test from 'node:test';
import assert from 'node:assert/strict';
import {validateWorldSnapshot} from '../core/validation/index.mjs';
const provenance={source:'fixture',retrievedAt:'2026-10-22',season:'2026'};
const sample={schemaVersion:'1.0.0',clubs:[{id:'club-a',name:'A',country:'BRA',season:2026,playerIds:['p1'],provenance}],players:[{id:'p1',name:'Player',clubId:'club-a',nationality:'BRA',position:'GK',season:2026,attributes:Object.fromEntries(Array.from({length:70},(_,i)=>['a'+i,50])),provenance}],competitions:[{id:'league-2026',name:'League',season:2026,format:'round_robin',participantIds:['club-a'],provenance}]};
test('accepts canonical-shaped world snapshot and counts records',()=>{const r=validateWorldSnapshot(sample);assert.equal(r.valid,true);assert.deepEqual(r.counts,{clubs:1,players:1,competitions:1});});
test('reports entity, record ID and path for invalid references and attributes',()=>{const bad=structuredClone(sample);bad.players[0].attributes={a0:150};bad.clubs[0].playerIds=['missing'];const r=validateWorldSnapshot(bad);assert.equal(r.valid,false);assert(r.errors.some(e=>e.entity==='player'&&e.id==='p1'&&e.path==='attributes'));assert(r.errors.some(e=>e.entity==='club'&&e.id==='club-a'&&e.path==='playerIds[0]'));});
test('rejects unknown schema versions with a useful error',()=>{const r=validateWorldSnapshot({...sample,schemaVersion:'99'});assert.equal(r.valid,false);assert(r.errors.some(e=>e.path==='schemaVersion'));});
test('requires complete named attribute vectors on every player',()=>{const bad=structuredClone(sample);delete bad.players[0].attributes;const r=validateWorldSnapshot(bad);assert.equal(r.valid,false);assert(r.errors.some(e=>e.entity==='player'&&e.id==='p1'&&e.path==='attributes'));});
