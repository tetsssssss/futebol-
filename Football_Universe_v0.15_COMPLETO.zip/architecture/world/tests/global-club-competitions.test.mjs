import test from 'node:test';
import assert from 'node:assert/strict';
import {GLOBAL_CLUB_COMPETITIONS,FIFA_CLUB_WORLD_CUP_2025,FIFA_CLUB_WORLD_CUP_2029,getGlobalCompetition} from '../engines/competitions/global-club-competitions.mjs';

test('catalogs 2026 national/continental club finals with official participants and outcomes',()=>{
 const cbr=getGlobalCompetition('copa-do-brasil-2026');assert.equal(cbr.participantCount,126);assert.equal(cbr.matchCount,155);assert.equal(cbr.phaseCount,9);assert.equal(cbr.finalFormat,'single-match');
 assert.equal(cbr.phases.reduce((sum,phase)=>sum+phase.matches,0),155);assert.deepEqual(cbr.phases.map(p=>p.entrants),[28,88,48,24,32,16,8,4,2]);
 assert.deepEqual(cbr.phases.map(p=>p.legs),[1,1,1,1,2,2,2,2,1]);assert.deepEqual(cbr.semifinalistIds,['atletico-mg','gremio','palmeiras','vasco']);
 const supercopa=getGlobalCompetition('supercopa-rei-2026');assert.deepEqual(supercopa.participantIds,['flamengo','corinthians']);assert.deepEqual(supercopa.scoreByClub,{flamengo:0,corinthians:2});assert.equal(supercopa.championId,'corinthians');
 const recopa=getGlobalCompetition('conmebol-recopa-2026');assert.deepEqual(new Set(recopa.participantIds),new Set(['lanus','flamengo']));assert.equal(recopa.championId,'lanus');
 const inter=getGlobalCompetition('fifa-intercontinental-cup-2026');assert.equal(inter.participantIds.length,6);assert(inter.participantIds.includes('tbd-conmebol-libertadores-2026'));assert.equal(inter.matchesPlanned,5);
});

test('has the complete official 2025 Super Mundial field, with all six confederation/host pathways',()=>{
 assert.equal(FIFA_CLUB_WORLD_CUP_2025.participantIds.length,32);assert.equal(FIFA_CLUB_WORLD_CUP_2025.groups.length,8);
 assert(FIFA_CLUB_WORLD_CUP_2025.groups.every(g=>g.teamIds.length===4));
 assert.deepEqual(FIFA_CLUB_WORLD_CUP_2025.slots,{AFC:4,CAF:4,Concacaf:4,CONMEBOL:6,OFC:1,UEFA:12,host:1});
 assert.equal(new Set(FIFA_CLUB_WORLD_CUP_2025.participantIds).size,32);
 for(const club of FIFA_CLUB_WORLD_CUP_2025.clubs)assert(['AFC','CAF','Concacaf','CONMEBOL','OFC','UEFA'].includes(club.confederation));
 assert.deepEqual(FIFA_CLUB_WORLD_CUP_2025.groups.flatMap(g=>g.teamIds).sort(),[...FIFA_CLUB_WORLD_CUP_2025.participantIds].sort());
 for(const [confederation,expected] of Object.entries(FIFA_CLUB_WORLD_CUP_2025.slots).filter(([key])=>key!=='host')){
  assert.equal(FIFA_CLUB_WORLD_CUP_2025.clubs.filter(c=>c.confederation===confederation&&c.qualificationPath!=='host-nation').length,expected,`vagas ${confederation}`);
 }
 assert.equal(FIFA_CLUB_WORLD_CUP_2025.clubs.filter(c=>c.qualificationPath==='host-nation').length,1);
});

test('records only publicly confirmed 2029 qualifiers and leaves access-list slots undefined',()=>{
 assert.equal(FIFA_CLUB_WORLD_CUP_2029.season,2029);assert.equal(FIFA_CLUB_WORLD_CUP_2029.status,'qualification-in-progress');
 assert.deepEqual(new Set(FIFA_CLUB_WORLD_CUP_2029.participantIds),new Set(['al-ahli','pyramids','mamelodi-sundowns','cruz-azul','toluca','psg','flamengo']));
 assert.equal(FIFA_CLUB_WORLD_CUP_2029.slots,null);
});

test('exposes source and season on every competition record',()=>{
 assert(GLOBAL_CLUB_COMPETITIONS.every(x=>x.sourceUrl&&x.season));
});
