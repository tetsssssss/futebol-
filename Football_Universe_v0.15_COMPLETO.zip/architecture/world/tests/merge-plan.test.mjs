import test from 'node:test'; import assert from 'node:assert/strict';
import {createMergePlan} from '../core/data_merger/api.mjs';
const p={source:'fixture',retrievedAt:'2026-10-22',season:'2026'};
const base={clubs:[{id:'a',name:'Alpha FC',country:'BRA',season:2026,playerIds:[],provenance:p}],players:[],competitions:[]};
test('plans additions without mutating either input and blocks fixtures',()=>{
 const add={clubs:[{id:'b',name:'Beta FC',country:'BRA',season:2026,playerIds:[],provenance:p}],players:[],competitions:[]}; const before=JSON.stringify(add);
 const plan=createMergePlan(base,add); assert.equal(plan.mode,'DRY_RUN_ONLY'); assert.equal(plan.autoApply,false); assert.equal(plan.summary.NOVO,1); assert.equal(JSON.stringify(add),before);
 assert.equal(createMergePlan(base,add,{fixtureOnly:true}).ok,false);
});
test('rejects dangling candidate references',()=>{
 const add={clubs:[],players:[{id:'p',name:'P',clubId:'missing',nationality:'BRA',position:'MF',season:2026,provenance:p}],competitions:[]};
 const plan=createMergePlan(base,add); assert.equal(plan.summary.CONFLITO,1);
});
