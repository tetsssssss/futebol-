import test from 'node:test';
import assert from 'node:assert/strict';
import {REGIONAL_COUNTRIES,REGIONAL_COMPETITIONS,REGIONAL_EDITION_VERIFICATION,createRegionalSeason} from '../engines/competitions/regional.mjs';

test('registra 9 países sul-americanos e 7 ligas europeias com IDs estáveis',()=>{
 assert.equal(REGIONAL_COUNTRIES.filter(x=>x.region==='south-america').length,9);
 assert.equal(REGIONAL_COUNTRIES.filter(x=>x.region==='europe').length,7);
 assert.equal(REGIONAL_COMPETITIONS.length,16);
 assert.equal(new Set(REGIONAL_COMPETITIONS.map(x=>x.id)).size,16);
 assert(REGIONAL_COMPETITIONS.every(x=>x.participantStatus==='official-count-verified'&&x.rosterImported===false));
});

test('mantém verificação por edição, fontes oficiais e não confunde lista consultável com elenco importado',()=>{
 assert.equal(REGIONAL_EDITION_VERIFICATION.length,16);
 assert(REGIONAL_EDITION_VERIFICATION.every(x=>x.season==='2026'||x.season==='2026-27'));
 assert(REGIONAL_EDITION_VERIFICATION.every(x=>x.calendar?.sourceUrl&&x.rosters?.imported===false));
 assert(REGIONAL_EDITION_VERIFICATION.every(x=>['official-roster-page','official-club-list','not-located'].includes(x.rosters?.status)));
 assert(REGIONAL_EDITION_VERIFICATION.every(x=>x.participantCount>0&&x.formatSummary));
 assert(REGIONAL_COMPETITIONS.every(x=>x.participantCount>0&&x.sources.calendar));
 assert.equal(new Set(REGIONAL_EDITION_VERIFICATION.map(x=>x.competitionId)).size,16);
});

test('gera temporada nacional só com participantes e formato fornecidos explicitamente',()=>{
 const clubs=Array.from({length:4},(_,i)=>({id:`club-${i+1}`,country:'ARG'}));
 const season=createRegionalSeason('argentina-primera-division',clubs,{season:2026,startDate:'2026-01-01'});
 assert.equal(season.fixtures.length,12);
 assert.equal(season.participantIds.length,4);
 assert.equal(season.sourceStatus,'generated-from-explicit-input');
 assert.throws(()=>createRegionalSeason('argentina-primera-division',[],{season:2026}),/participantes/);
 assert.throws(()=>createRegionalSeason('argentina-primera-division',[{id:'bad',country:'BRA'},{id:'x',country:'ARG'}],{season:2026}),/país/);
});
