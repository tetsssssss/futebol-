const DATE = /^\d{4}-\d{2}-\d{2}$/;
const ID = /^[a-zA-Z0-9][a-zA-Z0-9_.:-]{0,119}$/;
const IS_NUM = (v) => typeof v === 'number' && Number.isFinite(v);
const OBJECT = (v) => v !== null && typeof v === 'object' && !Array.isArray(v);
const STR = (v) => typeof v === 'string' && v.trim().length > 0;

export function validDate(v) {
  if (!DATE.test(v ?? '')) return false;
  const d = new Date(`${v}T00:00:00.000Z`);
  return !Number.isNaN(d.valueOf()) && d.toISOString().startsWith(v);
}
const validateId = (v, path, errors) => { if (!STR(v) || !ID.test(v)) errors.push(`${path}: id inválido`); };
const validProvenance = (v, p, errors) => {
  if (!OBJECT(v)) { errors.push(`${p}: origem obrigatória`); return; }
  if (!STR(v.source) || !STR(v.retrievedAt) || !validDate(v.retrievedAt) || !STR(v.season)) errors.push(`${p}: origem, data e temporada obrigatórias`);
};
const validateExternal = (v,p,errors) => {
  if (v == null) return;
  if (!OBJECT(v) || Object.entries(v).some(([k,x])=> !STR(k) || (!STR(x) && !Number.isInteger(x)))) errors.push(`${p}: externalIds inválidos`);
};
const optionalText = (value, label, errors) => {if (value != null && typeof value !== 'string') errors.push(`${label}: texto esperado`);};

export function validateClub(v, path='club') {
  const e=[];
  if (!OBJECT(v)) return [`${path}: objeto obrigatório`];
  validateId(v.id,`${path}.id`,e);
  if (!STR(v.name)) e.push(`${path}.name: obrigatório`);
  if (!/^[A-Z]{3}$/.test(v.country ?? '')) e.push(`${path}.country: código ISO alfa-3 (ou Fifa) em maiúsculas esperado`);
  if (!Number.isInteger(v.season) || v.season < 1900 || v.season > 2300) e.push(`${path}.season: ano inválido`);
  for(const k of ['city','region','shortName','stadium']) optionalText(v[k],`${path}.${k}`,e);
  for(const k of ['budget','wageBudget','reputation']) if(v[k] != null && (!IS_NUM(v[k]) || v[k]<0)) e.push(`${path}.${k}: número não negativo esperado`);
  if(v.reputation != null && v.reputation>100) e.push(`${path}.reputation: maior que 100`);
  if(v.playerIds != null && (!Array.isArray(v.playerIds) || v.playerIds.some(x=>!STR(x)))) e.push(`${path}.playerIds: IDs inválidos`);
  validateExternal(v.externalIds,`${path}.externalIds`,e);
  validProvenance(v.provenance,`${path}.provenance`,e);
  return e;
}
export function validatePlayer(v,path='player') {
  const e=[];
  if (!OBJECT(v)) return [`${path}: objeto obrigatório`];
  validateId(v.id,`${path}.id`,e);
  if (!STR(v.name)) e.push(`${path}.name: obrigatório`);
  if(!STR(v.clubId) && v.clubId !== null) e.push(`${path}.clubId: obrigatório ou null (sem clube)`);
  if (!/^[A-Z]{3}$/.test(v.nationality ?? '')) e.push(`${path}.nationality: código ISO alfa-3 esperado`);
  if(v.born != null && !validDate(v.born)) e.push(`${path}.born: data inválida`);
  if (!STR(v.position)) e.push(`${path}.position: obrigatório`);
  if (!Number.isInteger(v.season) || v.season<1900 || v.season>2300) e.push(`${path}.season: ano inválido`);
  if (v.attributes != null) {
    if (!OBJECT(v.attributes) || Object.entries(v.attributes).some(([k,x]) => !STR(k) || !IS_NUM(x) || x < 0 || x > 100)) e.push(`${path}.attributes: valores devem ser 0-100`);
  }
  for (const k of ['overall','potential','form','condition']) if(v[k]!=null && (!IS_NUM(v[k]) || v[k]<0 || v[k]>100)) e.push(`${path}.${k}: 0 a 100`);
  if(v.photo != null && (!OBJECT(v.photo) || !STR(v.photo.path) || !STR(v.photo.source))) e.push(`${path}.photo: caminho e origem necessários`);
  validateExternal(v.externalIds,`${path}.externalIds`,e);
  validProvenance(v.provenance,`${path}.provenance`,e);
  return e;
}
export function validateCompetition(v,path='competition') {
  const e=[];
  if (!OBJECT(v)) return [`${path}: objeto obrigatório`];
  validateId(v.id,`${path}.id`,e);
  if(!STR(v.name)) e.push(`${path}.name: obrigatório`);
  if(!Number.isInteger(v.season) || v.season<1900 || v.season>2300) e.push(`${path}.season: inválida`);
  if (!['round_robin','knockout','group_knockout','continental','custom'].includes(v.format)) e.push(`${path}.format: desconhecido`);
  if (v.participantIds != null && (!Array.isArray(v.participantIds) || new Set(v.participantIds).size!==v.participantIds.length)) e.push(`${path}.participantIds: duplicados ou não é lista`);
  validProvenance(v.provenance,`${path}.provenance`,e);
  return e;
}
export function validateDataset(data,{strictLinks=true}={}) {
  const errors=[];if(!OBJECT(data)) return ['dataset: objeto obrigatório'];
  const clubs=data.clubs??[],players=data.players??[],competitions=data.competitions??[];
  if (![clubs,players,competitions].every(Array.isArray)) return ['dataset: clubs, players e competitions devem ser listas'];
  for(const [items,check,label] of [[clubs,validateClub,'clubs'],[players,validatePlayer,'players'],[competitions,validateCompetition,'competitions']]){
    const seen=new Set();items.forEach((v,i)=>{errors.push(...check(v,`${label}[${i}]`));if(v?.id){if(seen.has(v.id)) errors.push(`${label}: ID duplicado ${v.id}`);seen.add(v.id);}});
  }
  if (strictLinks) {
    const c=new Set(clubs.map(x=>x.id)),p=new Set(players.map(x=>x.id));
    for(const x of players) if(x.clubId !== null && !c.has(x.clubId)) errors.push(`jogador ${x.id}: clube ${x.clubId} inexistente`);
    for(const x of clubs) for(const id of x.playerIds??[]) if(!p.has(id)) errors.push(`clube ${x.id}: jogador ${id} inexistente`);
    for(const x of competitions) for(const id of x.participantIds??[]) if(!c.has(id)) errors.push(`competição ${x.id}: clube ${id} inexistente`);
  }
  return errors;
}

/** Validates a versioned interchange snapshot and returns machine-readable diagnostics. */
export function validateWorldSnapshot(snapshot) {
  const errors=[];
  if (!OBJECT(snapshot)) return {valid:false,errors:[{entity:'snapshot',id:null,path:'$',message:'object required'}],counts:{clubs:0,players:0,competitions:0}};
  if (snapshot.schemaVersion!=='1.0.0') errors.push({entity:'snapshot',id:null,path:'schemaVersion',message:'unsupported schema version'});
  for (const key of ['clubs','players','competitions']) if (!Array.isArray(snapshot[key])) errors.push({entity:key,id:null,path:key,message:'array required'});
  const counts={clubs:Array.isArray(snapshot.clubs)?snapshot.clubs.length:0,players:Array.isArray(snapshot.players)?snapshot.players.length:0,competitions:Array.isArray(snapshot.competitions)?snapshot.competitions.length:0};
  if (errors.length) return {valid:false,errors,counts};
  const raw=validateDataset(snapshot,{strictLinks:true});
  for (const item of raw) {
    const m=item.match(/^(clubs|players|competitions)\[(\d+)\](?:\.([^:]+))?: (.*)$/);
    const link=item.match(/^(jogador|clube|competição) ([^:]+): (?:clube|jogador) ([^ ]+) inexistente$/);
    if (m) {const entity={clubs:'club',players:'player',competitions:'competition'}[m[1]],record=snapshot[m[1]][Number(m[2])];errors.push({entity,id:record?.id??null,path:m[3]||'$record',message:m[4]});}
    else if(link){
      const entity=link[1]==='jogador'?'player':link[1]==='clube'?'club':'competition';
      const field=entity==='player'?'clubId':entity==='club'?'playerIds':'participantIds';
      const collection=entity==='player'?snapshot.players:entity==='club'?snapshot.clubs:snapshot.competitions;
      const record=collection.find(x=>x?.id===link[2]);
      const index=entity==='player'?null:(record?.[field]??[]).indexOf(link[3]);
      errors.push({entity,id:link[2],path:index==null?field:`${field}[${index}]`,message:`unresolved reference ${link[3]}`});
    }
    else errors.push({entity:'snapshot',id:null,path:'$',message:item});
  }
  for (const player of snapshot.players) if(!player?.attributes||typeof player.attributes!=='object'||Array.isArray(player.attributes)||Object.keys(player.attributes).length!==70) errors.push({entity:'player',id:player?.id??null,path:'attributes',message:'expected 70 named attributes'});
  return {valid:errors.length===0,errors,counts};
}
