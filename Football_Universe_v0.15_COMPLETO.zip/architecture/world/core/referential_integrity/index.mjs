/** Referential integrity for an independent world snapshot (never edits its input). */
export function auditReferences(world,{allowPartial=false}={}) {
  if(!world || typeof world!=='object') throw new Error('World object required');
  const clubs=world.clubs??[],players=world.players??[],competitions=world.competitions??[];
  if(![clubs,players,competitions].every(Array.isArray))throw new Error('World lists invalid');
  const clubById=new Map(clubs.map(c=>[c.id,c]));
  const playerById=new Map(players.map(p=>[p.id,p]));
  const issues=[];
  const add=(severity,kind,id,ref,reason)=>issues.push({severity,kind,id,ref,reason});
  for(const p of players) {
    if(p.clubId!==null && p.clubId!==undefined && !clubById.has(p.clubId))add(allowPartial?'warning':'error','player',p.id,p.clubId,'missing-club');
  }
  for(const c of clubs){
    const ids=c.playerIds??[];
    if(!Array.isArray(ids)){add('error','club',c.id,null,'invalid-playerIds');continue;}
    const used=new Set();
    for(const id of ids){
      if(used.has(id))add('error','club',c.id,id,'duplicate-player-link');
      used.add(id);
      const player=playerById.get(id);
      if(!player){add(allowPartial?'warning':'error','club',c.id,id,'missing-player');continue;}
      if(player.clubId!==c.id)add('error','club',c.id,id,'player-club-mismatch');
    }
  }
  for(const comp of competitions){
    const ids=comp.participantIds??[];
    if(!Array.isArray(ids)){add('error','competition',comp.id,null,'invalid-participants');continue;}
    const used=new Set();
    for(const id of ids){
      if(used.has(id))add('error','competition',comp.id,id,'duplicate-participant');
      used.add(id);
      if(!clubById.has(id))add(allowPartial?'warning':'error','competition',comp.id,id,'missing-participant');
    }
  }
  return {ok:!issues.some(i=>i.severity==='error'),issues,counts:{clubs:clubs.length,players:players.length,competitions:competitions.length}};
}

/** Historical state is separate from catalog: never propagate current roster into saved career. */
export function compareCareerBoundary(catalog,save){
  const reasons=[];
  if(!catalog||!save||typeof save!=='object') reasons.push('invalid-input');
  if(save?.schemaVersion==null)reasons.push('save-schema-unknown');
  if(save?.careerId==null)reasons.push('save-identity-unknown');
  return {canAutoApply:false,requiresBackup:true,canInspect:reasons.length===0,reasons};
}
