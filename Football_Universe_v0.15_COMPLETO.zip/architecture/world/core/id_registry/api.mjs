/** Explicit IDs/aliases only. Alias ambiguity is preserved as a conflict. */
export function createIdRegistry(records=[],aliases=[]){
 const byId=new Map(),byAlias=new Map();
 for(const r of records){if(!r?.id)throw new Error('record ID required');if(byId.has(r.id))throw new Error(`Duplicate ID: ${r.id}`);byId.set(r.id,r);}
 const entries=Array.isArray(aliases)?aliases:Object.entries(aliases).flatMap(([alias,target])=>[].concat(target).map(id=>({alias,target:id})));
 for(const a of entries){if(!a?.alias||!a?.target)continue;const s=byAlias.get(a.alias)??new Set();s.add(a.target);byAlias.set(a.alias,s);}
 return Object.freeze({byId,byAlias});
}
export function resolveId(registry,value){
 if(registry.byId.has(value))return {status:'EXISTENTE',id:value};
 const targets=[...(registry.byAlias.get(value)??[])].filter(id=>registry.byId.has(id));
 if(targets.length===1)return {status:'EXISTENTE',id:targets[0]};
 if(targets.length>1)return {status:'CONFLITO',reason:'ambiguous-alias',candidates:targets.sort()};
 return {status:'NOVO',id:value};
}
