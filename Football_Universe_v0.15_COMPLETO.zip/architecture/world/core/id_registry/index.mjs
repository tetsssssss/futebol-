export const normalizeName = (value='') => String(value).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/\b(fc|sc|cf|ac|clube|club|futebol|football|sociedade|esporte|de|da|do|the)\b/g,' ').replace(/[^a-z0-9]+/g,' ').trim().replace(/\s+/g,' ');
export const countryOf = item=>item.country??item.nationality??'';
export const nameCountryKey = item=>`${normalizeName(item.name)}|${countryOf(item)}`;
export const identityKey = item=>`${nameCountryKey(item)}|${item.born??''}`;
export function indexRecord(reg,item){
  if(!item?.id || reg.byId.has(item.id))throw new Error(`ID duplicado na base: ${item?.id}`);
  for(const [source,id] of Object.entries(item.externalIds??{})){
    const key=`${source}:${id}`;
    if(reg.byExternal.has(key) && reg.byExternal.get(key).id!==item.id)throw new Error(`ID externo duplicado ${key}`);
  }
  reg.byId.set(item.id,item);
  for(const [source,id] of Object.entries(item.externalIds??{}))reg.byExternal.set(`${source}:${id}`,item);
  const key=identityKey(item);
  reg.byIdentity.set(key,[...(reg.byIdentity.get(key)??[]),item]);
  const nameKey=nameCountryKey(item);
  reg.byNameCountry.set(nameKey,[...(reg.byNameCountry.get(nameKey)??[]),item]);
}
export function createRegistry(items=[]) {
  const reg={byId:new Map(),byExternal:new Map(),byIdentity:new Map(),byNameCountry:new Map()};
  for(const item of items)indexRecord(reg,item);
  return reg;
}
export function identifyCandidate(incoming, registry, kind='club') {
  const direct=registry.byId.get(incoming.id);
  if(direct){
    const sameIdentity=normalizeName(direct.name)===normalizeName(incoming.name) && countryOf(direct)===countryOf(incoming);
    return sameIdentity ? {status:'EXISTENTE',match:direct,reason:'exact-id'} : {status:'CONFLITO',reason:'id-used-by-different-entity',candidates:[direct.id]};
  }
  const externalMatches=[...new Set(Object.entries(incoming.externalIds??{}).map(([k,v])=>registry.byExternal.get(`${k}:${v}`)).filter(Boolean))];
  if(externalMatches.length>1)return {status:'CONFLITO',reason:'multiple-external-ids',candidates:externalMatches.map(x=>x.id)};
  if(externalMatches.length===1)return {status:'EXISTENTE',match:externalMatches[0],reason:'external-id'};
  const potential=registry.byIdentity.get(identityKey(incoming))??[];
  if(potential.length)return {status:'CONFLITO',reason:'identity-similar',candidates:potential.map(x=>x.id)};
  if(kind==='player'&&!incoming.born)return {status:'CONFLITO',reason:'missing-birth-date'};
  const colliding=registry.byNameCountry.get(nameCountryKey(incoming))??[];
  if(colliding.length)return {status:'CONFLITO',reason:'possible-duplicate',candidates:colliding.map(x=>x.id)};
  return {status:'NOVO',reason:'unmatched'};
}
