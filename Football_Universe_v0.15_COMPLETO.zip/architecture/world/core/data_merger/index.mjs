import {createRegistry,identifyCandidate,indexRecord,normalizeName} from '../id_registry/index.mjs';
import {validateDataset} from '../validation/index.mjs';
import {auditReferences} from '../referential_integrity/index.mjs';
const protectedFields=new Set(['id','clubId','playerIds','participantIds','leagueId','attributes','attrs','overall','potential','form','condition','photo','faceAsset','crest','saves','career','transfers','history','stats','fixtures','contract','contractEnd','clubIds','kits']);
const ignoreMetadata=new Set(['provenance','externalIds']);
const same=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
const categories=[['clubs','club'],['players','player'],['competitions','competition']];

/** Conservative dry-run only; remaps staging aliases to actual base IDs. */
export function planMerge(base,addition,{allowUnsafeBase=false}={}) {
  const baselineProblems=validateDataset(base,{strictLinks:!allowUnsafeBase});
  const expansionProblems=validateDataset(addition,{strictLinks:false});
  if(baselineProblems.length||expansionProblems.length)return {ok:false,mode:'DRY_RUN_ONLY',errors:{base:baselineProblems,addition:expansionProblems},changes:[],summary:{NOVO:0,EXISTENTE:0,CONFLITO:0}};
  const changes=[],aliases={clubs:Object.create(null),players:Object.create(null),competitions:Object.create(null)},warnings=[];
  for(const [entity,kind] of categories){
    const reg=createRegistry(base[entity]??[]);
    for(const item of addition[entity]??[]){
      const incoming=structuredClone(item);
      if(entity==='players' && Object.hasOwn(aliases.clubs,incoming.clubId))incoming.clubId=aliases.clubs[incoming.clubId];
      if(entity==='competitions' && incoming.participantIds) incoming.participantIds=incoming.participantIds.map(id=>Object.hasOwn(aliases.clubs,id)?aliases.clubs[id]:id);
      const result=identifyCandidate(incoming,reg,kind);
      if(result.status==='CONFLITO'){
        changes.push({entity,id:incoming.id,status:'CONFLITO',reason:result.reason,candidates:result.candidates??[]});continue;
      }
      if(result.status==='NOVO'){
        const ch={entity,id:incoming.id,status:'NOVO',reason:result.reason,record:incoming};
        changes.push(ch);
        indexRecord(reg,incoming);
        continue;
      }
      const target=result.match,patch={},conflicts=[],ignoredDifferences=[];
      if(entity==='players' && incoming.born && target.born && incoming.born!==target.born)conflicts.push({field:'born',reason:'identity-birth-mismatch'});
      if(entity==='players' && incoming.nationality!==target.nationality)conflicts.push({field:'nationality',reason:'identity-nationality-mismatch'});
      if(result.reason==='external-id' && (normalizeName(incoming.name)!==normalizeName(target.name) || (incoming.country??incoming.nationality)!==(target.country??target.nationality)))conflicts.push({field:'identity',reason:'external-id-vs-name-or-country'});
      for(const [k,v] of Object.entries(incoming)){
        if(k==='id'||ignoreMetadata.has(k)||v===null||v===undefined)continue;
        if(target[k]===undefined||target[k]===null||target[k]===''){
          if(!protectedFields.has(k))patch[k]=structuredClone(v);
          else conflicts.push({field:k,reason:'protected-field-even-if-blank'});
        } else if(!same(target[k],v)){
          if(protectedFields.has(k))conflicts.push({field:k,reason:'protected-field-difference'});
          else ignoredDifferences.push(k);
        }
      }
      changes.push({entity,id:incoming.id,existingId:target.id,status:conflicts.length?'CONFLITO':'EXISTENTE',reason:result.reason,patch,conflicts,ignoredDifferences});
      if(!conflicts.length)aliases[entity][incoming.id]=target.id;
    }
  }
  // Update new club -> new/player existing IDs where the mapping is unambiguous.
  for(const ch of changes.filter(x=>x.entity==='clubs'&&x.status==='NOVO'&&Array.isArray(x.record.playerIds))){
    ch.record.playerIds=ch.record.playerIds.map(id=>Object.hasOwn(aliases.players,id)?aliases.players[id]:id);
  }
  const invalidClubs=new Set(changes.filter(x=>x.entity==='clubs'&&x.status==='CONFLITO').map(x=>x.id));
  const newClubs=new Set(changes.filter(x=>x.entity==='clubs'&&x.status==='NOVO').map(x=>x.record.id));
  const knownClubs=new Set([...(base.clubs??[]).map(x=>x.id),...newClubs]);
  for(const ch of changes.filter(x=>x.entity==='players'&&x.status==='NOVO')){
    if(ch.record.clubId!==null&&(!knownClubs.has(ch.record.clubId)||invalidClubs.has(ch.record.clubId))){
      ch.status='CONFLITO';ch.reason='club-not-in-candidate-dataset';delete ch.record;
    }
  }
  for(const ch of changes.filter(x=>x.entity==='competitions'&&x.status==='NOVO')){
    if((ch.record.participantIds??[]).some(id=>!knownClubs.has(id)||invalidClubs.has(id))){ch.status='CONFLITO';ch.reason='participant-not-in-candidate-dataset';delete ch.record;}
    else if(new Set(ch.record.participantIds??[]).size!==(ch.record.participantIds??[]).length){ch.status='CONFLITO';ch.reason='participant-alias-duplicate';delete ch.record;}
  }
  const playerIds=new Set([...(base.players??[]).map(x=>x.id),...changes.filter(x=>x.entity==='players'&&x.status==='NOVO').map(x=>x.record.id)]);
  for(const ch of changes.filter(x=>x.entity==='clubs'&&x.status==='NOVO'))if((ch.record.playerIds??[]).some(id=>!playerIds.has(id))){ch.status='CONFLITO';ch.reason='player-not-in-candidate-dataset';delete ch.record;}
  // Prevent unsafe partial export, including missing clubs caused by an earlier conflict.
  if(changes.some(x=>x.status==='CONFLITO'))warnings.push('Conflitos bloqueiam a exportação automática das adições.');
  for(const ch of changes.filter(x=>x.entity==='players'&&x.status==='NOVO')){
    const c=(base.clubs??[]).find(x=>x.id===ch.record.clubId);
    if(c && Array.isArray(c.playerIds) && !c.playerIds.includes(ch.record.id))warnings.push(`Jogador ${ch.id}: vínculo bidirecional com clube ${c.id} precisará de revisão.`);
  }
  const summary={NOVO:0,EXISTENTE:0,CONFLITO:0};changes.forEach(x=>summary[x.status]++);
  const candidate={clubs:[...base.clubs,...changes.filter(c=>c.entity==='clubs'&&c.status==='NOVO').map(c=>c.record)],players:[...base.players,...changes.filter(c=>c.entity==='players'&&c.status==='NOVO').map(c=>c.record)],competitions:[...base.competitions,...changes.filter(c=>c.entity==='competitions'&&c.status==='NOVO').map(c=>c.record)]};
  const links=auditReferences(candidate,{allowPartial:allowUnsafeBase});
  if(!links.ok)warnings.push('Referências resultantes precisam de reparo antes da integração.');
  return {ok:true,mode:'DRY_RUN_ONLY',basePriority:true,changes,summary,aliases,warnings,referenceAudit:links};
}
// Export is still a proposal, not a mutation of the original project or career save.
export function exportAdditions(plan){
  if(!plan.ok||plan.changes.some(c=>c.status==='CONFLITO')||plan.referenceAudit?.ok===false)throw new Error('Plano possui conflitos de identidade ou referência');
  const data={clubs:[],players:[],competitions:[]};
  for(const c of plan.changes)if(c.status==='NOVO')data[c.entity].push(structuredClone(c.record));
  return data;
}
