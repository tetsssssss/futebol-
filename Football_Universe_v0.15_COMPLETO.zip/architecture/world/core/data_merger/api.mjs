import {planMerge} from './index.mjs';
/** Dry-run planning only. Fixture datasets are never eligible for merge review. */
export function createMergePlan(base,additions,{fixtureOnly=false,aliases=[]}={}){
 if(fixtureOnly)return {ok:false,mode:'DRY_RUN_ONLY',autoApply:false,errors:{addition:['fixture-only dataset rejected']},changes:[],summary:{NOVO:0,EXISTENTE:0,CONFLITO:0}};
 const aliasMap=Object.create(null);
 for(const a of aliases){if(!a?.sourceId||!a?.targetId)continue;aliasMap[a.sourceId]=a.targetId;}
 const rewritten=structuredClone(additions);
 for(const c of rewritten.clubs??[])if(aliasMap[c.id])c.id=aliasMap[c.id];
 for(const p of rewritten.players??[])if(aliasMap[p.clubId])p.clubId=aliasMap[p.clubId];
 for(const c of rewritten.clubs??[])c.playerIds=(c.playerIds??[]).map(id=>aliasMap[id]??id);
 for(const c of rewritten.competitions??[])c.participantIds=(c.participantIds??[]).map(id=>aliasMap[id]??id);
 const plan=planMerge(base,rewritten);
 return {...plan,autoApply:false,mode:'DRY_RUN_ONLY'};
}
