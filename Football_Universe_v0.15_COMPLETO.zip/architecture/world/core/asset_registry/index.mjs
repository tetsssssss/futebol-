import {posix as path} from 'node:path';
const ID=/^[A-Za-z0-9][A-Za-z0-9_.:-]{0,119}$/;
const SHA=/^[a-f0-9]{64}$/i;
/** Catalogs existing authorized media. No image download and no identity guess. */
export function buildAssetRegistry(records,{maxThumbnailBytes=90_000}={}){
  if(!Array.isArray(records)||!Number.isInteger(maxThumbnailBytes)||maxThumbnailBytes<1000)throw new Error('Registry arguments invalid');
  const assets=[],issues=[],ids=new Set(),paths=new Set(),hashes=new Map();
  for(const [i,r] of records.entries()){
    const p=`records[${i}]`;
    if(!r || typeof r!=='object'||!ID.test(r.entityId??'' )||!['club','player','competition','national_team'].includes(r.kind)) {issues.push(`${p}: entity identification invalid`);continue;}
    if(typeof r.path!=='string'||r.path.startsWith('/')||/^[a-z][a-z0-9+.-]*:/i.test(r.path)||r.path.includes('\\')||r.path.split('/').includes('..')||!['.webp','.png','.jpeg','.jpg'].includes(path.extname(r.path).toLowerCase())||r.path.includes('?')||r.path.includes('#')) {issues.push(`${p}: unsafe local image path`);continue;}
    if(typeof r.source!=='string'||!r.source.trim()||typeof r.license!=='string'||!r.license.trim()||!SHA.test(r.sha256??'')) {issues.push(`${p}: source/license/sha256 required`);continue;}
    const key=`${r.kind}:${r.entityId}:${r.variant??'thumb'}`;
    if(ids.has(key)){issues.push(`${p}: repeated variant ${key}`);continue;}
    if(paths.has(r.path)){issues.push(`${p}: repeated filename ${r.path}`);continue;}
    if(hashes.has(r.sha256)&&hashes.get(r.sha256)!==key){issues.push(`${p}: matching image hash for multiple entities; review identity`);continue;}
    if(!Number.isInteger(r.bytes)||r.bytes<=0){issues.push(`${p}: invalid media size`);continue;}
    if((r.variant??'thumb')==='thumb'&&r.bytes>maxThumbnailBytes)issues.push(`${p}: exceeds thumbnail budget`);
    ids.add(key);paths.add(r.path);hashes.set(r.sha256,key);
    assets.push({...structuredClone(r),variant:r.variant??'thumb',cachePolicy:'on-demand'});
  }
  return {ok:issues.length===0,issues,assets,summary:{count:assets.length,bytes:assets.reduce((n,r)=>n+r.bytes,0)}};
}
export function makeLazyMediaMap(registry,{fallback='assets/placeholders/player.webp'}={}){
  if(!registry?.ok)throw new Error('Asset registry has issues');
  const map={};
  for(const asset of registry.assets){const k=`${asset.kind}:${asset.entityId}`;
    map[k]??={fallback,variants:{}};
    map[k].variants[asset.variant]=asset.path;
  }
  return map;
}
