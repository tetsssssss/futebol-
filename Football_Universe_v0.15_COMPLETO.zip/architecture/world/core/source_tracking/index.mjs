export function provenance({source,season,retrievedAt=new Date().toISOString().slice(0,10),reliability='unverified',license='unknown',notes=''}) {
  if(!source || !season || !/^\d{4}-\d{2}-\d{2}$/.test(retrievedAt)) throw new Error('Metadados de proveniência insuficientes');
  return {source,season:String(season),retrievedAt,reliability,license,notes};
}
