import {readFile,writeFile,stat} from 'node:fs/promises';import {resolve} from 'node:path';import {pathToFileURL} from 'node:url';import {createHash} from 'node:crypto';
import {snapshotV015,hashSnapshot} from '../integration/adapters/v015.mjs';
import {validateWorldSnapshot} from '../core/validation/index.mjs';
import {createMergePlan} from '../core/data_merger/api.mjs';
import {validateEdition} from '../engines/edition_rules/index.mjs';
import {buildAssetRegistry} from '../core/asset_registry/index.mjs';
import {buildHandoff,evaluateHandoffGates} from '../integration/handshake/index.mjs';
export async function writeReportExclusive(path,data){await writeFile(path,JSON.stringify(data,null,2)+'\n',{flag:'wx'});}
const readJson=async path=>JSON.parse(await readFile(path,'utf8'));
export async function runCommand(command,args={}){
 if(args.input&&args.output&&resolve(args.input).toLowerCase()===resolve(args.output).toLowerCase())throw new Error('input and output resolve to the same file');
 let report;
 if(command==='snapshot'){const snapshot=await snapshotV015();report={snapshot,sha256:hashSnapshot(snapshot),readOnly:true};}
 else if(command==='validate'){const loaded=args.data??await readJson(args.input);report=validateWorldSnapshot(loaded.snapshot??loaded);}
 else if(command==='merge-plan'){report=createMergePlan(await readJson(args.base),await readJson(args.additions),{fixtureOnly:args.fixtureOnly==='true'});}
 else if(command==='edition-check'){const edition=args.edition?JSON.parse(args.edition):await readJson(args.input);const issues=validateEdition(edition);report={ok:issues.length===0,issues,verification:edition?.verification??null};}
 else if(command==='asset-audit'){const records=await readJson(args.input);const r=buildAssetRegistry(records);const issues=[...r.issues];for(const a of r.assets){const file=resolve(args.root??'.',a.path);try{const bytes=await readFile(file);if(bytes.length!==a.bytes)issues.push(`${a.path}: byte-count mismatch`);if(createHash('sha256').update(bytes).digest('hex')!==a.sha256)issues.push(`${a.path}: hash mismatch`);}catch{issues.push(`${a.path}: missing local file`);}}report={ok:issues.length===0,issues,count:r.assets.length};}
 else if(command==='handoff'){const plan=await readJson(args.input);const handoff=buildHandoff({plan,baseline:{sha256:args.sha256}});report={handoff,gates:evaluateHandoffGates(handoff)};}
 else throw new Error(`unknown command: ${command}`);
 if(args.output)await writeReportExclusive(args.output,report);return report;
}
async function main(argv){const [command,...rest]=argv,args={};for(let i=0;i<rest.length;i++){if(rest[i].startsWith('--'))args[rest[i].slice(2)]=rest[++i]??'true';}const report=await runCommand(command,args);if(!args.output)process.stdout.write(JSON.stringify(report,null,2)+'\n');if(report.ok===false)process.exitCode=1;}
if(process.argv[1]&&import.meta.url===pathToFileURL(resolve(process.argv[1])).href)main(process.argv.slice(2)).catch(e=>{process.stderr.write(`${e.message}\n`);process.exitCode=1;});
