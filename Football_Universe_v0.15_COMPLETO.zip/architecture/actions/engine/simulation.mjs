import {evaluateEligibility} from './resolver.mjs';
import {buildTimeline} from './timeline.mjs';
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
const RISK={none:0,low:0.012,medium:0.028,high:0.05};
const HARD=new Map([
  ['shots.009',0.80],['shots.014',0.82],['shots.020',0.93],['shots.021',0.88],['shots.022',0.96],
  ['dribbles.004',0.78],['dribbles.011',0.91],['crosses.010',0.86],['passes.011',0.86],['passes.012',0.82],
  ['keeper_saves.009',0.88],['keeper_saves.006',0.8]
]);
export function seededRandom(seed){
  if(!Number.isInteger(seed))throw new Error('seed inteira obrigatória');
  let x=(seed>>>0)||0x6d2b79f5;
  return ()=>{x^=(x<<13);x^=(x>>>17);x^=(x<<5);return (x>>>0)/4294967296};
}
const weights={shots:'shooting',dribbles:'dribbling',crosses:'crossing',tackles:'tackling',slides:'tackling',movement:'movement',keeper_exits:'goalkeeping',keeper_saves:'goalkeeping',passes:'passing',gestures:'composure'};
export function estimateAction(action,context){
  const skillKey=weights[action.category];
  if(!skillKey)return {chance:null,energyCost:0,designNote:'Incidente não executável'};
  const attrs=context.actor?.attributes??{};
  // Convenção do módulo: todos os atributos normalizados 0-100; mapeamento do Claude pendente.
  const score=Number(attrs[skillKey]??50);
  const fatigue=Number(context.actor?.fatigue??0); // 0 descansado; 100 exausto
  const pressure=Number(context.pressure??0); // 0 a 100
  const distance=Number(context.distance??0); // 0 a 100, índice de dificuldade, não metros
  const weather=Number(context.weatherImpact??0); // 0 a 100
  for(const [label,value] of Object.entries({score,fatigue,pressure,distance,weather}))if(!Number.isFinite(value)||value<0||value>100)throw new Error(`${label} deve estar entre 0 e 100`);
  const difficult=HARD.get(action.id)??(action.category==='gestures'||action.category==='movement'?0.1:0.48);
  const scorePart=(score/100)*0.61;
  const passive=action.category==='movement'||action.category==='gestures';
  const chance=passive?null:clamp(0.34+scorePart-0.34*difficult-0.13*(pressure/100)-0.11*(fatigue/100)-0.09*(distance/100)-0.06*(weather/100),0.03,0.98);
  const energyCost=+(RISK[action.riskBand]*100*(1+0.3*difficult)).toFixed(2);
  return {chance:chance===null?null:Number(chance.toFixed(4)),energyCost,difficulty:difficult,designNote:'Valores provisórios de game design: não calibração esportiva real'};
}
export function runAction(registry,actionId,context,{seed=1,clipKeys=[]}={}){
  const action=registry.get(actionId);
  if(!action)return {ok:false,errors:['unknown_action'],events:[]};
  const eligibility=evaluateEligibility(action,context);
  if(!eligibility.eligible)return {ok:false,errors:eligibility.errors,events:[]};
  const metrics=estimateAction(action,context);
  const timeline=buildTimeline(action,{availableClips:clipKeys});
  const passive=metrics.chance===null;
  const roll=passive?null:seededRandom(seed)();
  const success=passive?true:roll<metrics.chance;
  // Nenhum estado original é mutado: o motor entrega intenção e eventos para o integrador.
  return {ok:true,success,actionId,roll:roll===null?null:Number(roll.toFixed(6)),metrics,timeline,
    effects:{type:action.ballEffect,disposition:success?'candidate_success':'candidate_failure',requiresHostPhysics:true},
    events:[{type:'ACTION_ATTEMPT',actionId},{type:success?'ACTION_RESOLVED_SUCCESS':'ACTION_RESOLVED_FAILURE',actionId}],
    mutatesGameState:false};
}
