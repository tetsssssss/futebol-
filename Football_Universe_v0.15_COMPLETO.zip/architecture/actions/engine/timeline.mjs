/** Cronograma conceitual de contatos; clipes e rigs reais serão mapeados no código do Claude. */
const TIMING={
  kick:{ms:650,contact:0.48},ball_skill:{ms:740,contact:0.52},stand_tackle:{ms:570,contact:0.46},
  slide_tackle:{ms:900,contact:0.6},locomotion:{ms:650,contact:null},keeper_claim:{ms:820,contact:0.58},
  keeper_save:{ms:750,contact:0.62},gesture:{ms:1300,contact:null},reaction:{ms:1200,contact:null}
};
export function buildTimeline(action,{speed=1,availableClips=[]}={}){
  if(!action)throw new Error('action obrigatório');
  if(typeof speed!=='number'||!Number.isFinite(speed)||speed<=0||speed>3)throw new Error('speed inválida');
  const family=action.animation.family,config=TIMING[family];if(!config)throw new Error('família de animação desconhecida');
  const durationMs=Math.round(config.ms/speed),requestedClip=action.animation.clipKey;
  const clip=requestedClip&&availableClips.includes(requestedClip)?requestedClip:null;
  const noBallContact = action.category==='dribbles' && new Set([12,15,16,17,18,34,35,36,37]).has(action.ordinal);
  const events=[{atMs:0,name:'start'}];
  if(config.contact!==null && !noBallContact)events.push({atMs:Math.round(durationMs*config.contact),name:'contact'});
  events.push({atMs:durationMs,name:'recover'});
  return {actionId:action.id,family,durationMs,clip,needsAnimation:clip===null,events,
          fallback:'placeholder_visual_only',note:'Não significa que animação 2D/3D já exista'};
}
export function eventsReached(timeline,fromMs,toMs){
  if(!timeline||!Number.isFinite(fromMs)||!Number.isFinite(toMs)||toMs<fromMs)throw new Error('intervalo inválido');
  return timeline.events.filter(e=>e.atMs>fromMs && e.atMs<=toMs);
}
