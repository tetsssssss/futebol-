/** Lesões são resultados da simulação, não controles. Não estimar diagnósticos nem tempo real de recuperação. */
export function registerIncident(registry,injuryActionId,{playerId,matchId,minute,source,clinicalDays=null}={}){
  const action=registry.get(injuryActionId);
  if(!action||action.category!=='injuries')throw new Error('ID de lesão inválido');
  if(typeof playerId!=='string'||!playerId||typeof matchId!=='string'||!matchId)throw new Error('playerId/matchId obrigatórios');
  if(!Number.isFinite(minute)||minute<0||minute>150)throw new Error('minuto de partida inválido');
  if(clinicalDays!==null && (!Number.isInteger(clinicalDays)||clinicalDays<0||clinicalDays>3650))throw new Error('clinicalDays inválido');
  if(typeof source!=='string'||!source.trim())throw new Error('fonte obrigatória');
  return {type:'INJURY_INCIDENT',id:action.id,name:action.name,playerId,matchId,minute,source,
    severityBand:action.injury.severityBand,absenceDays:clinicalDays,requiresMedicalAssessment:clinicalDays===null,
    applyToSave:false};
}
