/** Gramática de sequências, ainda sem atualizar posse ou estado do campo. */
const combos=[
 {name:'parada_arrancada',steps:['dribbles.019','dribbles.020'],context:'with_ball'},
 {name:'corte_finalizacao',steps:['dribbles.013','shots.030'],context:'with_ball'},
 {name:'dominio_chute',steps:['dribbles.028','shots.016'],context:'with_ball'},
 {name:'finta_chute',steps:['dribbles.034','shots.001'],context:'with_ball'},
 {name:'puxada_passe',steps:['dribbles.023','passes.001'],context:'with_ball'},
 {name:'finta_cruzamento',steps:['dribbles.036','crosses.001'],context:'with_ball'},
 {name:'tabela_infiltracao',steps:['passes.019','movement.026'],context:'team_cooperation'},
 {name:'corte_passe',steps:['dribbles.014','passes.016'],context:'with_ball'},
 {name:'roubo_passe',steps:['tackles.010','passes.016'],context:'possession_transition'}
];
export function listCombos(registry){return combos.map(c=>({...c,stepNames:c.steps.map(id=>registry.get(id)?.name??null)}))}
export function planCombo(registry,name,context){
 const combo=combos.find(x=>x.name===name);
 if(!combo)throw new Error('combo desconhecido');
 const missing=combo.steps.filter(id=>!registry.has(id));
 if(missing.length)throw new Error('referências não cadastradas: '+missing.join(','));
 return {name,steps:[...combo.steps],mode:'PLANNING_ONLY',autoExecute:false,
  guards:['each_step_requires_host_eligibility','possession_must_be_rechecked','animation_contacts_must_be_confirmed'],
  startCondition:combo.context,hostContextProvided:!!context,
  note:'Planejamento: a saída de uma ação nunca altera implicitamente o estado da próxima.'};
}
