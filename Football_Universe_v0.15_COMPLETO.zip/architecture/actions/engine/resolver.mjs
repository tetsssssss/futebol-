/** Verificações prévias separadas do motor e dos efeitos visuais. */
const stages = new Set(['play','penalty','free_kick','celebration','stoppage']);
const controlled = new Set(['controlled']);
const hasOpponent = new Set(['opponent','contested']);
const loose = new Set(['loose','opponent','contested']);
const restrictedWhenStopped = new Set(['shots','dribbles','crosses','tackles','slides','passes','keeper_exits','keeper_saves']);

export function evaluateEligibility(action,context={}){
  const errors=[];
  if(!action)return {eligible:false,errors:['unknown_action']};
  if(action.type==='incident')return {eligible:false,errors:['injury_is_incident_not_action']};
  if(context.actor?.role===undefined)errors.push('missing_actor_role');
  const actor=context.actor?.role;
  if(action.requires.actor==='goalkeeper' && actor!=='goalkeeper')errors.push('goalkeeper_required');
  const stage=context.phase??'play';
  if(!stages.has(stage))errors.push('invalid_match_phase');
  if(action.requires.phase!=='any'&&action.requires.phase!==stage)errors.push(`phase_required:${action.requires.phase}`);
  if(restrictedWhenStopped.has(action.category)&&['stoppage','celebration'].includes(stage))errors.push('ball_out_of_play');
  const ball=context.ball?.state;
  switch(action.requires.ball){
    case 'controlled': if(!controlled.has(ball))errors.push('ball_control_required'); break;
    case 'opponent': if(!hasOpponent.has(ball))errors.push('opponent_or_contested_ball_required');break;
    case 'loose_or_opponent': if(!loose.has(ball))errors.push('loose_or_opponent_ball_required');break;
    case 'incoming_shot':if(ball!=='incoming_shot')errors.push('incoming_shot_required');break;
  }
  if(action.requires.contact==='airborne' && context.ball?.height!=='airborne')errors.push('airborne_ball_required');
  if(context.actor?.unavailable===true)errors.push('actor_unavailable');
  if(context.actor?.fatigue===undefined)errors.push('fatigue_missing');
  return {eligible:errors.length===0,errors};
}

export function selectEligible(registry,context,category){
  return registry.list({category,selectable:true}).filter(a=>evaluateEligibility(a,context).eligible);
}
