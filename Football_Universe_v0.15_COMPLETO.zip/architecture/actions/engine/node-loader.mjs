import {readFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {dirname,resolve} from 'node:path';
const catalogPath=resolve(dirname(fileURLToPath(import.meta.url)),'../catalog/actions.257.json');
export async function loadActionCatalog(){return JSON.parse(await readFile(catalogPath,'utf8'));}
