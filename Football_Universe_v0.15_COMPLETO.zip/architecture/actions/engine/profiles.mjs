/**
 * Intenções cinemáticas e táticas, NÃO trajetórias físicas completas.
 * Parâmetros relativos (0..1) para adapters, nunca afirmar resultado de física/gol/falta.
 */
const SHOTS=[
 ['placed','inner','mid','near_post'],['ground_cross','instep','low','far_post'],
 ['placed_near','inner','mid','near_post'],['placed_far','inner','mid','far_post'],
 ['power_instep','instep','mid','center'],['power_low','instep','low','center'],
 ['half_height','instep','mid','center'],['chip','instep','lofted','over_keeper'],
 ['panenka','instep','lofted','center'],['trivela','outer','mid','far_post'],
 ['dipping','instep','high','center'],['inward_curve','inner','mid','far_post'],
 ['outward_curve','outer','mid','far_post'],['knuckle','instep','high','center'],
 ['first_touch','instep','mid','center'],['after_first_control','instep','mid','center'],
 ['volley_frontal','instep','mid','center'],['volley_side','instep','mid','center'],
 ['half_volley','instep','mid','center'],['bicycle','instep','high','center'],
 ['half_bicycle','instep','mid','center'],['scorpion','heel','high','center'],
 ['heel','heel','low','center'],['toe_poke','toe','low','center'],
 ['weak_foot','instep','mid','center'],['spinning_body','instep','mid','center'],
 ['long_range','instep','high','center'],['close_range','instep','low','center'],
 ['free_kick_wall','inner','high','upper_corner'],['cut_inside','instep','mid','far_post']
];
const GROUNDED=new Set(['low','ground']);
const PHYSICS=new Set(['shots','crosses','passes']);
const TACTICAL=new Set(['movement','gestures']);
const TOUGH=['slides','tackles'];
const CROSSES={3:{delivery:'cutback',height:'low',target:'edge_of_box'},6:{delivery:'driven',height:'low',target:'six_yard_box'},8:{delivery:'early',height:'high'},9:{delivery:'trivela',spin:'outside'},10:{delivery:'rabona'},14:{delivery:'inswing',spin:'inward'},15:{delivery:'outswing',spin:'outward'},18:{delivery:'floating',height:'high'}};
const PASSES={1:{delivery:'short',surface:'inner'},4:{delivery:'long',height:'high'},6:{delivery:'through',height:'low'},7:{delivery:'through',height:'high'},9:{delivery:'heel'},10:{delivery:'trivela'},11:{delivery:'rabona'},12:{delivery:'behind_standing_leg'},15:{delivery:'switch_play',height:'high'},16:{delivery:'line_break'},19:{delivery:'one_two'},23:{delivery:'header'},24:{delivery:'chest'},27:{delivery:'no_look'},29:{delivery:'line_break'},30:{delivery:'counterattack_long',height:'high'}};
export function actionProfile(action){
  if(!action)throw new Error('ação obrigatória');
  const p={id:action.id,variant:action.variant,category:action.category,
    family:action.animation.family,ballEffect:action.ballEffect,
    visualBindingRequired:action.animation.clipKey===null,
    confidence:'design_estimate_only',notRealPhysics:true};
  if(action.category==='shots'){
    const row=SHOTS[action.ordinal-1]; if(!row)throw new Error('perfil de chute não encontrado');
    return {...p,kind:'ball_launch',technique:row[0],surface:row[1],height:row[2],target:row[3],
       spin:['trivela','inward_curve','outward_curve','dipping','knuckle'].includes(row[0])?row[0]:'standard',
       ballisticInterface:{origin:'ball_contact',velocity:'host_required',gravity:'host_required',collision:'host_required'}};
  }
  if(action.category==='crosses')return {...p,kind:'ball_launch',delivery:'cross',height:'high',target:'penalty_area',...CROSSES[action.ordinal]};
  if(action.category==='passes')return {...p,kind:'ball_launch',delivery:'short',height:'low',target:'teammate',...PASSES[action.ordinal]};
  if(action.category==='dribbles')return {...p,kind:'ball_control',footContact:'multi_touch',possessionExpected:true,bodyFeint:action.variant.includes('finta')};
  if(TOUGH.includes(action.category))return {...p,kind:'duel',surface:action.category==='slides'?'slide':'standing',refereeCheckRequired:true,foulResolvedByHost:true};
  if(action.category==='movement')return {...p,kind:action.type==='tactic'?'tactical_intent':'locomotion',requiresNavmesh:action.type==='tactic',motionStyle:action.variant};
  if(action.category==='keeper_exits')return {...p,kind:'keeper_interception',collisionRequired:true,handsAllowed:'host_rules_only'};
  if(action.category==='keeper_saves')return {...p,kind:'keeper_reaction',incomingShotRequired:true,handsAllowed:'host_rules_only'};
  if(action.category==='gestures')return {...p,kind:'presentation',noBallCollision:true,overlaySafe:true};
  if(action.category==='injuries')return {...p,kind:'incident',bodyRegion:action.injury.bodyRegion,
      requiresMedicalAssessment:true,generatedByPlayerControl:false};
  throw new Error('categoria desconhecida');
}
export function summarizeProfiles(registry){
  const count={};for(const a of registry.list()){const t=actionProfile(a);count[t.kind]=(count[t.kind]??0)+1};return count;
}
