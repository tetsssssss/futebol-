/** Registro puro, sem mutação da fonte e sem I/O: navegadores podem injetar JSON por import/fetch. */
export const REQUIRED_COUNTS = Object.freeze({shots:30,dribbles:40,crosses:20,tackles:10,slides:10,movement:35,keeper_exits:10,keeper_saves:12,passes:30,gestures:30,injuries:30});
const allowedKinds = new Set(['animation','tactic','presentation','incident']);
const phases = new Set(['any','play','penalty','free_kick','celebration','stoppage']);
const balls = new Set(['controlled','opponent','loose_or_opponent','incoming_shot','any']);
const contactTypes=new Set(['any','airborne']);
export function validateCatalog(catalog){
  const errors=[];
  if(!catalog || typeof catalog!=='object'|| !Array.isArray(catalog.actions)) return {ok:false,errors:['catálogo sem array actions']};
  if(catalog.schemaVersion!=='football-universe-actions-v1')errors.push('schemaVersion incompatível');
  const ids=new Set(), names=new Set(), got={};
  for(const action of catalog.actions){
    if(!action||typeof action!=='object'){errors.push('item inválido');continue}
    const {id,ordinal,name,category,type,requires,animation}=action;
    if(typeof id!=='string'|| !/^[a-z_]+\.\d{3}$/.test(id))errors.push(`id inválido: ${id}`);
    if(ids.has(id))errors.push(`id duplicado: ${id}`);ids.add(id);
    if(!Object.hasOwn(REQUIRED_COUNTS,category))errors.push(`categoria inválida: ${category}`);
    else {got[category]=(got[category]??0)+1;const expectedId=`${category}.${String(ordinal).padStart(3,'0')}`;if(id!==expectedId)errors.push(`id/ordinal: ${id}`)}
    if(typeof name!=='string'||!name.trim())errors.push(`nome inválido: ${id}`);
    const key=`${category}|${name?.normalize?.('NFC').toLocaleLowerCase('pt-BR')}`;
    if(names.has(key))errors.push(`nome duplicado: ${id}`);names.add(key);
    if(!allowedKinds.has(type))errors.push(`tipo inválido: ${id}`);
    if(!requires||!['goalkeeper','any'].includes(requires.actor)||!balls.has(requires.ball)||!phases.has(requires.phase)||!contactTypes.has(requires.contact))errors.push(`requisitos inválidos: ${id}`);
    if(!animation || typeof animation.family!=='string'||typeof animation.implemented!=='boolean'||!Array.isArray(animation.markers))errors.push(`animação inválida: ${id}`);
    if(action.category==='injuries' && (type!=='incident'||action.ai?.selectable!==false||!action.injury?.medicalReviewRequired))errors.push(`lesão deve ser incidente: ${id}`);
    if(action.category!=='injuries'&&type==='incident')errors.push(`evento inesperado: ${id}`);
  }
  for(const [key,count] of Object.entries(REQUIRED_COUNTS))if(got[key]!==count)errors.push(`categoria ${key}: ${got[key]??0}/${count}`);
  if(catalog.actions.length!==257)errors.push(`contagem total: ${catalog.actions.length}/257`);
  if(!Array.isArray(catalog.categories)||catalog.categories.length!==11)errors.push('índice de categorias incompleto');
  return {ok:!errors.length,errors,stats:{total:catalog.actions.length,byCategory:got,selectable:catalog.actions.filter(a=>a.ai?.selectable).length}};
}
export function createRegistry(catalog){
  const report=validateCatalog(catalog);if(!report.ok)throw new Error(`Catálogo inválido: ${report.errors.join('; ')}`);
  const byId=new Map(catalog.actions.map(x=>[x.id,structuredClone(x)]));
  const list=Object.freeze([...byId.values()]);
  return Object.freeze({version:catalog.catalogVersion,count:list.length,
    get(id){const action=byId.get(id);return action?structuredClone(action):null},
    has(id){return byId.has(id)},
    list({category,type,selectable}={}){return list.filter(x=>(!category||x.category===category)&&(!type||x.type===type)&&(selectable===undefined||x.ai.selectable===selectable)).map(item=>structuredClone(item))},
    categories(){return Object.keys(REQUIRED_COUNTS)}
  });
}
export function createActionRegistry(catalog){
 const raw=createRegistry(catalog);
 const freeze=(value)=>{if(value&&typeof value==='object'&&!Object.isFrozen(value)){Object.freeze(value);for(const child of Object.values(value))freeze(child);}return value;};
 return Object.freeze({size:raw.count,ids:()=>raw.list().map(x=>x.id),get:(id)=>{const value=raw.get(id);return value?freeze(value):null;},list:(filters)=>raw.list(filters).map(freeze)});
}
