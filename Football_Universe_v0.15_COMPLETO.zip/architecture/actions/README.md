# CP017–CP024 — catálogo de ações

`catalog/actions.257.json` e o esquema fornecido são carregados pelo registro validado em `engine/registry.mjs`. A camada `integration/` adapta atributos/contexto v0.15 e retorna somente elegibilidade, intenção e marcadores. `treinador/match-engine.js` permanece a autoridade única de resultado; esta integração não altera decisões, RNG, eventos, disponibilidade nem saves.

O treinador carrega o catálogo validado no navegador e observa, em memória volátil, as categorias dos passes, dribles/conduções, cruzamentos, finalizações, desarmes e lesões já resolvidos pelo motor. Os registros nativos, placares, RNG e saves permanecem inalterados. As animações de catálogo ainda não são selecionadas por IDs específicos. Lesão é classificada como incidente, sem diagnóstico anatômico, gravidade ou afastamento inferido.

Os 227 tipos de ação e 30 definições de incidente estão disponíveis para consulta. Todos os perfis são estimativas declaradas, não física calibrada. Sem clipe concreto, a timeline informa `implemented: false`. Incidentes de lesão descrevem metadados e não estimam afastamento ou gravam disponibilidade.

```js
import {loadActionCatalog} from './engine/node-loader.mjs';
import {createActionRegistry} from './engine/registry.mjs';
const registry=createActionRegistry(await loadActionCatalog());
```
