/** Adaptador dry-run: never mutate player/game/save. */
export const ACTIONS_COMPATIBILITY_VERSION='football-universe-actions-v1';
export function checkGameAdapter({catalog,host={}}={}){
  const blockers=[];
  if(catalog?.schemaVersion!==ACTIONS_COMPATIBILITY_VERSION)blockers.push('catalog_schema');
  if(typeof host.engineVersion!=='string'||!host.engineVersion)blockers.push('engine_version_missing');
  if(typeof host.resolvePlayerAttribute!=='function')blockers.push('attribute_adapter_missing');
  if(typeof host.resolveAnimationClip!=='function')blockers.push('animation_adapter_missing');
  if(typeof host.commitMatchEvent!=='function')blockers.push('match_event_adapter_missing');
  if(typeof host.saveStateVersion!=='string'||!host.saveStateVersion)blockers.push('save_schema_unverified');
  return {format:'football-universe-action-adapter-v1',mode:'DRY_RUN_ONLY',autoApply:false,ready:!blockers.length,
     blockers,excludedFromSave:['catalog','animationMetadata','pendingAttempts'],preserveExistingIds:true};
}
export function planActionBinding(registry,hostBindings={}){
  const assignments=[],missingClips=[],warnings=[];
  for(const action of registry.list()){
    const actual=hostBindings[action.id];
    if(actual===undefined){missingClips.push(action.id);continue}
    if(typeof actual!=='string'||!actual.trim())warnings.push(`${action.id}: clipe inválido`);
    else assignments.push({id:action.id,proposedClip:actual,applied:false});
  }
  return {mode:'DRY_RUN_ONLY',autoApply:false,assignments,missingClips,warnings,baseSourceRequired:true};
}
