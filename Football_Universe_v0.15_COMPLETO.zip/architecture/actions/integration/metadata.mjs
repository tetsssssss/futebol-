import {actionProfile} from '../engine/profiles.mjs';
import {buildTimeline} from '../engine/timeline.mjs';
import {registerIncident} from '../engine/incidents.mjs';
export const getActionProfile=(registry,id)=>{const action=registry.get(id);return action?actionProfile(action):null;};
export const createVisualTimeline=(registry,id,context={})=>{const action=registry.get(id);if(!action)return null;const time=buildTimeline(action,{speed:context.speed??1,availableClips:context.availableClips??[]});return {...time,implemented:!!time.clip};};
export const describeIncident=(registry,id,context)=>registerIncident(registry,id,context);
