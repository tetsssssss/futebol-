/** Validate action eligibility and return intent metadata only; the host engine resolves all outcomes. */
export function dispatchAction(registry,context,actionId){
 const action=registry?.get?.(actionId);
 if(!context?.accepted)return {accepted:false,reason:context?.reason??'context-rejected'};
 if(!action)return {accepted:false,reason:'unknown-action'};
 const r=action.requires??{};
 if(r.phase&&r.phase!=='any'&&r.phase!==context.phase)return {accepted:false,reason:'phase-mismatch'};
 if(r.ball&&r.ball!=='any'&&r.ball!==context.ballState&&!(r.ball==='loose_or_opponent'&&context.ballState==='opponent'))return {accepted:false,reason:'ball-state-mismatch'};
 if(r.ball==='controlled'&&!context.actorControlsBall)return {accepted:false,reason:'actor-does-not-control-ball'};
 if(r.contact==='airborne'&&context.contact!=='airborne')return {accepted:false,reason:'airborne-contact-required'};
 if(r.actor==='goalkeeper'&&context.actor?.position!=='GK')return {accepted:false,reason:'goalkeeper-required'};
 return {accepted:true,intent:{actionId:action.id,category:action.category,type:action.type,variant:action.variant},markers:[...(action.animation?.markers??[])],outcomeAuthority:'v015-match-engine',commitEvent:false,persistActionId:false};
}
