import {classifyHostAction} from './host-events.mjs';

let registry=null;
const timeline=new WeakMap();
export function configureActionRuntime(value){registry=value??null;}
export function observeHostAction(match,event){
 const classified=classifyHostAction(event);if(!classified||!match||typeof match!=='object')return null;
 const actionIds=registry?.list?.({category:classified.category}).map(x=>x.id)??[];
 const observation=Object.freeze({...classified,availableActionIds:Object.freeze(actionIds),observedAt:{minute:match.minute??null,time:match.time??null}});
 const items=timeline.get(match)??[];items.push(observation);if(items.length>500)items.shift();timeline.set(match,items);
 return observation;
}
export function readActionObservations(match){return (timeline.get(match)??[]).map(x=>({...x,availableActionIds:[...x.availableActionIds],observedAt:{...x.observedAt}}));}
