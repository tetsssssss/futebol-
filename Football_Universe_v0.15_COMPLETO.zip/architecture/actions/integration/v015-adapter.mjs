const ALLOWED=new Set(['firstTouch','shortPass','longPass','finishing','dribbling','crossing','heading','tackling','marking','technique','ballControl','volleys','weakFoot','pace','acceleration','agility','balance','strength','stamina','jumping','coordination','naturalFitness','decisions','anticipation','composure','concentration','vision','offBall','workRate','bravery','determination','leadership','positioning','pressing','transition','compactness','spaceReading','overlapping','defensiveCover','tempoControl','roleDiscipline','ambition','professionalism','discipline','loyalty','temperament','teamwork','competitive','reflexes','handling','oneOnOnes','aerialReach','command','distribution','kicking','freeKicks','penalties','corners','longThrows','charisma','lockerRoom','coachTrust','language','adaptability','cultural','domestic','international','injuryResistance','consistency','pressureHandling']);
export function resolveMappedAttribute(player,key){if(!ALLOWED.has(key))return null;const n=player?.attrs?.[key];return Number.isFinite(n)&&n>=0&&n<=100?n:null;}
export function toActionContext(match,side,actorId){
 const reject=reason=>({accepted:false,reason});
 if(!match||!Array.isArray(match.squads)||![0,1].includes(side)||!match.ball)return reject('invalid-match-context');
 if(match.finished)return reject('match-finished');
 const squad=match.squads[side],index=squad?.playing?.findIndex(p=>p.id===actorId)??-1,actor=squad?.playing?.[index];
 if(!actor||actor.dismissed)return reject('actor-not-active');
 const opponents=match.squads[1-side]?.playing??[];
 const distance=(a,b)=>Math.hypot((a.x-b.x)*1.05,(a.y-b.y)*.68);
 const pressure=opponents.filter(p=>!p.dismissed).reduce((n,p)=>n+(distance(p,actor)<8?1:0),0);
 const phase=match.penalties||match.restart?.kind==='penalty'?'penalty':match.restart?.kind==='freeKick'?'free_kick':match.restart?'stoppage':match.events?.at(-1)?.type==='goal'?'celebration':'play';
 const ballState=match.action?.kind==='shot'?'incoming_shot':match.action?.kind==='loose'?'loose_or_opponent':match.possession===side?'controlled':'opponent';
 return Object.freeze({accepted:true,actor:Object.freeze({id:actor.id,position:actor.position,attrs:Object.freeze(structuredClone(actor.attrs??{}))}),actorControlsBall:match.possession===side&&index===match.carrier,ball:Object.freeze({x:match.ball.x,y:match.ball.y,z:match.ball.z??0}),phase,ballState,contact:match.ball.z>0?'airborne':'any',pressure,distance:distance(actor,match.ball),weatherImpact:null});
}
