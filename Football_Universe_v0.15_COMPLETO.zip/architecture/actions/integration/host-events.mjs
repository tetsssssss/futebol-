const EVENT_CATEGORY=Object.freeze({shot:'shots',cross:'crosses',pass:'passes',distribution:'passes',dribble:'dribbles',carry:'movement',tackle:'tackles',slide:'slides',injury:'injuries',save:'keeper_saves'});

/** Categoriza eventos já resolvidos pelo jogo; não seleciona clínica nem resultado. */
export function classifyHostAction(event){
 const category=EVENT_CATEGORY[event?.kind];if(!category)return null;
 const injury=category==='injuries';
 return Object.freeze({category,nativeKind:event.kind,nativeSubtype:event.subtype??null,actorId:event.actorId??null,
  actionId:null,status:injury?'medical-detail-unavailable':'category-only',
  reason:injury?'o motor não fornece diagnóstico clínico':'variante visual ainda não mapeada ao subtipo nativo'});
}
