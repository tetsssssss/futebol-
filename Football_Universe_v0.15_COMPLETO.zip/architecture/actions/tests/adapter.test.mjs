import test from 'node:test'; import assert from 'node:assert/strict';
import {resolveMappedAttribute,toActionContext} from '../integration/v015-adapter.mjs';
test('maps only exact v0.15 attrs and reports unsupported keys',()=>{assert.equal(resolveMappedAttribute({attrs:{finishing:81}},'finishing'),81);assert.equal(resolveMappedAttribute({attrs:{finishing:81}},'unknown'),null);});
test('creates read-only context for active player; rejects an unknown actor',()=>{
 const match={minute:12,finished:false,possession:0,carrier:0,ball:{x:75,y:50,z:0},restart:null,action:null,squads:[{playing:[{id:'p',attrs:{finishing:80},x:75,y:50,dismissed:false} ]},{playing:[]}]};
 const before=JSON.stringify(match);const c=toActionContext(match,0,'p');assert.equal(c.actor.id,'p');assert.equal(c.phase,'play');assert.equal(JSON.stringify(match),before);assert.equal(toActionContext(match,0,'missing').accepted,false);
});
test('exposes defensive actor context without granting possession',()=>{
 const match={minute:12,finished:false,possession:1,carrier:0,ball:{x:40,y:50,z:0},restart:null,action:null,squads:[{playing:[{id:'def',position:'CB',attrs:{tackling:70},x:40,y:50,dismissed:false}]},{playing:[{id:'att',position:'ST',attrs:{},x:60,y:50,dismissed:false}]}]};
 const c=toActionContext(match,0,'def');assert.equal(c.accepted,true);assert.equal(c.ballState,'opponent');assert.equal(c.actorControlsBall,false);
});
