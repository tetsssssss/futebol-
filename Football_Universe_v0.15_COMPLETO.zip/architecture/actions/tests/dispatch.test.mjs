import test from 'node:test'; import assert from 'node:assert/strict';
import {loadActionCatalog} from '../engine/node-loader.mjs';
import {createActionRegistry} from '../engine/registry.mjs';
import {dispatchAction} from '../integration/dispatch.mjs';
test('dispatch emits intent without resolving or persisting a match outcome',async()=>{
 const reg=createActionRegistry(await loadActionCatalog());const a=reg.ids().map(id=>reg.get(id)).find(x=>x.category==='shots');
 const result=dispatchAction(reg,{accepted:true,phase:'play',ballState:'controlled',actorControlsBall:true,contact:'any',actor:{id:'p',position:'ST'}},a.id);
 assert.equal(result.accepted,true);assert.equal(result.outcomeAuthority,'v015-match-engine');assert.equal(result.commitEvent,false);assert.equal(result.persistActionId,false);
});
test('unknown and phase-ineligible actions reject cleanly',async()=>{
 const reg=createActionRegistry(await loadActionCatalog());assert.equal(dispatchAction(reg,{accepted:true,phase:'play',actor:{position:'ST'}},'missing').accepted,false);
 const a=reg.ids().map(id=>reg.get(id)).find(x=>x.requires.phase==='penalty');assert.equal(dispatchAction(reg,{accepted:true,phase:'play',actor:{position:'ST'}},a.id).reason,'phase-mismatch');
});
