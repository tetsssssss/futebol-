import test from 'node:test'; import assert from 'node:assert/strict';
import {loadActionCatalog} from '../engine/node-loader.mjs';
import {createActionRegistry} from '../engine/registry.mjs';
import {getActionProfile,createVisualTimeline,describeIncident} from '../integration/metadata.mjs';
test('profiles are estimates and missing clips stay unimplemented',async()=>{const reg=createActionRegistry(await loadActionCatalog());const shot=reg.ids().map(id=>reg.get(id)).find(x=>x.category==='shots');assert.equal(getActionProfile(reg,shot.id).notRealPhysics,true);const t=createVisualTimeline(reg,shot.id);assert.equal(t.implemented,false);assert.ok(t.events.every((e,i)=>!i||e.atMs>=t.events[i-1].atMs));});
test('injury definition is descriptive and never writes availability',async()=>{const reg=createActionRegistry(await loadActionCatalog());const injury=reg.ids().map(id=>reg.get(id)).find(x=>x.category==='injuries');const event=describeIncident(reg,injury.id,{playerId:'p',matchId:'m',minute:2,source:'test'});assert.equal(event.applyToSave,false);assert.equal(event.absenceDays,null);});
