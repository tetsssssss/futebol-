import test from 'node:test';
import assert from 'node:assert/strict';
import {classifyHostAction} from '../integration/host-events.mjs';
import {configureActionRuntime,observeHostAction,readActionObservations} from '../integration/runtime.mjs';
import {loadActionCatalog} from '../engine/node-loader.mjs';
import {createActionRegistry} from '../engine/registry.mjs';

test('classifica os eventos nativos de passe, drible e lesão sem alegar animação ou diagnóstico',()=>{
 assert.equal(classifyHostAction({kind:'pass',subtype:'shortPass'}).category,'passes');
 assert.equal(classifyHostAction({kind:'dribble',subtype:'stepover'}).category,'dribbles');
 const injury=classifyHostAction({kind:'injury',subtype:null});
 assert.equal(injury.category,'injuries');
 assert.equal(injury.actionId,null);
 assert.equal(injury.status,'medical-detail-unavailable');
});

test('ignora eventos que não pertencem ao catálogo de ações',()=>{
 assert.equal(classifyHostAction({kind:'goal'}),null);
});

test('liga observações ao catálogo em memória sem escrever no estado da partida',async()=>{
 configureActionRuntime(createActionRegistry(await loadActionCatalog()));
 const match={minute:12,time:720,events:[]};
 const obs=observeHostAction(match,{kind:'pass',subtype:'short',actorId:'p1'});
 assert.equal(obs.category,'passes');assert.equal(obs.availableActionIds.length,30);assert.equal(obs.actionId,null);
 assert.deepEqual(match,{minute:12,time:720,events:[]});
 observeHostAction(match,{kind:'dribble',subtype:'feint',actorId:'p2'});
 observeHostAction(match,{kind:'injury',actorId:'p2'});
 const timeline=readActionObservations(match);
 assert.deepEqual(timeline.map(x=>x.category),['passes','dribbles','injuries']);
 assert.equal(timeline[2].actionId,null);assert.equal(timeline[2].status,'medical-detail-unavailable');
 configureActionRuntime(null);
});
