import test from 'node:test'; import assert from 'node:assert/strict';
import {loadActionCatalog} from '../engine/node-loader.mjs';
import {createActionRegistry} from '../engine/registry.mjs';
test('registers 257 stable action and incident IDs as immutable definitions',async()=>{
 const catalog=await loadActionCatalog(); const reg=createActionRegistry(catalog); assert.equal(reg.size,257); assert.equal(new Set(reg.ids()).size,257); assert.ok(Object.isFrozen(reg.get(reg.ids()[0])));
});
test('rejects duplicate or malformed action IDs',async()=>{const c=await loadActionCatalog();c.actions[1]={...c.actions[0]};assert.throws(()=>createActionRegistry(c),/duplicado/i);});
