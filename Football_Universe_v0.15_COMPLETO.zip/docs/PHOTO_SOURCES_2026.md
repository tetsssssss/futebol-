# Fotografias de jogadores: fontes e licenças

**v0.14.0 — fontes atuais.** Rostos EA FC 26 / SoFIFA (`cdn.sofifa.net`), retratos oficiais das listas da Copa 2026 (FIFA Digital Hub), TheSportsDB, Wikipédia/Wikimedia Commons e Transfermarkt (conferência manual), todos guardados em `assets/faces`. Procedência individual das fotos extras em `data/media-sources.json`; escudos e uniformes: TheSportsDB. O aplicativo é de uso pessoal e não comercial; as licenças de terceiros seguem as das fontes e não foram auditadas. A base EA FC 26 não licencia o Brasileirão: atletas dessa liga são fictícios e ficam fora.

---

(Texto original abaixo — manifesto do Wikimedia Commons da v0.4.)

Fotografias reais do Wikimedia Commons catalogadas individualmente. A imagem é carregada da internet na primeira utilização; em uso offline, deve ser baixada com `npm run fotos` e embutida em `npm run build`. Sem foto licenciada, o sistema informa que não há retrato disponível.

- **flamengo/Lucas Paquetá**: [Lucas Paqueta Brazil V Morocco 13 June 2026-134 (cropped).jpg](https://commons.wikimedia.org/wiki/File:Lucas_Paqueta_Brazil_V_Morocco_13_June_2026-134_(cropped).jpg); CC BY-SA 4.0; autor: Bryan Berlin / WikiPortraits.
- **flamengo/Giorgian de Arrascaeta**: [Giorgian de Arrascaeta WC2022.jpg](https://commons.wikimedia.org/wiki/File:Giorgian_de_Arrascaeta_WC2022.jpg); CC BY 4.0; autor: Tasnim News Agency.
- **flamengo/Agustín Rossi**: [Agustin rossi.jpg](https://commons.wikimedia.org/wiki/File:Agustin_rossi.jpg); CC BY-SA 4.0; autor: Leandro641.
- **palmeiras/Vitor Roque**: [Vitor-roque-palmeiras-internacional-sep2025.jpg](https://commons.wikimedia.org/wiki/File:Vitor-roque-palmeiras-internacional-sep2025.jpg); CC BY-SA 4.0; autor: NullReason.
- **palmeiras/Jhon Arias**: [Jhon Arias en Palmeiras - Copa Libertadores 2026.jpg](https://commons.wikimedia.org/wiki/File:Jhon_Arias_en_Palmeiras_-_Copa_Libertadores_2026.jpg); CC BY 4.0; autor: Fotógrafo no Wikimedia Commons.
- **palmeiras/Gustavo Gómez**: [Gustavo-Gomez-Palmeiras-2022.png](https://commons.wikimedia.org/wiki/File:Gustavo-Gomez-Palmeiras-2022.png); CC BY 3.0; autor: UMA PALESTRINA.
- **palmeiras/Andreas Pereira**: [Andreas-Pereira-Palmeiras-Jacuipense-abr26.jpg](https://commons.wikimedia.org/wiki/File:Andreas-Pereira-Palmeiras-Jacuipense-abr26.jpg); CC BY-SA 4.0; autor: NullReason.
- **corinthians/Yuri Alberto**: [Yuri Alberto Corinthians.jpg](https://commons.wikimedia.org/wiki/File:Yuri_Alberto_Corinthians.jpg); CC BY 4.0; autor: Cris Sevieri.
- **corinthians/Hugo Souza**: [Hugo Souza 2025 (cropped).jpg](https://commons.wikimedia.org/wiki/File:Hugo_Souza_2025_(cropped).jpg); CC BY 4.0; autor: TV Central do Timão.
- **corinthians/Rodrigo Garro**: [Rodrigo Garro 2025.jpg](https://commons.wikimedia.org/wiki/File:Rodrigo_Garro_2025.jpg); CC BY 4.0; autor: TV / autor conforme Commons.
- **sao-paulo/Jonathan Calleri**: [Jonathan-Calleri-Sao-Paulo-Juventude-jun-2022 (cropped).jpg](https://commons.wikimedia.org/wiki/File:Jonathan-Calleri-Sao-Paulo-Juventude-jun-2022_(cropped).jpg); Public Domain Mark 1.0; autor: SOCCER DIGITAL / Fabio Giannelli.
- **sao-paulo/Rafael Tolói**: [Rafael Tolói 02 (cropped).JPG](https://commons.wikimedia.org/wiki/File:Rafael_Tol%C3%B3i_02_(cropped).JPG); CC BY-SA 4.0; autor: Ago76.
- **flamengo/Pedro**: [Pedro in a match for Flamengo7658.png](https://commons.wikimedia.org/wiki/File:Pedro_in_a_match_for_Flamengo7658.png); CC BY-SA 4.0; autor: Jester77aa08.
- **palmeiras/Maurício**: [Mauricio-palmeiras-sport-ago-25 (cropped).jpg](https://commons.wikimedia.org/wiki/File:Mauricio-palmeiras-sport-ago-25_(cropped).jpg); CC BY-SA 4.0; autor: NullReason.
- **palmeiras/Flaco López**: [Flaco Lopez Palmeiras 2025 06 23 Inter Miami.jpg](https://commons.wikimedia.org/wiki/File:Flaco_Lopez_Palmeiras_2025_06_23_Inter_Miami.jpg); CC BY 4.0; autor: Autor indicado na página Commons.
