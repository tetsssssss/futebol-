# Football Universe v0.6 — Modo Treinador 2D

Projeto web local/offline, com a base v0.5 preservada e um **Modo Treinador 2D** independente para Brasileirão Série A 2026 e Copa do Mundo 2026.

## Como abrir

**Mais simples:** extraia o ZIP e abra `dist/index.html` no navegador. No menu principal, selecione **Treinador 2D**. Se preferir, abra diretamente `dist/treinador/index.html`.

**Desenvolvimento:** Node.js 20+ na pasta raiz; `npm start` e acesse `http://127.0.0.1:4173/treinador/index.html`. Para testes e artefatos: `npm test`, `npm run build`, `npm run test:ui` (Playwright Python + Chromium, se instalados).

A pasta `/copa` mantém o modo anterior de importação de 100 seleções e 23 jogadores reais por país. O Modo Treinador tenta usar essa base de seleções **quando já sincronizada no IndexedDB do mesmo navegador e origem**. Sem esse banco, usa posições genéricas de demonstração, nunca nomes inventados apresentados como jogadores reais.

## O que existe nesta versão

- Brasileirão Série A: os **20 clubes reais de 2026** com calendário estruturado de **38 rodadas, 380 partidas, 19 mandos por clube**. O primeiro conjunto de confrontos parte da rodada divulgada pela CBF. Demais adversários/rodadas e suas datas são **gerados pelo simulador**. Não representam a tabela básica oficial completa.
- Copa: 48 seleções, 12 grupos de quatro, classificação de dois por grupo e oito terceiros, até **104 partidas**. Grupos, distribuição e datas são alternativos/hipotéticos, não o chaveamento real.
- Campo Canvas com 22 jogadores, bola, posições, deslocamentos, finalizações, gols, passes e eventos; placar e estatísticas.
- Treinador: time controlado, escalação inicial alterável, formações 4-2-3-1 / 4-3-3 / 4-4-2 / 3-5-2, mentalidade, pressão, ritmo, até cinco substituições, pausa, avanço por minuto, velocidade, conclusão e registro da partida.
- Simulação de rodadas e fases completas, tabelas/classificação, campeão e arquivo de eventos das partidas.
- Saves locais independentes com exportação/importação em JSON, validação de referências e estrutura.
- Retrocompatibilidade preservada: Manager v0.5 e Modo Copa v0.5 permanecem no ZIP, com correção no empacotador para funções assíncronas.

## O que *não* existe ainda

- Motor definitivo do futebol: impedimentos, cartões e suspensões completos, faltas/bola parada em detalhe, lesões em partida, IA tática sofisticada, modelagem física completa da bola, sprites humanos animados e narrativa detalhada de 90 minutos.
- Todas as **datas oficiais CBF** e todos os elencos reais do Brasileirão. A base v0.5 contém **107 atletas verificados em quatro clubes**; para os outros 16 clubes o Modo Treinador representa o time por **23 posições neutras** e 70 parâmetros técnicos hipotéticos, rotulados como pendência.
- Todas as seleções com dados reais offline. O banco das 100 seleções do Modo Copa é importável, mas não está embutido no ZIP.
- Calendário exato, grupos, tabela de classificados e chaveamento oficial da FIFA 2026; tabelas e datas do Modo Treinador são simuladas.
- 3D Babylon.js: não implementado nesta versão, conforme prioridade do 2D.

## Observações de qualidade

Em modo treinador a simulação não depende do Canvas: **o estado do motor determina o resultado**. `finishMatch`, `advanceMatch` e `matchResult` alimentam tanto o 2D quanto as tabelas. A seed permite reproduzir uma partida sob as mesmas condições iniciais. Os próprios comandos do usuário alteram o estado ao vivo.

Armazenamento: `football-universe-coach-v06` no localStorage, isolado dos saves anteriores. Um save longo de 380 partidas tem cerca de 2,1 MB de JSON; a capacidade do navegador ainda pode variar. Sempre exporte backups.

### Fontes

- CBF: [clubes da Série A 2026](https://www.cbf.com.br/futebol-brasileiro/times/campeonato-brasileiro/serie-a/2026).
- CBF: [rodada inicial do Brasileirão 2026](https://www.cbf.com.br/futebol-brasileiro/noticias/olimpica/a/confira-o-retrospecto-dos-confrontos-entre-os-clubes-do-brasileirao-betano-2026).
- CBF: [calendário 2026](https://www.cbf.com.br/a-cbf/por-dentro-da-cbf/informes-cbf/a/cbf-anuncia-novo-calendario-do-futebol-profissional-masculino).
- FIFA: [regulamento de classificação da Copa 2026](https://www.fifa.com/pt/tournaments/mens/worldcup/canadamexicousa2026/articles/copa-mundo-grupos-regulamento-classificacao-desempate).

Essas fontes amparam **identidade de clubes e formato**, não validam os resultados hipotéticos ou os parâmetros técnicos inventados pela simulação.

Veja `RELATORIO_DESENVOLVIMENTO.md` e `CHANGELOG.md` para auditoria e próximos passos.
