# RELATÓRIO DE DESENVOLVIMENTO | Football Universe v0.6

**Data:** 2026-10-09  
**Natureza:** novo módulo jogável experimental, não simulação definitiva do futebol  
**Base preservada:** ZIP v0.5, Manager, Copa anterior, 70 atributos, 107 jogadores iniciais reais, importadores e saves anteriores.

## 1. IMPLEMENTADO

### Motor 2D / simulação

- Motor esportivo em `treinador/engine.js`, separado dos gráficos.
- Estado persistente por partida: tempo, score, equipes, titulares, reservas, substituições, bola, jogadores, mentalidades, pressing, tempo e eventos.
- Simulação determinística com seed, ações sucessivas de passes, perdas de bola, finalizações, defesas e gols.
- Posições procedurais dos 22 jogadores e movimentação em um campo 100×100 normalizado, renderizado como Canvas 900×550 responsivo.
- Dados de partida: posse, chutes, chutes no gol, passes, faltas e narração textual de eventos.
- Modificações táticas durante a partida: mentalidade, pressão e ritmo, com influência sobre o estado simulado.
- Até 5 substituições por time por partida; escalação inicial de 11 jogadores, incluindo goleiro, modificável antes da partida.
- Formações 4-2-3-1, 4-3-3, 4-4-2 e 3-5-2, com diferentes posições-base.
- Controles de jogo: assistir, pausar, velocidade 1×/3×/6×, avançar 1/5 min, concluir até 90 min e registrar o resultado.

### Brasileirão Série A

- Identidade de 20 clubes reais de 2026 validada junto à CBF.
- Algoritmo turno/returno: 38 rodadas, 380 partidas, 19 mandos e 19 visitas por clube, sem adversários duplicados.
- Confrontos da primeira rodada correspondem à relação divulgada pela CBF. A distribuição das demais partidas **não é oficial**.
- Datas estimadas para jogos e interrupção aproximada da simulação durante a Copa. Datas posteriores à primeira rodada **não são oficiais**.
- Cálculo de tabela, pontos, gols, vitórias, empates, derrotas e campeão da temporada demonstrativa.
- Simulação integral do campeonato pela engine e opção de assistir ou simular jogos da rodada.

### Copa do Mundo

- Novamente usa a base de 48 participantes e 12 grupos da v0.5, com 104 partidas até a final, inclusive terceiro lugar.
- Jogável no Modo Treinador e no Canvas 2D, com comandos e substituições; jogos das demais seleções simuláveis por fase.
- Reutilização dos 23 atletas por seleção da v0.5 quando o banco já foi sincronizado no mesmo navegador.
- Fallback honesto para posições genéricas sem nomes falsos, quando o banco real está ausente.
- Datas **hipotéticas** dentro da janela junho/julho de 2026, não reprodução da tabela histórica oficial.

### Infraestrutura

- Nova área `treinador/`, acessível pelo menu do Manager, com navegação para o Modo Copa anterior.
- Salvar/carregar arquivo JSON do treinador com checagem estrutural e armazenamento isolado em `localStorage`.
- Build `dist/treinador/index.html` independente de servidor, gerado pelo mesmo build que Manager e Copa.
- Correção na função de build para suportar `export async function` das fontes de dados, evitando JavaScript inválido no HTML portátil da Copa.
- Correção visual de uniformes parecidos no 2D (cores contrastantes).

## 2. TESTES

- **47 de 47 testes automatizados aprovados**, incluindo 11 novos casos do modo treinador.
- Teste programático de toda a Série A: 380 jogos, 760 participações de clubes e campeão.
- Teste programático da Copa: 104 jogos, 48 seleções, campeão.
- Teste de estabilidade da seed, 22 jogadores, táticas, substituições, elencos de 70 atributos e serialização.
- **Navegador**: 390, 768 e 1440 px, com entrada no Brasileirão e Copa, Canvas, comandos táticos, substituição, avanço de minutos, conclusão e classificação; sem erros JavaScript ou overflow horizontal nos cenários.
- O Chromium bloqueou abrir URLs locais. Para a checagem visual, usamos `set_content` com o HTML portátil real e `localStorage` simulado. **Não foi validada a execução via URL em ambiente hospedado ou em dispositivos reais**.

## 3. O QUE AINDA NÃO É DEFINITIVO

| Módulo | Estado | Principal lacuna |
|---|---|---|
| Calendário Série A | Parcial | Data, locais e ordem oficial CBF das 38 rodadas |
| Database de clubes | Parcial | Elencos reais de 16 clubes; fontes por atleta e fotos |
| Banco de seleções | Parcial | Sincronização efetiva e validação offline dos 48 elencos |
| Copa no treinador | Parcial | Grupos, datas, chaveamento e desempates oficiais |
| Motor 2D | Protótipo avançado | Física, impedimentos, escanteios, cartões, faltas, lesões, IA individual e animação |
| Carreira de técnico | Parcial | Contratos, diretoria, demissões, empregos, reputação e histórico multianual |
| 2D visual | Protótipo funcional | Sprites humanos, curvas da bola, replays, câmeras avançadas, transições contínuas |
| Saves | Parcial | Banco escalável e migração automática entre versões do modo treinador |
| 3D Babylon.js | Pendente | Não é parte desta entrega |

## 4. RISCOS

1. **Elencos neutros:** 16 equipes da Série A ainda não possuem jogadores identificados; há 23 marcadores de posição por time, sem alegação de serem pessoas reais. Seleções dependem da importação do modo anterior.
2. **Modelo simplificado:** resultados não devem ser comparados com dados históricos, probabilidades profissionais ou Football Manager.
3. **Tabela real:** a primeira rodada foi fundamentada na CBF, mas as seguintes são geradas; NÃO apresentar este calendário como a tabela oficial de 2026.
4. **Impacto dos atributos:** os 70 campos estão no cadastro, mas o motor ainda utiliza um subconjunto de parâmetros esportivos; não foram calibrados empiricamente.
5. **Armazenamento:** 380 jogos geram cerca de 2,1 MB de JSON, limite tolerável em vários navegadores, mas não garantido em todos. Sem backup automático externo.
6. **Licenças das fotos:** URLs de imagens da v0.5 permanecem sujeitas a disponibilidade e direitos de uso. Nenhum facepack offline completo foi produzido nesta fase.

## 5. RECOMENDAÇÕES

**Prioridade 1:** preencher dados reais de todos os 20 clubes da Série A, jogadores, escalações, técnicos, contratos, retratos permitidos e fonte por campo; estabelecer cadastro offline coerente para as 48 seleções.

**Prioridade 2:** substituir datas geradas pelas **38 rodadas oficiais do Brasileirão 2026**, integrar calendário real FIFA e critérios de classificação sem simplificações.

**Prioridade 3:** elevar o motor de lances: condicionamento, ocupação, pressões de bloco, impedimentos, faltas e cartões, set pieces, goleiro, marcação e bolas desviadas, sob seeds reproduzíveis. Criar baterias estatísticas para plausibilidade.

**Prioridade 4:** animação 2D interpolada em 60 fps, estados de atleta, replay, highlights, câmera e melhores momentos, sem desviar o motor de partida para o renderizador.

**Prioridade 5:** aprofundar a carreira de técnico com contratos, delegação, diretoria, imprensa, demissões, convocação de seleção e calendário multitemporada. Só depois iniciar o 3D Babylon.js.

## 6. VEREDITO

**Aprovação para continuidade como v0.6 experimental**, com modo 2D e competições inteiras simuláveis, sem alegar que o jogo esteja no nível definitivo pedido. Melhorias demonstráveis e testes aprovados, pendências claramente separadas.
