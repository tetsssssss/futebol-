# Changelog | Football Universe

## v0.6 — 2026-10-09
- Preservada a v0.5, sem substituir saves existentes.
- Novo modo treinador 2D, com controle de equipe, campo Canvas, jogadores/bola, eventos e placar.
- Brasileiro 2026 com 20 clubes, 38 rodadas e 380 jogos. Primeiro conjunto de confrontos amparado na CBF; restante do calendário gerado.
- Copa 2026: 48 seleções, 104 jogos, grupos e eliminatórias, com opção de reaproveitar elencos já sincronizados.
- Escalação inicial, quatro formações, mentalidade, ritmo, pressão e até cinco substituições.
- Saves independentes, histórico de resultados e partidas reproduzíveis por seed.
- Correção de bundle assíncrono no Modo Copa v0.5.
- Testes ampliados para 47, QA no browser para três larguras com origem isolada simulada.
- Compatibilidade mantida com v0.5 e módulos anteriores.

## v0.5 — 2026-10-09
- Criado modo Copa com catálogo de 100 seleções e importador para 23 jogadores reais por equipe, sujeito à sincronização externa.
