# FOOTBALL UNIVERSE — PROJECT CONTEXT

> Arquivo-base de contexto persistente do projeto.
> Use este documento como **fonte principal de continuidade** ao iniciar uma nova conversa, trocar de modelo ou retomar o desenvolvimento após uma pausa.

---

## 0. IDENTIDADE DO PROJETO

**Nome:** Football Universe  
**Tipo:** Simulador de futebol completo com universo persistente  
**Referência principal:** Football Manager  
**Filosofia:** Realismo equilibrado com diversão  
**Plataforma inicial:** Web app local/offline com aparência de jogo  
**Plataforma futura:** Android  
**Horizonte típico de save:** 15–30 temporadas  
**Estado atual:** Fase de arquitetura e definição da base do produto  
**Modelo de trabalho atual:** ChatGPT 5.6 High como arquiteto inicial; Codex ainda não entra no fluxo

### Objetivo central

Construir um simulador de futebol profundo, persistente e modular, combinando:

- database extensa;
- manager de clube;
- carreira de jogador;
- técnico de seleção;
- mercado e scouting;
- universo histórico persistente;
- motor de partida;
- visualização 2D;
- visualização 3D progressiva;
- mídia, narrativa e relações;
- editor e suporte a modding.

O projeto **não deve virar apenas um dashboard de números**. Todos os sistemas importantes precisam produzir consequências observáveis no universo.

---

# 1. ESCOPO INICIAL

O primeiro universo deverá conter:

- Brasileirão Série A;
- Brasileirão Série B;
- seleções participantes da Copa do Mundo de 2026;
- elencos completos;
- técnicos;
- competições;
- calendário;
- contratos;
- mercado;
- scouting;
- histórico;
- fotos de jogadores como assets;
- escudos e cores originais como assets;
- aproximadamente 70 atributos por jogador;
- partidas simuladas;
- visualização 2D;
- base inicial do 3D;
- saves persistentes.

### Expansão prioritária

Após o núcleo inicial:

1. Libertadores;
2. Copa Sul-Americana.

### Competições brasileiras previstas desde a arquitetura

- Copa do Brasil;
- Supercopa do Brasil;
- Estaduais;
- Copa do Nordeste;
- Copa Verde;
- Série C;
- Série D;
- Categorias de base.

---

# 2. MODOS DE JOGO

O sistema deverá suportar:

- Manager de clube;
- Carreira de jogador;
- Técnico de seleção;
- Modo espectador;
- Criador de clube;
- Editor de database.

### Ordem prática

A Carreira de Jogador é parte oficial do projeto, mas **não deve ser o primeiro módulo implementado**.

A fundação precisa servir primeiro a:

- database;
- manager;
- universo;
- tática;
- motor de partida.

Depois a carreira reutiliza essa infraestrutura.

---

# 3. PRINCÍPIOS DE DESIGN

## 3.1 Realismo equilibrado com diversão

O jogo deve buscar plausibilidade, mas sem burocracia inútil.

Evitar:

- realismo que atrapalha a experiência;
- sistemas decorativos;
- opções sem efeito;
- dados que nunca alteram nada;
- excesso de telas sem propósito;
- aleatoriedade sem causalidade.

## 3.2 Sistemas conectados

Exemplo esperado:

Lesão  
→ menor disponibilidade  
→ menos minutos  
→ pior desenvolvimento  
→ mudança de hierarquia do elenco  
→ possível contratação  
→ impacto financeiro  
→ imprensa  
→ moral  
→ resultado esportivo.

## 3.3 Explicabilidade

O motor deve poder explicar, quando necessário:

- por que um jogador evoluiu;
- por que perdeu espaço;
- por que uma equipe contratou alguém;
- por que uma tática falhou;
- por que determinado resultado ocorreu;
- por que o valor de mercado mudou.

Logs avançados devem existir de forma opcional.

---

# 4. DATABASE DE JOGADORES

## Escala

**0–100**

## Quantidade

Aproximadamente **70 atributos por jogador**.

## Visibilidade

Nem todos os atributos são sempre visíveis.

A informação disponível depende de:

- conhecimento do clube;
- scouting;
- qualidade do scout;
- tempo de observação;
- região;
- reputação;
- exposição pública.

## Famílias obrigatórias

- Técnicos;
- Físicos;
- Mentais;
- Táticos;
- Comportamentais;
- Goleiro;
- Bola parada;
- Relacionamento;
- Adaptabilidade;
- Reputação;
- Lesão/condição.

---

# 5. POTENCIAL E DESENVOLVIMENTO

O potencial deve ser **dinâmico influenciado pelo contexto**.

Não usar somente um teto rígido.

O desenvolvimento deverá considerar:

- idade;
- talento;
- minutos jogados;
- nível da competição;
- treino;
- técnico;
- qualidade da comissão;
- moral;
- personalidade;
- lesões;
- ambiente;
- sequência de jogos;
- função tática;
- estabilidade;
- pressão;
- adaptação.

---

# 6. PERSONALIDADE E COMPORTAMENTO

A personalidade deve ser parcialmente oculta e emergir pelo comportamento.

Possíveis componentes:

- ambição;
- profissionalismo;
- disciplina;
- lealdade;
- competitividade;
- coragem;
- liderança;
- temperamento;
- adaptação;
- consistência;
- reação à pressão;
- ego;
- cooperação.

Não exibir tudo como número cru.

Jogadores diferentes precisam **parecer diferentes em campo e fora dele**.

---

# 7. DADOS DE CADA JOGADOR

Desde o início:

- nome;
- idade;
- data de nascimento;
- nacionalidade;
- altura;
- peso;
- pé dominante;
- posições;
- clube;
- seleção;
- valor de mercado;
- salário;
- reputação;
- relações;
- condição;
- histórico.

### Histórico individual

Registrar:

- clubes por temporada;
- jogos;
- gols;
- assistências;
- títulos;
- lesões;
- transferências;
- salários;
- notas médias;
- prêmios;
- seleções;
- posições jogadas.

### Fotos

Prioridade para retrato real em todas as fichas.

Os assets devem ficar **separados da lógica do jogo**, permitindo facepacks e substituição posterior.

### Escudos

Escudos e cores originais têm prioridade visual.

Também devem ficar separados da lógica do jogo.

---

# 8. REGENS / NEWGENS

**Não entram no início.**

A arquitetura, porém, não deve impedir a futura inclusão de:

- novos jogadores;
- categorias de base;
- geração procedural;
- origens regionais;
- academias;
- perfis de personalidade;
- desenvolvimento de longo prazo.

---

# 9. FICHA DO JOGADOR

A ficha do jogador é uma das interfaces mais importantes.

### Direção visual

**Card premium de scouting + histórico completo**

### Deve incluir

- foto;
- nome;
- idade;
- clube;
- seleção;
- posições;
- pé dominante;
- altura;
- peso;
- condição;
- forma;
- reputação;
- valor;
- salário;
- contrato;
- atributos;
- estatísticas;
- histórico;
- lesões;
- relações;
- prêmios;
- convocações;
- transferências.

Evitar transformar a tela em uma parede de números.

---

# 10. LAYOUT / UI

## Direção

Football Manager moderno, com identidade própria.

## Tema

- Claro;
- Escuro;
- Alternável pelo usuário.

## Telas de maior prioridade visual

1. Ficha do jogador;
2. Tática;
3. Partida;
4. Competições;
5. Calendário.

## Linguagem visual desejada

- produto esportivo premium;
- leitura rápida;
- cards;
- tabelas inteligentes;
- fotos;
- escudos;
- gráficos;
- mini mapas táticos;
- timelines;
- navegação lateral;
- breadcrumbs;
- painéis contextuais.

---

# 11. MANAGER DE CLUBE

Responsabilidades centrais:

- escalação;
- tática;
- treino;
- imprensa;
- gestão de elenco;
- reuniões com diretoria.

Responsabilidades podem ser delegadas.

### Controle configurável

O usuário poderá decidir quem cuida de:

- transferências;
- contratos;
- scouting;
- base;
- treino;
- imprensa.

---

# 12. DIRETORIA

A diretoria deve possuir:

- filosofia;
- expectativas;
- objetivos;
- tolerância;
- política interna;
- confiança;
- situação financeira;
- prioridades.

A avaliação do técnico não deve depender apenas de vitórias.

Também considerar:

- estilo;
- finanças;
- base;
- contratações;
- desempenho por competição;
- gestão do elenco;
- cumprimento de filosofia.

---

# 13. CARREIRA DE TÉCNICO

Sistema completo com:

- reputação;
- mercado de trabalho;
- entrevistas;
- propostas;
- demissões;
- conquistas;
- histórico;
- especialidades;
- relações;
- evolução de filosofia.

Clubes devem procurar técnicos coerentes com seu perfil.

---

# 14. CARREIRA DE JOGADOR

## Sistemas pessoais

- contrato;
- empresário;
- treino;
- moral;
- relação com técnico;
- relação com elenco;
- imprensa;
- patrocinadores;
- vida financeira simplificada;
- lesões;
- reputação;
- redes sociais simuladas.

## Controle em partida

Inicialmente:

**decisões e simulação**, sem necessidade de controlar manualmente o jogador.

## Pós-carreira

Deve existir carreira completa após aposentadoria.

Possíveis caminhos futuros:

- treinador;
- dirigente;
- agente;
- outras funções.

## Reputação

Separar:

- fama esportiva;
- fama midiática.

## Relação com treinador

Peso muito alto sobre:

- escalação;
- minutos;
- função;
- desenvolvimento;
- oportunidades.

## Background

Jogador criado deverá poder ter:

- origem;
- região;
- contexto;
- formação;
- história inicial.

## Conversas

Sistema profundo de:

- entrevistas;
- diálogos;
- respostas;
- consequências;
- memória.

## Ritmo

Configurável pelo usuário.

---

# 15. EVENTOS NARRATIVOS DA CARREIRA

Possíveis eventos:

- disputa por posição;
- conflitos com técnico;
- rivalidades;
- convocação;
- transferências;
- lesões;
- críticas da imprensa;
- renovação;
- capitania;
- prêmios;
- propostas internacionais;
- eventos aleatórios coerentes.

---

# 16. MOTOR DE PARTIDA

O placar nunca deve ser simplesmente sorteado.

A partida deverá emergir de:

- jogadores;
- posições;
- espaço;
- tática;
- atributos;
- fadiga;
- moral;
- bola;
- contexto;
- decisões;
- adversário.

### Regra estrutural

**O motor de partida é a fonte da verdade.**

2D e 3D são visualizações do mesmo estado de partida.

Nunca construir lógica diferente para 2D e 3D.

---

# 17. PARTIDA 2D

## Visual

2D moderno com sprites.

## Modos de visualização

- partida completa;
- highlights;
- velocidade ajustável.

## Física da bola

Avançada:

- spin;
- quique;
- curva;
- superfície;
- velocidade;
- desaceleração.

## Ações visualmente distintas

- passe curto;
- passe longo;
- cruzamento;
- drible;
- finalização;
- cabeceio;
- desarme;
- pressão;
- defesa do goleiro;
- bola parada;
- corrida sem bola.

---

# 18. ESTILOS DE FINALIZAÇÃO

A ação "chute" não pode ser genérica.

Planejar suporte a:

- peito do pé;
- colocado;
- chapa;
- trivela;
- cobertura;
- voleio;
- sem-pulo;
- bicicleta;
- calcanhar;
- letra;
- chute mascado;
- cabeceio;
- primeira intenção;
- chute forte;
- finalização improvisada.

A escolha deve depender de:

- posição;
- orientação corporal;
- trajetória da bola;
- pressão;
- atributos;
- personalidade;
- contexto.

---

# 19. INSTRUÇÕES DURANTE A PARTIDA

Suportar:

- banco;
- mentalidade;
- substituições;
- ajustes;
- instruções individuais;
- mudanças táticas;
- reações ao placar;
- contexto da partida.

---

# 20. PARTIDA 3D

## Estado inicial

Visual simples e funcional.

## Prioridade

Visualização primeiro.

Controle direto pode vir depois.

## Câmeras

- TV lateral;
- atrás do jogador;
- tática alta;
- broadcast dinâmica;
- replay.

## Animações

Sistema híbrido:

- procedural;
- animações;
- blends;
- contexto.

## Prioridades técnicas

Equilíbrio entre:

- performance;
- fidelidade;
- física;
- IA tática.

---

# 21. ESTÁDIOS

Objetivo:

Todos os estádios da Série A e Série B.

No início, o sistema pode usar modelos modulares desde que a arquitetura suporte substituição por estádios específicos.

---

# 22. CLIMA

Sistema completo com:

- chuva;
- gramado;
- vento;
- temperatura.

O clima deve afetar:

- bola;
- passe;
- domínio;
- fadiga;
- velocidade;
- risco;
- gramado;
- visual.

---

# 23. TÁTICA

Profundidade no estilo Football Manager.

## Conceitos obrigatórios

- pressão;
- linha defensiva;
- ritmo;
- marcação;
- bola parada;
- funções individuais;
- gatilhos de pressão.

A arquitetura deve permanecer preparada para expandir para:

- largura;
- transições;
- construção;
- overlaps;
- zonas de criação;
- instruções por fase.

---

# 24. IA TÁTICA

A IA deverá adaptar tática usando:

- identidade do técnico;
- contexto;
- adversário;
- elenco;
- placar;
- tempo;
- competição.

Cada técnico deve possuir filosofia persistente e evolutiva.

Exemplos:

- posse;
- transição;
- pressão;
- jogo direto;
- defesa baixa;
- amplitude;
- jogo interior.

---

# 25. PERFIL COMPORTAMENTAL DOS JOGADORES

Para evitar jogadores idênticos:

usar perfil comportamental completo.

A tomada de decisão deve refletir:

- atributos;
- traits;
- personalidade;
- contexto;
- preferências.

---

# 26. IA DOS CLUBES

Clubes controlados pela IA devem planejar:

- elenco;
- orçamento;
- contratações;
- vendas;
- empréstimos;
- renovações;
- técnico;
- curto prazo;
- médio prazo;
- múltiplas temporadas.

### Regra do usuário

O usuário poderá intervir pelo editor ou por ferramentas administrativas porque ele controla o universo do jogo.

---

# 27. MERCADO DE TRANSFERÊNCIAS

Sistema profundo com:

- clubes concorrentes;
- empresários;
- necessidade de elenco;
- orçamento;
- interesse;
- reputação;
- negociação;
- planejamento plurianual.

---

# 28. CONTRATOS

Suportar:

- salário;
- duração;
- bônus;
- luvas;
- cláusulas;
- percentual de venda;
- opção de extensão;
- metas;
- papel no elenco;
- empréstimo;
- compra futura.

---

# 29. EMPRESÁRIOS

Empresários devem possuir:

- personalidade;
- reputação;
- relações;
- carteira de clientes;
- exigências;
- influência.

---

# 30. SCOUTING

Sistema profundo com:

- scouts;
- relatórios;
- erro;
- incerteza;
- evolução de conhecimento;
- conhecimento regional;
- tempo de observação.

Atributos desconhecidos podem aparecer como:

- faixa;
- estimativa;
- desconhecido.

---

# 31. VALOR DE MERCADO

Base principal:

- forma;
- reputação;
- mercado.

Arquitetura preparada para considerar também:

- idade;
- contrato;
- posição;
- desempenho;
- competição;
- procura;
- oferta;
- potencial percebido.

---

# 32. JANELA E IMPRENSA

A janela de transferências deverá ter:

- rumores;
- jornalistas;
- fontes;
- acertos;
- erros;
- especulações;
- negociações;
- vazamentos.

---

# 33. LESÕES

Sistema profundo.

Considerar:

- carga;
- condição física;
- gramado;
- idade;
- histórico;
- medicina;
- risco de recorrência;
- intensidade de jogo;
- calendário.

---

# 34. TREINOS

Afetar:

- atributos;
- tática;
- condição;
- entrosamento;
- desenvolvimento.

---

# 35. FINANÇAS

Incluir:

- folha;
- premiações;
- dívida;
- patrocínio;
- estádio;
- receitas;
- despesas;
- orçamento.

Não transformar o jogo em simulador contábil, mas as finanças devem gerar consequências esportivas.

---

# 36. SELEÇÕES

Mesmo nível conceitual de profundidade dos clubes.

Incluir:

- técnico;
- convocação;
- esquema;
- entrosamento;
- competições;
- histórico;
- estatísticas;
- forma;
- lesões;
- reputação.

---

# 37. NARRATIVA E MÍDIA

Camadas obrigatórias:

- notícias;
- jornalistas;
- coletivas;
- rumores;
- rivalidades;
- redes sociais simuladas;
- prêmios;
- histórias emergentes;
- entrevistas;
- torcida.

---

# 38. MEMÓRIA DE MUNDO

O universo deverá lembrar:

- rivalidades;
- recordes;
- crises;
- títulos;
- eliminações;
- transferências marcantes;
- declarações;
- treinadores;
- sequências;
- legados.

Eventos antigos devem poder ser citados anos depois.

---

# 39. HISTÓRICO DO UNIVERSO

Registrar:

- campeões;
- artilheiros;
- assistências;
- recordes de clubes;
- recordes de jogadores;
- transferências;
- técnicos;
- convocações;
- confrontos diretos;
- prêmios.

### Histórico real inicial

Usar o máximo possível de histórico confiável antes do início do save.

---

# 40. CALENDÁRIOS E REGULAMENTOS

Usar:

**regras reais com editor.**

O sistema deve ser parametrizado.

Mudanças futuras podem ocorrer por:

- editor;
- eventos dinâmicos.

Evitar regras hardcoded quando possível.

---

# 41. SAVE

Infraestrutura crítica desde cedo.

Requisitos:

- save robusto;
- autosave;
- múltiplos saves;
- backups;
- compatibilidade de versão quando possível;
- histórico persistente.

---

# 42. EDITOR DE DATABASE

Permitir alterar:

- jogadores;
- atributos;
- clubes;
- competições;
- técnicos;
- contratos;
- regras;
- reputação;
- histórico.

---

# 43. MODDING

Dados e assets devem ser modulares.

Evitar hardcode.

Separar:

- engine;
- database;
- imagens;
- escudos;
- kits;
- fotos;
- estádios;
- regras.

---

# 44. ANDROID

Android é objetivo futuro.

Nenhuma decisão estrutural inicial deve impedir adaptação posterior.

---

# 45. REQUISITOS TÉCNICOS BASE

Desde cedo:

- save robusto;
- autosave;
- múltiplos saves;
- editor;
- modding;
- arquitetura preparada para Android;
- logs de simulação;
- dados separados do motor;
- assets separados da lógica.

---

# 46. ORDEM DE CONSTRUÇÃO

Ordem oficial inicial:

1. Arquitetura geral;
2. Design system e layout;
3. Modelo de dados;
4. Sistema dos ~70 atributos;
5. Clubes, jogadores e competições;
6. Universo persistente;
7. Tática;
8. Motor de partida;
9. Visualização 2D;
10. Manager;
11. Carreira;
12. Mercado e scouting;
13. Seleções;
14. Narrativa;
15. 3D;
16. Expansões continentais.

### Regra

**Não começar pelo 3D.**

---

# 47. PRIMEIRO GRANDE MILESTONE

A primeira grande versão jogável deverá possuir:

- database sólida;
- layout convincente;
- manager funcional;
- carreira funcional;
- universo persistente;
- 2D sólido;
- 3D inicial para visualização.

Não considerar sucesso apenas por quantidade de telas.

---

# 48. PRIORIDADES IMEDIATAS

A próxima fase deve começar por:

1. Layout;
2. Ficha do jogador;
3. Design system;
4. Database;
5. Estrutura dos 70 atributos.

Esses elementos definem a identidade e a espinha dorsal do produto.

---

# 49. REGRAS PARA O AGENTE DO PROJETO

O agente responsável deve:

- não repetir perguntas já respondidas;
- usar este arquivo como contexto principal;
- identificar contradições;
- priorizar decisão mais recente;
- preservar sistemas já aprovados;
- executar quando houver informação suficiente;
- não criar complexidade desnecessária;
- recomendar quando houver alternativas;
- pesquisar fatos externos quando necessário;
- separar fatos pesquisados de decisões de design;
- testar entregas importantes quando ferramentas permitirem.

---

# 50. PROJECT STATE

## Concluído

- Visão geral definida;
- Escopo inicial definido;
- Filosofia do simulador definida;
- Modos principais definidos;
- Competição inicial definida;
- Prioridades de expansão definidas;
- Direção da database definida;
- Escala 0–100 definida;
- Filosofia dos 70 atributos definida;
- Scouting definido;
- Manager definido;
- Carreira definida;
- Filosofia do 2D definida;
- Direção inicial do 3D definida;
- Filosofia da IA e tática definida;
- Mercado definido;
- Lesões definidas;
- Treino definido;
- Finanças definidas;
- Seleções definidas;
- Narrativa definida;
- Layout definido;
- Save/modding definidos;
- Ordem macro de construção definida.

## Em desenvolvimento

- Arquitetura técnica;
- Design system;
- Layout principal;
- Ficha do jogador;
- Modelo de dados;
- Lista definitiva dos 70 atributos.

## Pendente

- Estrutura de diretórios;
- Schema da database;
- Database inicial da Série A;
- Database inicial da Série B;
- Database das seleções da Copa 2026;
- Design system visual;
- Protótipo navegável;
- Motor de universo;
- Motor de calendário;
- Tática;
- Motor de partida;
- 2D;
- Manager;
- Carreira;
- Mercado;
- Seleções;
- Narrativa;
- 3D.

---

# 51. CRITÉRIO DE QUALIDADE

Antes de aprovar qualquer módulo, verificar:

- Está conectado ao resto do universo?
- Gera consequências reais?
- Pode ser expandido?
- Está separado de dados/assets quando necessário?
- Funciona em saves longos?
- Evita hardcode desnecessário?
- Tem UI coerente?
- É compreensível para o jogador?
- Preserva realismo sem virar burocracia?

---

# 52. REGRA MESTRA

O objetivo não é criar:

> um menu bonito com dados de futebol.

O objetivo é criar:

> um universo de futebol vivo, persistente, explicável, expansível e divertido, onde jogadores, clubes, técnicos, competições, mercado, tática, partidas e história influenciam uns aos outros ao longo de décadas.

---

# 53. COMO USAR ESTE ARQUIVO

Ao iniciar uma nova conversa ou ferramenta:

1. fornecer este arquivo como contexto;
2. pedir para lê-lo antes de propor mudanças;
3. tratar decisões deste arquivo como vigentes;
4. atualizar somente quando houver nova decisão explícita;
5. nunca reiniciar o projeto do zero sem necessidade;
6. registrar mudanças importantes em uma seção de changelog.

---

# 54. CHANGELOG

## v0.1 — Contexto inicial

Consolidado o briefing mestre do Football Universe e definido o Project State inicial.

---

# 55. PRÓXIMA TAREFA RECOMENDADA

**Criar a arquitetura visual do produto e a ficha de jogador**, juntamente com:

- design system;
- navegação principal;
- estrutura de telas;
- modelo da ficha;
- agrupamento dos ~70 atributos;
- primeiro schema da database.

Isso deve acontecer antes do motor 2D/3D.

---

# 56. REGRA DE ENTREGA: RELATÓRIO DE DESENVOLVIMENTO

**Decisão expressa do usuário em 09/10/2026:** a partir da primeira entrega ZIP, todo pacote do Football Universe deve incluir um arquivo `RELATORIO_DESENVOLVIMENTO.md` com, no mínimo:

- funcionalidades **implementadas**, **parciais**, **protótipos**, **pendentes** e **planejadas**, com classificação honesta;
- o que ainda falta em relação ao próximo milestone e ao produto completo;
- recomendações e ordem técnica de prioridades, incluindo riscos, decisões e alternativas;
- testes de fato executados, resultados e o que ainda não foi validado;
- bugs identificados, limitações e arquivos alterados;
- changelog e próximos passos com critérios de aprovação.

O relatório deverá integrar o ZIP e também ser disponibilizado separadamente quando possível. Esta regra complementa as seções 49, 51 e 54, sem mudar a ordem de construção da seção 46.

**Changelog complementar — 09/10/2026:** padronização obrigatória dos relatórios de desenvolvimento, iniciada pela auditoria da v0.1.

---

# ADENDO DE CONTINUIDADE · 2026-10-09 · v0.2

A definição de produto e as prioridades originais acima permanecem vigentes.

**Estado implementado nesta etapa:** protótipo web navegável, 70 atributos, database fictícia com 4 clubes e 64 atletas, editor ampliado, treino configurável, scouting limitado/progressivo, mini-liga fictícia que resolve 6 jogos com motor estatístico experimental, classificação, notícias persistentes, saves com migração v1→v2, validação reforçada e build reproduzível.

**Ainda NÃO definitivos:** elencos reais, competições reais, temporadas repetidas, evolução de carreira, contratos completos, scouts e treino avançados, motor espacial de partida, animação 2D, 3D, mundo de 15–30 temporadas e imprensa autônoma.

**Regra de entrega aprovada pelo usuário:** cada nova versão deve ter um relatório completo **diretamente na resposta da conversa**, com o que foi implementado, o que falta, testes, riscos e recomendações. Incluir também `RELATORIO_DESENVOLVIMENTO.md` no ZIP como registro secundário.

---

# ADENDO DE CONTINUIDADE · 2026-10-09 · v0.3

A v0.3 foi construída incrementalmente sobre v0.2. A liga fictícia agora tem turno e returno (12 partidas), encerramento manual de temporada, campeonato seguinte gerado, arquivo de campeões e estatísticas de jogos. Treino individual, scouting com custo financeiro/cancelamento, reagendamento de partidas futuras, notícias de títulos, schema v3 e migração de saves v1/v2 foram implementados. Testes: 22 de núcleo + fluxos reais no Chromium a 390, 768 e 1440 px + consistência/serialização de 20 temporadas demonstrativas. Dados seguem **inteiramente fictícios**. Não há motor de partida espacial, múltiplas competições reais, clubes/elencos reais, aposentadorias/newgens, carreira completa ou 2D/3D. Não declarar nenhum módulo definitivamente concluído. Manter relatório completo **na conversa** e ZIP com o relatório técnico.

---

## Atualização de implementação v0.4 — 09/10/2026

Preservadas as decisões originais do contexto mestre. Foi criada uma base parcial de quatro clubes reais e 107 nomes reais de atletas de 2026, com links de fonte por clube. As 70 avaliações são **provisórias para testar a simulação**, não avaliações oficiais. Há links documentados para 15 fotografias reais e de licença identificada no Wikimedia Commons. Os bytes das imagens ainda não acompanham o ZIP; a geração de HTML com imagens offline depende do download opcional em máquina com internet. As futuras etapas devem completar dados/fotos de A e B e seleções, preservando IDs e saves e evitando tratar resultados experimentais como fatos. Relatório obrigatório escrito diretamente no chat a cada ZIP.

---

## Atualização v0.5 — Modo Copa do Mundo (09/10/2026)

- Implementado módulo Copa separado do Manager, com interface de catálogo para 100 países, 48 participantes selecionáveis, ficha com 70 atributos, grupos, mata-mata, 104 jogos e save local.
- Integrador online de duas fontes: 48 inscritos FIFA 2026 (23 selecionados por nação) e até 52 seleções adicionais por jogadores elegíveis na base EA FC 26, com validação de 23 por equipe.
- Fotos externas e atributos derivados/estimados, com transparência de origem. Nenhum facepack completo incluído no ZIP.
- Pendente: sincronizar, validar e congelar snapshot real completo de 2.300 jogadores, fotos licenciadas locais, chaveamento FIFA exato e simulação espacial.
- Consultar RELATORIO_DESENVOLVIMENTO.md da v0.5 antes de avançar.

---

## v0.6 — Continuidade implementada (09/10/2026)

- Modo Treinador 2D desenvolvido em `treinador/`, com motor espacial simplificado e Canvas, táticas durante o jogo e substituições.
- Brasileirão Série A 2026 gerado com 20 clubes e 380 jogos, 38 rodadas. O calendário e suas datas não são integrais oficiais; apenas o conjunto de confrontos da primeira rodada foi amparado no boletim CBF.
- Copa 2026 jogável com 48 seleções no treinador, 104 partidas, e possibilidade de usar os elencos de 23 atletas sincronizados no modo anterior. Ausências são marcadas por posições neutras.
- Motor permanece **experimental**, com FIFA/CBF reais apenas como fontes para identidades e formato, não para resultados.
- Modo treinador guarda estado independente em localStorage com exportação JSON.
- Testes automatizados: 47/47; browser via HTML injetado em Chromium isolado: 390, 768 e 1440 px, sem erros nos fluxos validados.
- Próxima prioridade: elencos reais completos, calendário oficial, 2D com física/regras realistas, formação/tática profunda e carreira multitemporada.
- Relatório completo obrigatório na resposta do assistente e dentro do ZIP.
