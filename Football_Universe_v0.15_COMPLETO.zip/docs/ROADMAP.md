# Roadmap oficial preservado

Origem: seção 46 e seção 55 de `FOOTBALL_UNIVERSE_CONTEXT.md`.

## Ordem macro

1. Arquitetura geral: iniciada em v0.1.
2. Design system e layout: protótipo funcional em v0.1.
3. Modelo de dados: schema inicial v1 funcional, ainda sem dados reais.
4. Sistema dos ~70 atributos: catálogo e validações v0.1 concluídos.
5. Clubes, jogadores e competições: infraestrutura de demonstração; importar elencos reais da Série A, Série B e seleções de 2026.
6. Universo persistente: começar motor de calendário, histórico, eventos, temporadas completas e reconciliação de saves.
7. Tática: expandir papéis, instruções por fase e IA dos técnicos.
8. Motor de partida: evolução de estados coerente com jogadores, espaço, atributos e bola; eventos auditáveis.
9. Visualização 2D: consumir o estado do motor de jogo, sem duplicar regras.
10. Manager: contratos, treino, comissões, diretoria, finanças, delegação.
11. Carreira: jogador e treinador sobre a mesma infraestrutura.
12. Mercado e scouting: avançar negociações, concorrência e incerteza.
13. Seleções: convocações, temporadas e competições.
14. Narrativa: notícias, imprensa e memória de mundo.
15. 3D: visualização derivada do **mesmo motor de jogo**; sem começar pelo 3D.
16. Expansões continentais: Libertadores e Sul-Americana.

## Próxima fase recomendada

Integrar fontes verificáveis para os elencos, contratos e calendário oficial, mantendo diferenciação entre dado confirmado, estimado e fictício. Consolidar schema e migrações antes do motor de partidas. Testar saves de várias temporadas quando o calendário completo estiver implementado.

## Atualização de progresso · v0.2 (09/10/2026)

- Reforço de integridade de database e migração v1→v2: **implementados no escopo demo**.
- Editor atleta/clube, scouting, treino e notícias: **protótipos mais funcionais, não definitivos**.
- Liga de Demonstração: **resultados/classificação funcional**, com motor estatístico determinístico **experimental**, sem posição/bola ou 2D.
- Manter prioridade de database real verificada, persistência longa e motor de partida espacial antes das interfaces gráficas 2D e 3D.

## Atualização de progresso · v0.13 (12/10/2026)

- Item 16 (Expansões continentais): **Libertadores e Sul-Americana implementadas** no universo de ligas (formato, vagas de 2026, transferência entre torneios, virada de temporada). Pendentes: ligas dos demais países sul-americanos, Copa do Brasil, Recopa e, em seguida, a estrutura europeia (Champions, Europa e Conference League).

## Atualização de progresso · v0.15 (13/10/2026)

- Item 5 (Clubes, jogadores e competições): **Série A 2026 completa** (20 clubes, 673 atletas, 38 rodadas) no Manager e no Treinador. Pendentes: Série B e demais ligas, treinadores e salários verificados, calendário oficial da CBF e estatísticas reais de desempenho (gols, assistências, minutos) para refinar os atributos.
