# CP017–CP024 Action Architecture Integration Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use `superpowers:executing-plans` to implement this plan task-by-task. Run after CP001–CP016 adapter contracts have been approved and merged into the working branch.

**Goal:** Make the 257-entry action catalog available to the v0.15 match engine through a guarded adapter while preserving the existing engine as the sole authority for official outcomes.

**Architecture:** Keep catalog, registry, eligibility, profiles, timeline and incidents under `architecture/actions/`. An adapter translates real v0.15 match/player context and selected action intent; `treinador/match-engine.js` alone commits outcomes. Unsupported actions fall back to the current decision path and do not persist experimental IDs.

**Tech Stack:** Node.js 20+, ESM, Node test runner, existing v0.15 match engine and renderer; no third-party runtime dependency.

**Spec:** `docs/superpowers/specs/2026-10-22-football-universe-action-architecture-design.md`

## Global Constraints

- Complete and use the approved CP001–CP016 snapshot and adapter contracts first.
- Never run independent action success RNG that can contradict the match engine.
- Do not store catalog action IDs in existing saves.
- `animation.implemented` remains false unless a real corresponding clip is present.
- Injury definitions never invent recovery duration or independently change availability.
- Unknown/ineligible action falls back to the current engine action without state mutation.

## Review Focus

- Attribute mapping mismatch could read the wrong skill; pin every mapping to the source attribute key and test it.
- Calling both the prototype simulator and host engine could roll twice; test host outcome/RNG authority.
- Animation IDs could overstate actual visuals; test absent-clip fallback and report flags.
- Unsupported categories could dead-end play; test fallback for every category.
- Mid-match saves could change shape; compare save schema and exact state around adapter calls.

---

### Task 1: Import catalog and preserve registry contracts

**Files:** Create `architecture/actions/catalog/`, `architecture/actions/engine/registry.mjs`, `architecture/actions/tests/registry.test.mjs`.

**Interfaces:** `createActionRegistry(catalog) -> registry`; `registry.get(id)` returns immutable record; catalog declares all 257 IDs and 11 categories.

- [ ] Write tests for the 257 stable IDs, category counts, schema, duplicate IDs and immutability; run and observe expected failures.
- [ ] Add catalog/schema and implement registry validation.
- [ ] Run `node --test architecture/actions/tests/registry.test.mjs`; expected: exact count and schema pass.

### Task 2: Map v0.15 context and attributes

**Files:** Create `architecture/actions/integration/v015-adapter.mjs`, `architecture/actions/tests/adapter.test.mjs`.

**Interfaces:** `toActionContext(match, side, actorId) -> { actor, ball, phase, pressure, distance, weatherImpact } | rejection`; `resolveMappedAttribute(player, key) -> number | rejection`.

- [ ] Write tests using actual player records and match states for each mapped attribute and each phase/ball/actor condition.
- [ ] Verify exact source fields in v0.15 before mapping; reject missing/ambiguous values without guessing.
- [ ] Implement context and attribute translation; prove it does not mutate match state or RNG.

### Task 3: Integrate eligibility and action intent with one outcome authority

**Files:** Create `architecture/actions/integration/dispatch.mjs`, modify `treinador/decisions.js` and `treinador/match-engine.js` only through the adapter seam identified in CP025; add `architecture/actions/tests/dispatch.test.mjs`.

**Interfaces:** `dispatchAction(registry, context, actionId) -> { accepted, intent, markers, reason }`; it does not produce goals, possession outcomes or committed events.

- [ ] Test valid/invalid shots, passes, dribbles, tackles, goalkeeping and phase-gated actions; assert rejection preserves state/RNG.
- [ ] Implement dispatch for only host-supported categories and leave unsupported IDs on existing `chooseAction` fallback.
- [ ] Test same-seed host match remains deterministic and the existing engine applies each result once.

### Task 4: Add bounded profiles, visual timeline and injury incident bridge

**Files:** Adapt `engine/profiles.mjs`, `engine/timeline.mjs`, `engine/sequence.mjs`, `engine/incidents.mjs` under `architecture/actions/`; create `architecture/actions/tests/profiles-timeline.test.mjs`.

**Interfaces:** `getActionProfile(id, context)`, `createVisualTimeline(id, context)`, `describeIncident(id, context)`. Returned probability/profile is intent metadata and cannot update the host match directly.

- [ ] Test all shot profiles and one representative from other categories; missing visual clip always reports `implemented: false`.
- [ ] Test timeline marker bounds, ordering and cancellation without changing official event state.
- [ ] Test injury incident only emits descriptive metadata; existing discipline/availability state remains unchanged absent an explicit host contract.

### Task 5: Add regression entrypoint and update report

**Files:** Modify `package.json`, `README.md`, `CHANGELOG.md`, `RELATORIO_DESENVOLVIMENTO.md`; add `architecture/actions/tests/run-all.test.mjs` only if needed.

- [ ] Add `test:actions` and `test:all` while preserving existing scripts.
- [ ] Run action architecture tests, all existing v0.15 tests, build, league/continental/Cup simulations, save migration/reload and protected dry-run checks.
- [ ] Record action IDs registered, categories actually dispatchable, fallbacks, absent clips, uncalibrated values and runtime checks.
- [ ] Generate final ZIP only after successful verification; exclude `.git`, temporary files and `node_modules`.
