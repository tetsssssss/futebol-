# CP001–CP016 World Architecture Integration Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use `superpowers:executing-plans` to implement this plan task-by-task. Keep every step as a test-first change.

**Goal:** Integrate the CP001–CP016 data architecture into Football Universe v0.15 as an optional, read-only validation and import-planning layer.

**Architecture:** Place adapted modules in `architecture/world/`; make the v0.15 catalog the canonical input through an explicit snapshot adapter. Validation, identity, dry-run planning, asset auditing and handoff produce reports without changing game data or saves.

**Tech Stack:** Node.js 20+, ESM, Node built-in test runner, existing JSON Schema files and CLI conventions; no runtime dependency additions.

**Spec:** `docs/superpowers/specs/2026-10-22-football-universe-world-architecture-design.md`

## Global Constraints

- The v0.15 catalog, IDs, attributes, competitions and saves remain canonical.
- All merge planning is `DRY_RUN_ONLY`; `autoApply` stays false.
- Fixture-only examples are never production records.
- Existing inputs and saves are read-only and are never overwritten.
- No external photo download or identity inference is added.
- No official competition claims without edition-specific source evidence.

## Review Focus

- Ambiguous aliases could merge different clubs or players; require explicit identity evidence and test conflicts.
- Broken references could leak into a report as importable records; validate every remapped reference.
- Existing output paths could be overwritten; test exclusive output creation.
- v0.15 save/private data could enter a snapshot; constrain snapshot fields and test exclusion.
- Legacy package samples could be mistaken for real data; tag fixtures and assert the import gate rejects them.

---

### Task 1: Isolate source package and establish v0.15 baseline

**Files:** Extract supplied v0.15 ZIP into a new `football-universe-v0.15` directory; do not alter the ZIP or sibling v0.6 project. Add `architecture/world/README.md` and baseline notes under `architecture/world/reference/`.

**Interfaces:** Source archive is `Football_Universe_v0.15.0_Brasileirao_20_clubes_38_rodadas_2026-10-13.zip`; architecture source is `FOOTBALL_UNIVERSE_ARQUITETURAS_CP001_CP024.zip`.

- [ ] Record archive SHA-256 and extracted source revision fingerprint in a new baseline manifest.
- [ ] Run `npm test` and `npm run build` in the extracted project and save unmodified baseline output under `qa/architecture/baseline/`.
- [ ] Verify the original ZIP hashes are unchanged and the target folder did not pre-exist.

### Task 2: Add adapted schemas and validation entrypoint

**Files:** Create `architecture/world/core/schema/`, `architecture/world/core/validation/index.mjs`, `architecture/world/tests/validation.test.mjs`.

**Interfaces:** `validateWorldSnapshot(snapshot) -> { valid, errors, counts }`; all errors identify entity type, record ID and field path. Adapt external schemas in a separate input envelope; do not change game-native records.

- [ ] Write tests for valid club/player/competition records, missing IDs, malformed 70-attribute vectors and unknown schema versions; run and observe expected failures.
- [ ] Adapt the source schemas and implement `validateWorldSnapshot` with explicit schema-version gates.
- [ ] Run `node --test architecture/world/tests/validation.test.mjs`; expected: all validation assertions pass.

### Task 3: Add ID registry and referential audit

**Files:** Create `architecture/world/core/id_registry/index.mjs`, `architecture/world/core/referential_integrity/index.mjs`, `architecture/world/tests/identity.test.mjs`.

**Interfaces:** `createIdRegistry(records, aliases) -> registry`; `auditReferences(snapshot, registry) -> { errors, warnings }`. Registry lookups cover stable IDs and explicit aliases; ambiguous matches return conflict records, never a selected candidate.

- [ ] Write failing tests for duplicate IDs, explicit aliases, ambiguous aliases, club/player crosslinks and missing competition participants.
- [ ] Implement indexed lookup and a bidirectional reference audit.
- [ ] Run `node --test architecture/world/tests/identity.test.mjs`; expected: ambiguous and dangling links are rejected.

### Task 4: Add immutable v0.15 snapshot adapter and fingerprints

**Files:** Create `architecture/world/integration/snapshots/index.mjs`, `architecture/world/integration/adapters/v015.mjs`, `architecture/world/tests/snapshot.test.mjs`.

**Interfaces:** `snapshotV015(readOnlySource) -> snapshot`; `hashSnapshot(snapshot) -> sha256`; adapter emits only approved public catalog fields and excludes save/carrier/user state.

- [ ] Test adapter output against real v0.15 fixtures for the 20 clubs, 673 players, 70 attributes and current competition records; test private/save-field exclusion.
- [ ] Test that source bytes/hash are identical before and after snapshot creation.
- [ ] Implement the adapter and deterministic hashing; run the focused test.

### Task 5: Add conservative dry-run merger

**Files:** Create `architecture/world/core/data_merger/index.mjs`, `architecture/world/tests/merge-plan.test.mjs`.

**Interfaces:** `createMergePlan(base, additions, { aliases, fixtureOnly }) -> plan`; every record is `NOVO`, `EXISTENTE` or `CONFLITO`; plan contains remapped references and `autoApply: false`.

- [ ] Write tests for duplicate, new, conflict, alias remapping, invalid remapped references and fixture-only rejection.
- [ ] Implement index-based comparison and immutable planned mappings; do not add a write/apply function.
- [ ] Verify base and additions hashes are unchanged and all conflicts block eligible additions.

### Task 6: Integrate edition rules, tournament audit and asset registry

**Files:** Adapt `engines/edition_rules/`, `engines/tournament/`, `core/asset_registry/`; add `architecture/world/tests/edition-assets.test.mjs`.

**Interfaces:** `checkEdition(edition) -> report`; `auditTournament(edition) -> report`; `auditAssets(manifest, root) -> report`. Edition checks require edition IDs and source metadata; tournament audit validates bracket structure but does not simulate results; asset audit hashes existing local files only.

- [ ] Test unsupported/missing-source rules, conflicting club dates, incomplete groups and asset path escape/missing-file cases.
- [ ] Adapt the package modules and add report-only asset validation with bounded size/dimension checks.
- [ ] Run the focused suite; expected: no generated result or asset import.

### Task 7: Add protected CLI and handoff gates

**Files:** Create `architecture/world/tools/cli.mjs`, `architecture/world/integration/handshake/index.mjs`, `architecture/world/tests/cli.test.mjs`.

**Interfaces:** CLI subcommands `snapshot`, `validate`, `merge-plan`, `edition-check`, `asset-audit`, `handoff`; `writeReportExclusive(path, data)` uses exclusive creation. Handoff includes source revision, schema/save version, adapter status, backup/test status and `autoApply: false`.

- [ ] Test all commands using temporary fixtures, output collision, input/output path collision and incomplete handoff gates.
- [ ] Implement argument parsing and gate report; errors return nonzero exit status.
- [ ] Run `node --test architecture/world/tests/cli.test.mjs` and CLI smoke commands.

### Task 8: Full regression and delivery notes

**Files:** Modify `package.json`, `README.md`, `CHANGELOG.md`, `RELATORIO_DESENVOLVIMENTO.md`; add `architecture/world/tests/run-all.test.mjs` only if needed.

- [ ] Add `test:architecture` and `test:all` scripts without changing existing command behavior.
- [ ] Run architecture Node tests, existing `npm test`, `npm run build`, schema validation and dry-run CLI against v0.15 snapshot.
- [ ] Verify saves/catalogs/ZIP input fingerprints remain unchanged; document exact passes, conflicts, unfilled datasets and unsupported gates.
- [ ] Regenerate distribution only after all tests pass; prepare complete source ZIP after verification.
