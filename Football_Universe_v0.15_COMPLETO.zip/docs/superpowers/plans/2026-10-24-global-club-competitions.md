# Plano: catálogo de competições globais de clubes

## Intenção

Registrar no Football Universe os formatos e participantes oficiais do Mundial de Clubes FIFA 2025, as classificações já confirmadas para 2029, a Copa Intercontinental FIFA 2026, a Copa do Brasil 2026, a Supercopa Rei 2026 e a Recopa CONMEBOL 2026. Os dados precisam distinguir fatos concluídos, calendário futuro e vagas pendentes.

## Limites

- Não substituir os calendários ou elencos das competições jogáveis existentes.
- Não inventar a distribuição de vagas ou participantes ainda não anunciados para 2029.
- Não tratar o catálogo arquitetural como integração visual/jogável completa.
- Manter identificadores coerentes com os clubes nacionais já existentes.

## Abordagens consideradas

1. Criar catálogo na arquitetura mundial e exportá-lo pelo índice de competições — escolhido, pois essa camada já contém a estrutura genérica do Super Mundial e possui testes próprios.
2. Adaptar já as telas e motores nativos do modo Treinador — amplia o escopo e exigiria calendários/plantéis internacionais completos que não fazem parte deste pacote de evidências.
3. Apenas documentar os resultados — não deixa dados consultáveis nem valida formatos por código.

## Arquivos

- Criar `architecture/world/engines/competitions/global-club-competitions.mjs` com registros imutáveis, fontes, clubes, grupos, vagas, fases e resultados.
- Exportar o catálogo em `architecture/world/engines/competitions/index.mjs`.
- Validar os dados em `architecture/world/tests/global-club-competitions.test.mjs`, cobrindo participantes, distribuição, fases, duplicatas, resultados e status de qualificação.
- Atualizar `README.md` e `CHANGELOG.md` com a disponibilidade e o limite arquitetural.

## Verificação e entrega

Executar o teste focado, `npm run test:all`, `npm run build`, `npm run architecture:validate` e criar novo ZIP completo sem substituir entregas anteriores. Inspecionar o conteúdo e calcular SHA-256 antes de informar a entrega.
