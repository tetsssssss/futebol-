# Plano: transmissão 2.5D como visual inicial das partidas

## Intenção

Aplicar às partidas do Modo Treinador (Brasileirão, Copa, Eliminatórias e competições continentais) o visual do campo em perspectiva das referências, com câmera de transmissão, atletas/bola 3D, HUD e controles táticos; manter a câmera tática/bola e o Canvas 2D compatíveis.

## Decisões e abordagens

- **Escolhida:** promover o renderer Babylon.js 2.5D já compartilhado pela partida a modo visual inicial; persistir preferência visual/câmera localmente; manter fallback automático para Canvas 2D. Isso reaproveita simulação, replays, comandos e saves.
- Refazer o motor ou substituir a partida por uma nova implementação 3D: rejeitado porque duplicaria estado e poderia divergir de placares/saves.
- Converter toda a interface do Manager para o campo: fora do pedido, pois as referências tratam a apresentação da partida.

## Arquivos

- `treinador/visual-preferences.js`: leitura e persistência segura das preferências de apresentação.
- `treinador/viewer.js`, `treinador/hud.js`, `treinador/app.js`, `treinador/renderer-25d.js`, `treinador/style.css`: integração, rótulos, UX de carregamento/fallback e textos.
- `tools/build.mjs`: incluir GLBs de `assets/3d/` no pacote portátil.
- `tests/visual-preferences.test.js` e `tools/browser-qa.cjs`: contrato de preferência e verificação da partida real no desktop/mobile.
- README e CHANGELOG: comportamento implementado e limites restantes.

## Limites

Não alterar motor, RNG, resultados, regulamentos, calendário ou modelo de save. A câmera 2.5D depende de WebGL, Babylon.js disponível via CDN na versão atual, e hardware compatível; Canvas 2D permanece como fallback. Os modelos de jogador ainda são de baixa contagem de polígonos e não têm ciclo de caminhada rigado.

## Verificação e entrega

Testes de preferência, suíte completa, build, verificação dos assets copiados e QA visual do Modo Treinador em largura desktop e mobile. Gerar ZIP completo novo, verificar entradas e SHA-256.
