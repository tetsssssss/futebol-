# Football Universe v0.15 — Integração do catálogo de ações (CP017–CP024)

## Contexto e objetivo

Integrar o catálogo versionado de 257 ações como dados e contratos de seleção/eligibilidade no modo treinador v0.15. O motor atual continua decidindo a consequência oficial de cada jogada. A integração deve ser incremental: ação sem adaptador compatível é recusada com motivo claro, sem interferir na partida.

## Dependência

Depende da camada de compatibilidade e snapshot CP001–CP016, para fixar o schema e mapear os 70 atributos e as referências do v0.15. A versão atual já possui estado, decisões, simulação, disciplina, replay, resumo, renderer e testes em `treinador/`. O pacote de ações relata explicitamente que não implementa corpos rígidos, física real ou clipes: todos os 257 `animation.implemented` estão falsos.

## Arquitetura proposta

Manter o catálogo CP017–CP024 em `architecture/actions/` com ID, schema, registry imutável, elegibilidade, perfil/intenção, marcadores de timeline e incidentes. Criar um adaptador no modo treinador que:

- traduza atleta, bola, fase, pressão e contato do estado v0.15 para o contexto de ação;
- resolva atributos usando o mapeamento CP025 aprovado, sem adivinhar índices;
- consulte o registry e devolva ação elegível, perfil/intenção e motivo de rejeição;
- associe marcadores visuais apenas aos estados que renderer/animações realmente suportam;
- entregue ao motor atual a jogada autorizada e deixe placar, posse, falta, cartão e resultado sob responsabilidade de `match-engine.js`.

`simulation.mjs` não será uma segunda autoridade para acerto/gol nem uma segunda rolagem estocástica. Pode ser usado em harness isolado de calibração, explicitamente marcado como não autoritativo. Catálogo não escreverá IDs em saves legados; qualquer futura persistência exige migração versionada separada.

Lesões permanecem incidentes condicionais. Disponibilidade, prognóstico e suspensão usam `discipline.js`/estado existente somente após mapeamento comprovado; o catálogo não inventa dias de afastamento nem cria indisponibilidade por si só.

## Fluxo e fallback

O motor propõe contexto → adaptador resolve ação → registry verifica ID/requisitos/fase → adaptador converte o perfil em comando que o motor atual reconhece → motor aplica o resultado oficial → replay/renderer exibem apenas marcadores e estados suportados. Se uma ação for incompatível, o motor usa sua decisão existente e registra diagnóstico; o ID experimental não entra em save ou resultado oficial.

## Verificação

- Manter 257 IDs estáveis e validar schema/contagens no registry.
- Mapear cada ação por categoria para entradas reais do estado v0.15; provar que ação inelegível não muda RNG, placar, bola, posse ou save.
- Testar determinismo da autoridade do motor, independência do renderer e timeline sem mutação de estado.
- Testar atributos, contato e aliases com atletas existentes e slots posicionais.
- Confirmar que ação sem clip mantém fallback visual e não alega animação implementada.
- Regressão completa: ligas, Copa, Libertadores/Sul-Americana, disciplinas, replays, saves e build.

## Critérios de aceite

1. Catálogo CP017–CP024 executável e validado dentro da estrutura v0.15.
2. Adaptador usa schema/atributos identificados na etapa mundial e não resolve resultado oficial em paralelo.
3. Ações não suportadas são rejeitadas com fallback existente, sem corromper a partida.
4. Incidentes de lesão não inventam tempos clínicos e não alteram disponibilidade sem contrato explícito.
5. As alegações distinguem itens cadastrados, ações executáveis e clipes realmente existentes.

## Fora desta etapa

257 animações reais, física 2D/3D completa, pathfinding, novos rigs, sintomas ou prognósticos clínicos, equilíbrio de probabilidades em partidas reais e gravação retrocompatível de identificadores experimentais em saves antigos. Esses itens continuam pendentes no roadmap CP025–CP040.
