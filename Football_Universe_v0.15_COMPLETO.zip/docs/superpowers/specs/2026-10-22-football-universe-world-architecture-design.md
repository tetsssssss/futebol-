# Football Universe v0.15 — Integração da arquitetura mundial (CP001–CP016)

## Contexto e objetivo

Integrar ao código-fonte v0.15.0 os componentes reutilizáveis do pacote World Expansion, preservando a aplicação atual como fonte de verdade para clubes, atletas, atributos, competições e saves. A arquitetura deve acrescentar contratos de validação e preparação de dados; não deve substituir o Manager, as competições existentes nem importar os exemplos fictícios.

## Evidência e fronteira

O pacote afirma expressamente que CP001–CP024 é independente e não está integrado. Seu próprio contrato exige snapshot, adaptação específica, plano revisável e proíbe auto-merge. O ZIP v0.15 contém fontes JavaScript (`src/`, `treinador/`), testes e build; não é apenas o APK legado examinado pelo relatório CP001–CP009. Portanto, a auditoria de integração será feita contra o conteúdo do ZIP e registrará hashes locais. O índice `legacy_v015_index.json` é referência histórica, não um catálogo a importar.

## Arquitetura proposta

Organizar os módulos integrados sob `architecture/world/`, preservando a separação dos pacotes e adaptando interfaces na borda:

- **Esquemas e validação:** validar clubes, atletas e competições com versões explícitas. Conversores de entrada traduzem dados para o formato v0.15; nenhuma tela ou motor passa a consumir o schema externo diretamente.
- **Identidade e integridade:** registro indexado e auditoria de referências. ID do v0.15 prevalece; aliases exigem correspondência explícita. Conflitos permanecem pendentes de revisão.
- **Planejamento de merge e snapshots:** produzir fingerprint e plano `DRY_RUN_ONLY` fora dos saves. O processo não altera JSONs de origem nem aplica adições automaticamente.
- **Competições e temporadas:** regras e resultados são por edição e só entram no jogo por adaptador quando dados/regulamento tiverem fonte declarada. Placeholders não são qualificados como clubes ou participantes reais.
- **Assets:** índice com hash, origem, tipo e limites; integração não baixa nem identifica imagens automaticamente.
- **Handoff:** contrato registra versão/hash, schema, save, interfaces do motor, assets e resultado dos gates antes de permitir um plano de escrita.

`src/`, `treinador/engine.js`, `treinador/match-state.js`, arquivos de dados e save v0.15 permanecem donos das entidades atuais. Integração dos módulos não altera o formato nem migra saves nesta etapa.

## Fluxo de dados

1. Ler a base v0.15 e gerar snapshot/hash somente de leitura.
2. Validar adições contra schema e identidade; testar referências.
3. Emitir classificação `NOVO`, `EXISTENTE` ou `CONFLITO`, mapeamentos de aliases e relatório sem mutar as entradas.
4. Bloquear consumo pelo jogo quando houver conflito ou gate de handoff pendente.
5. Somente em uma etapa posterior e explicitamente revisada, produzir exportação de catálogo versionada e adaptada ao v0.15.

## Falhas e compatibilidade

Schema desconhecido, hash divergente, IDs ambíguos, referências ausentes, dados fictícios usados como produção, regras sem edição/fonte e relatório de saída já existente devem falhar de forma explícita. O snapshot é isolado de dados de carreira e de informações pessoais. A versão atual do jogo permanece executável mesmo sem a arquitetura opcional carregada.

## Verificação

- Testes de unidade para schema, índices, aliases, referências e estados de conflito.
- Testes de imutabilidade que comparam bytes/hash das entradas antes e depois de snapshot, validação, handoff e merge-plan.
- Testes de não sobrescrita para saída preexistente e entradas.
- Fixtures são rotuladas fictícias e proibidas de entrar no catálogo de produção.
- Testes de regressão do v0.15: temporadas, competições, mídia, saves e build.

## Critérios de aceite

1. Componentes CP001–CP016 selecionados estão sob namespace próprio e executáveis pelo projeto v0.15.
2. A arquitetura lê um snapshot adaptado do v0.15 e detecta vínculos inválidos sem alterar a base.
3. Plano de merge e handoff declaram `autoApply: false` e bloqueiam conflito/gates incompletos.
4. Referência histórica e exemplos fictícios não se tornam dados do jogo.
5. Build e saves existentes passam na regressão.

## Fora desta etapa

Pesquisa/ingestão de dezenas de milhares de registros, revisão de aliases ambíguos, fotos sem identidade confirmada, validação de cada regulamento oficial, publicação/geração de APK, migração de save e merge automático. A etapa prepara interfaces para expansão; não afirma que os seis continentes ou todas as competições estão preenchidos.

## Decomposição

Esta especificação cobre a fundação CP001–CP016. O catálogo de ações CP017–CP024 tem especificação e plano independentes, dependentes do snapshot e adaptador do motor estabelecidos aqui. Ele não será misturado aos dados de clubes nem assumido como animação pronta.
