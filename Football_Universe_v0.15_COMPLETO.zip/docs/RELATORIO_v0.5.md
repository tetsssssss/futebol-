# FOOTBALL UNIVERSE · RELATÓRIO DE DESENVOLVIMENTO v0.5

**Data:** 9 de outubro de 2026
**Missão:** acrescentar Modo Copa do Mundo, com 48 participantes selecionados entre um banco de 100 seleções, 23 atletas por seleção, fotos e 70 atributos.

## 1. IMPLEMENTADO NO CÓDIGO

- Módulo autônomo `copa/`, navegável a partir do menu do aplicativo original, sem reconstruir o manager.
- Banco de identidades de 48 seleções da Copa real 2026, com suporte de importação da lista FIFA (jogadores e URLs de retratos).
- Lista de países candidatos extras e ingestão de dados EA FC 26 para formar 52 seleções adicionais com no mínimo 23 atletas.
- Normalização de nomes e posições, 70 atributos de 0–100 com mapeamento de métricas EA FC quando disponíveis e estimativas explícitas nos campos faltantes.
- Validação rigorosa: 100 seleções distintas, 23 jogadores distintos por seleção, 70 atributos inteiros e dados essenciais presentes.
- Página de 100 seleções (antes da sincronização, apenas os nomes disponíveis como catálogo), busca, filtros e ficha com 70 atributos em 11 grupos.
- Exibição de imagens reais remotas quando disponíveis, com fallback neutro e indicação de procedência.
- Escolha dos 48 participantes, sorteio reprodutível de 12 grupos com quatro, classificação de dois primeiros + oito melhores terceiros.
- Eliminatórias com 32 classificados, oitavas, quartas, semifinais, terceiro lugar e final; 104 partidas em total.
- Simulação determinística experimental, placares, gols atribuídos, artilharia e histórico.
- Cache IndexedDB da base e da Copa, backups separados para o universo da Copa e a database.
- Interface integrada ao manager existente e builds HTML portáteis `dist/index.html`, `dist/copa/index.html`.

## 2. O QUE AINDA NÃO FOI CONCLUÍDO

- **2.300 atletas reais dentro do ZIP:** NÃO. O pacote contém o motor de sincronização, não uma cópia offline completa dos elencos.
- **100 seleções preenchidas pela fonte real:** NÃO foi verificado nesta execução. O preenchimento real depende de conexão/importação das fontes; caso a base EA FC tenha menos que 52 nacionalidades elegíveis com ao menos 23 registros, o processo alerta e não preenche artificialmente.
- **Fotos locais para todos os 2.300 atletas:** NÃO. O projeto salva apenas URLs de retratos dos provedores; disponibilidade e licença de redistribuição não verificadas individualmente.
- **Atributos FIFA oficiais:** NÃO. Parte vem de avaliações do jogo EA FC 26; outra parte é estimativa técnica determinística e não deve ser usada como se fosse estatística factual.
- **Convocações oficiais das 52 equipes extras:** NÃO. São seleções de jogadores elegíveis da database e não chamadas oficiais.
- **Chaveamento oficial da Copa 2026:** NÃO. A distribuição de grupos e confrontos dos eliminatórios usa algoritmo alternativo próprio.
- **Motor com movimentação de jogadores:** NÃO. Segue uma simulação estatística inicial.

## 3. TESTES E EVIDÊNCIAS

- `npm test`: **36/36** (24 regressivos manager v0.4 + 12 relativos ao modo Copa); verificou também 100×23×70 em dataset controlado de teste, não nos dados finais reais.
- Simulação integral automatizada: 104 partidas, um campeão, grupos e chaveamento consistentes; determinismo por seed.
- `npm run build`: gerou dois HTML portáteis sem dependências npm externas.
- Validação sintática Node dos módulos e dos scripts embutidos: aprovada.
- Teste visual Chromium: **não concluído**. O navegador bloqueou os endereços `file://` e `http://127.0.0.1:4173/` com `ERR_BLOCKED_BY_ADMINISTRATOR` neste ambiente.
- Sincronização real dos 100 elencos por rede: **não executada** no container, onde DNS/HTTP externo estão bloqueados.

## 4. RISCOS

1. Datasets externos podem modificar endpoints, CORS, conteúdo ou disponibilidade, impedindo ingestão.
2. A fonte EA FC pode não fornecer 52 seleções extras com 23 nomes cada. Nessa situação, a sincronização informa o déficit em vez de falsificar registros.
3. Fotografias e ratings de terceiros têm direitos de imagem, marcas e eventuais termos de licença. Uso pessoal não equivale a direito de redistribuição.
4. Estimativas de atributos, especialmente perfis mentais, não são medições verificadas.
5. Os critérios de desempate e o chaveamento não são inteiramente fiéis aos regulamentos da FIFA.
6. A persistência depende da cota IndexedDB e é local à origem do navegador.

## 5. RECOMENDAÇÕES

**Prioridade máxima:** obter um snapshot completo verificável de 100 × 23 em ambiente com acesso a dados externos; exportar arquivo JSON e realizar inspeção manual de cada seleção. Em paralelo, pesquisar fontes oficiais de convocações e licenças de retratos individuais. Só após essas etapas declarar a database das 100 seleções **definitiva**.

**Prioridade alta:** adicionar gestão individual das convocações, seleção de 23 entre listas ampliadas, substitutos, lesões, capitães e funções táticas reais. Reproduzir grupos e critérios oficiais se o objetivo passar a ser recrear exatamente a Copa de 2026.

**Prioridade média:** calibrar as estimativas no motor com dados de desempenho e incorporar atributos de goleiros e sistema de tática internacional.

## 6. REGRA DE TRANSPARÊNCIA

Não confundir *100 países cadastrados como opção no catálogo* com *100 elencos de 23 atletas reais já presentes offline*. O segundo estado só ocorre após sincronização real completa e validação.
