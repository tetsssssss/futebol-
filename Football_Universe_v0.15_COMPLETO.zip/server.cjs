// Servidor local sem dependências, limitado ao diretório do projeto.
const http=require('node:http'),fs=require('node:fs'),path=require('node:path');
const root=__dirname,port=Number(process.env.PORT)||4173;
const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.mjs':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json; charset=utf-8','.svg':'image/svg+xml','.webp':'image/webp','.png':'image/png','.md':'text/plain; charset=utf-8','.glb':'model/gltf-binary','.jpg':'image/jpeg'};
http.createServer((req,res)=>{
 const pathname=decodeURIComponent((req.url||'/').split('?')[0]);const relative=pathname==='/'?'index.html':pathname.replace(/^\/+/,''),full=path.resolve(root,relative);
 if(!full.startsWith(root+path.sep)&&full!==path.join(root,'index.html')){res.writeHead(403);return res.end('Forbidden');}
 fs.stat(full,(err,stat)=>{if(err||!stat.isFile()){res.writeHead(404);return res.end('Not found');}res.writeHead(200,{'Content-Type':types[path.extname(full)]||'application/octet-stream','Cache-Control':'no-cache','X-Content-Type-Options':'nosniff'});fs.createReadStream(full).pipe(res);});
}).listen(port,'127.0.0.1',()=>console.log(`Football Universe: http://127.0.0.1:${port}`));
