# Football Universe v0.8 — Treinador 2D, Séries A e B e temporadas contínuas

> **v0.15.0:** Brasileirão Série A com os **20 clubes reais, 673 atletas e 38 rodadas** no Manager e no Treinador. Atributos: avaliação real do EA/FIFA evoluída até 2026 (283 atletas) ou estimada pelo valor de mercado (390), com a origem declarada em cada ficha. Dados em `data/brasileirao-2026.json`; para refazer: `node tools/build-brasileirao.mjs`.

> **v0.14.0:** fotos originais de atletas, escudos e uniformes guardados no projeto (`assets/faces`, `assets/badges`, `assets/kits`). Para atualizar a mídia: `node tools/fetch-faces.mjs`, `node tools/fetch-faces-extra.mjs`, `node tools/fetch-teams.mjs` e `node tools/resolve-kits.mjs` (precisam de `npm i --no-save sharp`). Detalhes e limites no `CHANGELOG.md`.

> **v0.13.0 (Fase 6):** Libertadores e Sul-Americana de 2026 integradas ao Brasileirão: aba **Conmebol** com preliminares, grupos, playoffs e mata-mata, vagas definidas pela tabela da Série A e rodízio nos demais países. Módulos: `treinador/continental.js` (regras e fases), `treinador/conmebol.js` (clubes e vagas) e `treinador/continental-views.js` (telas).


> **v0.11.0:** modo **Eliminatórias da Copa 2030** e elencos reais de seleções. Na tela inicial (ou na aba Elenco de um modo de seleções) use **Sincronizar a base de 2026**; depois crie as Eliminatórias ou a Copa. Sem sincronizar, as seleções jogam com posições neutras. Cobertura, fotos e limites estão no `CHANGELOG.md`.


> **v0.10.0 (Fase 3):** Copa do Mundo com regulamento de grupos, ranking de terceiros, chave em árvore, cerimônia e prêmios, condição física entre jogos e crônica das partidas. Módulos: `treinador/cup.js` (regras e chave) e `treinador/cup-views.js` (telas).


> **v0.9.0 (Fase 2):** equipes jogam em bloco compacto e respondem a largura, linha defensiva, saída de bola e função individual. Veja a tabela de calibração e as pendências no `CHANGELOG.md`. Para medir: `node tools/calibrate.mjs 60` e `node tools/diagnose.mjs 12`.


Evolução do ZIP **v0.6 Treinador 2D Brasileirão/Copa fornecido em 09/10/2026**. O Manager e o Modo Copa anterior continuam no projeto. A pasta `docs/base-v06` conserva a documentação recebida.

## Jogar

- Extraia o ZIP completo e abra `dist/treinador/index.html` no Chrome. A persistência exige que o navegador permita IndexedDB nesta origem.
- Opção recomendada: Node.js 20+, execute `npm start` e abra `http://127.0.0.1:4173/treinador/index.html`.
- Para hospedagem estática, publique o conteúdo de `dist`. Os três HTMLs contêm seus próprios módulos e estilos.
- Escolha Brasileirão ou Copa, equipe e escalação. Entre no próximo jogo, clique em Continuar. Um jogo em 1× dura aproximadamente nove minutos reais; em 8×, cerca de 68 segundos, além das pausas.
- Há pausa automática no intervalo. Confirme o resultado no final para atualizar calendário e classificação.

## Implementado

Canvas 2D com campo proporcional, 22 atletas, uniformes contrastantes, goleiros, numeração, orientação, seleção e nomes opcionais. Movimento com aceleração, formação, apoio, cobertura, pressão, desgaste e desmarcação. Bola com trajetórias, altura, sombra, curva, desvio e reinícios.

Passes curtos/médios/longos, primeira, recuo, profundidade, inversão, tabela e assistência; sete contextos de drible; cinco cruzamentos; chutes fortes/colocados/de longe/primeira, cabeceio, voleio, pressão e bloqueio. Goleiros têm encaixe, defesa lateral, ponte, espalmada, defesa próxima, cruzamentos e distribuição curta/longa. Faltas, cartões, impedimentos, escanteios e reposições pertencem ao estado da partida.

Controles: pausa, 1×/2×/4×/8×, próximo lance, avanço de minuto, simulação final, três câmeras, zoom, foco automático, quatro formações, mentalidade, pressão, ritmo, seis instruções e cinco substituições. Jogador substituído não retorna. Replays curtos usam quadros gravados da mesma simulação. Retêm até dez lances por partida e replays das cinco partidas confirmadas mais recentes; os resultados antigos permanecem.

Brasileirão: 20 clubes, 38 rodadas, 380 jogos. Copa: 48 seleções, grupos e eliminatórias, 104 jogos. Ambos usam o mesmo motor espacial do treinador.

## Saves

IndexedDB `football-universe-coach-v07`, com gravação atômica do universo e resumo, revisões para detectar conflito entre abas, exportação/importação JSON e aviso de falha de escrita. Alterações só são indicadas como salvas depois da transação concluir. Durante reprodução há gravação a cada aproximadamente 2,5 segundos e em comandos/pausas.

O save local v0.6 é migrado ao primeiro carregamento. A chave original permanece intacta. Partidas antigas preservam placar, minuto e atletas; seus replays começam na migração. Mudar de origem, navegador ou computador requer exportar/importar. Elencos nacionais sincronizados no Modo Copa dependem do cache dessa origem; o elenco da partida ativa é incluído no save, mas o catálogo nacional externo completo não acompanha o backup do treinador.

## Estado e limites

- **IMPLEMENTADO:** ciclo jogável 2D, comandos, competições, persistência e replays curtos.
- **PROTÓTIPO:** IA, equilíbrio estatístico e animações procedurais. Sprites detalhados e física biomecânica exigem outra etapa.
- **PARCIAL:** dados reais. Quatro clubes possuem cadastro; os outros 16 usam posições neutras. Seleções usam cadastro sincronizado quando disponível, ou posições neutras. Atributos são provisórios.
- **IMPLEMENTADO NO MOTOR:** incidentes de lesão durante a partida, registrados com tempo de afastamento simulado e substituição forçada quando possível. **PENDENTE:** diagnóstico clínico específico e tratamento, além de suspensões entre jogos, prorrogação, arbitragem completa e teste em aparelhos móveis físicos. Empates eliminatórios são resolvidos por disputa de pênaltis textual após 90 minutos.
- **DEFINITIVO:** não atribuído ao produto inteiro nesta entrega.

Calendários e resultados são hipotéticos. A primeira rodada da liga mantém os confrontos da base recebida; as demais datas/confrontos são gerados. Fotos externas e suas licenças mantêm apenas a procedência declarada pela base; este trabalho não é uma auditoria de direitos. A associação não confirmada de fotografia a Agustín Rossi foi removida; o modo 2D usa desenho procedural local.

## Arquitetura

### Camada de dados e ações CP001–CP024

O pacote inclui uma camada de validação e planejamento sem gravação, além do diretório estrutural de 9 ligas sul-americanas e 7 europeias. Essas 16 ligas ainda não têm elencos/regulamentos oficiais associados; calendários genéricos só são gerados se participantes forem fornecidos. O snapshot do Brasileirão v0.15, registro de IDs/aliases, verificação de referências, auditoria de edição/mídia e planos de merge dry-run preservam o catálogo atual. Para limites e comandos, consulte `architecture/world/README.md`.

O catálogo `architecture/world/engines/competitions/global-club-competitions.mjs` registra o campo e os grupos oficiais do Super Mundial 2025, as classificações publicadas até agora para 2029, a Copa Intercontinental 2026, e formatos/participantes conhecidos da Copa do Brasil, Supercopa Rei e Recopa 2026. Os clubes internacionais do Mundial são dados de competição (identidade, país, confederação, grupo e caminho de vaga), não plantéis de jogadores; este catálogo também não liga essas competições ao calendário jogável do Modo Treinador.

O catálogo CP017–CP024 registra 257 definições consultáveis; o treinador agora classifica em memória eventos nativos de passe, drible, finalização, cruzamento, desarme e lesão. O motor existente continua resolvendo resultados e RNG, e os diagnósticos não entram nos saves. Ainda não há correspondência de ID de catálogo com animação real nem diagnóstico clínico de lesão. Consulte `architecture/actions/README.md`.

Verificações: `npm run test:architecture` (novos adaptadores) e `npm run test:all` (suíte inteira). `npm run architecture:snapshot -- --output snapshot.json` gera um relatório sem sobrescrever o destino.

| Responsabilidade | Módulo em `treinador/` |
| --- | --- |
| Estado, migração e validação | `match-state.js` |
| Decisões, regras e movimento | `decisions.js`, `match-engine.js`, `movement.js` |
| Competições e resultados | `engine.js` |
| Campo/câmeras e desenho | `graphics.js`, `renderer.js`, `animations.js` |
| HUD e comandos | `hud.js`, `controls.js` |
| Loop, interpolação, reprodução | `viewer.js`, `replay.js` |
| Gravação transacional | `storage.js` |

Simulação determinística em passos de 0,2 segundo real / 2 segundos do relógio de jogo, separada do `requestAnimationFrame`. O renderizador e o replay não consomem RNG nem alteram placares. Sem WebGL e sem dependências de execução. Sem Canvas, ficam disponíveis placar, relato e comandos.

## Reproduzir verificações

```text
npm test
npm run build
npm run test:ui
node tools/actions-qa.cjs
node tools/performance-qa.cjs
```

Testes de navegador exigem Playwright instalado no ambiente e Chrome. Configure `CHROME_PATH` para seu executável e `QA_URL` para a origem do servidor (padrão dos scripts: `http://127.0.0.1:4174`). O código do jogo não depende de Playwright. Resultados e capturas estão em `qa/v07`; consulte `RELATORIO_DESENVOLVIMENTO.md` para o escopo da validação.


## v0.7.1

Jogos eliminatórios da Copa empatados vão à prorrogação (30 min) e, se necessário, a pênaltis cobrança a cobrança. Visualização gráfica das cobranças ainda não implementada.

Também na v0.7.1: lesões e suspensões entre jogos (Elenco mostra indisponíveis), marcação por referência, calibração (`node tools/calibrate.mjs 100`) e painel de pênaltis.


## v0.8.0 — Fundação de competições


### v0.8.1 — Assets 3D e protótipo 2.5D

**Apresentação atual da partida:** ao abrir uma partida no Modo Treinador, a transmissão 2.5D é carregada primeiro; a preferência e a câmera escolhidas ficam guardadas neste navegador. Se WebGL ou Babylon.js não estiverem disponíveis, a partida troca para o campo 2D. Escolha entre câmera de transmissão, tática e acompanhamento da bola; os nomes e números podem ser ocultados. Brasileirão, Copa, Eliminatórias e partidas continentais compartilham o mesmo visualizador e motor.


Com `npm start`, abra `http://127.0.0.1:4173/treinador/preview-25d.html`. Para regenerar os modelos (Blender 4.2+):

```text
blender --background --factory-startup --python tools/blender/build_assets.py
```

| Asset | Triângulos | Observação |
| --- | --- | --- |
| `ball.glb` | 320 | 22 cm, origem no ponto de contato com o chão |
| `goal.glb` | 364 | 7,32 × 2,44 m internos; `FU_Goal_Frame` e `FU_Goal_Net` separados |
| `pitch.glb` | 402 | 105 × 68 m, faixas de corte, linhas, áreas, círculo, meias-luas e escanteios |
| `referee.glb` | 428 | 1,77 m, malha única com pesos rígidos em 11 ossos; sem animações |
| `stand_module.glb` / `_lod1` | 3.644 / 380 | módulo de 10 m, 8 fileiras, cobertura |

- **IMPLEMENTADO:** renderer 2.5D integrado na partida e nos replays ativos; o build copia os GLBs para `dist/assets/3d`. O carregamento da biblioteca Babylon.js ainda depende de CDN e WebGL; Canvas 2D funciona como alternativa.
- **PENDENTE:** árbitro em campo (a simulação não calcula a posição dele), animações de caminhada/contato para os modelos 3D e medição de desempenho em equipamento modesto.
- **BLOQUEADO:** variáveis no Figma. O arquivo foi criado, mas o conector recusou a escrita pelo limite de chamadas do plano Starter.


O Brasileirão passa a ser um universo de duas divisões no mesmo save: Série A e Série B com 20 clubes e 38 rodadas cada, playoff de acesso, 4 acessos e 4 rebaixamentos, virada de temporada e histórico. "Simular rodada" avança as duas divisões; é possível treinar qualquer um dos 40 clubes.

| Responsabilidade | Módulo em `treinador/` |
| --- | --- |
| Regulamentos versionados e classificação com desempates | `rules.js` |
| Divisões, calendário, playoff, virada de temporada, histórico | `league.js` |
| Resumo persistido da partida e estatísticas individuais | `match-summary.js` |
| Páginas de Tabela, Calendário, Estatísticas e Histórico | `league-views.js` |

- **IMPLEMENTADO:** regras versionadas, desempates, Série B, playoff, acesso/rebaixamento, virada de temporada, histórico, estatísticas derivadas de eventos, save compacto com migração.
- **PARCIAL:** Central de Estatísticas (rankings, eficiência coletiva e mapa de finalizações; sem gráficos de evolução nem comparativos). Fotos (avatar de fallback pronto; sem manifesto local de imagens).
- **PENDENTE:** elencos de 36 dos 40 clubes (posições neutras, sem diferença de força entre eles), Série C, conferência dos regulamentos nos documentos oficiais da CBF, regulamento e chaveamento oficiais da Copa.
- **Limite conhecido do motor:** os gols se concentram demais nos centroavantes e o volume de passes por jogo (~70 por equipe) é baixo. As estatísticas mostram o que o motor produz; a calibração é assunto da evolução do 2D.

Fontes da composição e do formato da Série B 2026 e dos critérios da Série A: imprensa esportiva consultada em 12/10/2026; confirme no Regulamento Específico da CBF antes de tratar como definitivo.
