import {clamp,seedValue,worldX,round2} from './math.js';
export const SHAPES={
 '4-2-3-1':{positions:['GK','RB','CB','CB','LB','DM','CM','AM','RW','LW','ST'],zones:[[7,50],[25,83],[23,63],[23,37],[25,17],[43,60],[44,37],[65,50],[71,82],[71,18],[83,50]]},
 '4-3-3':{positions:['GK','RB','CB','CB','LB','DM','CM','CM','RW','LW','ST'],zones:[[7,50],[25,82],[23,62],[23,38],[25,18],[42,50],[56,68],[56,32],[76,82],[76,18],[86,50]]},
 '4-4-2':{positions:['GK','RB','CB','CB','LB','RM','CM','CM','LM','ST','ST'],zones:[[7,50],[24,82],[23,62],[23,38],[24,18],[54,84],[51,61],[51,39],[54,16],[82,37],[82,63]]},
 '3-5-2':{positions:['GK','CB','CB','CB','RB','LB','DM','CM','AM','ST','ST'],zones:[[7,50],[23,75],[21,50],[23,25],[47,86],[47,14],[42,50],[58,68],[63,32],[83,38],[83,62]]}
};
export const SAVE_STYLES=['catch','dive','fullStretch','parry','closeSave','claim'];
export const VISUAL_STATES=['idle','run','decelerate','press','carry','pass','cross','shoot','header','dribble','mark','tackle','fall','celebrate','complain','save','sweep','distribute'];
export const TACTICAL_INSTRUCTIONS=['balanced','wide','through','counter','retain','shoot'];
export function buildSquad(team,ids=null,formation='4-2-3-1'){
 const shape=SHAPES[formation],roster=team.roster;
 if(!shape||!Array.isArray(roster)||roster.length<11||new Set(roster.map(p=>p.id)).size!==roster.length)throw Error('Elenco ou formação inválidos.');
 if(ids&&(ids.length!==11||new Set(ids).size!==11||ids.some(id=>!roster.some(p=>p.id===id))||ids.filter(id=>roster.find(p=>p.id===id).position==='GK').length!==1))throw Error('Escalação exige 11 atletas distintos e um goleiro.');
 const pool=(ids?ids.map(id=>roster.find(p=>p.id===id)):roster).map(p=>structuredClone(p)).sort((a,b)=>(b.overall||65)-(a.overall||65));
 const playing=shape.positions.map((role,slot)=>{let i=pool.findIndex(p=>p.position===role);if(i<0)i=pool.findIndex(p=>role==='GK'?p.position==='GK':p.position!=='GK');if(i<0)throw Error('Elenco sem goleiro ou jogadores suficientes.');const p=pool.splice(i,1)[0];return {...p,slot,role,number:p.number||slot+1,x:shape.zones[slot][0],y:shape.zones[slot][1],baseX:shape.zones[slot][0],baseY:shape.zones[slot][1],vx:0,vy:0,angle:0,fatigue:0,visual:'idle',visualUntil:0,cards:0,dismissed:false};});
 const selected=new Set(playing.map(p=>p.id));return {playing,bench:structuredClone(roster.filter(p=>!selected.has(p.id))),used:[],subs:0,formation};
}
export function createMatchState(home,away,seed,knockout=false,setup={}){
 if(!home?.id||!away?.id||home.id===away.id)throw Error('Confronto inválido.');
 const squads=[home,away].map(team=>buildSquad(team,setup[team.id]?.xi,setup[team.id]?.formation));
 squads[1].playing.forEach(p=>{p.x=100-p.x;p.angle=Math.PI});
 // Desgaste herdado de partidas recentes (torneios curtos): vale para titulares e para quem entrar depois.
 if(setup.fatigue)for(const squad of squads)for(const p of [...squad.playing,...squad.bench]){const f=Number(setup.fatigue[p.id]);if(Number.isFinite(f)&&f>0)p.fatigue=clamp(f,0,60)}
 const state={version:2,seed:String(seed),rngState:seedValue(seed),home:home.id,away:away.id,minute:0,clock:0,time:0,tick:0,half:1,endTick:2700,shootout:null,knockout,score:[0,0],tactics:squads.map(()=>({mentality:'balanced',pressing:55,tempo:55,instruction:'balanced',width:55,line:50,buildUp:'mixed'})),squads,possession:0,carrier:10,ball:{x:50,y:50,z:0,vx:0,vy:0,lastTouch:0},action:null,restart:{kind:'kickoff',side:0,x:50,y:50,remaining:1},decisionAt:0,transitionAt:0,events:[],eventSequence:0,stats:{shots:[0,0],onTarget:[0,0],passes:[0,0],completedPasses:[0,0],possession:[0,0],fouls:[0,0],corners:[0,0],saves:[0,0],tackles:[0,0],interceptions:[0,0],dribbles:[0,0],crosses:[0,0],offsides:[0,0],yellow:[0,0],red:[0,0],xG:[0,0]},snapshots:[],replay:{rolling:[],clips:[],pending:[],enabled:setup.recordReplay!==false},actionCounts:{},tally:{},aggregate:Array.isArray(setup.aggregate)?[...setup.aggregate]:null,noExtraTime:!!setup.noExtraTime,finished:false,penalties:null};
 state.events.push({id:++state.eventSequence,minute:0,time:0,type:'start',text:'Início de jogo. Saída no círculo central.'});return state;
}
export function compactFrame(s){return {time:round2(s.time),clock:s.clock,score:[...s.score],possession:s.possession,ball:[round2(s.ball.x),round2(s.ball.y),round2(s.ball.z||0)],players:s.squads.map(squad=>squad.playing.map(p=>[round2(p.x),round2(p.y),round2(p.angle),VISUAL_STATES.indexOf(p.visual),p.dismissed?1:0,p.number,Math.max(0,SAVE_STYLES.indexOf(p.saveStyle))])),ids:s.squads.map(squad=>squad.playing.map(p=>p.id)),action:s.action?{kind:s.action.kind,subtype:s.action.subtype,side:s.action.side,from:s.action.from,to:s.action.to}:null};}
export function upgradeMatchState(s){
 if(s.version===2)return s;
 if(s.version!==1)throw Error('Versão de partida não suportada.');
 const source=structuredClone(s),teams=[{id:s.home,roster:s.squads[0].playing.concat(s.squads[0].bench)},{id:s.away,roster:s.squads[1].playing.concat(s.squads[1].bench)}];
 // Legacy substitutions allowed returning players. Deduplicate without inventing identities.
 teams.forEach(t=>{t.roster=[...new Map(t.roster.map(p=>[p.id,p])).values()]});
 const m=createMatchState(teams[0],teams[1],s.seed,s.knockout,Object.fromEntries(teams.map((t,i)=>[t.id,{xi:s.squads[i].playing.map(p=>p.id)}])));
 Object.assign(m,{tick:s.tick*15,clock:s.tick*30,time:s.tick*3,minute:Math.floor(s.tick/2),half:s.minute>=45?2:1,score:[...s.score],finished:s.finished,penalties:s.penalties,events:source.events.map((e,i)=>({...e,id:i+1,time:e.minute*6})),eventSequence:source.events.length,snapshots:source.snapshots||[],tactics:source.tactics.map(t=>({...t,instruction:'balanced'})),restart:null,possession:s.possession,carrier:s.carrier,ball:{...source.ball,z:0,vx:0,vy:0,lastTouch:s.possession},legacyMigrated:true});
 for(const key of Object.keys(m.stats))if(source.stats[key])m.stats[key]=source.stats[key];
 m.squads.forEach((squad,i)=>{squad.subs=source.squads[i].subs;squad.playing.forEach(p=>{const old=source.squads[i].playing.find(x=>x.id===p.id);Object.assign(p,{x:clamp(old.x,0,100),y:clamp(old.y,0,100),fatigue:old.fatigue||0})})});
 m.events.push({id:++m.eventSequence,minute:m.minute,time:m.time,type:'migration',text:'Partida v0.6 retomada. Replay disponível a partir desta migração.'});return m;
}
export function validateMatchState(s){
 if(!s||s.version!==2||!Number.isInteger(s.tick)||s.tick<0||s.tick>3600||!Number.isFinite(s.clock)||s.clock<0||s.clock>7200||!Number.isFinite(s.time)||!Number.isInteger(s.rngState)||!Array.isArray(s.score)||s.score.length!==2||s.score.some(x=>!Number.isInteger(x)||x<0||x>100)||![1,2,3,4].includes(s.half)||![0,1].includes(s.possession)||!Number.isInteger(s.carrier)||s.carrier<0||s.carrier>10)throw Error('Estado espacial inválido.');
 if(!Array.isArray(s.squads)||s.squads.length!==2||!Array.isArray(s.tactics)||s.tactics.length!==2||!s.ball||[s.ball.x,s.ball.y,s.ball.z].some(n=>!Number.isFinite(n))||s.ball.x< -10||s.ball.x>110||s.ball.y< -10||s.ball.y>110)throw Error('Campo inválido.');
 const ids=new Set();for(const squad of s.squads){if(squad.playing?.length!==11||!Array.isArray(squad.bench)||!Array.isArray(squad.used)||squad.subs<0||squad.subs>5||!SHAPES[squad.formation])throw Error('Elenco da partida inválido.');for(const p of [...squad.playing,...squad.bench]){if(!p.id||ids.has(p.id))throw Error('Atleta repetido.');ids.add(p.id)}for(const p of squad.playing)if([p.x,p.y,p.vx,p.vy,p.angle,p.fatigue].some(n=>!Number.isFinite(n))||p.x<0||p.x>100||p.y<0||p.y>100||p.fatigue<0||p.fatigue>100||!VISUAL_STATES.includes(p.visual))throw Error('Posição/estado visual inválido.');}
 for(const t of s.tactics)if(!['defensive','balanced','attacking'].includes(t.mentality)||!TACTICAL_INSTRUCTIONS.includes(t.instruction)||[t.pressing,t.tempo,t.width??55,t.line??50].some(n=>!Number.isFinite(n)||n<20||n>95)||!['short','mixed','direct'].includes(t.buildUp??'mixed'))throw Error('Instrução tática inválida.');
 for(const squad of s.squads)for(const p of squad.playing)if(p.duty!==undefined&&!['default','attack','support','defend'].includes(p.duty))throw Error('Função individual inválida.');
 if(!Array.isArray(s.events)||s.events.length>4000||!Array.isArray(s.snapshots)||s.snapshots.length>130||!s.stats||Object.values(s.stats).some(v=>!Array.isArray(v)||v.length!==2||v.some(n=>!Number.isFinite(n)||n<0)))throw Error('Estatísticas ou eventos inválidos.');
 if(['shots','onTarget','passes','completedPasses','possession','fouls','corners','saves','tackles','interceptions','dribbles','crosses','offsides','yellow','red','xG'].some(key=>!Array.isArray(s.stats[key]))||s.events.some(e=>!Number.isInteger(e.id)||!Number.isFinite(e.minute)||typeof e.text!=='string'))throw Error('Relato da partida incompleto.');
 if(!s.replay||!Array.isArray(s.replay.rolling)||s.replay.rolling.length>70||!Array.isArray(s.replay.clips)||s.replay.clips.length>10)throw Error('Replay excede os limites.');
 const point=p=>p&&Number.isFinite(p.x)&&Number.isFinite(p.y)&&Math.abs(p.x)<200&&Math.abs(p.y)<200;
 const visualAction=a=>a&&['pass','shot','cross','distribution','loose','carry','dribble'].includes(a.kind)&&point(a.from)&&point(a.to)&&[0,1].includes(a.side);
 if(s.action&&(!visualAction(s.action)||!Number.isFinite(s.action.elapsed)||s.action.elapsed<0||!Number.isFinite(s.action.duration)||s.action.duration<=0||s.action.duration>10||!ids.has(s.action.actorId)||s.action.targetId&&!ids.has(s.action.targetId)))throw Error('Ação em andamento inválida.');
 if(s.restart&&(!point(s.restart)||!['kickoff','corner','goalKick','freeKick','throwIn'].includes(s.restart.kind)||![0,1].includes(s.restart.side)||!Number.isFinite(s.restart.remaining)||s.restart.remaining>20))throw Error('Reinício inválido.');
 if(!Number.isFinite(s.decisionAt)||!Number.isInteger(s.eventSequence)||typeof s.finished!=='boolean'||![undefined,2700,3600].includes(s.endTick)||s.endTick===3600&&!s.knockout||s.finished&&s.tick!==(s.endTick||2700)||s.tick===(s.endTick||2700)&&!s.finished||s.shootout&&(!Array.isArray(s.shootout)||s.shootout.length>40||!s.finished)||s.clock!==s.tick*2||s.time!==round2(s.tick*.2))throw Error('Relógio da partida inválido.');
 if(!Array.isArray(s.replay.pending)||s.replay.pending.length>2)throw Error('Fila de replay inválida.');
 if(s.aggregate!=null&&(!Array.isArray(s.aggregate)||s.aggregate.length!==2||s.aggregate.some(n=>!Number.isInteger(n)||n<0||n>30)||!s.knockout))throw Error('Placar agregado inválido.');
 for(const clip of [...s.replay.clips,...s.replay.pending]){if(!Array.isArray(clip.frames)||clip.frames.length>70||!Number.isFinite(clip.at)||typeof clip.label!=='string')throw Error('Clipe inválido.');}
 const frames=[...s.replay.rolling,...s.replay.clips.flatMap(c=>c.frames),...s.replay.pending.flatMap(c=>c.frames)];
 for(const f of frames){if(!Number.isFinite(f.time)||!Number.isFinite(f.clock)||!Array.isArray(f.score)||f.score.length!==2||!Array.isArray(f.ball)||f.ball.length!==3||f.ball.some(n=>!Number.isFinite(n))||f.players?.length!==2||f.ids?.length!==2||f.players.some((sq,i)=>sq.length!==11||f.ids[i]?.length!==11||sq.some(p=>!Array.isArray(p)||![6,7].includes(p.length)||p.some(n=>!Number.isFinite(n))))||f.action&&!visualAction(f.action))throw Error('Quadro de replay inválido.');}
 return true;
}
