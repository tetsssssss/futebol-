// Fotos de atletas: um único ponto decide de onde uma foto pode vir, em que tamanho, e o que fazer quando não há.
// Primeiro vale o arquivo local (assets/faces, baixado por tools/fetch-faces.mjs); só depois as fontes que carregam fora do site de origem; o resto vira avatar.
import {faceURL,faceFile} from '../src/media.js';
export const PHOTO_SOURCES={
 'digitalhub.fifa.com':{label:'Listas da Copa 2026 (FIFA)',usable:true,sized:(url,px)=>`${url.split('?')[0]}?io=transform:fill,width:${px},height:${px}`},
 'commons.wikimedia.org':{label:'Wikimedia Commons (licença indicada no manifesto)',usable:true,sized:(url,px)=>{const [base,query='']=url.split('?'),rest=query.split('&').filter(p=>p&&!p.startsWith('width='));return `${base}?${[...rest,'width='+px].join('&')}`}},
 'cdn.sofifa.net':{label:'EA FC 26 / SoFIFA',usable:false,reason:'bloqueada fora do site de origem'}
};
export const rawPhoto=player=>{const raw=typeof player?.photo==='string'?player.photo:player?.photo?.url;return /^https:\/\/[^\s"'<>]+$/.test(raw||'')?raw:null};
export const photoHost=url=>{try{return new URL(url).host}catch{return null}};
/** Endereço da foto no tamanho pedido (px no lado maior), ou null quando o atleta deve aparecer com avatar. */
export function photoURL(player,px=96){
 const local=faceURL(player);if(local)return local;
 const raw=rawPhoto(player);if(!raw)return null;const source=PHOTO_SOURCES[photoHost(raw)];
 if(!source)return raw; // fonte desconhecida: tenta como está; o avatar cobre a falha de carregamento
 return source.usable?source.sized(raw,Math.max(32,Math.min(512,Math.round(px)))):null;
}
let registry=new Map();
/** Registra os elencos em uso para que rankings e prêmios encontrem a foto pelo id do atleta. */
export function setPhotoRegistry(teams){registry=new Map();for(const team of teams||[])for(const p of [...(team.roster||[]),...(team.reserve||[])])if(p.photo)registry.set(p.id,p.photo);return registry.size}
export const registeredPhoto=id=>registry.has(id)?{photo:registry.get(id)}:null;
/** Auditoria: cobertura por fonte, referências inválidas e fotos repetidas entre atletas diferentes. */
export function auditPhotos(players){
 const out={total:0,usable:0,local:0,blocked:0,missing:0,invalid:0,unknownSource:0,bySource:{},duplicates:[]},seen=new Map();
 for(const p of players){
  if(p.placeholder)continue;out.total++;
  const file=faceFile(p);if(file){out.local++;out.usable++;out.bySource.local=(out.bySource.local||0)+1;if(!seen.has(file))seen.set(file,[]);seen.get(file).push(p.id);continue}
  const given=typeof p.photo==='string'?p.photo:p.photo?.url;if(!given){out.missing++;continue}
  const raw=rawPhoto(p);if(!raw){out.invalid++;continue}
  const host=photoHost(raw),source=PHOTO_SOURCES[host];out.bySource[host]=(out.bySource[host]||0)+1;
  if(!source)out.unknownSource++;else if(source.usable)out.usable++;else out.blocked++;
  const key=raw.split('?')[0];if(!seen.has(key))seen.set(key,[]);seen.get(key).push(p.id);
 }
 for(const [url,ids] of seen)if(new Set(ids).size>1)out.duplicates.push({url,ids:[...new Set(ids)]});
 out.coverage=out.total?Math.round(out.usable/out.total*1000)/10:0;return out;
}
