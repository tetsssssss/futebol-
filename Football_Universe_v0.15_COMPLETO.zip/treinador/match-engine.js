import {clamp,lerp,fieldDistance,localX,worldX,teamDirection,rating,randomValue,nearestPlayer,round2} from './math.js';
import {SHAPES,TACTICAL_INSTRUCTIONS,compactFrame} from './match-state.js';
import {chooseAction,planPass,planCross,planShot,ACTION_LABELS} from './decisions.js';
import {movePlayers,BUILD_UPS,DUTIES,TACTIC_DEFAULTS} from './movement.js';
import {observeHostAction,readActionObservations} from '../architecture/actions/integration/runtime.mjs';
export const TICK_SECONDS=.2;
export function readMatchActionObservations(match){return readActionObservations(match);}
const find=(s,id)=>s.squads.flatMap(x=>x.playing).find(p=>p.id===id);
const important=new Set(['goal','save','shot','foul','card','corner','offside','cross']);
export function recordEvent(s,type,text,extra={}){
 const event={id:++s.eventSequence,minute:s.minute,time:round2(s.time),type,text,...extra};s.events.push(event);
 if(type==='goal'&&s.replay.pending.length>=2)s.replay.pending.splice(s.replay.pending.findIndex(c=>c.type!=='goal'),1);
 if(s.replay.enabled&&important.has(type)&&s.replay.pending.length<2){s.replay.pending.push({eventId:event.id,type,label:text,at:s.time,until:s.time+2,labels:Object.fromEntries(s.squads.flatMap(x=>x.playing).map(p=>[p.id,{name:p.name,role:p.role}])),frames:structuredClone(s.replay.rolling.slice(-28))});}
 return event;
}
function replayTick(s){
 if(!s.replay.enabled||s.tick%2)return;
 const frame=compactFrame(s);s.replay.rolling.push(frame);if(s.replay.rolling.length>60)s.replay.rolling.shift();
 for(const clip of s.replay.pending)clip.frames.push(frame);
 const ready=s.replay.pending.filter(c=>s.time>=c.until||s.finished);
 for(const clip of ready){s.replay.clips.push(clip);if(s.replay.clips.length>10){const expendable=s.replay.clips.findIndex(c=>c.type!=='goal');s.replay.clips.splice(expendable<0?0:expendable,1)}}
 s.replay.pending=s.replay.pending.filter(c=>!ready.includes(c));
}
// Contagens individuais derivadas das mesmas ações oficiais; não consomem RNG.
function passTally(s,id,index){const t=(s.tally??={})[id]??=[0,0];t[index]++}
function shotOutcome(s,action,outcome){const e=action?.eventId&&s.events.findLast(x=>x.id===action.eventId);if(e)e.outcome=outcome}
const level=s=>s.score[0]+(s.aggregate?.[0]||0)===s.score[1]+(s.aggregate?.[1]||0);
function pose(s,p,visual,duration=.7){if(p){p.visual=visual;p.visualUntil=s.time+duration;}}
function giveBall(s,side,p,point=null){
 if(!p||p.dismissed)return;
 const changed=s.possession!==side;s.possession=side;s.carrier=s.squads[side].playing.indexOf(p);s.ball={...s.ball,x:point?.x??p.x,y:point?.y??p.y,z:0,lastTouch:side,vx:0,vy:0};s.action=null;s.receivedAt=s.time;s.decisionAt=s.time+1.16-s.tactics[side].tempo*.012;if(changed){s.transitionAt=s.time;s.lastPass=null;s.oneTwo=null;}
}
function restart(s,kind,side,x,y,delay=1.5){
 s.action=null;s.possession=side;s.ball={x:clamp(x,0,100),y:clamp(y,0,100),z:0,lastTouch:side,vx:0,vy:0};
 const direct=kind==='freeKick'&&localX(s,side,s.ball.x)>70&&Math.abs(s.ball.y-50)<24,specialist=attr=>s.squads[side].playing.filter(p=>!p.dismissed&&p.role!=='GK').sort((a,b)=>rating(b,attr)-rating(a,attr)||creative(a)-creative(b)||a.slot-b.slot)[0],creative=p=>{const i=['AM','CM','RW','LW','RM','LM','DM','ST'].indexOf(p.role);return i<0?9:i};
 // Bola parada tem dono: falta frontal e escanteio são cobrados pelo melhor batedor em campo, não por quem estava mais perto.
 const taker=kind==='goalKick'?s.squads[side].playing.find(p=>!p.dismissed&&p.role==='GK'):direct?specialist('freeKicks'):kind==='corner'?specialist('corners'):nearestPlayer(s.squads[side].playing,s.ball,p=>p.role!=='GK');
 s.restart={kind,side,x:s.ball.x,y:s.ball.y,remaining:delay,takerId:taker?.id};if(taker)s.carrier=s.squads[side].playing.indexOf(taker);
}
function launch(s,action){
 if(!action)return;
 observeHostAction(s,{kind:action.kind,subtype:action.subtype,actorId:action.actorId});
 s.action=action;s.actionCounts[action.kind]=(s.actionCounts[action.kind]||0)+1;s.actionCounts[action.subtype]=(s.actionCounts[action.subtype]||0)+1;
 const p=find(s,action.actorId),side=action.side;
 if(action.kind==='shot'){s.stats.shots[side]++;s.stats.xG[side]=round2(s.stats.xG[side]+action.xG);if(action.onTarget)s.stats.onTarget[side]++;pose(s,p,action.subtype==='header'?'header':'shoot',.9);action.eventId=recordEvent(s,'shot',`${p.name}: ${ACTION_LABELS[action.subtype]||'finalização'}`,{side,player:p.name,playerId:p.id,subtype:action.subtype,xG:action.xG,x:round2(localX(s,side,s.ball.x)),y:round2(s.ball.y),onTarget:!!action.onTarget,outcome:'off'}).id;}
 else if(action.kind==='cross'){s.stats.crosses[side]++;s.stats.passes[side]++;passTally(s,p.id,0);pose(s,p,'cross');recordEvent(s,'cross',`${p.name}: ${ACTION_LABELS[action.subtype]}`,{side,playerId:p.id,subtype:action.subtype});}
 else if(['pass','distribution'].includes(action.kind)){s.stats.passes[side]++;passTally(s,p.id,0);pose(s,p,action.kind==='distribution'?'distribute':'pass');if(['oneTwo','assist','long','switch'].includes(action.subtype))recordEvent(s,'pass',`${p.name}: ${ACTION_LABELS[action.subtype]}`,{side,playerId:p.id,subtype:action.subtype});}
 else if(action.kind==='dribble'){s.stats.dribbles[side]++;pose(s,p,'dribble',action.duration);recordEvent(s,'dribble',`${p.name}: ${ACTION_LABELS[action.subtype]}`,{side,playerId:p.id,subtype:action.subtype});}
}
function injure(s,p,side){
 const matches=1+Math.floor(randomValue(s)*4),squad=s.squads[side];p.injured=true;p.fatigue=Math.max(p.fatigue,70);
 observeHostAction(s,{kind:'injury',subtype:null,actorId:p.id});
 recordEvent(s,'injury','Lesão: '+p.name+' deixa o jogo com problema físico.',{side,playerId:p.id,matches});
 if(squad.subs>=5)return;
 const keeper=p.role==='GK',cand=squad.bench.filter(b=>keeper?b.position==='GK':b.position!=='GK').sort((a,b)=>(b.position===p.position)-(a.position===p.position)||(b.overall||0)-(a.overall||0))[0];
 if(cand)try{makeSubstitution(s,side,p.id,cand.id)}catch{/* substituição forçada é melhor esforço: sem goleiro válido o atleta segue em campo */}
}
function foul(s,offender,victim,side){
 const opp=1-side;s.stats.fouls[opp]++;pose(s,victim,'fall',1.6);pose(s,offender,'complain',1.5);
 recordEvent(s,'foul',`Falta de ${offender.name} sobre ${victim.name}`,{side:opp,playerId:offender.id,victimId:victim.id,x:victim.x,y:victim.y});
 const severity=randomValue(s);if(severity<(offender.cards?.08:.2)){offender.cards=(offender.cards||0)+1;const red=offender.cards>=2||severity<.004;offender.dismissed=red;if(red)offender.outTick=s.tick;offender.cardShow=red?'red':'yellow';offender.cardUntil=s.time+3;s.stats[red?'red':'yellow'][opp]++;recordEvent(s,'card',`${red?'Cartão vermelho':'Cartão amarelo'} para ${offender.name}`,{side:opp,playerId:offender.id,color:red?'red':'yellow'});}
 if(!victim.dismissed&&!victim.injured&&randomValue(s)<.02)injure(s,victim,side);
 restart(s,'freeKick',side,victim.x,victim.y,2.2);
}
function tackle(s){
 const side=s.possession,p=s.squads[side].playing[s.carrier];if(!p||p.dismissed)return;
 const defender=nearestPlayer(s.squads[1-side].playing,s.ball);if(!defender)return;
 const d=fieldDistance(defender,s.ball),rate=.085+(s.tactics[1-side].pressing-50)*.0015;
 if(d>2.8||randomValue(s)>rate)return;
 pose(s,defender,'tackle');
 if(randomValue(s)<.3){foul(s,defender,p,side);return;}
 const attack=(rating(p,'dribbling')+rating(p,'balance')+rating(p,'strength'))/3,defence=(rating(defender,'tackling')+rating(defender,'anticipation'))/2;
 if(randomValue(s)<clamp(.48+(defence-attack)*.009+(p.fatigue-defender.fatigue)*.003,.15,.85)){
  s.stats.tackles[1-side]++;observeHostAction(s,{kind:'tackle',subtype:d<1.2?'physical':'standing',actorId:defender.id});recordEvent(s,'tackle',`${defender.name} recupera em ${d<1.2?'disputa física':'desarme em pé'}`,{side:1-side,playerId:defender.id,subtype:d<1.2?'physical':'standing'});
  // Desarme dentro da própria área, perto da linha de fundo, muitas vezes só afasta: a bola sai e é escanteio.
  if(localX(s,1-side,s.ball.x)<14&&randomValue(s)<.4){s.ball.lastTouch=1-side;s.action={kind:'loose',subtype:'clearance',side:1-side,actorId:defender.id,from:{x:s.ball.x,y:s.ball.y},to:{x:worldX(s,side,103),y:clamp(s.ball.y+(s.ball.y<50?-12:12),-2,102)},duration:.7,elapsed:0,height:.6,curve:0};return;}
  giveBall(s,1-side,defender);
 }
}
function segmentDistance(p,a,b){const dx=(b.x-a.x)*1.05,dy=(b.y-a.y)*.68,l=dx*dx+dy*dy,t=l?clamp(((p.x-a.x)*1.05*dx+(p.y-a.y)*.68*dy)/l,0,1):0;return fieldDistance(p,{x:lerp(a.x,b.x,t),y:lerp(a.y,b.y,t)});}
function boundary(s,action){
 const ball=s.ball,side=action.side,dir=teamDirection(s,side),pastGoal=dir===1?ball.x>=100:ball.x<=0;
 if(action.kind==='shot'&&pastGoal&&ball.y>=44.62&&ball.y<=55.38&&!action.saved){
  s.score[side]++;shotOutcome(s,action,'goal');const p=find(s,action.actorId),assist=s.lastPass?.side===side&&s.time-s.lastPass.at<6?s.lastPass.playerId:null;
  recordEvent(s,'goal',`GOL! ${p.name}${assist?' após passe de '+find(s,assist)?.name:''}`,{side,player:p.name,playerId:p.id,assistId:assist,subtype:action.subtype});
  s.squads[side].playing.filter(p=>!p.dismissed).forEach(p=>pose(s,p,'celebrate',2.2));restart(s,'kickoff',1-side,50,50,2.3);return true;
 }
 if(ball.x<=0||ball.x>=100){const defending=ball.x<=0?(s.half===1?0:1):(s.half===1?1:0);if(ball.lastTouch===defending){const attack=1-defending;s.stats.corners[attack]++;recordEvent(s,'corner','Escanteio para a equipe atacante.',{side:attack});restart(s,'corner',attack,ball.x<=0?1:99,ball.y<50?1:99,1.8)}else{recordEvent(s,'goalKick','Tiro de meta.',{side:defending});restart(s,'goalKick',defending,worldX(s,defending,5),50,1.5)}return true;}
 if(ball.y<=0||ball.y>=100){const side=1-ball.lastTouch;recordEvent(s,'throwIn','Bola fora. Arremesso lateral.',{side});restart(s,'throwIn',side,ball.x,ball.y<=0?1:99,1.2);return true;}return false;
}
function flightTick(s,dt){
 const a=s.action,p=find(s,a.actorId),side=a.side,opp=1-side;a.elapsed+=dt;
 if(['carry','dribble'].includes(a.kind)){
  s.ball.x=clamp(p.x+Math.cos(p.angle)*.8,0,100);s.ball.y=clamp(p.y+Math.sin(p.angle)*1.1,0,100);s.ball.z=a.kind==='dribble'?Math.abs(Math.sin(a.elapsed*10))*.08:0;tackle(s);
  if(s.action===a&&a.elapsed>=a.duration){s.action=null;s.decisionAt=s.time+.15;}return;
 }
 const old={x:s.ball.x,y:s.ball.y},q=clamp(a.elapsed/a.duration,0,1),ease=1-(1-q)**1.08,dx=a.to.x-a.from.x,dy=a.to.y-a.from.y,len=Math.hypot(dx,dy)||1,curve=Math.sin(Math.PI*q)*(a.curve||0);
 s.ball.x=lerp(a.from.x,a.to.x,ease)-dy/len*curve;s.ball.y=lerp(a.from.y,a.to.y,ease)+dx/len*curve;s.ball.z=Math.sin(Math.PI*q)*(a.height||0)+(a.kind==='loose'?Math.abs(Math.sin(q*Math.PI*4))*(1-q)*.6:0);s.ball.vx=(s.ball.x-old.x)/dt;s.ball.vy=(s.ball.y-old.y)/dt;
 if(a.kind==='shot'&&q>=.68&&!a.keeperChecked){
  a.keeperChecked=true;const keeper=s.squads[opp].playing.find(p=>!p.dismissed&&p.role==='GK');
  if(keeper&&a.onTarget){const gap=Math.abs(keeper.y-a.to.y)*.68,saveChance=clamp(.825+(rating(keeper,'reflexes')-65)*.006-gap*.025-a.xG*.9-keeper.fatigue*.002,.1,.94);
   if(randomValue(s)<saveChance){a.saved=true;a.saveStyle=a.xG>.21?'closeSave':gap>4?'fullStretch':a.height>1.2?'parry':gap>1.6?'dive':'catch';a.keeperId=keeper.id;a.to={x:keeper.x,y:keeper.y};a.from={...s.ball};a.elapsed=0;a.duration=.25;a.height=.2;keeper.saveStyle=a.saveStyle;pose(s,keeper,'save',1.1);}
  }
 }
 if(!a.saved&&q<.92&&q>.12&&s.ball.z<1.8){
  const interceptor=nearestPlayer(s.squads[opp].playing,s.ball,p=>p.role!=='GK');
  if(interceptor&&segmentDistance(interceptor,old,s.ball)<.8&&randomValue(s)<clamp(.13+rating(interceptor,'anticipation')*.003,.13,.45)){
   if(a.kind==='shot'){shotOutcome(s,a,'blocked');pose(s,interceptor,'tackle');recordEvent(s,'block',`${interceptor.name} bloqueia a finalização.`,{side:opp,playerId:interceptor.id});s.ball.lastTouch=opp;s.action={kind:'loose',subtype:'block',side,actorId:interceptor.id,from:{...s.ball},to:randomValue(s)<.4?{x:worldX(s,side,103),y:s.ball.y+(randomValue(s)<.5?-1:1)*10}:{x:clamp(s.ball.x+(randomValue(s)-.5)*18,-2,102),y:s.ball.y+(randomValue(s)<.5?-1:1)*15},duration:.8,elapsed:0,height:.8,curve:0};return;}
   s.stats.interceptions[opp]++;pose(s,interceptor,a.kind==='cross'?'header':'tackle');recordEvent(s,'interception',`${interceptor.name}: ${a.kind==='cross'?'corte de cruzamento':'interceptação de passe'}`,{side:opp,playerId:interceptor.id,subtype:a.kind==='cross'?'clearance':'interception'});
   if(a.kind==='cross'){s.ball.lastTouch=opp;s.action={kind:'loose',subtype:'clearance',side:opp,actorId:interceptor.id,from:{...s.ball},to:randomValue(s)<.5?{x:worldX(s,side,103),y:s.ball.y+(randomValue(s)<.5?-1:1)*14}:{x:worldX(s,opp,35),y:randomValue(s)<.5?-2:102},duration:1.5,elapsed:0,height:3,curve:0};}else giveBall(s,opp,interceptor,{x:s.ball.x,y:s.ball.y});return;
  }
 }
 if(a.elapsed<a.duration)return;
 if(a.saved){shotOutcome(s,a,'saved');const keeper=find(s,a.keeperId);s.stats.saves[opp]++;recordEvent(s,'save',`${keeper.name}: ${ACTION_LABELS[a.saveStyle]}`,{side:opp,playerId:keeper.id,subtype:a.saveStyle});
  if(a.saveStyle==='parry'||['dive','fullStretch','closeSave'].includes(a.saveStyle)&&randomValue(s)<.45){s.ball.lastTouch=opp;s.action={kind:'loose',subtype:'parry',side,actorId:keeper.id,from:{...s.ball},to:{x:worldX(s,side,102),y:a.to.y+(randomValue(s)<.5?-1:1)*12},duration:.65,elapsed:0,height:1,curve:0};}else giveBall(s,opp,keeper);return;}
 if(boundary(s,a))return;
 if(a.offside){s.stats.offsides[side]++;recordEvent(s,'offside','Impedimento assinalado na recepção.',{side,playerId:a.targetId});restart(s,'freeKick',opp,s.ball.x,s.ball.y,1.5);return;}
 if(a.kind==='shot'){restart(s,'goalKick',opp,worldX(s,opp,5),50,1.2);return;}
 const receiver=a.targetId?find(s,a.targetId):nearestPlayer(s.squads[side].playing,s.ball),defender=nearestPlayer(s.squads[opp].playing,s.ball);
 if(a.kind==='cross'){
  const keeper=s.squads[opp].playing.find(p=>!p.dismissed&&p.role==='GK');
  if(keeper&&fieldDistance(keeper,s.ball)<8&&randomValue(s)<rating(keeper,'aerialReach')/140){keeper.saveStyle='claim';pose(s,keeper,'save',.9);recordEvent(s,'save',`${keeper.name}: defesa de cruzamento.`,{side:opp,playerId:keeper.id,subtype:'claim'});giveBall(s,opp,keeper);return;}
 }
 if(receiver&&!receiver.dismissed&&fieldDistance(receiver,s.ball)<(a.kind==='cross'?10:9)&&(!defender||fieldDistance(receiver,s.ball)<fieldDistance(defender,s.ball)+2.5)){
  const point={x:s.ball.x,y:s.ball.y},height=a.height;
  // Sobras e rebotes recuperados não são passes: não contam como passe certo nem geram assistência.
  if(a.kind!=='loose'){s.stats.completedPasses[side]++;passTally(s,a.actorId,1);s.lastPass={side,playerId:a.actorId,at:s.time};}giveBall(s,side,receiver,point);
  s.oneTwo=a.kind==='pass'&&a.subtype==='short'?{side,playerId:a.actorId,until:s.time+3}:null;
  if(a.kind==='cross'&&localX(s,side,point.x)>76){s.ball.z=height>1?.9:.1;launch(s,planShot(s,receiver,height>1?'header':randomValue(s)<.3?'volley':'firstTime'));}
 }else{const winner=!receiver||receiver.dismissed||defender&&fieldDistance(defender,s.ball)<fieldDistance(receiver,s.ball)?defender:receiver;giveBall(s,winner===defender?opp:side,winner,{x:s.ball.x,y:s.ball.y});}
}
function restartTick(s,dt){
 const r=s.restart;r.remaining-=dt;if(r.remaining>0)return;
 const taker=find(s,r.takerId)||nearestPlayer(s.squads[r.side].playing,s.ball);if(!taker)return;
 // Repositioning at a stopped-ball restart is explicit, not part of open-play movement.
 taker.x=s.ball.x;taker.y=s.ball.y;taker.vx=0;taker.vy=0;s.restart=null;giveBall(s,r.side,taker);
 if(r.kind==='corner')launch(s,planCross(s,taker,true));
 else if(r.kind==='freeKick'&&localX(s,r.side,s.ball.x)>70&&Math.abs(s.ball.y-50)<24){recordEvent(s,'freeKick','Cobrança direta de falta.',{side:r.side});launch(s,planShot(s,taker,'placed',true));}
 else{if(r.kind==='freeKick')recordEvent(s,'freeKick','Tiro livre cobrado em passe.',{side:r.side});if(r.kind==='kickoff')recordEvent(s,'restart','Bola novamente em jogo.',{side:r.side});launch(s,planPass(s,taker,r.kind==='goalKick'));}
}
function shootout(s){
 const takers=s.squads.map(squad=>squad.playing.filter(p=>!p.dismissed).sort((a,b)=>(a.role==='GK')-(b.role==='GK')||rating(b,'penalties')+rating(b,'finishing')-rating(a,'penalties')-rating(a,'finishing')));
 const keepers=s.squads.map(squad=>squad.playing.find(p=>!p.dismissed&&p.role==='GK')),kicks=[],goals=[0,0],taken=[0,0];
 const decided=()=>{const left=side=>Math.max(0,5-taken[side]);if(taken[0]<=5||taken[1]<=5){return goals[0]>goals[1]+left(1)||goals[1]>goals[0]+left(0)}return taken[0]===taken[1]&&goals[0]!==goals[1]};
 recordEvent(s,'penalties','Disputa de pênaltis.');
 for(let n=0;n<40&&!decided();n++){
  const side=n%2,p=takers[side][Math.floor(n/2)%takers[side].length],keeper=keepers[1-side];
  const chance=clamp(.7+(rating(p,'penalties')-65)*.004-(rating(keeper,'reflexes')-65)*.002,.5,.88),scored=randomValue(s)<chance;
  taken[side]++;if(scored)goals[side]++;kicks.push({side,player:p.name,scored});
  recordEvent(s,'penalty',`Pênalti ${taken[side]} · ${p.name} ${scored?'converte':'perde'}. ${goals[0]} a ${goals[1]}.`,{side});
 }
 s.shootout=kicks;s.penalties=goals;recordEvent(s,'penalties',`Disputa de pênaltis: ${goals[0]} a ${goals[1]}.`);
}
export function tickMatch(s){
 if(s.finished)return s;
 const dt=TICK_SECONDS;s.tick++;s.time=round2(s.tick*dt);s.clock=Math.min(7200,s.tick*2);s.minute=Math.floor(s.clock/60);s.stats.possession[s.possession]++;
 if(s.clock===2700&&s.half===1){s.half=2;s.pauseSuggested=true;recordEvent(s,'halftime','Intervalo. As equipes trocam de lado.');s.squads.forEach(squad=>squad.playing.forEach(p=>{p.x=100-p.x;p.y=100-p.y;p.vx=0;p.vy=0;p.fatigue=Math.max(0,p.fatigue-8)}));restart(s,'kickoff',1,50,50,2);}
 if(s.endTick===3600&&s.half===3&&s.tick===3150){s.half=4;s.pauseSuggested=true;recordEvent(s,'extratime','Intervalo da prorrogação. As equipes trocam de lado.');s.squads.forEach(squad=>squad.playing.forEach(p=>{p.x=100-p.x;p.y=100-p.y;p.vx=0;p.vy=0}));restart(s,'kickoff',1,50,50,2);}
 movePlayers(s,dt);
 if(s.restart)restartTick(s,dt);else if(s.action)flightTick(s,dt);else{
  let p=s.squads[s.possession].playing[s.carrier];if(p.dismissed){p=nearestPlayer(s.squads[s.possession].playing,s.ball);giveBall(s,s.possession,p);}
  s.ball.x=clamp(p.x+Math.cos(p.angle)*.7,0,100);s.ball.y=clamp(p.y+Math.sin(p.angle)*.9,0,100);s.ball.z=0;tackle(s);
  if(!s.action&&!s.restart&&s.time>=s.decisionAt)launch(s,chooseAction(s));
 }
 if(s.tick===1||s.tick%30===0)s.snapshots.push({minute:s.minute,ball:{x:round2(s.ball.x),y:round2(s.ball.y)},players:s.squads.map(squad=>squad.playing.map(p=>({id:p.id,x:round2(p.x),y:round2(p.y),slot:p.slot,dismissed:p.dismissed}))),score:[...s.score],possession:s.possession});
 if(s.tick===2700&&s.knockout&&!s.noExtraTime&&level(s)&&(s.endTick||2700)===2700){s.endTick=3600;s.half=3;s.pauseSuggested=true;s.action=null;recordEvent(s,'extratime','Empate no tempo normal. Começa a prorrogação de 30 minutos.');s.squads.forEach(squad=>squad.playing.forEach(p=>{p.x=100-p.x;p.y=100-p.y;p.vx=0;p.vy=0;p.fatigue=Math.max(0,p.fatigue-4)}));restart(s,'kickoff',0,50,50,2);}
 else if(s.tick===(s.endTick||2700)){s.finished=true;s.action=null;s.restart=null;if(s.knockout&&level(s))shootout(s);recordEvent(s,'end','Fim de jogo. Resultado pronto para confirmar no calendário.');}
 replayTick(s);return s;
}
export function changeTactics(s,side,values){
 if(s.finished||![0,1].includes(side))throw Error('Comando indisponível.');const candidate={...TACTIC_DEFAULTS,...s.tactics[side],...values},sliders=['pressing','tempo','width','line'];
 if(!['defensive','balanced','attacking'].includes(candidate.mentality)||!TACTICAL_INSTRUCTIONS.includes(candidate.instruction)||!BUILD_UPS.includes(candidate.buildUp)||sliders.some(key=>!Number.isFinite(Number(candidate[key]))))throw Error('Instrução tática inválida.');
 for(const key of sliders)candidate[key]=clamp(Math.round(Number(candidate[key])),20,95);s.tactics[side]=candidate;
 recordEvent(s,'tactics',`Instrução: ${candidate.mentality==='attacking'?'ofensiva':candidate.mentality==='defensive'?'defensiva':'equilibrada'} · pressão ${candidate.pressing} · ritmo ${candidate.tempo} · largura ${candidate.width} · linha ${candidate.line} · saída ${({short:'curta',mixed:'mista',direct:'direta'})[candidate.buildUp]}`,{side});return s;
}
/** Função individual: muda onde o atleta se posiciona e o quanto arrisca; vale até ele sair de campo. */
export function setDuty(s,side,playerId,duty){
 if(s.finished||![0,1].includes(side)||!DUTIES.includes(duty))throw Error('Função individual indisponível.');const p=s.squads[side].playing.find(x=>x.id===playerId&&!x.dismissed);
 if(!p)throw Error('Atleta fora de campo.');if(p.role==='GK'&&duty!=='default')throw Error('O goleiro não recebe função de linha.');
 p.duty=duty;recordEvent(s,'tactics',`${p.name}: função ${({default:'padrão',attack:'atacar',support:'apoiar',defend:'defender'})[duty]}.`,{side,playerId});return s;
}
export function reshape(s,side,formation){
 if(s.finished||![0,1].includes(side)||!SHAPES[formation])throw Error('Formação indisponível.');const squad=s.squads[side],shape=SHAPES[formation],pool=[...squad.playing],carrierId=s.squads[s.possession].playing[s.carrier]?.id;
 squad.playing=shape.positions.map((role,slot)=>{let i=pool.findIndex(p=>p.role===role&&!p.dismissed);if(i<0)i=pool.findIndex(p=>role==='GK'?p.position==='GK':p.position!=='GK');if(i<0)i=0;const p=pool.splice(i,1)[0];Object.assign(p,{slot,role,baseX:shape.zones[slot][0],baseY:shape.zones[slot][1]});return p});squad.formation=formation;s.carrier=s.squads[s.possession].playing.findIndex(p=>p.id===carrierId);recordEvent(s,'formation',`Formação alterada para ${formation}. Reorganização em movimento.`,{side});return s;
}
export function makeSubstitution(s,side,outId,inId){
 if(s.finished||![0,1].includes(side))throw Error('Substituição indisponível.');const squad=s.squads[side],i=squad.playing.findIndex(p=>p.id===outId&&!p.dismissed),j=squad.bench.findIndex(p=>p.id===inId);
 if(squad.subs>=5)throw Error('Limite de cinco substituições.');if(i<0||j<0||squad.used.includes(inId))throw Error('Substituição inválida. Atletas substituídos não podem retornar.');
 const old=squad.playing[i],incoming=squad.bench[j],gks=squad.playing.filter(p=>!p.dismissed&&p.role==='GK'&&p.id!==outId).length+(incoming.position==='GK'?1:0);if(gks!==1)throw Error('Mantenha exatamente um goleiro em campo.');
 const next={...structuredClone(incoming),x:old.x,y:old.y,baseX:old.baseX,baseY:old.baseY,slot:old.slot,role:incoming.position==='GK'?'GK':old.role,number:incoming.number||old.slot+1,vx:0,vy:0,angle:old.angle,fatigue:incoming.fatigue||0,visual:'idle',visualUntil:0,cards:0,dismissed:false,inTick:s.tick};
 squad.playing[i]=next;squad.bench.splice(j,1);squad.used.push(old.id);squad.subs++;(squad.out??=[]).push({id:old.id,name:old.name,position:old.position,inTick:old.inTick||0,outTick:s.tick,fatigue:old.fatigue});
 if(s.action?.actorId===old.id)s.action.actorId=next.id;if(s.action?.targetId===old.id)s.action.targetId=next.id;if(s.restart?.takerId===old.id)s.restart.takerId=next.id;
 recordEvent(s,'substitution',`Sai ${old.name}, entra ${next.name}.`,{side,outId,inId});return s;
}
