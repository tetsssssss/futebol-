import {clamp,fieldDistance,localX,worldX,teamDirection,rating,randomValue,nearestPlayer} from './math.js';
export const ACTION_LABELS={short:'Passe curto',medium:'Passe médio',through:'Passe em profundidade',long:'Lançamento',switch:'Inversão',firstTime:'Passe de primeira',back:'Passe recuado',oneTwo:'Tabela',assist:'Passe para finalização',touch:'Drible curto',cutInside:'Corte para dentro',change:'Mudança de direção',shield:'Proteção de bola',body:'Corpo a corpo',feint:'Finta',burst:'Arrancada',open:'Cruzamento aberto',inswing:'Cruzamento fechado',low:'Cruzamento rasteiro',farPost:'Segundo pau',cutback:'Cruzamento recuado',power:'Chute forte',placed:'Chute colocado',volley:'Voleio',longShot:'Chute de longe',header:'Cabeceio',pressured:'Finalização sob pressão',catch:'Encaixe',dive:'Defesa lateral',fullStretch:'Ponte',parry:'Espalmada',closeSave:'Defesa à queima-roupa',claim:'Defesa de cruzamento',shortDistribution:'Reposição curta',longDistribution:'Reposição longa'};
function flight(s,kind,subtype,p,to,options={}){
 const from={x:s.ball.x,y:s.ball.y},length=fieldDistance(from,to),speed=kind==='shot'?25:kind==='cross'?18:subtype==='short'?12:20;
 return {kind,subtype,side:s.possession,actorId:p.id,from,to:{...to},elapsed:0,duration:clamp(length/speed,.35,3),height:0,curve:0,...options};
}
export function planShot(s,p,subtype=null,setPiece=false){
 const side=s.possession,opp=1-side,dir=teamDirection(s,side),goal=dir===1?100:0,dist=fieldDistance(p,{x:goal,y:50}),defender=nearestPlayer(s.squads[opp].playing,p),pressure=defender?clamp(1-fieldDistance(defender,p)/9,0,1):0;
 subtype||=s.ball.z>.8?'header':s.ball.z>.3?'volley':dist>25?'longShot':pressure>.7?'pressured':s.action?.kind==='cross'?'firstTime':randomValue(s)<.5?'power':'placed';
 const skill=rating(p,subtype==='header'?'heading':subtype==='volley'?'volleys':'finishing'),accuracy=clamp(.56+(skill-60)*.005-dist*.005-pressure*.12-(setPiece?.1:0),.22,.82),onTarget=randomValue(s)<accuracy;
 // Falta direta: a barreira e a distância derrubam a chance; quem bate bem recupera parte dela.
 const xG=setPiece?clamp(.075-Math.max(0,dist-18)*.0035+(rating(p,'freeKicks')-65)*.0016,.012,.14):clamp(.34-dist*.0088-Math.abs(p.y-50)*.0022-pressure*.06+(skill-65)*.0011,.015,.36);
 const y=onTarget?50+(randomValue(s)-.5)*9:50+(randomValue(s)<.5?-1:1)*(7+randomValue(s)*12);
 return flight(s,'shot',subtype,p,{x:goal+dir*1.4,y},{height:subtype==='header'?.9:subtype==='volley'?1.5:subtype==='longShot'?1.9:.7,curve:subtype==='placed'?(y>50?1:-1)*2:0,onTarget,xG,pressure});
}
/** Menor distância (m) de um adversário à linha do passe, ignorando quem está colado no passador. Mede se a linha está fechada. */
export function laneClearance(from,to,rivals){let best=99;const dx=(to.x-from.x)*1.05,dy=(to.y-from.y)*.68,l=dx*dx+dy*dy||1;for(const r of rivals){if(r.dismissed||r.role==='GK')continue;const q=clamp(((r.x-from.x)*1.05*dx+(r.y-from.y)*.68*dy)/l,0,1);if(q<.12)continue;const d=Math.hypot((r.x-from.x)*1.05-dx*q,(r.y-from.y)*.68-dy*q);if(d<best)best=d}return best}
/** Qualidade da posição para finalizar (0–0,4): distância e ângulo em relação ao gol adversário. */
export function shotQuality(s,side,point){const goal={x:worldX(s,side,100),y:50},dist=fieldDistance(point,goal);return dist>34?0:clamp(.34-dist*.0088-Math.abs(point.y-50)*.0022,0,.4)}
export function planCross(s,p,restart=false){
 const side=s.possession,kind=randomValue(s),subtype=kind<.2?'open':kind<.4?'inswing':kind<.6?'low':kind<.8?'farPost':'cutback',fromHigh=p.y>50;
 const endX=subtype==='cutback'?80:subtype==='farPost'?92:89,endY=subtype==='farPost'?(fromHigh?43:57):subtype==='cutback'?50:(fromHigh?56:44),spot={x:worldX(s,side,endX),y:endY},aerial=!['low','cutback'].includes(subtype);
 // Alvo: quem está na área e mais perto do ponto de queda; pelo alto pesa o cabeceio, rasteiro pesa a finalização.
 const inBox=s.squads[side].playing.filter(x=>!x.dismissed&&x.id!==p.id&&x.role!=='GK'&&localX(s,side,x.x)>72&&Math.abs(x.y-50)<30);
 const ranked=inBox.map(x=>({x,score:rating(x,aerial?'heading':'finishing')*.4-fieldDistance(x,spot)*2.6})).sort((m,n)=>n.score-m.score);
 const fallback=s.squads[side].playing.filter(x=>!x.dismissed&&x.id!==p.id&&['ST','AM','CM','RW','LW'].includes(x.role)).sort((m,n)=>(n.role==='ST'?25:0)+rating(n,'heading')-(m.role==='ST'?25:0)-rating(m,'heading'));
 // Cada tipo de cruzamento procura uma infiltração diferente: segundo pau é do ponta oposto, bola recuada é dos meias.
 const mates=s.squads[side].playing.filter(x=>!x.dismissed&&x.id!==p.id),nearest=list=>list.sort((m,n)=>fieldDistance(m,spot)-fieldDistance(n,spot))[0];
 const runner=subtype==='farPost'?nearest(mates.filter(x=>['RW','LW','RM','LM'].includes(x.role)&&(x.baseY>50)!==fromHigh&&localX(s,side,x.x)>68)):subtype==='cutback'?nearest(mates.filter(x=>['AM','CM','DM'].includes(x.role)&&localX(s,side,x.x)>62)):null;
 const receiver=runner||(ranked.length?ranked[Math.min(ranked.length-1,randomValue(s)<.62?0:1)].x:fallback[Math.min(fallback.length-1,subtype==='farPost'?1:0)])||p;
 return flight(s,'cross',subtype,p,spot,{targetId:receiver.id,height:aerial?2.8:.1,curve:subtype==='inswing'?(fromHigh?-1:1)*5:subtype==='open'?(fromHigh?1:-1)*3:0,restart});
}
export function planPass(s,p,distribution=false){
 const side=s.possession,dir=teamDirection(s,side),t=s.tactics[side],build=t.buildUp||'mixed',ownX=localX(s,side,p.x),rivals=s.squads[1-side].playing;
 const deepLine=rivals.filter(x=>!x.dismissed).map(x=>localX(s,side,x.x)).sort((a,b)=>b-a)[1]??100,isOffside=player=>localX(s,side,player.x)>50&&localX(s,side,player.x)>ownX&&localX(s,side,player.x)>deepLine+.3;
 // Construção: curta valoriza o apoio próximo; direta valoriza ganhar campo e aceita passes longos.
 const forward=(t.instruction==='through'?1.4:t.instruction==='retain'?.2:.9)*(build==='direct'?1.35:build==='short'?.6:1),reach=(build==='direct'?27:build==='short'?12:15)+(t.tempo>75?5:0),finalThird=ownX>60;
 const options=s.squads[side].playing.filter(x=>!x.dismissed&&x.id!==p.id).map(player=>{const distance=fieldDistance(player,p),ahead=dir*(player.x-p.x),marker=nearestPlayer(rivals,player),space=marker?fieldDistance(marker,player):20;
  // No terço final o passe procura quem está em melhor condição de finalizar, não apenas quem está mais à frente.
  const lx=localX(s,side,player.x),flank=Math.abs(player.y-50)>25&&lx>62?(t.instruction==='wide'?11:6)+Math.min(space,8)*.6:0,quality=shotQuality(s,side,player),threat=(finalThird?quality*36+quality*Math.min(space,8)*13:0)+(ownX>48?flank:0);
  // Passe rasteiro por uma linha fechada tende a ser interceptado: o portador evita. Bolas longas passam por cima.
  const lane=distance<34?Math.max(0,3.4-laneClearance(p,player,rivals))*(3+rating(p,'vision')*.03):0;
  return {player,distance,ahead,score:ahead*forward*(finalThird?.45:1)+space*.55-Math.abs(distance-reach)*.25+threat-lane+(player.duty==='attack'&&ahead>0?2:0)+(player.role==='GK'?-10:0)};}).filter(x=>x.distance>2&&x.distance<75).filter(x=>distribution||!isOffside(x.player)||randomValue(s)<.3)/* impedimento por pouco nem sempre é percebido por quem passa */.sort((a,b)=>b.score-a.score);
 // Quem decide e enxerga melhor escolhe a melhor opção com mais frequência.
 const read=clamp(.3+(rating(p,'decisions')+rating(p,'vision')-120)*.006,.2,.75);
 let chosen=options[randomValue(s)<read?0:Math.min(options.length-1,1+Math.floor(randomValue(s)*2))];if(!chosen)return null;
 if(distribution){const shortOptions=options.filter(x=>x.distance<30&&['CB','RB','LB','DM'].includes(x.player.role));if(shortOptions.length&&randomValue(s)<(build==='short'?.9:build==='direct'?.15:t.tempo>75?.3:.7))chosen=shortOptions[0];}
 if(s.oneTwo?.side===side&&s.time<s.oneTwo.until){const returner=options.find(x=>x.player.id===s.oneTwo.playerId);if(returner)chosen=returner;}
 const {player,distance:dist,ahead}=chosen;let subtype=distribution?(dist>25?'longDistribution':'shortDistribution'):s.oneTwo?.playerId===player.id?'oneTwo':ahead< -5?'back':Math.abs(player.y-p.y)>45?'switch':dist>34?'long':t.instruction==='through'&&ahead>8?'through':s.time-(s.receivedAt||-10)<.45?'firstTime':dist<14?'short':'medium';
 if(!distribution&&ownX>66&&ahead>3)subtype='assist';
 const lead=['through','long','assist'].includes(subtype)?3:1,to={x:clamp(player.x+dir*lead,2,98),y:clamp(player.y+player.vy*.35,2,98)};
 const accuracy=rating(p,dist>28?'longPass':'shortPass'),error=(100-accuracy)/100*(dist>25?3.5:1.4);
 to.x+=(randomValue(s)-.5)*error;to.y+=(randomValue(s)-.5)*error;
 const offside=!distribution&&isOffside(player);
 return flight(s,distribution?'distribution':'pass',subtype,p,to,{targetId:player.id,height:['long','switch','longDistribution'].includes(subtype)?3:subtype==='through'?.2:0,offside,passerId:p.id});
}
/** Bola em profundidade: passe no espaço atrás da última linha para quem a ataca. O impedimento é julgado no momento do passe. */
export function planThrough(s,p){
 const side=s.possession,t=s.tactics[side],ownX=localX(s,side,p.x),rivals=s.squads[1-side].playing,xs=rivals.filter(x=>!x.dismissed).map(x=>localX(s,side,x.x)).sort((a,b)=>b-a),line=Math.max(50,xs[1]??100);
 if(ownX<32||ownX>line-4||line>88)return null; // precisa de espaço entre a linha e o gol, e o passador atrás da linha
 const runners=s.squads[side].playing.filter(x=>!x.dismissed&&x.id!==p.id&&['ST','RW','LW','RM','LM','AM'].includes(x.role)&&localX(s,side,x.x)>line-13&&fieldDistance(x,p)<42&&fieldDistance(x,p)>6);
 if(!runners.length)return null;
 const runner=runners.sort((a,b)=>rating(b,'pace')+rating(b,'offBall')+(b.duty==='attack'?8:0)-rating(a,'pace')-rating(a,'offBall')-(a.duty==='attack'?8:0)||a.slot-b.slot)[Math.floor(randomValue(s)*runners.length)]; // qualquer atacante próximo da linha pode ser o alvo: a ruptura não é só do centroavante
 const to={x:worldX(s,side,Math.min(94,line+8+(rating(runner,'pace')-65)*.08)),y:clamp(runner.y*.65+50*.35,8,92)};
 if(laneClearance(p,to,rivals)<1.1)return null;
 const error=(100-rating(p,'vision'))/100*3.2;to.x+=(randomValue(s)-.5)*error;to.y+=(randomValue(s)-.5)*error;
 return flight(s,'pass','through',p,to,{targetId:runner.id,height:.2,offside:localX(s,side,runner.x)>line+.3,passerId:p.id});
}
export function chooseAction(s){
 const squad=s.squads[s.possession],p=squad.playing[s.carrier];if(!p||p.dismissed)return null;
 const side=s.possession,t=s.tactics[side],ownX=localX(s,side,p.x),marker=nearestPlayer(s.squads[1-side].playing,p),pressure=marker?fieldDistance(marker,p):30;
 if(p.role==='GK')return planPass(s,p,true);
 const wide=Math.abs(p.y-50)>22,quality=shotQuality(s,side,p);
 // Ponta que corta para dentro: em vez de cruzar sempre, conduz em diagonal para a área e ganha ângulo de chute.
 if(ownX>60&&ownX<90&&wide&&quality<.1&&p.role!=='RB'&&p.role!=='LB'&&randomValue(s)<clamp(.24+(rating(p,'dribbling')-65)*.008-(t.instruction==='wide'?.16:0),.06,.5))return {kind:'dribble',subtype:'cutInside',side,actorId:p.id,from:{x:p.x,y:p.y},to:{x:worldX(s,side,Math.min(91,ownX+8)),y:clamp(p.y+(50-p.y)*.5,5,95)},elapsed:0,duration:1.5,height:0,curve:0};
 // Quem já está dentro da área em ângulo razoável finaliza ou serve; cruzamento é para quem está aberto e sem ângulo.
 if(ownX>66&&wide&&quality<.1&&randomValue(s)<.68)return planCross(s,p);
 // Finalizar depende da posição (distância e ângulo), da instrução, da função e de quem tem a bola — não do nome da posição.
 if(quality>0&&(!wide||quality>=.1)){
  // Companheiro livre em posição melhor? Marcado de perto, o portador prefere servir a chutar travado.
  const rivals=s.squads[1-side].playing,squeeze=pt=>{const m=nearestPlayer(rivals,pt);return m?clamp(1-fieldDistance(m,pt)/9,0,1):0},mine=quality-squeeze(p)*.09;
  const better=squad.playing.some(x=>!x.dismissed&&x.id!==p.id&&x.role!=='GK'&&fieldDistance(x,p)<26&&shotQuality(s,side,x)-squeeze(x)*.09>mine+.025&&laneClearance(p,x,rivals)>1.4);
  const will=(better?.4:1)*clamp(.2+quality*2.8+(t.instruction==='shoot'?.22:0)+(p.duty==='attack'?.06:p.duty==='defend'?-.08:0)+(rating(p,'finishing')-65)*.004+(pressure>6?.1:pressure<2.5?-.22:pressure<4?-.08:0)-(t.instruction==='retain'?.1:0),.03,.88);if(randomValue(s)<will)return planShot(s,p);}
 // Drible é resposta a pressão real (ou escolha de quem tem recurso), não o padrão em qualquer disputa a 9 m.
 if(pressure<5.5&&rating(p,'dribbling')+rating(p,'agility')>100&&randomValue(s)<clamp(.22+(rating(p,'dribbling')-65)*.006,.12,.5)){
  const subtype=pressure<2?'body':pressure<3?'shield':wide?'cutInside':t.instruction==='counter'?'burst':['touch','change','feint'][Math.floor(randomValue(s)*3)];
  return {kind:'dribble',subtype,side,actorId:p.id,from:{x:p.x,y:p.y},to:{x:worldX(s,side,clamp(ownX+(subtype==='shield'?2:10),4,96)),y:clamp(p.y+(wide?(50-p.y)*.25:(randomValue(s)-.5)*16),5,95)},elapsed:0,duration:subtype==='shield'?1.3:1.6,height:0,curve:subtype==='feint'?3:0};
 }
 // Profundidade: quem enxerga o espaço atrás da linha e tem um companheiro para atacá-lo tenta o passe decisivo.
 if(randomValue(s)<clamp(.13+(rating(p,'vision')-65)*.005+(t.instruction==='through'?.24:0)+(t.buildUp==='direct'?.07:0)-(t.instruction==='retain'?.09:0),.03,.6)){const through=planThrough(s,p);if(through)return through;}
 // Conduzir: vale quando o corredor à frente está livre, mesmo com marcador por perto ou atrás.
 const corridor=!s.squads[1-side].playing.some(r=>!r.dismissed&&r.role!=='GK'&&localX(s,side,r.x)>ownX+.5&&localX(s,side,r.x)<ownX+10&&Math.abs(r.y-p.y)<9);
 if(wide&&ownX>52&&ownX<=66&&pressure<9&&randomValue(s)<clamp(.2+(rating(p,'dribbling')-65)*.008,.1,.5))return {kind:'dribble',subtype:'burst',side,actorId:p.id,from:{x:p.x,y:p.y},to:{x:worldX(s,side,Math.min(92,ownX+13)),y:p.y},elapsed:0,duration:1.7,height:0,curve:0};
 if((corridor||pressure>8)&&ownX<88&&randomValue(s)<(corridor?.42:.2)+(t.instruction==='counter'?.25:0)+(t.buildUp==='direct'?.06:0)-(t.instruction==='retain'?.12:0))return {kind:'carry',subtype:'burst',side,actorId:p.id,from:{x:p.x,y:p.y},to:{x:worldX(s,side,Math.min(94,ownX+12)),y:clamp(p.y+(50-p.y)*.12,5,95)},elapsed:0,duration:1.8,height:0,curve:0};
 return planPass(s,p);
}
