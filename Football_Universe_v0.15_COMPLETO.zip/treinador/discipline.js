// Disciplina e disponibilidade entre jogos: cartões acumulados, suspensões e lesões.
// Opera apenas sobre o save e sobre eventos já registrados pela partida; não usa RNG.
const YELLOW_LIMIT={brasileirao:3,copa:2,eliminatorias:2};
export function ensureDiscipline(save){if(!save.discipline)save.discipline={yellows:{},suspended:{},injured:{}};return save.discipline}
export function unavailableMap(save,teamId){
 const d=save?.discipline,out={};if(!d)return out;
 for(const [kind,bucket] of [['suspended',d.suspended],['injured',d.injured]])for(const [id,e] of Object.entries(bucket||{}))if(e.team===teamId&&e.left>0)out[id]={kind,left:e.left,reason:e.reason};
 return out;
}
export function availableTeam(team,save){
 const gone=unavailableMap(save,team.id),ids=new Set(Object.keys(gone));if(!ids.size)return team;
 const roster=team.roster.filter(p=>!ids.has(p.id));
 const enough=roster.length>=16&&roster.some(p=>p.position==='GK')&&roster.filter(p=>p.position!=='GK').length>=13;
 return enough?{...team,roster}:team;
}
export function applyMatchDiscipline(save,state){
 const d=ensureDiscipline(save),limit=YELLOW_LIMIT[save.mode]||3,teams=[state.home,state.away];
 for(const bucket of [d.suspended,d.injured])for(const [id,e] of Object.entries(bucket))if(teams.includes(e.team)&&--e.left<=0)delete bucket[id];
 for(const e of state.events){
  if(e.type==='card'&&e.playerId){
   const team=teams[e.side];
   if(e.color==='red'){d.suspended[e.playerId]={team,left:1,reason:'Cartão vermelho'};d.yellows[e.playerId]=0}
   else{d.yellows[e.playerId]=(d.yellows[e.playerId]||0)+1;if(d.yellows[e.playerId]>=limit){d.suspended[e.playerId]={team,left:1,reason:`${limit} cartões amarelos`};d.yellows[e.playerId]=0}}
  }
  if(e.type==='injury'&&e.playerId&&Number.isInteger(e.matches)){const old=d.injured[e.playerId];d.injured[e.playerId]={team:teams[e.side],left:Math.max(old?.left||0,e.matches),reason:'Lesão em jogo'}}
 }
 return d;
}
export function validateDiscipline(d){
 if(d===undefined)return true;
 if(!d||typeof d!=='object'||['yellows','suspended','injured'].some(k=>!d[k]||typeof d[k]!=='object'))throw Error('Disciplina inválida.');
 for(const [id,n] of Object.entries(d.yellows))if(!Number.isInteger(n)||n<0||n>10||!id)throw Error('Cartões acumulados inválidos.');
 for(const bucket of [d.suspended,d.injured])for(const e of Object.values(bucket))if(typeof e.team!=='string'||!Number.isInteger(e.left)||e.left<0||e.left>40)throw Error('Indisponibilidade inválida.');
 return true;
}
