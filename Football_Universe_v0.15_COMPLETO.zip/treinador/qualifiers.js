// Eliminatórias da Copa do Mundo: sorteio por potes, grupos por confederação, repescagem intercontinental e lista final.
// Opera sobre resultados confirmados; as partidas são jogadas pelo mesmo motor espacial das demais competições.
import {rankTable} from './rules.js';
import {NATION,membersOf,CONFEDERATIONS} from './nations.js';
// Formato versionado e NÃO oficial: a FIFA ainda não publicou a divisão de vagas nem o regulamento de 2030.
// Anfitriões classificados conforme anunciado; vagas por confederação repetem 2026; grupos e repescagem são do simulador.
export const QUALIFYING_RULES=[{id:'fifa-wcq',edition:2030,revision:1,verified:false,finalsTeams:48,hosts:['ESP','POR','MAR','ARG','PAR','URU'],excluded:['RUS'],
 points:{win:3,draw:1,loss:0},tiebreakers:['goalDifference','goalsFor','headToHead','fairPlay','draw'],headToHead:{onlyTwoTeams:false},yellowLimit:2,
 zones:{CONMEBOL:{groups:1,legs:2,direct:3,playoff:1},UEFA:{groups:12,legs:2,direct:14,playoff:0},CAF:{groups:9,legs:2,direct:8,playoff:2},AFC:{groups:8,legs:2,direct:8,playoff:1},CONCACAF:{groups:6,legs:2,direct:6,playoff:1},OFC:{groups:2,legs:1,direct:1,playoff:1,final:true}},
 intercontinental:{entrants:6,spots:2},firstMatchday:'2027-09-02',
 notes:'Seis anfitriões classificados (Espanha, Portugal, Marrocos, Argentina, Paraguai e Uruguai). A divisão de vagas repete a de 2026 e ainda não foi confirmada para 2030. Formato de grupos, datas e repescagem são do simulador. Rússia fora, como nas eliminatórias de 2026.',
 source:'Anúncios da FIFA sobre os anfitriões de 2030 (imprensa, consultado em 12/10/2026)'}];
export const qualifyingRules=(edition=2030)=>{const r=QUALIFYING_RULES.filter(x=>x.edition<=edition).sort((a,b)=>b.edition-a.edition||b.revision-a.revision)[0];if(!r)throw Error('Sem regulamento de eliminatórias para '+edition);return r};
const hash=text=>{let h=2166136261;for(const c of String(text))h=Math.imul(h^c.charCodeAt(0),16777619)>>>0;return h};
const LETTERS='ABCDEFGHIJKLMNOPQRSTUVWXYZ';
function schedule(codes,legs){ // todos contra todos pelo método do círculo; com número ímpar, um folga por rodada
 const list=codes.length%2?[...codes,null]:[...codes],n=list.length,rounds=[];let order=[...list];
 for(let r=0;r<n-1;r++){const games=[];for(let k=0;k<n/2;k++){const a=order[k],b=order[n-1-k];if(a&&b){const first=k?k%2===1:r%2===1;games.push(first?[a,b]:[b,a])}}rounds.push(games);order=[order[0],order[n-1],...order.slice(1,n-1)]}
 return legs===2?[...rounds,...rounds.map(g=>g.map(([h,a])=>[a,h]))]:rounds;
}
const matchdayDate=(first,day)=>new Date(Date.parse(first)+(Math.floor((day-1)/2)*56+((day-1)%2)*4)*86400000).toISOString().slice(0,10);
/** Cria as eliminatórias. `strengthOf(code)` ordena os potes do sorteio (força do elenco; 0 quando desconhecida). */
export function createQualifying(strengthOf=()=>0,seed='wcq-2030',edition=2030){
 const rules=qualifyingRules(edition),out={edition,rules:{id:rules.id,edition:rules.edition,revision:rules.revision},seed,stage:'groups',zones:{},extra:[],playoff:null,qualified:null};
 for(const [zone,z] of Object.entries(rules.zones)){
  const teams=membersOf(zone).filter(c=>!rules.hosts.includes(c)&&!rules.excluded.includes(c)).sort((a,b)=>strengthOf(b)-strengthOf(a)||hash(seed+a)-hash(seed+b)),groups={},fixtures=[];
  // Potes: os mais fortes são cabeças de chave; dentro de cada pote a ordem é sorteada pela semente.
  for(let pot=0;pot*z.groups<teams.length;pot++)teams.slice(pot*z.groups,(pot+1)*z.groups).sort((a,b)=>hash(`${seed}|${zone}|${pot}|${a}`)-hash(`${seed}|${zone}|${pot}|${b}`)).forEach((code,i)=>(groups[LETTERS[i]]??=[]).push(code));
  for(const [group,codes] of Object.entries(groups))schedule(codes,z.legs).forEach((games,r)=>games.forEach(([home,away],i)=>fixtures.push({id:`Q-${zone}-${group}-${r+1}-${i+1}`,zone,group,stage:'group',matchday:r+1,home,away,date:matchdayDate(rules.firstMatchday,r+1),dateSource:'gerada pelo simulador',played:false})));
  out.zones[zone]={groups,fixtures};
 }
 return out;
}
export const zoneOf=code=>NATION[code]?.confederation||null;
export const qualifyingFixtures=q=>[...Object.values(q.zones).flatMap(z=>z.fixtures),...q.extra];
export const qualifyingTeams=q=>Object.values(q.zones).flatMap(z=>Object.values(z.groups).flat());
export function groupOfTeam(q,code){const zone=zoneOf(code),groups=q.zones[zone]?.groups||{},group=Object.keys(groups).find(g=>groups[g].includes(code));return group?{zone,group}:null}
function tableRules(q,zone){const rules=qualifyingRules(q.edition),z=rules.zones[zone],single=z.groups===1;
 return {...rules,id:`${rules.id}-${zone}`,zones:single?[{from:1,to:z.direct,key:'promotion',label:'Vaga direta'},{from:z.direct+1,to:z.direct+z.playoff,key:'playoff',label:'Repescagem intercontinental'}]:[{from:1,to:1,key:'promotion',label:z.final?'Final da zona':z.direct>=z.groups?'Vaga direta':'Vaga direta (melhores primeiros)'},{from:2,to:2,key:'playoff',label:z.direct>z.groups||z.playoff?'Disputa vaga entre os segundos':'Eliminado'}]}}
export function zoneTable(q,zone,group){const z=q.zones[zone];return rankTable(z.fixtures.filter(m=>m.group===group),z.groups[group],tableRules(q,zone),`${q.seed}|${zone}|${group}`)}
/** Dia de jogos em aberto: a rodada mais antiga com partidas pendentes; depois vêm finais de zona e repescagem. */
export function currentMatchday(q){
 const open=Object.values(q.zones).flatMap(z=>z.fixtures).filter(m=>!m.played);
 if(open.length){const day=Math.min(...open.map(m=>m.matchday));return {label:`Rodada ${day}`,matchday:day,matches:open.filter(m=>m.matchday===day)}}
 const extra=q.extra.filter(m=>!m.played);if(!extra.length)return null;const stage=extra[0].stage;return {label:STAGE_LABEL[stage],matchday:null,matches:extra.filter(m=>m.stage===stage)};
}
export const STAGE_LABEL={group:'Fase de grupos','zone-final':'Final da zona','playoff-semi':'Repescagem · semifinais','playoff-final':'Repescagem · finais'};
const perGame=r=>({ppg:r.played?r.pts/r.played:0,gdpg:r.played?r.gd/r.played:0,gfpg:r.played?r.gf/r.played:0});
const byRate=(a,b)=>b.ppg-a.ppg||b.gdpg-a.gdpg||b.gfpg-a.gfpg||a.code.localeCompare(b.code);
const knockoutWinner=m=>m.hg>m.ag?m.home:m.hg<m.ag?m.away:m.penalties?(m.penalties[0]>m.penalties[1]?m.home:m.away):null;
/** Vagas de uma zona depois de encerrada a fase de grupos (e a final, quando houver). Grupos de tamanhos diferentes comparam por média. */
export function zoneOutcome(q,zone){
 const z=qualifyingRules(q.edition).zones[zone],groups=Object.keys(q.zones[zone].groups),tables=groups.map(g=>zoneTable(q,zone,g).map(r=>({...r,group:g,...perGame(r)})));
 if(z.groups===1){const t=tables[0];return {direct:t.slice(0,z.direct).map(r=>r.code),playoff:t.slice(z.direct,z.direct+z.playoff).map(r=>r.code),ranked:t}}
 const winners=tables.map(t=>t[0]).sort(byRate),seconds=tables.map(t=>t[1]).filter(Boolean).sort(byRate);
 if(z.final){const final=q.extra.find(m=>m.stage==='zone-final'&&m.zone===zone);if(!final?.played)return {direct:[],playoff:[],pendingFinal:winners.map(r=>r.code),ranked:[...winners,...seconds]};const champion=knockoutWinner(final);return {direct:[champion],playoff:[final.home===champion?final.away:final.home],ranked:[...winners,...seconds]}}
 const order=[...winners,...seconds];return {direct:order.slice(0,z.direct).map(r=>r.code),playoff:order.slice(z.direct,z.direct+z.playoff).map(r=>r.code),ranked:order};
}
const extraDate=(q,days)=>{const last=Object.values(q.zones).flatMap(z=>z.fixtures).map(m=>m.date).sort().at(-1);return new Date(Date.parse(last)+days*86400000).toISOString().slice(0,10)};
const single=(id,stage,home,away,date,zone=null)=>({id,zone,group:null,stage,matchday:null,home,away,date,dateSource:'gerada pelo simulador',knockout:true,played:false});
/** Avança as fases depois de cada resultado: finais de zona, repescagem e lista final de classificados. */
export function afterQualifier(q){
 const rules=qualifyingRules(q.edition),groupsDone=Object.values(q.zones).every(z=>z.fixtures.every(m=>m.played));if(!groupsDone||q.stage==='done')return q;
 if(q.stage==='groups'){
  for(const [zone,z] of Object.entries(rules.zones))if(z.final&&!q.extra.some(m=>m.stage==='zone-final'&&m.zone===zone)){const [a,b]=zoneOutcome(q,zone).pendingFinal;q.extra.push(single(`Q-${zone}-FINAL`,'zone-final',a,b,extraDate(q,30),zone))}
  q.stage='zone-finals';
 }
 if(q.stage==='zone-finals'&&q.extra.filter(m=>m.stage==='zone-final').every(m=>m.played)){
  // Repescagem: seis seleções ordenadas pela campanha; as duas melhores esperam na final, as outras quatro jogam semifinais.
  const entrants=Object.keys(rules.zones).flatMap(zone=>{const o=zoneOutcome(q,zone);return o.playoff.map(code=>({code,zone,...perGame(o.ranked.find(r=>r.code===code))}))}).sort(byRate).map(e=>e.code);
  if(entrants.length!==rules.intercontinental.entrants)throw Error('Repescagem intercontinental com número inesperado de seleções.');
  q.playoff={entrants,winners:null};q.extra.push(single('Q-PO-S1','playoff-semi',entrants[2],entrants[5],extraDate(q,60)),single('Q-PO-S2','playoff-semi',entrants[3],entrants[4],extraDate(q,60)));q.stage='playoff-semi';
 }
 if(q.stage==='playoff-semi'&&q.extra.filter(m=>m.stage==='playoff-semi').every(m=>m.played)){
  const [s1,s2]=['Q-PO-S1','Q-PO-S2'].map(id=>knockoutWinner(q.extra.find(m=>m.id===id)));
  q.extra.push(single('Q-PO-F1','playoff-final',q.playoff.entrants[0],s2,extraDate(q,64)),single('Q-PO-F2','playoff-final',q.playoff.entrants[1],s1,extraDate(q,64)));q.stage='playoff-final';
 }
 if(q.stage==='playoff-final'&&q.extra.filter(m=>m.stage==='playoff-final').every(m=>m.played)){
  q.playoff.winners=['Q-PO-F1','Q-PO-F2'].map(id=>knockoutWinner(q.extra.find(m=>m.id===id)));
  q.qualified=[...rules.hosts.map(code=>({code,via:'Anfitrião'})),...Object.keys(rules.zones).flatMap(zone=>zoneOutcome(q,zone).direct.map(code=>({code,via:`Eliminatórias · ${CONFEDERATIONS[zone]}`}))),...q.playoff.winners.map(code=>({code,via:'Repescagem intercontinental'}))];
  if(q.qualified.length!==rules.finalsTeams||new Set(q.qualified.map(x=>x.code)).size!==rules.finalsTeams)throw Error('Lista de classificados inconsistente.');
  q.stage='done';
 }
 return q;
}
/** Situação atual de classificação: anfitriões, já garantidos (após o fim) e quem ocupa vaga no momento. */
export function qualificationPicture(q){
 const rules=qualifyingRules(q.edition);if(q.qualified)return {final:true,slots:q.qualified};
 const started=Object.values(q.zones).some(z=>z.fixtures.some(m=>m.played));
 return {final:false,slots:[...rules.hosts.map(code=>({code,via:'Anfitrião',sure:true})),...(started?Object.keys(rules.zones).flatMap(zone=>zoneOutcome(q,zone).direct.map(code=>({code,via:`Em vaga direta · ${CONFEDERATIONS[zone]}`,sure:false}))):[])]};
}
export function validateQualifying(q){
 const rules=qualifyingRules(q?.edition),known=new Set(Object.keys(NATION));if(!q||typeof q.seed!=='string'||!q.zones||!Array.isArray(q.extra)||!Object.keys(STAGE_LABEL).concat(['groups','zone-finals','done']).includes(q.stage))throw Error('Eliminatórias inválidas.');
 const seen=new Set(),ids=new Set();
 for(const zone of Object.keys(rules.zones)){const z=q.zones[zone];if(!z||!z.groups||!Array.isArray(z.fixtures)||Object.keys(z.groups).length!==rules.zones[zone].groups)throw Error('Zona inválida: '+zone);
  for(const code of Object.values(z.groups).flat()){if(!known.has(code)||seen.has(code)||rules.hosts.includes(code)||zoneOf(code)!==zone)throw Error('Seleção inválida nas eliminatórias: '+code);seen.add(code)}}
 for(const m of qualifyingFixtures(q)){if(ids.has(m.id)||!known.has(m.home)||!known.has(m.away)||m.home===m.away||typeof m.played!=='boolean')throw Error('Confronto inválido');ids.add(m.id);if(m.played&&(!Number.isInteger(m.hg)||!Number.isInteger(m.ag)||m.hg<0||m.ag<0||m.hg>30||m.ag>30))throw Error('Placar inválido')}
 if(q.qualified&&(q.qualified.length!==rules.finalsTeams||q.stage!=='done'))throw Error('Classificados inválidos.');
 return true;
}
