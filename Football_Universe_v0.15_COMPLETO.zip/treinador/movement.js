import {clamp,fieldDistance,localX,worldX,teamDirection,rating} from './math.js';
// Movimento coletivo. Coordenadas "locais": o próprio gol fica em x=0 e o ataque vai para x=100.
// Nada aqui consome RNG: a forma da equipe decorre das instruções, da bola e dos adversários.
export const TACTIC_DEFAULTS={width:55,line:50,buildUp:'mixed'};
export const BUILD_UPS=['short','mixed','direct'],DUTIES=['default','attack','support','defend'];
export const tacticOf=t=>({...TACTIC_DEFAULTS,...t});
const WIDE=['RW','LW','RM','LM'],BACKS=['RB','LB'];
/** Linha de impedimento vista pelo time `side`: o penúltimo adversário, nunca antes do meio-campo. */
export function offsideLine(s,side){const xs=s.squads[1-side].playing.filter(p=>!p.dismissed).map(p=>localX(s,side,p.x)).sort((a,b)=>b-a);return Math.max(50,xs[1]??100)}
/** Forma medida da equipe (jogadores de linha): largura, comprimento do bloco e altura da linha defensiva, em % do campo. */
export function teamShape(s,side){
 const outfield=s.squads[side].playing.filter(p=>!p.dismissed&&p.role!=='GK'),xs=outfield.map(p=>localX(s,side,p.x)).sort((a,b)=>a-b),ys=outfield.map(p=>p.y);
 return xs.length<2?{width:0,length:0,line:0}:{width:Math.max(...ys)-Math.min(...ys),length:xs.at(-1)-xs[0],line:(xs[0]+xs[1])/2};
}
export function movePlayers(s,dt){
 const ball=s.ball;
 for(let side=0;side<2;side++){
  const squad=s.squads[side],t=tacticOf(s.tactics[side]),own=s.possession===side,dir=teamDirection(s,side),progress=localX(s,side,ball.x),mental=t.mentality==='attacking'?5:t.mentality==='defensive'?-5:0;
  const pressers=own?[]:squad.playing.filter(p=>!p.dismissed&&p.role!=='GK').sort((a,b)=>fieldDistance(a,ball)-fieldDistance(b,ball)).slice(0,t.pressing>75?3:t.pressing>40?2:1).map(p=>p.id);
  // Marcação por referência: defensores livres acompanham os atacantes mais perigosos pelo lado do gol, sem trocar as zonas.
  const marks=new Map();
  if(!own){
   const free=squad.playing.filter(p=>!p.dismissed&&p.role!=='GK'&&!pressers.includes(p.id)),taken=new Set(),ownGoal={x:worldX(s,side,0),y:50};
   const threats=s.squads[1-side].playing.filter(a=>!a.dismissed&&a.role!=='GK').sort((a,b)=>fieldDistance(a,ownGoal)-fieldDistance(b,ownGoal)).slice(0,5);
   for(const a of threats){let best=null,bd=26;for(const d of free){if(taken.has(d.id))continue;const dd=fieldDistance(d,a);if(dd<bd){bd=dd;best=d}}if(best){taken.add(best.id);marks.set(best.id,a)}}
  }
  // Bloco: uma linha defensiva e um comprimento. Cada função ocupa uma fração desse comprimento (compactação entre setores).
  const last=offsideLine(s,side),transition=s.time-s.transitionAt<4,direct=t.buildUp==='direct';
  const attackLine=clamp(progress-31+(t.line-50)*.1+mental,14,58),attackLength=(direct?44:t.buildUp==='short'?36:40)+mental*.6;
  let defendLine=clamp(17+(progress-30)*.42+(t.line-50)*.24+mental*.5,9,50);defendLine=Math.min(defendLine,Math.max(8,progress-4)); // bola nas costas: a linha recua
  const defendLength=30+(t.pressing-55)*.14-(t.line>65?2:0),widthIn=.6+t.width*.006+(t.instruction==='wide'?.12:0),widthOut=.48+t.width*.0042;
  const farBackHolds=role=>role==='RB'?ball.y<50:ball.y>50; // equilíbrio: só o lateral do lado da bola ultrapassa
  for(const p of squad.playing){
   if(p.dismissed){p.vx=0;p.vy=0;continue;}
   const depth=clamp((p.baseX-23)/63,0,1),duty=p.duty||'default';
   let tx,ty,visual=own?'run':'mark';
   if(own){
    tx=attackLine+depth*attackLength+(duty==='attack'?6:duty==='defend'?-7:0);ty=50+(p.baseY-50)*widthIn;
    if(p.role==='CB')tx=Math.min(tx,progress-12);
    if(p.role==='DM')tx=clamp(Math.max(tx,progress-(duty==='defend'?20:14)),tx,progress-(duty==='attack'?2:7));
    if(['CM','AM'].includes(p.role)){
     // Apoio próximo: o meio-campo acompanha a bola de perto em vez de ficar preso à linha de trás.
     tx=Math.max(tx,progress+(p.role==='AM'?3:-8)+(duty==='attack'?5:duty==='defend'?-8:0));tx=Math.min(tx,progress+(duty==='defend'?4:12));ty=clamp(ty+(ball.y-50)*.2,15,85);
     if(progress>72&&duty!=='defend')tx=Math.max(tx,p.role==='AM'?82:77);} // meias chegam à entrada da área para o passe recuado e o chute de média distância
    if(BACKS.includes(p.role)&&progress>55&&duty!=='defend'&&(!farBackHolds(p.role)||duty==='attack'||t.mentality==='attacking'&&progress>70)){tx=Math.max(tx,progress+(duty==='attack'?12:8));}
    if(WIDE.includes(p.role)){tx=Math.max(tx,Math.min(last-.1,progress+(duty==='attack'||t.instruction==='counter'?18:11)));ty=50+(p.baseY-50)*(widthIn+.08);const ballFar=Math.abs(ball.y-p.baseY)>30;if(progress>64&&t.instruction!=='wide'&&ballFar)ty=50+(ty-50)*.62;} // ponta do lado oposto fecha para a área
    if(p.role==='ST'){tx=Math.max(tx,progress+8,Math.min(last+.6,progress+(duty==='defend'?12:27)));/* fixa a última linha e dá profundidade ao time */ty=50+(p.slot%2?8:-8)+(ball.y-50)*.08;}
    if(transition&&t.instruction==='counter'&&['ST','RW','LW','AM'].includes(p.role))tx+=7;
    // Atacantes buscam profundidade no ombro do penúltimo defensor, sem se adiantar à linha.
    if(['ST',...WIDE,'AM'].includes(p.role)&&p.id!==squad.playing[s.carrier]?.id)tx=Math.min(tx,Math.max(progress+1,last+(p.role==='ST'?.6:p.duty==='attack'?.4:.1)));
   }else{
    tx=defendLine+depth*defendLength+(duty==='attack'?4:duty==='defend'?-3:0);ty=clamp((50+(p.baseY-50)*widthOut)*.74+ball.y*.26,8,92);
    if(p.role==='CB')tx=defendLine;
    if(p.role==='DM')tx=clamp(Math.min(tx,progress-2),defendLine+3,defendLine+13);
    const mk=marks.get(p.id);if(mk){const w=clamp(.4+t.pressing*.003,.4,.65);tx=clamp(tx*(1-w)+(localX(s,side,mk.x)-2.4)*w,tx-14,tx+12);ty=clamp(ty*(1-w)+(mk.y+(ball.y-mk.y)*.08)*w,5,95);}
    if(pressers.includes(p.id)&&fieldDistance(p,ball)<(18+t.pressing*.18)){tx=progress;ty=ball.y;visual='press';}
    else if(transition&&localX(s,side,p.x)>progress+6)visual='run'; // recomposição: quem ficou à frente da bola volta correndo
   }
   if(p.role==='GK'){tx=clamp(4+progress*.075,4,13);ty=clamp(50+(ball.y-50)*.28,40,60);visual='idle';if(!own&&progress<18&&!s.action&&fieldDistance(p,ball)<14){tx=progress;ty=ball.y;visual='sweep';}}
   let target={x:worldX(s,side,clamp(tx,3,96)),y:clamp(ty,4,96)};
   if(s.action?.targetId===p.id){target={...s.action.to};visual='run';}
   if(own&&p.id===squad.playing[s.carrier]?.id&&!s.action){target={x:worldX(s,side,Math.min(95,progress+5)),y:clamp(p.y+(50-p.y)*.03,3,97)};visual='carry';}
   if(s.action?.actorId===p.id&&['carry','dribble'].includes(s.action.kind)){target={...s.action.to};visual=s.action.kind;}
   if(s.oneTwo?.playerId===p.id&&s.time<s.oneTwo.until){target.x=worldX(s,side,Math.min(94,localX(s,side,p.x)+8));visual='run';}
   if(s.action?.kind==='cross'&&own&&['ST','AM','CM',...WIDE].includes(p.role)&&s.action.targetId!==p.id&&s.action.actorId!==p.id){const high=s.action.from.y>50,spot={ST:[89,high?56:44],AM:[82,50],CM:[78,p.baseY>50?58:42]}[p.role]||[92,high?43:57];/* centroavante no primeiro pau, ponta oposto no segundo */target={x:worldX(s,side,spot[0]),y:spot[1]};}
   if(s.action?.kind==='shot'&&!own&&p.role==='GK'){target={x:worldX(s,side,2.8),y:clamp(s.action.to.y,43,57)};visual='save';}
   if(s.restart){
    if(s.restart.kind==='kickoff'||s.restart.kind==='halftime'){target={x:worldX(s,side,Math.min(p.baseX*.56,48)),y:p.baseY};}
    else if(!own&&s.restart.kind==='freeKick'&&p.role==='CB'){target={x:s.ball.x-dir*9,y:clamp(s.ball.y+(p.slot%2?3:-3),5,95)};}
    // Escanteio: zagueiros sobem para a área e os defensores se fecham à frente do gol.
    else if(s.restart.kind==='corner'&&p.role==='CB'&&duty!=='defend')target=own?{x:worldX(s,side,89),y:p.slot%2?45:55}:{x:worldX(s,side,6),y:p.slot%2?46:54};
    if(s.restart.takerId===p.id)target={x:s.ball.x,y:s.ball.y};
   }
   // Local separation avoids stacking; no teleportation to formation slots.
   let dx=(target.x-p.x)*1.05,dy=(target.y-p.y)*.68,length=Math.hypot(dx,dy);
   const speed=(4.1+rating(p,'pace')*.035)*(1-p.fatigue*.004)*(visual==='press'?1.1:1),desired=Math.min(speed,length*2.5);
   let vx=length>.05?dx/length*desired/1.05:0,vy=length>.05?dy/length*desired/.68:0;
   for(const teammate of squad.playing){if(teammate===p||teammate.dismissed)continue;const d=fieldDistance(p,teammate);if(d>.05&&d<1.7){vx+=(p.x-teammate.x)*(1.7-d)*1.1;vy+=(p.y-teammate.y)*(1.7-d)*1.1}}
   if(s.time<p.visualUntil&&['fall','celebrate','complain','tackle'].includes(p.visual)){vx*=.08;vy*=.08;}
   const ease=clamp(dt*(3+rating(p,'acceleration')*.025),0,1);p.vx+=(vx-p.vx)*ease;p.vy+=(vy-p.vy)*ease;
   p.x=clamp(p.x+p.vx*dt,.8,99.2);p.y=clamp(p.y+p.vy*dt,.8,99.2);
   const magnitude=Math.hypot(p.vx,p.vy);if(magnitude>.12)p.angle=Math.atan2(p.vy*.68,p.vx*1.05);
   if(s.time>=p.visualUntil)p.visual=magnitude<.15?'idle':magnitude<1?'decelerate':visual;
   // Desgaste: correr, pressionar, jogar em ritmo alto e sustentar linha alta custam fôlego.
   p.fatigue=clamp(p.fatigue+dt*(.011+magnitude*.002+t.pressing*.00012+Math.max(0,t.tempo-55)*.00005+Math.max(0,t.line-60)*.00004)*(1.25-rating(p,'stamina')*.006),0,100);
  }
 }
}
