// Renderizador 2.5D (Babylon.js) — PROTÓTIPO. Consome a mesma vista que o renderer 2D
// (captureView / blendViews / replayView) e nunca lê nem altera o estado da partida.
// Não tem laço próprio: quem chama decide quando desenhar, como no Canvas 2D.
// Coordenadas: campo da simulação em % (x 0–100 comprimento, y 0–100 largura) → metros, origem no centro.
export const ASSET_BASE=new URL('../assets/3d/',import.meta.url).href;
export const BABYLON_SCRIPTS=['https://cdn.jsdelivr.net/npm/babylonjs@7.54.3/babylon.js','https://cdn.jsdelivr.net/npm/babylonjs-loaders@7.54.3/babylonjs.loaders.min.js'];
export const toWorld=(x,y)=>({x:(x-50)*1.05,z:(y-50)*.68});
import {resolveKits} from './graphics.js';
const hex=c=>/^#[0-9a-f]{6}$/i.test(c||'')?c:'#8dcbb8';
export function webglAvailable(){try{const c=document.createElement('canvas');return !!(c.getContext('webgl2')||c.getContext('webgl'))}catch{return false}}
/** Carrega o Babylon.js sob demanda; as páginas administrativas nunca dependem dele. */
export async function loadBabylon(){
 for(const src of BABYLON_SCRIPTS){if(document.querySelector(`script[src="${src}"]`))continue;await new Promise((resolve,reject)=>{const s=document.createElement('script');s.src=src;s.onload=resolve;s.onerror=()=>reject(Error('Não foi possível carregar o Babylon.js (sem rede?).'));document.head.append(s)})}
 if(!window.BABYLON?.SceneLoader)throw Error('Babylon.js indisponível.');return window.BABYLON;
}
/** Cria o renderizador. `BABYLON` é injetado; `shared` permite reutilizar câmera e opções do renderer 2D. */
export async function createRenderer25D(canvas,teams,BABYLON,{shadows=true,stands=true,playerScale=1.45,shared=null}={}){
 const engine=new BABYLON.Engine(canvas,true,{preserveDrawingBuffer:false,stencil:false,powerPreference:'high-performance'});
 engine.setHardwareScalingLevel(1/Math.min(devicePixelRatio||1,1.5));
 const scene=new BABYLON.Scene(engine);scene.useRightHandedSystem=true;scene.clearColor=new BABYLON.Color4(.03,.07,.09,1);scene.skipPointerMovePicking=true;
 const camera=shared?.camera||{mode:'broadcast',x:50,y:50,zoom:1,requestedZoom:1,autoFocus:false},options=shared?.options||{names:false,selected:null};
 const cam=new BABYLON.FreeCamera('FU_Camera',new BABYLON.Vector3(0,62,98),scene);cam.fov=.62;cam.minZ=1;cam.maxZ=500;
 const hemi=new BABYLON.HemisphericLight('FU_Sky',new BABYLON.Vector3(0,1,0),scene);hemi.intensity=.75;hemi.groundColor=new BABYLON.Color3(.25,.3,.28);
 const sun=new BABYLON.DirectionalLight('FU_Sun',new BABYLON.Vector3(-.35,-1,-.45),scene);sun.intensity=1.1;sun.position=new BABYLON.Vector3(30,60,40);
 const shadow=shadows?new BABYLON.ShadowGenerator(1024,sun):null;if(shadow){shadow.useBlurExponentialShadowMap=true;shadow.blurKernel=16;shadow.darkness=.45}
 const load=async file=>{const result=await BABYLON.SceneLoader.ImportMeshAsync('',ASSET_BASE,file,scene);return {root:result.meshes[0],meshes:result.meshes.filter(m=>m.getTotalVertices()>0)}};
 const copyOf=(asset,position,turn=0)=>{const node=asset.root.instantiateHierarchy(null,{doNotInstantiate:false});node.position=position;node.rotation=new BABYLON.Vector3(0,turn,0);return node};
 const [pitch,goal,ball,stand,flag,player]=await Promise.all(['pitch.glb','goal.glb','ball.glb','stand_module_lod1.glb','corner_flag.glb','player.glb'].map(load));
 for(const m of pitch.meshes){m.receiveShadows=true;m.freezeWorldMatrix()}
 // O gol é modelado com a rede para −X: serve como está na linha de fundo esquerda e girado na direita.
 goal.root.position.x=-52.5;copyOf(goal,new BABYLON.Vector3(52.5,0,0),Math.PI);
 flag.root.position=new BABYLON.Vector3(-52.5,0,-34);for(const [x,z] of [[52.5,-34],[-52.5,34],[52.5,34]])copyOf(flag,new BABYLON.Vector3(x,0,z));
 if(stands){stand.root.rotation=new BABYLON.Vector3(0,-Math.PI/2,0);stand.root.position=new BABYLON.Vector3(-50,0,-41);for(let i=1;i<=10;i++)copyOf(stand,new BABYLON.Vector3(-50+i*10,0,-41),-Math.PI/2)}else stand.root.setEnabled(false);
 for(const m of ball.meshes)shadow?.addShadowCaster(m);
 for(const m of scene.meshes)m.isPickable=false; // só os atletas respondem ao clique
 // Uniformes: quatro conjuntos de materiais (dois times + dois goleiros) derivados dos materiais do modelo.
 const colors=resolveKits(teams).map(k=>hex(k.c1));
 const base=name=>scene.materials.find(m=>m.name===name),tint=(name,key,color)=>{const mat=base(name).clone(`${name}_${key}`);mat.albedoColor=BABYLON.Color3.FromHexString(color).toLinearSpace();return mat};
 const kits=[['Home',colors[0],'#f1f1f1'],['Away',colors[1],'#1d252b'],['GK_Home','#f2ba56','#22282c'],['GK_Away','#b8a2ef','#22282c']].map(([key,shirt,shorts])=>({FU_Player_Shirt:tint('FU_Player_Shirt',key,shirt),FU_Player_Shorts:tint('FU_Player_Shorts',key,shorts),FU_Player_Socks:tint('FU_Player_Socks',key,shirt)}));
 player.root.setEnabled(false);
 const ringMat=new BABYLON.StandardMaterial('FU_Marker_Ring',scene);ringMat.emissiveColor=new BABYLON.Color3(.98,.95,.66);ringMat.disableLighting=true;
 const ring=BABYLON.MeshBuilder.CreateTorus('FU_Carrier_Ring',{diameter:2.1,thickness:.13,tessellation:24},scene);ring.material=ringMat;ring.isPickable=false;
 const picked=ring.clone('FU_Selected_Ring');picked.material=ringMat.clone('FU_Marker_Selected');picked.material.emissiveColor=new BABYLON.Color3(.66,.97,1);picked.setEnabled(false);
 const markers=new Map();
 function dispose(m){m.node.dispose(false,false);for(const plate of [m.label,m.namePlate]){plate.material.diffuseTexture.dispose();plate.material.dispose();plate.dispose()}}
 function marker(p,side){
  const key=p.id,wanted=(p.role==='GK'?2:0)+side;let m=markers.get(key);
  if(m&&m.kit!==wanted){dispose(m);markers.delete(key);m=null}
  if(!m){
   const node=new BABYLON.TransformNode('FU_Athlete_'+key,scene),body=player.root.instantiateHierarchy(null,{doNotInstantiate:true});body.parent=node;body.setEnabled(true);node.scaling.setAll(playerScale);
   for(const mesh of body.getChildMeshes()){const swap=kits[wanted][mesh.material?.name];if(swap)mesh.material=swap;mesh.metadata={id:p.id,side};mesh.isPickable=true;mesh.alwaysSelectAsActiveMesh=true;shadow?.addShadowCaster(mesh)}
   const tex=new BABYLON.DynamicTexture('FU_Number_'+key,{width:64,height:64},scene,false);tex.hasAlpha=true;const ctx=tex.getContext();ctx.clearRect(0,0,64,64);ctx.font='800 44px system-ui';ctx.textAlign='center';ctx.textBaseline='middle';ctx.lineWidth=7;ctx.strokeStyle='#08151c';ctx.strokeText(String(p.number||''),32,34);ctx.fillStyle='#fff';ctx.fillText(String(p.number||''),32,34);tex.update();
   const label=BABYLON.MeshBuilder.CreatePlane('FU_Label_'+key,{size:1.6},scene);label.billboardMode=BABYLON.Mesh.BILLBOARDMODE_ALL;label.isPickable=false;const lm=new BABYLON.StandardMaterial('FU_LabelMat_'+key,scene);lm.diffuseTexture=tex;lm.emissiveTexture=tex;lm.opacityTexture=tex;lm.disableLighting=true;lm.backFaceCulling=false;label.material=lm;
   const nameTex=new BABYLON.DynamicTexture('FU_Name_'+key,{width:512,height:72},scene,false);nameTex.hasAlpha=true;const nameCtx=nameTex.getContext();nameCtx.clearRect(0,0,512,72);nameCtx.fillStyle='rgba(4,16,21,.84)';nameCtx.fillRect(8,8,496,56);nameCtx.font='700 29px system-ui';nameCtx.textAlign='center';nameCtx.textBaseline='middle';nameCtx.fillStyle='#f5fff9';nameCtx.fillText(`#${p.number||'–'}  ${String(p.name||p.id).slice(0,24)}`,256,37,470);nameTex.update();
   const namePlate=BABYLON.MeshBuilder.CreatePlane('FU_NamePlate_'+key,{width:4.2,height:.62},scene);namePlate.billboardMode=BABYLON.Mesh.BILLBOARDMODE_ALL;namePlate.isPickable=false;const nm=new BABYLON.StandardMaterial('FU_NameMat_'+key,scene);nm.diffuseTexture=nameTex;nm.emissiveTexture=nameTex;nm.opacityTexture=nameTex;nm.disableLighting=true;nm.backFaceCulling=false;namePlate.material=nm;namePlate.setEnabled(Boolean(options.names));
   m={node,label,namePlate,kit:wanted,seen:0};markers.set(key,m)}
  return m;
 }
 let frame=0,last=performance.now(),spin=0;
 function draw(view){
  frame++;const now=performance.now(),dt=Math.min(.05,(now-last)/1000);last=now;ring.setEnabled(false);
  for(const [side,squad] of view.players.entries())for(const p of squad){const m=marker(p,side),w=toWorld(p.x,p.y),visible=!p.dismissed;m.seen=frame;m.node.setEnabled(visible);m.label.setEnabled(visible);if(!visible)continue;
   // O modelo olha para +X; o ângulo da simulação está no plano do campo (x → X, y → Z).
   const down=p.visual==='fall';m.node.position.set(w.x,down?.25:0,w.z);m.node.rotation.set(0,-(p.angle||0),down?Math.PI/2.4:0);m.label.position.set(w.x,1.77*playerScale+.9,w.z);m.namePlate.position.set(w.x,2.18*playerScale+1.05,w.z);m.namePlate.setEnabled(Boolean(options.names));
   if(view.carrierId===p.id){ring.position.set(w.x,.06,w.z);ring.setEnabled(true)}if(options.selected===p.id){picked.position.set(w.x,.08,w.z);picked.setEnabled(true)}}
  for(const [key,m] of markers)if(m.seen!==frame){dispose(m);markers.delete(key)} // substituídos
  if(!options.selected)picked.setEnabled(false);
  const b=toWorld(view.ball.x,view.ball.y);spin+=dt*7;ball.root.position.set(b.x,Math.max(0,view.ball.z||0),b.z);ball.root.rotation=new BABYLON.Vector3(spin,0,spin*.6);
  // Câmera: mesmo modelo de enquadramento do 2D (alvo suavizado), só que em perspectiva.
  const danger=view.ball.x<20||view.ball.x>80,track=camera.mode==='ball'||camera.autoFocus&&danger,ease=1-Math.exp(-dt*2.3),zoom=camera.requestedZoom*(track&&camera.mode==='ball'?1.9:1);
  camera.x+=((track?Math.max(30,Math.min(70,view.ball.x)):50)-camera.x)*ease;camera.y+=((track?Math.max(35,Math.min(65,view.ball.y)):50)-camera.y)*ease;camera.zoom+=(zoom-camera.zoom)*ease;
  const t=toWorld(camera.x,camera.y),top=camera.mode==='tactical',distance=(top?12:98)/camera.zoom,height=(top?150:62)/camera.zoom;
  cam.position.set(t.x,height,t.z+distance);cam.setTarget(new BABYLON.Vector3(t.x,0,t.z+(top?0:-4)));
  scene.render();
 }
 const resize=()=>engine.resize();const observer=new ResizeObserver(resize);observer.observe(canvas);
 return {draw,resize,camera,options,
  hit(x,y){const pick=scene.pick(x,y,m=>!!m.metadata?.id);return pick?.hit?pick.pickedMesh.metadata:null},
  stats(){return {fps:Math.round(engine.getFps()),meshes:scene.getActiveMeshes().length,triangles:Math.round(scene.getActiveIndices()/3),materials:scene.materials.length}},
  destroy(){observer.disconnect();scene.dispose();engine.dispose()}};
}
