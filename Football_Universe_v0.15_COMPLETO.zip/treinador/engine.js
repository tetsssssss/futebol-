import {SHAPES,buildSquad,createMatchState,upgradeMatchState,validateMatchState} from './match-state.js';
import {tickMatch,changeTactics,makeSubstitution,reshape,setDuty} from './match-engine.js';
/** Football Universe v0.6: núcleo espacial determinístico compartilhado entre Liga/Copa.
 * Dados de clubes reais; elencos ausentes são POSIÇÕES NEUTRAS, não atletas inventados.
 * Resultados são exclusivamente simulados e independentes do renderizador. */
import {seeded,makeGroups,nextStage,scoreGroup,winner,QUALIFIED,COUNTRY} from '../copa/engine.js';
import {applyMatchDiscipline,validateDiscipline} from './discipline.js';
import {CLUBS,INITIAL_PLAYERS,ATTRIBUTE_KEYS} from '../src/data.js';
import {SERIE_A_2026,SERIE_B_2026,FEEDER_2026,CLUB_DIRECTORY,makeLeague as buildLeague,leagueOf,leagueTable,leagueFixtures,divisionOf,divisionsOf,currentRound,afterResult,knockoutSetup,validateLeagues,seasonFinished,seasonOutcome,advanceSeason as advanceLeagueSeason} from './league.js';
import {createContinental,afterContinental,continentalFixtures,continentalSetup,continentalDone,rollContinental,continentalSummary,validateContinental} from './continental.js';
import {CONMEBOL_CLUBS} from './conmebol.js';
import {summarizeMatch,applyStats,validateStats,blankLine} from './match-summary.js';
import {advanceCup} from './cup.js';
import {createQualifying,qualifyingFixtures,currentMatchday,afterQualifier,validateQualifying} from './qualifiers.js';
import {NATIONS,NATION,fallbackColor} from './nations.js';
import {SQUAD_SIZE} from './national-pool.js';
import {kitOf} from '../src/media.js';
/** Uniforme principal (cores e padrão do uniforme real, quando a mídia local o tem). `color` segue sendo a cor de identidade da equipe; o campo usa `kit`. */
const withKit=team=>({...team,kit:kitOf(team.id,team.color)});
export const makeLeague=buildLeague;
const withSource=(list,source)=>list.map(([id,name,short,color])=>({id,name,short,color,source,rosterComplete:CLUBS.some(c=>c.id===id)}));
export const BRAZIL_2026=withSource(SERIE_A_2026,'CBF Série A 2026');
export const BRAZIL_B_2026=withSource(SERIE_B_2026,'CBF Série B 2026');
export const BRAZIL_FEEDER_2026=withSource(FEEDER_2026,'Rebaixados da Série B 2025');
export const PLAYER_POS=['GK','RB','CB','CB','LB','DM','CM','AM','RW','LW','ST'];
export const PLAYER_ZONES=[[7,50],[22,83],[23,63],[23,37],[22,17],[44,56],[53,38],[68,50],[73,82],[73,18],[87,50]];
export const FORMATIONS=SHAPES;
const cap=(n,a,b)=>Math.max(a,Math.min(b,n));
export const standing=league=>leagueTable(league);
export function placeholderPlayers(code){return [...PLAYER_POS,...['GK','CB','RB','LB','DM','CM','AM','ST','LW','RW','ST','CM']].map((pos,i)=>{const attrs=Object.fromEntries(ATTRIBUTE_KEYS.map(key=>[key,key==='reflexes'||key==='handling'||key==='oneOnOnes'||key==='aerialReach'||key==='command'||key==='kicking'?(pos==='GK'?70:15):key==='finishing'?(pos==='ST'?72:57):65]));return {id:`${code}-slot-${i}`,name:`Posição ${pos} ${i+1}`,position:pos,overall:65,attrs,placeholder:true};});} 
const weighted=['shortPass','finishing','decisions','stamina','pressing','pace'];
function normClubPlayers(c){const owned=INITIAL_PLAYERS.filter(p=>p.clubId===c.id);
 if(owned.length<11)return placeholderPlayers(c.id);
 return owned.map(p=>({id:p.id,name:p.name,position:p.position,overall:p.overall,attrs:p.attrs,number:p.number,photo:p.id==='flamengo-p1'?null:p.photo,placeholder:false}));}
// Cor predominante do uniforme principal de cada seleção: identidade visual, não dado esportivo.
export const NATION_COLORS={MEX:'#0f7a4a',RSA:'#f2c230',KOR:'#d63a45',CZE:'#d7323c',CAN:'#d8323a',BIH:'#2f5fb5',USA:'#f0f0f0',PAR:'#d8363f',HAI:'#2f5fbf',SCO:'#27407f',AUS:'#f2c53a',TUR:'#d92f3a',BRA:'#f1d74d',MAR:'#c23a3f',QAT:'#8a2a48',SUI:'#d8303a',CIV:'#f08a2e',ECU:'#f2d13a',GER:'#f1f1f1',CUW:'#2f69c0',NED:'#f07a23',JPN:'#2a4f9f',SWE:'#f3d03e',TUN:'#e9e9e9',KSA:'#2f8f5b',URU:'#6fb4e8',ESP:'#c9333b',CPV:'#2f5fb0',IRN:'#f0f0f0',NZL:'#ededed',BEL:'#c9303a',EGY:'#cf343c',FRA:'#2c4fa0',SEN:'#eeeeee',IRQ:'#3f9a5c',NOR:'#cf3540',ARG:'#7fbfe9',ALG:'#efefef',AUT:'#d5343c',JOR:'#ececec',GHA:'#f0f0f0',PAN:'#d2333b',ENG:'#f2f2f2',CRO:'#e04a4f',POR:'#c2313a',COD:'#3f86d0',UZB:'#f0f0f0',COL:'#f3d23c'};
const nationColor=code=>NATION_COLORS[code]||'#73a8cf';
export function defaultNational(code){return withKit({id:code,name:COUNTRY[code]||code,short:code,color:nationColor(code),roster:placeholderPlayers(code),rosterComplete:false})}
export function clubTeams(){return BRAZIL_2026.map(c=>withKit({...c,roster:normClubPlayers(c)}))}
/** Todos os clubes do universo de ligas (Série A, Série B e fila de retorno). */
export function universeTeams(){return [...[...BRAZIL_2026,...BRAZIL_B_2026,...BRAZIL_FEEDER_2026].map(c=>withKit({...c,roster:normClubPlayers(c)})),...continentalClubTeams()]}
/** Clubes da Conmebol fora do Brasil: sem elenco cadastrado, jogam com posições neutras. */
export function continentalClubTeams(){return CONMEBOL_CLUBS.map(c=>withKit({id:c.id,name:c.name,short:c.short,color:c.color,source:'Conmebol 2026',rosterComplete:false,roster:placeholderPlayers(c.id)}))}
/** As 211 seleções, com os elencos da base sincronizada quando existir; sem base, posições neutras. */
export function nationalTeams(pool=null){return NATIONS.map(n=>{const e=pool?.nations?.[n.code];return withKit({id:n.code,name:n.name,short:n.code,confederation:n.confederation,color:NATION_COLORS[n.code]||fallbackColor(n.code),roster:(e?.squad||placeholderPlayers(n.code)).map(p=>({...p})),reserve:(e?.reserve||[]).map(p=>({...p})),rosterComplete:!!e&&e.placeholders===0,realPlayers:e?.real||0,power:e?.power||0})})}
/** Aplica a convocação do treinador: 23 nomes escolhidos entre convocados e pré-lista. */
export function withCallups(team,save){const ids=save?.callups?.[team.id];if(!ids)return team;const all=[...team.roster,...(team.reserve||[])],roster=ids.map(id=>all.find(p=>p.id===id)).filter(Boolean);return roster.length===SQUAD_SIZE&&roster.some(p=>p.position==='GK')?{...team,roster,reserve:all.filter(p=>!ids.includes(p.id))}:team}
export function setCallup(save,team,outId,inId){if(save.current)throw Error('A convocação só muda entre partidas.');const current=withCallups(team,save),leaving=current.roster.find(p=>p.id===outId),coming=(current.reserve||[]).find(p=>p.id===inId);if(!leaving||!coming)throw Error('Escolha quem sai da lista e quem entra da pré-lista.');
 const ids=current.roster.map(p=>p.id===outId?inId:p.id),keepers=current.roster.filter(p=>p.position==='GK'&&p.id!==outId).length+(coming.position==='GK'?1:0);if(keepers<2)throw Error('A lista precisa de pelo menos dois goleiros.');(save.callups??={})[team.id]=ids;if(save.coachXI?.[team.id])save.coachXI[team.id]=save.coachXI[team.id].filter(id=>id!==outId);return save}
export function startQualifying(pool=null,team='BRA'){return {mode:'eliminatorias',schema:SAVE_SCHEMA,stats:{season:2030,players:{}},qual:createQualifying(code=>pool?.nations?.[code]?.power||0),team,current:null,archive:[],season:2030,callups:{}}}
export function teamsForWorldCup(imported=[]){if(imported?.nations){const all=new Map(nationalTeams(imported).map(t=>[t.id,t]));return QUALIFIED.map(code=>all.get(code))}const found=new Map(imported.map(t=>[t.code,t]));return QUALIFIED.map(code=>{const x=found.get(code);return x?.roster?.length>=23?withKit({id:code,short:code,name:COUNTRY[code],color:nationColor(code),roster:x.roster.map(p=>({...p})),rosterComplete:true}):defaultNational(code)})}
export function suggestedXI(team){return buildSquad(team).playing.map(p=>p.id)}
export function startMatch(home,away,seed,knockout=false,setup={}){return createMatchState(home,away,seed,knockout,setup)}
export function setTactics(state,side,values){return changeTactics(state,side,values)}
export function substitute(state,side,outId,inId){return makeSubstitution(state,side,outId,inId)}
export function setPlayerDuty(state,side,playerId,duty){return setDuty(state,side,playerId,duty)}
export function changeFormation(state,side,formation){return reshape(state,side,formation)}
export function stepMatch(state){return tickMatch(state)}
export function advanceMatch(state,minutes=1){if(!Number.isInteger(minutes)||minutes<0||minutes>120)throw Error('Minutos inválidos');const until=Math.min(3600,state.tick+minutes*30);while(state.tick<until&&!state.finished)stepMatch(state);return state}
export function finishMatch(state){while(!state.finished)stepMatch(state);return state}
export const SAVE_SCHEMA=3;
const KEY_TYPES=new Set(['goal','card','injury','substitution','penalty','penalties','extratime']);
/** Saves anteriores à v0.8: cria a Série B, compacta o relato arquivado e reconstrói o que os eventos permitem. */
export function upgradeSave(save){
 if(!save||save.schema>=SAVE_SCHEMA)return save;
 const fixtures=save.mode==='brasileirao'?save.league?.rounds?.flat()||[]:[...(save.cup?.matches||[]),...(save.cup?.history||[]).flatMap(h=>h.matches||[])];
 const stats={season:save.season||2026,players:{},partial:fixtures.some(m=>m.played)};
 for(const entry of save.archive||[]){
  const teams=[entry.home,entry.away],cards={yellow:[0,0],red:[0,0]},line=e=>stats.players[e.playerId]??=blankLine(e.playerId,e.player||e.playerId,teams[e.side],null);
  for(const e of entry.events||[]){if(!e.playerId||!teams[e.side])continue;
   if(e.type==='goal'){line(e).g++;if(e.assistId&&stats.players[e.assistId])stats.players[e.assistId].a++}
   if(e.type==='card'){line(e)[e.color==='red'?'rc':'yc']++;cards[e.color==='red'?'red':'yellow'][e.side]++}}
  const fixture=fixtures.find(m=>m.id===entry.id);if(fixture&&!fixture.st)fixture.st={...cards,...(fixture.coachLog?{shots:fixture.coachLog.shots,onTarget:fixture.coachLog.onTarget,passes:fixture.coachLog.passes}:{})};
  entry.events=(entry.events||[]).filter(e=>KEY_TYPES.has(e.type)).map(e=>({minute:e.minute,type:e.type,side:e.side,text:e.text,...(e.color?{color:e.color}:{})}));entry.shots??=[];
 }
 for(const m of fixtures)delete m.coachLog;
 save.stats??=stats;save.season??=2026;
 if(save.mode==='brasileirao'&&Array.isArray(save.league?.rounds)){Object.assign(save.league,{division:'A',ruleset:'br-serie-a',playoff:save.league.playoff??null});save.serieB??=makeLeague(SERIE_B_2026.map(c=>c[0]),save.season,'B');save.pool??=FEEDER_2026.map(c=>c[0]);save.history??=[]}
 save.schema=SAVE_SCHEMA;return save;
}
export function migrateCoachSave(payload){const candidate=upgradeSave(structuredClone(payload));if(candidate.mode==='brasileirao'&&!candidate.continental)candidate.continental=createContinental(candidate.season||2026);if(candidate.current)candidate.current.match=upgradeMatchState(candidate.current.match);validateSave(candidate);return candidate}
export function matchResult(state,original){if(!state.finished)throw Error('Partida ainda em andamento');if(original.home!==state.home||original.away!==state.away)throw Error('Resultado pertence a outro confronto.');const [hg,ag]=state.score,summary=summarizeMatch(state);return {...original,played:true,hg,ag,penalties:state.penalties,scorers:summary.scorers,st:summary.st}}
export function startBrazil(){return {mode:'brasileirao',schema:SAVE_SCHEMA,league:makeLeague(),serieB:makeLeague(SERIE_B_2026.map(c=>c[0]),2026,'B'),pool:FEEDER_2026.map(c=>c[0]),history:[],continental:createContinental(2026),stats:{season:2026,players:{}},team:'flamengo',current:null,archive:[],season:2026}}
function dateAt(day){return new Date(Date.UTC(2026,5,11)+(day*86400000)).toISOString().slice(0,10)}
function addWorldCupDates(cup){const dayStart={'Grupos':0,'32 avos':17,'Oitavas':23,'Quartas':28,'Semifinais':33,'Decisão':37}[cup.stage];cup.matches.forEach((m,i)=>{const span={'Grupos':17,'32 avos':6,'Oitavas':4,'Quartas':3,'Semifinais':2,'Decisão':2}[cup.stage];let offset=Math.floor(i*span/cup.matches.length);if(cup.stage==='Decisão')offset=m.round==='Final'?1:0;m.date=dateAt(dayStart+offset);m.dateSource='Data hipotética do simulador'});return cup}
export function startWorldCup(){return {mode:'copa',schema:SAVE_SCHEMA,stats:{season:2026,players:{}},cup:addWorldCupDates({...makeGroups(QUALIFIED,'coach-world-cup-2026'),bracket:'v2',year:2026}),team:'BRA',current:null,archive:[],season:2026}}
export function nextWorldCupStage(save){save.cup=addWorldCupDates(advanceCup(save.cup));return save}
// Condição física entre jogos: parte do desgaste fica no atleta e some com os dias de descanso até a próxima partida.
const RESIDUAL=.6,DAILY_KEEP=.75,dayOf=date=>Number.isFinite(Date.parse(date))?Date.parse(date)/86400000:null;
export function recordFitness(save,fixture,state){const book=save.fitness??={},day=dayOf(fixture.date);if(day===null)return;for(const squad of state.squads)for(const p of [...squad.playing,...(squad.out||[])])book[p.id]={f:Math.round(Math.min(60,(p.fatigue||0)*RESIDUAL)*10)/10,d:day}}
/** Desgaste que cada atleta do elenco ainda carrega na data informada (0 = descansado). */
export function fitnessFor(save,team,date){const out={},day=dayOf(date),book=save?.fitness;if(!book||day===null)return out;for(const p of team.roster){const e=book[p.id];if(!e)continue;const left=e.f*DAILY_KEEP**Math.max(0,day-e.d);if(left>.5)out[p.id]=Math.round(left*10)/10}return out}
function findLeagueFixture(save,id){for(const division of divisionsOf(save)){const league=leagueOf(save,division),fixture=leagueFixtures(league).find(m=>m.id===id);if(fixture)return {league,fixture}}return null}
/** Parâmetros de partida que dependem do regulamento da competição (mata-mata, agregado, prorrogação). */
export function fixtureSetup(save,fixture){
 if(save.mode==='copa')return {knockout:fixture.round!=='Grupos',options:{}};
 if(save.mode==='eliminatorias')return {knockout:!!fixture.knockout,options:{}};
 const continental=save.continental&&continentalFixtures(save.continental).find(m=>m.id===fixture.id);if(continental)return continentalSetup(save.continental,continental);
 const found=findLeagueFixture(save,fixture.id),options=found?knockoutSetup(found.league,found.fixture):null;return {knockout:!!options,options:options||{}};
}
export function commitResult(save,match,state){
 const result=matchResult(state,match),summary=summarizeMatch(state);
 let continentalTournament=null;
 if(save.mode==='brasileirao'){const cont=save.continental&&continentalFixtures(save.continental).find(m=>m.id===match.id);
  if(cont){if(cont.played)throw Error('Partida duplicada');Object.assign(cont,result);applyMatchDiscipline(save,state);afterContinental(save.continental);continentalTournament=save.continental[cont.comp]}
  else{const found=findLeagueFixture(save,match.id);if(!found||found.fixture.played)throw Error('Partida duplicada');Object.assign(found.fixture,result);applyMatchDiscipline(save,state);afterResult(found.league)}}
 else if(save.mode==='eliminatorias'){const m=qualifyingFixtures(save.qual).find(m=>m.id===match.id);if(!m||m.played)throw Error('Partida duplicada');Object.assign(m,result);applyMatchDiscipline(save,state);afterQualifier(save.qual)}
 else{const m=save.cup.matches.find(m=>m.id===match.id);if(!m||m.played)throw Error('Partida duplicada');Object.assign(m,result);applyMatchDiscipline(save,state);save.cup.number++;if(result.round==='Final')save.cup.champion=winner(m)}
 // Estatísticas continentais ficam no torneio: a artilharia de uma divisão nacional não as mistura.
 applyStats(continentalTournament?{stats:continentalTournament.stats,season:save.season}:save,summary);recordFitness(save,match,state);
 save.archive.push({id:match.id,home:state.home,away:state.away,score:[...state.score],events:summary.events,shots:summary.shots,replay:state.replay?.clips||[]});
 const withReplay=save.archive.filter(x=>x.replay?.length);for(const old of withReplay.slice(0,-5))old.replay=[];save.current=null;return save}
export function currentFixtures(save){if(save.mode==='eliminatorias')return currentMatchday(save.qual)?.matches||[];if(save.mode!=='brasileirao')return save.cup.matches;const league=leagueOf(save,divisionOf(save,save.team)||'A');return currentRound(league)?.matches||[]}
export function validateSave(save){validateDiscipline(save?.discipline);validateStats(save?.stats);if(save?.fitness!==undefined&&(!save.fitness||typeof save.fitness!=='object'||Object.values(save.fitness).some(e=>!Number.isFinite(e?.f)||e.f<0||e.f>60||!Number.isFinite(e.d))))throw Error('Condição física inválida.');if(!save||!['copa','brasileirao','eliminatorias'].includes(save.mode)||!Array.isArray(save.archive)||typeof save.team!=='string')throw Error('Save inválido');let all;const league=save.mode==='brasileirao';
 const codes=new Set(league?[...CLUB_DIRECTORY,...CONMEBOL_CLUBS].map(x=>x.id):QUALIFIED);
 if(save.mode==='eliminatorias'){validateQualifying(save.qual);if(!NATION[save.team])throw Error('Equipe controlada inválida');all=qualifyingFixtures(save.qual);for(const code of Object.keys(NATION))codes.add(code);if(save.callups!==undefined&&(typeof save.callups!=='object'||Object.values(save.callups).some(ids=>!Array.isArray(ids)||ids.length!==SQUAD_SIZE||new Set(ids).size!==SQUAD_SIZE)))throw Error('Convocação inválida.')}
 else if(league){if(!Array.isArray(save.league?.rounds))throw Error('Tabela da liga inválida');all=validateLeagues(save);if(save.continental){validateContinental(save.continental,codes);validateStats(save.continental.lib.stats);validateStats(save.continental.sula.stats);all=[...all,...continentalFixtures(save.continental)]}if(!divisionOf(save,save.team))throw Error('Equipe controlada inválida')}
 else{if(!codes.has(save.team))throw Error('Equipe controlada inválida');if(!Array.isArray(save.cup?.matches)||!save.cup.groups||Object.keys(save.cup.groups).length!==12||!Array.isArray(save.cup.history))throw Error('Copa inválida');all=[...save.cup.matches,...save.cup.history.flatMap(h=>h.matches||[])];if(all.length>104||new Set(all.map(m=>m.id)).size!==all.length)throw Error('Partidas repetidas ou extras na Copa')}
 for(const m of all){if(!codes.has(m.home)||!codes.has(m.away)||m.home===m.away||typeof m.played!=='boolean')throw Error('Confronto inválido');if(m.played&&(!Number.isInteger(m.hg)||!Number.isInteger(m.ag)||m.hg<0||m.ag<0||m.hg>30||m.ag>30))throw Error('Placar inválido')}
 if(save.current){const m=save.current.match;const pending=league||save.mode==='eliminatorias'?all:save.cup.matches;if(!pending.some(f=>f.id===save.current.fixtureId&&!f.played)||!m||!Number.isInteger(m.tick)||m.tick<0||m.tick>3600||!Array.isArray(m.squads)||m.squads.length!==2||m.squads.some(x=>x.playing?.length!==11))throw Error('Partida em andamento inválida');const fixture=pending.find(f=>f.id===save.current.fixtureId);if(m.home!==fixture.home||m.away!==fixture.away)throw Error('Partida difere do calendário');validateMatchState(m)}
 return true} 

/** Virada de temporada do universo de ligas: exige os torneios continentais encerrados e usa a tabela final da Série A
 * para as vagas da edição seguinte (Brasil) e a campanha continental para os demais países. */
export function seasonReady(save){return seasonFinished(save)&&(!save.continental||continentalDone(save.continental))}
export function advanceUniverse(save){
 if(!save.continental)return advanceLeagueSeason(save);
 if(!seasonReady(save))throw Error(seasonFinished(save)?'Libertadores e Sul-Americana ainda têm partidas pendentes.':'A temporada ainda tem partidas pendentes.');
 const brazil=seasonOutcome(save).tableA.map(r=>r.code),previous=save.continental,summary=continentalSummary(previous),result=advanceLeagueSeason(save);
 save.history.at(-1).continental=summary;save.continental=rollContinental(previous,save.season,brazil);
 return {...result,continental:summary};
}
