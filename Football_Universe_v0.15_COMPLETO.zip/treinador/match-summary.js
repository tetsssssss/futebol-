// Resumo persistido de uma partida encerrada. Tudo é derivado do estado e dos eventos oficiais;
// nenhuma estatística é gerada aqui. Substitui o arquivamento do relato completo (≈65 KB por jogo).
export const SHOT_OUTCOMES=['off','saved','blocked','goal'];
const KEY_EVENTS=new Set(['goal','card','injury','substitution','penalty','penalties','extratime']);
const TEAM_STATS=['shots','onTarget','xG','passes','completedPasses','fouls','corners','saves','tackles','interceptions','offsides','yellow','red'];
const round2=n=>Math.round(n*100)/100;
export const blankLine=(id,name,team,pos)=>({id,name,team,pos,gp:0,min:0,g:0,a:0,sh:0,sot:0,xg:0,pa:0,pc:0,tk:0,int:0,sv:0,fc:0,yc:0,rc:0});
export const LINE_KEYS=['gp','min','g','a','sh','sot','xg','pa','pc','tk','int','sv','fc','yc','rc'];
export function summarizeMatch(s){
 if(!s.finished)throw Error('Partida ainda em andamento');
 const teams=[s.home,s.away],end=s.tick,lines={},minutes=(from,to)=>Math.max(1,Math.round((to-from)*2/60));
 s.squads.forEach((squad,side)=>{
  const add=(p,from,to)=>{const l=lines[p.id]=blankLine(p.id,p.name,teams[side],p.position||p.role);l.gp=1;l.min=minutes(from,to)};
  for(const p of squad.playing)add(p,p.inTick||0,p.outTick??end);
  for(const p of squad.out||[])add(p,p.inTick||0,p.outTick);
 });
 // Partidas iniciadas antes da v0.8 não guardam quem saiu: a linha é reconstruída pelos eventos, sem minutos.
 const line=e=>!e.playerId?null:lines[e.playerId]||(teams[e.side]?lines[e.playerId]={...blankLine(e.playerId,e.player||e.playerId,teams[e.side],null),gp:1}:null);
 const shots=[];
 for(const e of s.events){
  const l=line(e);
  if(e.type==='shot'){if(l){l.sh++;l.xg=round2(l.xg+(e.xG||0));if(e.onTarget)l.sot++}if(Number.isFinite(e.x))shots.push([e.minute,e.side,Math.round(e.x),Math.round(e.y),Math.round((e.xG||0)*100),Math.max(0,SHOT_OUTCOMES.indexOf(e.outcome))])}
  else if(e.type==='goal'){if(l)l.g++;if(e.assistId&&lines[e.assistId])lines[e.assistId].a++}
  else if(e.type==='tackle'&&l)l.tk++;
  else if(e.type==='interception'&&l)l.int++;
  else if(e.type==='save'&&l&&e.subtype!=='claim')l.sv++;
  else if(e.type==='foul'&&l)l.fc++;
  else if(e.type==='card'&&l)l[e.color==='red'?'rc':'yc']++;
 }
 for(const [id,[attempted,completed]] of Object.entries(s.tally||{}))if(lines[id]){lines[id].pa=attempted;lines[id].pc=completed}
 const st=Object.fromEntries(TEAM_STATS.map(k=>[k,[...s.stats[k]]]));st.possession=[0,1].map(i=>Math.round(100*s.stats.possession[i]/(s.tick||1)));
 const scorers=side=>s.events.filter(e=>e.type==='goal'&&e.side===side).map(e=>({name:e.player,playerId:e.playerId,minute:e.minute}));
 return {st,lines,shots,scorers:{home:scorers(0),away:scorers(1)},events:s.events.filter(e=>KEY_EVENTS.has(e.type)).map(e=>({minute:e.minute,type:e.type,side:e.side,text:e.text,...(e.color?{color:e.color}:{})}))};
}
export function ensureStats(save){if(!save.stats||typeof save.stats!=='object')save.stats={season:save.season,players:{}};return save.stats}
export function applyStats(save,summary){
 const players=ensureStats(save).players;
 for(const l of Object.values(summary.lines)){const t=players[l.id]??=blankLine(l.id,l.name,l.team,l.pos);t.team=l.team;if(l.pos)t.pos=l.pos;for(const k of LINE_KEYS)t[k]=k==='xg'?round2(t[k]+l[k]):t[k]+l[k]}
 return save.stats;
}
export function validateStats(stats){
 if(stats===undefined)return true;
 if(!stats||typeof stats.players!=='object'||!stats.players)throw Error('Estatísticas inválidas.');
 for(const l of Object.values(stats.players))if(typeof l.id!=='string'||typeof l.team!=='string'||LINE_KEYS.some(k=>!Number.isFinite(l[k])||l[k]<0))throw Error('Linha de estatística inválida.');
 return true;
}
/** Ranking de jogadores por métrica; `teams` (Set) restringe a uma divisão ou clube. */
export function playerRanking(stats,key,{teams=null,limit=10,minGames=1}={}){
 const value=l=>key==='passPct'?(l.pa>=20?l.pc/l.pa*100:-1):l[key];
 return Object.values(stats?.players||{}).filter(l=>(!teams||teams.has(l.team))&&l.gp>=minGames&&value(l)>0).sort((a,b)=>value(b)-value(a)||a.min-b.min||a.name.localeCompare(b.name)).slice(0,limit).map(l=>({...l,value:round2(value(l))}));
}
