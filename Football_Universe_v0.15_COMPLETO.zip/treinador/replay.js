import {lerp,clamp} from './math.js';
import {VISUAL_STATES,SAVE_STYLES} from './match-state.js';
export function captureView(s){return {time:s.time,clock:s.clock,score:[...s.score],possession:s.possession,carrierId:s.squads[s.possession].playing[s.carrier]?.id,ball:{...s.ball},players:s.squads.map(squad=>squad.playing.map(p=>({id:p.id,name:p.name,number:p.number,slot:p.slot,role:p.role,x:p.x,y:p.y,angle:p.angle,visual:p.visual,saveStyle:p.saveStyle,cards:p.cards,cardShow:p.cardUntil>s.time?p.cardShow:null,dismissed:p.dismissed}))),action:s.action?{kind:s.action.kind,subtype:s.action.subtype,from:{...s.action.from},to:{...s.action.to},side:s.action.side}:null};}
export function blendViews(previous,current,alpha){
 const t=clamp(alpha,0,1);return {...current,time:lerp(previous.time,current.time,t),ball:{...current.ball,x:lerp(previous.ball.x,current.ball.x,t),y:lerp(previous.ball.y,current.ball.y,t),z:lerp(previous.ball.z||0,current.ball.z||0,t)},players:current.players.map((squad,side)=>squad.map(p=>{const old=previous.players[side].find(x=>x.id===p.id)||p,angle=Math.atan2(Math.sin(p.angle-old.angle),Math.cos(p.angle-old.angle));return {...p,x:lerp(old.x,p.x,t),y:lerp(old.y,p.y,t),angle:old.angle+angle*t}}))};
}
export function replayView(clip,time,labels={}){
 if(!clip?.frames?.length)throw Error('Replay sem quadros.');const frames=clip.frames,t=clamp(time,frames[0].time,frames.at(-1).time);let i=0;while(i<frames.length-2&&frames[i+1].time<=t)i++;
 const decode=f=>({time:f.time,clock:f.clock,score:f.score,possession:f.possession,ball:{x:f.ball[0],y:f.ball[1],z:f.ball[2]},players:f.players.map((squad,side)=>squad.map((p,slot)=>({id:f.ids[side][slot],name:labels[f.ids[side][slot]]?.name||f.ids[side][slot],role:labels[f.ids[side][slot]]?.role||(slot===0?'GK':'CM'),number:p[5],slot,x:p[0],y:p[1],angle:p[2],visual:VISUAL_STATES[p[3]]||'idle',dismissed:!!p[4],saveStyle:SAVE_STYLES[p[6]||0]}))),action:f.action});
 const a=frames[i],b=frames[i+1]||a;return blendViews(decode(a),decode(b),b.time===a.time?0:(t-a.time)/(b.time-a.time));
}
export const highlightTypes=new Set(['goal','shot','save','foul','corner','card','offside','cross','halftime','end']);
