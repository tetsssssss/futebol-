import {cameraTransform,fillPitch,resolveKits,easedCamera,strokePath} from './graphics.js';
import {drawPlayer} from './animations.js';
import {ACTION_LABELS} from './decisions.js';
export function createRenderer(canvas,teams){
 const ctx=canvas.getContext('2d'),camera={mode:'broadcast',x:50,y:50,zoom:1,requestedZoom:1,autoFocus:false},options={names:false,selected:null},kits=resolveKits(teams),colors=kits.map(k=>k.c1);let width=900,height=600,hits=[],lastView=null,lastReplay=false,last=performance.now();
 if(!ctx){canvas.replaceWith(Object.assign(document.createElement('p'),{textContent:'Canvas indisponível. Placar, relato textual e comandos do treinador continuam funcionando.'}));return {draw(){},resize(){},camera,options,hit(){return null},destroy(){}};}
 function resize(){width=Math.max(280,canvas.getBoundingClientRect().width||900);height=width*68/105+36;const dpr=Math.min(devicePixelRatio||1,2);canvas.width=Math.round(width*dpr);canvas.height=Math.round(height*dpr);canvas.style.height=height+'px';ctx.setTransform(dpr,0,0,dpr,0,0);if(lastView)draw(lastView,lastReplay);}
 const observer=new ResizeObserver(resize);observer.observe(canvas);resize();
 function draw(view,replaying=false){lastView=view;lastReplay=replaying;
  const now=performance.now(),dt=Math.min(.05,(now-last)/1000);last=now;easedCamera(camera,view,dt);const project=cameraTransform(width,height,camera);fillPitch(ctx,project,width,height);hits=[];
  // Leitura tática: na câmera tática, a última linha de cada equipe (penúltimo jogador a partir do próprio gol).
  if(camera.mode==='tactical')view.players.forEach((squad,side)=>{const keeper=squad.find(p=>p.role==='GK'&&!p.dismissed);if(!keeper)return;const deep=squad.filter(p=>!p.dismissed).sort((a,b)=>Math.abs(a.x-keeper.x)-Math.abs(b.x-keeper.x))[1];if(!deep)return;ctx.save();ctx.setLineDash([7,6]);ctx.strokeStyle=colors[side]+'cc';ctx.lineWidth=1.6;strokePath(ctx,project,[[deep.x,2],[deep.x,98]]);ctx.restore();const label=project(deep.x,3);ctx.font='700 9px system-ui';ctx.textAlign='center';ctx.fillStyle='#e7fff6';ctx.fillText(side?'LINHA VISITANTE':'LINHA MANDANTE',label.x,label.y-3)});
  if(view.action&&['pass','shot','cross','distribution','loose'].includes(view.action.kind)){
   ctx.save();ctx.setLineDash([4,5]);ctx.strokeStyle=view.action.kind==='shot'?'#ffbd7790':'#e2ffcc70';ctx.lineWidth=1.4;strokePath(ctx,project,[[view.action.from.x,view.action.from.y],[view.action.to.x,view.action.to.y]]);ctx.restore();
   const from=project(view.action.from.x,view.action.from.y),ball=project(view.ball.x,view.ball.y,view.ball.z);ctx.beginPath();ctx.moveTo(from.x,from.y);ctx.lineTo(ball.x,ball.y);ctx.strokeStyle='#ffffff20';ctx.lineWidth=3;ctx.stroke();const target=project(view.action.to.x,view.action.to.y);ctx.strokeStyle='#d4f3bc80';ctx.beginPath();ctx.arc(target.x,target.y,5,0,7);ctx.stroke();
  }
  const players=view.players.flatMap((squad,side)=>squad.map(p=>({...p,side}))).filter(p=>!p.dismissed||p.cardShow).sort((a,b)=>a.y-b.y);
  for(const p of players){const point=project(p.x,p.y);if(point.x< -30||point.x>width+30||point.y< -30||point.y>height+30)continue;drawPlayer(ctx,point,p,{color:p.role==='GK'?(p.side===0?'#f2ba56':'#b8a2ef'):colors[p.side],accent:p.role==='GK'?null:kits[p.side].c2,pattern:p.role==='GK'?'solid':kits[p.side].pattern,time:view.time,carrier:view.carrierId===p.id,selected:options.selected===p.id,names:options.names});hits.push({x:point.x,y:point.y,id:p.id,side:p.side})}
  const ground=project(view.ball.x,view.ball.y),ball=project(view.ball.x,view.ball.y,view.ball.z);ctx.fillStyle='#00181480';ctx.beginPath();ctx.ellipse(ground.x+1,ground.y+3,5+(view.ball.z||0),2.5,0,0,7);ctx.fill();ctx.fillStyle='#fff';ctx.strokeStyle='#0c1720';ctx.lineWidth=1.3;ctx.beginPath();ctx.arc(ball.x,ball.y,Math.max(3.3,Math.min(5.5,ball.scale*.4)),0,7);ctx.fill();ctx.stroke();ctx.fillStyle='#16252a';ctx.fillRect(ball.x-1,ball.y-1,2,2);
  ctx.fillStyle='#071b22d9';ctx.fillRect(10,10,Math.min(width-20,315),28);ctx.font='600 11px system-ui';ctx.textAlign='left';ctx.fillStyle='#d8fff0';ctx.fillText(`${replaying?'REPLAY · ':''}${view.action?ACTION_LABELS[view.action.subtype]||view.action.kind:'Organização e movimentação sem bola'}`,20,28);
  ctx.font='600 10px system-ui';ctx.fillStyle='#d8fff0';ctx.textAlign='right';ctx.fillText(camera.mode==='broadcast'?'TRANSMISSÃO':camera.mode==='ball'?'ACOMPANHANDO A BOLA':'CÂMERA TÁTICA',width-12,height-9);
 }
 return {draw,resize,camera,options,hit(x,y){return hits.find(p=>Math.hypot(p.x-x,p.y-y)<18)},destroy(){observer.disconnect()}};
}

