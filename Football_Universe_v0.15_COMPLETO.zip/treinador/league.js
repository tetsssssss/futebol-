// Universo de ligas nacionais: divisões, calendário, playoff, virada de temporada e histórico.
// Não depende do motor de partida; opera sobre resultados já confirmados no calendário.
import {rulesFor,rankTable} from './rules.js';
import {playerRanking} from './match-summary.js';
export const SERIE_A_2026=[
 ['athletico-pr','Athletico Paranaense','CAP','#d82836'],['atletico-mg','Atlético Mineiro','CAM','#dfdfdf'],['bahia','Bahia','BAH','#2675bf'],['botafogo','Botafogo','BOT','#e8e8e8'],['chapecoense','Chapecoense','CHA','#4aa66d'],['corinthians','Corinthians','COR','#e8e8e8'],['coritiba','Coritiba','CFC','#3aa368'],['cruzeiro','Cruzeiro','CRU','#2160bc'],['flamengo','Flamengo','FLA','#d62e43'],['fluminense','Fluminense','FLU','#9a3047'],['gremio','Grêmio','GRE','#4a9acc'],['internacional','Internacional','INT','#d52d42'],['mirassol','Mirassol','MIR','#e1c146'],['palmeiras','Palmeiras','PAL','#26935b'],['bragantino','Red Bull Bragantino','RBB','#e3e3e3'],['remo','Remo','REM','#4b7bae'],['santos','Santos','SAN','#ededed'],['sao-paulo','São Paulo','SAO','#d94d57'],['vasco','Vasco da Gama','VAS','#efefef'],['vitoria','Vitória','VIT','#e3424b']
];
// Participantes da Série B 2026 conforme divulgado; elencos ainda não cadastrados (posições neutras).
export const SERIE_B_2026=[
 ['america-mg','América Mineiro','AME','#2f9e5b'],['athletic','Athletic Club','ATH','#e6e6e6'],['atletico-go','Atlético Goianiense','ACG','#d6323b'],['avai','Avaí','AVA','#2c7fc4'],['botafogo-sp','Botafogo-SP','BSP','#d94a4a'],['ceara','Ceará','CEA','#e9e9e9'],['crb','CRB','CRB','#d93842'],['criciuma','Criciúma','CRI','#f0c93a'],['cuiaba','Cuiabá','CUI','#3f9a55'],['fortaleza','Fortaleza','FOR','#2a5fb8'],['goias','Goiás','GOI','#2e9a5a'],['juventude','Juventude','JUV','#3aa35f'],['londrina','Londrina','LON','#4a8fd0'],['nautico','Náutico','NAU','#d83a45'],['novorizontino','Novorizontino','NOV','#f2c230'],['operario-pr','Operário-PR','OPE','#dcdcdc'],['ponte-preta','Ponte Preta','PON','#e4e4e4'],['sao-bernardo','São Bernardo','SBE','#f0c53c'],['sport','Sport Recife','SPT','#d8323c'],['vila-nova','Vila Nova','VIL','#d83640']
];
// A Série C não é simulada. Quem cai da Série B entra no fim desta fila e os primeiros dela voltam:
// uma simplificação declarada, iniciada pelos quatro rebaixados reais da Série B 2025.
export const FEEDER_2026=[['ferroviaria','Ferroviária','FER','#9a2f45'],['amazonas','Amazonas','AMA','#e8c33a'],['volta-redonda','Volta Redonda','VRE','#f1c93f'],['paysandu','Paysandu','PAY','#5aa9de']];
export const DIVISIONS={A:{ruleset:'br-serie-a',prefix:'L',key:'league'},B:{ruleset:'br-serie-b',prefix:'B',key:'serieB'}};
export const CLUB_DIRECTORY=[...SERIE_A_2026,...SERIE_B_2026,...FEEDER_2026].map(([id,name,short,color])=>({id,name,short,color}));
const FIRST_ROUND_2026=[['atletico-mg','palmeiras'],['internacional','athletico-pr'],['coritiba','bragantino'],['vitoria','remo'],['fluminense','gremio'],['corinthians','bahia'],['chapecoense','santos'],['sao-paulo','flamengo'],['mirassol','vasco'],['botafogo','cruzeiro']];
function roundDate(season,round,half){const first=round<=half,start=first?Date.UTC(season,0,28):Date.UTC(season,6,29);return new Date(start+((first?round-1:round-half-1)*7)*86400000).toISOString().slice(0,10)}
export function makeLeague(ids=SERIE_A_2026.map(c=>c[0]),season=2026,division='A'){
 if(ids.length<4||ids.length%2||new Set(ids).size!==ids.length)throw Error('Liga requer número par de clubes distintos (mínimo 4).');
 const {prefix,ruleset}=DIVISIONS[division]||DIVISIONS.A,n=ids.length,half=n-1;let order=[...ids],rounds=[];
 // A primeira rodada da Série A 2026 usa os confrontos divulgados pela CBF. As demais são GERADAS.
 const official=division==='A'&&season===2026&&n===20&&FIRST_ROUND_2026.every(([h,a])=>ids.includes(h)&&ids.includes(a));
 if(official){order=Array(20);for(let k=0;k<10;k++){const [home,away]=FIRST_ROUND_2026[k];order[k]=k%2?home:away;order[19-k]=k%2?away:home;}}
 for(let r=0;r<half;r++){
  const matches=[];
  // Mandos: o clube fixo alterna a cada rodada; os demais alternam ao girar de posição (evita longas sequências em casa ou fora).
  for(let k=0;k<n/2;k++){const a=order[k],b=order[n-1-k],first=k?k%2===1:r%2===1;matches.push({id:`${prefix}-${season}-${r+1}-${k+1}`,home:first?a:b,away:first?b:a,round:r+1,date:official&&r===0&&k>=8?'2026-01-29':roundDate(season,r+1,half),dateSource:official&&r===0?'CBF - primeira rodada':'gerada pelo simulador',played:false});}
  rounds.push(matches);order=[order[0],order[n-1],...order.slice(1,n-1)];
 }
 for(let r=0;r<half;r++)rounds.push(rounds[r].map((m,i)=>({id:`${prefix}-${season}-${n+r}-${i+1}`,home:m.away,away:m.home,round:n+r,date:roundDate(season,n+r,half),dateSource:'gerada pelo simulador',played:false})));
 return {kind:'league',division,ruleset,year:season,round:1,rounds,completed:false,champion:null,playoff:null};
}
export const leagueOf=(save,division)=>save[DIVISIONS[division]?.key||'league'];
export const leagueTeams=league=>[...new Set(league.rounds[0].flatMap(m=>[m.home,m.away]))];
export const leagueRules=league=>rulesFor(league.ruleset||'br-serie-a',league.year||2026);
export const leagueTable=league=>rankTable(league.rounds.flat(),leagueTeams(league),leagueRules(league),league.year);
export const leagueFixtures=league=>[...league.rounds.flat(),...(league.playoff?.legs.flat()||[])];
export const divisionOf=(save,team)=>save.serieB&&leagueTeams(save.serieB).includes(team)?'B':leagueTeams(save.league).includes(team)?'A':null;
export const divisionsOf=save=>save.serieB?['A','B']:['A'];
/** Rodada em aberto de uma divisão. As pernas do playoff contam como rodadas extras após o returno. */
export function currentRound(league){
 const index=league.rounds.findIndex(r=>r.some(m=>!m.played));
 if(index>=0)return {number:index+1,label:`Rodada ${index+1}`,matches:league.rounds[index]};
 const leg=league.playoff?.legs.findIndex(l=>l.some(m=>!m.played))??-1;
 return leg>=0?{number:league.rounds.length+leg+1,label:`Playoff de acesso · ${leg?'volta':'ida'}`,matches:league.playoff.legs[leg]}:null;
}
export const leagueDone=league=>!currentRound(league)&&league.completed;
/** Confrontos do próximo dia de jogos do universo: a rodada mais atrasada entre as divisões. */
export function matchdayFixtures(save){
 const open=divisionsOf(save).map(d=>currentRound(leagueOf(save,d))).filter(Boolean);if(!open.length)return [];
 const number=Math.min(...open.map(r=>r.number));return open.filter(r=>r.number===number).flatMap(r=>r.matches);
}
function playoffTie(first,second,tied){
 // A volta inverte o mando: o mandante da volta foi o visitante da ida.
 // Agregado empatado: pênaltis quando a partida os disputou; senão vale a melhor campanha, que é sempre o mandante da volta.
 const home=second.hg+first.ag,away=second.ag+first.hg,pens=second.penalties;
 const winner=home>away?second.home:away>home?second.away:pens?(pens[0]>pens[1]?second.home:second.away):tied==='higherSeed'?second.home:null;
 return {home:second.home,away:second.away,aggregate:[home,away],penalties:pens||null,winner};
}
/** Atualiza rodada, campeão e playoff depois de um resultado confirmado. */
export function afterResult(league){
 const index=league.rounds.findIndex(r=>r.some(m=>!m.played)),rules=leagueRules(league);
 league.round=index<0?league.rounds.length:index+1;
 if(index<0&&!league.completed){
  const table=leagueTable(league),playoff=rules.promotion?.playoff;league.completed=true;league.champion=table[0].code;
  if(playoff){
   const last=league.rounds.at(-1)[0].date,date=days=>new Date(Date.parse(last)+days*86400000).toISOString().slice(0,10),prefix=DIVISIONS[league.division]?.prefix||'L',number=league.rounds.length;
   const pairs=playoff.pairs.map(([hi,lo])=>[table[hi-1].code,table[lo-1].code]);
   league.playoff={pairs,winners:null,legs:[
    pairs.map(([hi,lo],i)=>({id:`${prefix}-${league.year}-PO1-${i+1}`,home:lo,away:hi,round:number+1,stage:'playoff',leg:1,date:date(7),dateSource:'gerada pelo simulador',played:false})),
    pairs.map(([hi,lo],i)=>({id:`${prefix}-${league.year}-PO2-${i+1}`,home:hi,away:lo,round:number+2,stage:'playoff',leg:2,firstLeg:`${prefix}-${league.year}-PO1-${i+1}`,date:date(14),dateSource:'gerada pelo simulador',played:false}))]};
  }
 }
 if(league.playoff&&!league.playoff.winners&&league.playoff.legs.flat().every(m=>m.played)){
  const ties=league.playoff.legs[1].map((second,i)=>playoffTie(league.playoff.legs[0][i],second,rules.promotion?.playoff?.tied));
  if(ties.some(t=>!t.winner))throw Error('Playoff sem vencedor definido.');
  league.playoff.ties=ties;league.playoff.winners=ties.map(t=>t.winner);
 }
 return league;
}
/** Configuração de mata-mata para uma perna de playoff (agregado e ausência de prorrogação vêm do regulamento). */
export function knockoutSetup(league,fixture){
 if(fixture.stage!=='playoff'||fixture.leg!==2)return null;
 const first=league.playoff.legs[0].find(m=>m.id===fixture.firstLeg),rules=leagueRules(league).promotion.playoff;
 if(!first?.played)throw Error('A partida de ida ainda não foi disputada.');
 if(rules.tied!=='penalties')return null; // sem pênaltis: a volta é um jogo comum e o empate no agregado se resolve na tabela
 return {aggregate:[first.ag,first.hg],noExtraTime:!rules.extraTime};
}
/** Posição de um clube ao fim de cada rodada já concluída (para o gráfico de evolução). */
export function positionHistory(league,code){
 const rules=leagueRules(league),ids=leagueTeams(league),all=league.rounds.flat(),out=[];
 for(let r=0;r<league.rounds.length&&league.rounds[r].every(m=>m.played);r++)out.push(rankTable(all.filter(m=>m.round<=r+1),ids,rules,league.year).find(x=>x.code===code)?.position||null);
 return out;
}
export const seasonFinished=save=>divisionsOf(save).every(d=>leagueDone(leagueOf(save,d)));
/** Promoções e rebaixamentos decorrentes das tabelas finais, sem alterar o save. */
export function seasonOutcome(save){
 if(!seasonFinished(save))throw Error('A temporada ainda tem partidas pendentes.');
 const A=save.league,B=save.serieB,tableA=leagueTable(A),tableB=leagueTable(B),rulesA=leagueRules(A),rulesB=leagueRules(B);
 const relegatedA=tableA.slice(-rulesA.relegation.count).map(r=>r.code),direct=tableB.slice(0,rulesB.promotion.direct).map(r=>r.code),promoted=[...direct,...(B.playoff?.winners||[])];
 if(promoted.length!==relegatedA.length||new Set(promoted).size!==promoted.length)throw Error('Regulamentos das divisões são incompatíveis: acessos e rebaixamentos diferem.');
 // Só caem da Série B tantos clubes quantos a fila de retorno consegue repor.
 const drop=Math.min(rulesB.relegation.count,(save.pool||[]).length),relegatedB=drop?tableB.slice(-drop).map(r=>r.code):[],incoming=(save.pool||[]).slice(0,drop);
 return {season:save.season,tableA,tableB,championA:tableA[0].code,championB:tableB[0].code,relegatedA,promoted,direct,relegatedB,incoming};
}
const compactTable=table=>table.map(r=>[r.code,r.pts,r.w,r.d,r.l,r.gf,r.ga]);
const stamp=league=>{const r=leagueRules(league);return {id:r.id,season:r.season,revision:r.revision}};
/** Encerra a temporada: valida tabelas, aplica acessos e rebaixamentos, arquiva o histórico e gera o calendário seguinte. */
export function advanceSeason(save){
 if(save.mode!=='brasileirao'||!save.serieB)throw Error('Virada de temporada disponível apenas no universo de ligas.');
 if(save.current)throw Error('Encerre primeiro a partida ativa.');
 const o=seasonOutcome(save),A=save.league,B=save.serieB,teamsA=new Set(leagueTeams(A)),teamsB=new Set(leagueTeams(B));
 (save.history??=[]).push({season:save.season,
  A:{rules:stamp(A),champion:o.championA,table:compactTable(o.tableA),relegated:o.relegatedA},
  B:{rules:stamp(B),champion:o.championB,table:compactTable(o.tableB),promoted:o.promoted,relegated:o.relegatedB,incoming:o.incoming,playoff:B.playoff?.ties||null},
  scorers:{A:playerRanking(save.stats,'g',{teams:teamsA}).map(l=>[l.name,l.team,l.g]),B:playerRanking(save.stats,'g',{teams:teamsB}).map(l=>[l.name,l.team,l.g])},
  assists:{A:playerRanking(save.stats,'a',{teams:teamsA}).map(l=>[l.name,l.team,l.a]),B:playerRanking(save.stats,'a',{teams:teamsB}).map(l=>[l.name,l.team,l.a])}});
 const nextA=[...o.tableA.map(r=>r.code).filter(c=>!o.relegatedA.includes(c)),...o.promoted];
 const nextB=[...o.relegatedA,...o.tableB.map(r=>r.code).filter(c=>!o.promoted.includes(c)&&!o.relegatedB.includes(c)),...o.incoming];
 save.pool=[...(save.pool||[]).slice(o.incoming.length),...o.relegatedB];
 save.season++;save.league=makeLeague(nextA,save.season,'A');save.serieB=makeLeague(nextB,save.season,'B');
 save.archive=[];save.stats={season:save.season,players:{}};if(save.discipline)save.discipline.yellows={};
 const moved=!nextA.includes(save.team)&&!nextB.includes(save.team);if(moved)save.team=nextB[0];
 return {...o,nextSeason:save.season,teamReassigned:moved};
}
export function validateLeagues(save){
 const known=new Set(CLUB_DIRECTORY.map(c=>c.id)),seen=new Set(),all=[];
 for(const division of divisionsOf(save)){
  const league=leagueOf(save,division);if(!league||!Array.isArray(league.rounds)||!league.rounds.length)throw Error('Tabela da liga inválida');
  const rules=leagueRules(league),ids=leagueTeams(league),n=ids.length;
  if(n!==rules.teams||league.rounds.length!==2*(n-1)||league.rounds.some(r=>!Array.isArray(r)||r.length!==n/2||new Set(r.flatMap(m=>[m.home,m.away])).size!==n))throw Error('Tabela da liga inválida');
  for(const id of ids){if(!known.has(id)||seen.has(id))throw Error('Clube repetido ou desconhecido nas divisões');seen.add(id)}
  const fixtures=leagueFixtures(league);if(fixtures.some(m=>!ids.includes(m.home)||!ids.includes(m.away)))throw Error('Confronto fora da divisão');
  if(league.playoff&&(!Array.isArray(league.playoff.legs)||league.playoff.legs.length!==2||!league.completed))throw Error('Playoff inválido');
  all.push(...fixtures);
 }
 if(new Set(all.map(m=>m.id)).size!==all.length)throw Error('Tabela da liga inválida');
 if(save.pool!==undefined&&(!Array.isArray(save.pool)||save.pool.some(id=>!known.has(id)||seen.has(id))||new Set(save.pool).size!==save.pool.length))throw Error('Fila de acesso inválida');
 if(save.history!==undefined&&(!Array.isArray(save.history)||save.history.length>200||save.history.some(h=>!Number.isInteger(h.season)||!h.A?.table||!h.B?.table)))throw Error('Histórico de temporadas inválido');
 return all;
}
