// Copa do Mundo no Modo Treinador: classificação de grupos pelo regulamento configurado, ranking de terceiros,
// chaveamento em árvore, prêmios e campanhas. Opera sobre resultados confirmados; não simula partidas.
import {rulesFor,rankTable} from './rules.js';
import {winner,nextStage as legacyNextStage} from '../copa/engine.js';
export const CUP_STAGES=['Grupos','32 avos','Oitavas','Quartas','Semifinais','Decisão'];
export const cupRules=cup=>rulesFor('fifa-world-cup',cup.year||2026);
const hash=text=>{let h=2166136261;for(const c of String(text))h=Math.imul(h^c.charCodeAt(0),16777619)>>>0;return h};
export const allCupMatches=cup=>[...cup.history.flatMap(h=>h.matches||[]),...cup.matches];
export const groupMatches=cup=>cup.stage==='Grupos'?cup.matches:cup.history.find(h=>h.stage==='Grupos')?.matches||[];
export const groupOf=(cup,code)=>Object.keys(cup.groups).find(g=>cup.groups[g].includes(code))||null;
export function groupTable(cup,group){const rules=cupRules(cup);return rankTable(groupMatches(cup).filter(m=>m.group===group),cup.groups[group],{...rules,headToHead:rules.groups.headToHead},`${cup.seed}|${group}`)}
/** Terceiros colocados ordenados pelos critérios do regulamento; os primeiros `bestThirds` avançam. */
export function thirdsTable(cup){
 const rules=cupRules(cup),keys={goalDifference:r=>r.gd,goalsFor:r=>r.gf,fairPlay:r=>-(r.yc+3*r.rc),draw:r=>hash(`${cup.seed}|3|${r.code}`)};
 const rows=Object.keys(cup.groups).map(g=>({...groupTable(cup,g)[2],group:g}));
 rows.sort((a,b)=>{if(a.pts!==b.pts)return b.pts-a.pts;for(const k of rules.groups.thirdsTiebreakers){const d=keys[k](b)-keys[k](a);if(d)return d}return a.code.localeCompare(b.code)});
 return rows.map((r,i)=>({...r,position:i+1,qualified:i<rules.groups.bestThirds}));
}
const strength=(a,b)=>b.pts-a.pts||b.gd-a.gd||b.gf-a.gf||a.group.localeCompare(b.group);
// Emparelha duas listas na ordem dada sem repetir grupo; volta atrás quando a escolha gulosa trava.
function pairOff(left,right){
 const used=new Set(),out=[];
 const solve=i=>{if(i===left.length)return true;for(let j=right.length-1;j>=0;j--){if(used.has(j)||right[j].group===left[i].group)continue;used.add(j);out[i]=right[j];if(solve(i+1))return true;used.delete(j)}return false};
 if(!solve(0))throw Error('Não foi possível montar a chave sem repetir grupo.');return out;
}
const SLOT_ORDER=[1,16,8,9,5,12,4,13,6,11,3,14,7,10,2,15]; // distribuição padrão de 16 cabeças numa árvore
/** 32 avos: os 8 melhores primeiros enfrentam terceiros, os outros 4 enfrentam segundos e os 8 segundos restantes se enfrentam.
 * Chaveamento do simulador — não reproduz a tabela oficial de alocação da FIFA. */
export function roundOf32(cup){
 const tables=Object.keys(cup.groups).map(g=>groupTable(cup,g).map(r=>({...r,group:g})));
 const firsts=tables.map(t=>t[0]).sort(strength),seconds=tables.map(t=>t[1]).sort(strength),thirds=thirdsTable(cup).filter(r=>r.qualified);
 const top=firsts.slice(0,8),rest=firsts.slice(8),vsThird=pairOff(top,thirds),lowSeconds=seconds.slice(8),vsSecond=pairOff(rest,lowSeconds),mid=seconds.slice(0,8),vsMid=pairOff(mid.slice(0,4),mid.slice(4));
 const ties=[...top.map((t,i)=>[t,vsThird[i]]),...rest.map((t,i)=>[t,vsSecond[i]]),...mid.slice(0,4).map((t,i)=>[t,vsMid[i]])];
 return SLOT_ORDER.map((seed,slot)=>{const [home,away]=ties[seed-1];return {id:`R32-${slot+1}`,round:'32 avos',home:home.code,away:away.code,played:false}});
}
const NEXT={'32 avos':'Oitavas','Oitavas':'Quartas','Quartas':'Semifinais','Semifinais':'Decisão'};
/** Avança a Copa de fase. Copas criadas antes da v0.10 mantêm o chaveamento com que começaram. */
export function advanceCup(cup){
 if(cup.bracket!=='v2')return legacyNextStage(cup);
 const c=structuredClone(cup);if(c.matches.some(m=>!m.played))throw Error('Finalize os jogos da fase antes de avançar.');if(c.stage==='Decisão')throw Error('Copa já concluída.');
 const previous=c.matches;c.history.push({stage:c.stage,matches:structuredClone(previous)});
 if(c.stage==='Grupos'){c.matches=roundOf32(c);c.stage='32 avos';return c}
 const winners=previous.map(winner),next=NEXT[c.stage];if(!next||winners.some(w=>!w)||new Set(winners).size!==winners.length)throw Error('Chave eliminatória inválida.');
 if(c.stage==='Semifinais'){const losers=previous.map(m=>m.home===winner(m)?m.away:m.home);c.matches=[{id:'FINAL',round:'Final',home:winners[0],away:winners[1],played:false},{id:'THIRD',round:'Terceiro lugar',home:losers[0],away:losers[1],played:false}]}
 else c.matches=Array.from({length:winners.length/2},(_,i)=>({id:`${next}-${i+1}`,round:next,home:winners[2*i],away:winners[2*i+1],played:false}));
 c.stage=next;return c;
}
/** Árvore para desenhar: uma coluna por fase, com vagas ainda indefinidas descritas pelo confronto de origem. */
export function bracketColumns(cup){
 const played=allCupMatches(cup),byRound=round=>played.filter(m=>m.round===round),sizes=[['32 avos',16],['Oitavas',8],['Quartas',4],['Semifinais',2],['Final',1]],tree=cup.bracket==='v2';
 const columns=sizes.map(([round,count],index)=>{const real=byRound(round);return {round,matches:Array.from({length:count},(_,i)=>real[i]?{...real[i],winner:real[i].played?winner(real[i]):null}:{id:`${round}-pendente-${i+1}`,round,pending:true,
  homeLabel:index&&tree?`Vencedor ${sizes[index-1][0]} ${2*i+1}`:'A definir',awayLabel:index&&tree?`Vencedor ${sizes[index-1][0]} ${2*i+2}`:'A definir'})}});
 const third=byRound('Terceiro lugar')[0];return {columns,third:third?{...third,winner:third.played?winner(third):null}:null,tree};
}
/** Caminho de uma seleção no torneio, na ordem em que os jogos aconteceram. */
export function campaign(cup,code){
 return allCupMatches(cup).filter(m=>m.played&&(m.home===code||m.away===code)).map(m=>{const home=m.home===code,gf=home?m.hg:m.ag,ga=home?m.ag:m.hg,w=m.round==='Grupos'?null:winner(m);
  return {id:m.id,round:m.round,group:m.group||null,opponent:home?m.away:m.home,gf,ga,penalties:m.penalties?(home?m.penalties:[m.penalties[1],m.penalties[0]]):null,result:gf>ga?'W':gf<ga?'L':w?(w===code?'W':'L'):'D'}});
}
export function cupPodium(cup){
 if(!cup.champion)return null;const all=allCupMatches(cup),final=all.find(m=>m.id==='FINAL'),third=all.find(m=>m.id==='THIRD');
 const other=(m,code)=>m.home===code?m.away:m.home,bronze=third?.played?winner(third):null;
 return {champion:cup.champion,runnerUp:other(final,cup.champion),third:bronze,fourth:bronze?other(third,bronze):null,final};
}
/** Estatísticas coletivas por seleção, somadas dos resumos persistidos de cada partida. */
export function teamTotals(cup){
 const rows=new Map(cup.selected.map(code=>[code,{code,played:0,w:0,d:0,l:0,gf:0,ga:0,shots:0,xg:0,yc:0,rc:0,possession:0,withStats:0}]));
 for(const m of allCupMatches(cup)){if(!m.played)continue;[[m.home,0,m.hg,m.ag],[m.away,1,m.ag,m.hg]].forEach(([code,i,gf,ga])=>{const r=rows.get(code);if(!r)return;r.played++;r.gf+=gf;r.ga+=ga;r[gf>ga?'w':gf<ga?'l':'d']++;if(m.st?.possession){r.withStats++;r.shots+=m.st.shots[i];r.xg+=m.st.xG[i];r.yc+=m.st.yellow[i];r.rc+=m.st.red[i];r.possession+=m.st.possession[i]}})}
 return [...rows.values()];
}
export const PERFORMANCE_FORMULA='gols×4 + assistências×3 + chutes no alvo×0,3 + desarmes×0,25 + interceptações×0,25 + defesas×0,5 − amarelos×0,5 − vermelhos×2';
export const performanceIndex=l=>Math.round((l.g*4+l.a*3+l.sot*.3+l.tk*.25+l.int*.25+l.sv*.5-l.yc*.5-l.rc*2)*10)/10;
/** Prêmios individuais e coletivos, todos derivados de `save.stats` e dos resultados; só existem com a Copa encerrada. */
export function cupAwards(save){
 const cup=save.cup,podium=cupPodium(cup);if(!podium)return null;
 const lines=Object.values(save.stats?.players||{}),by=(key,extra=()=>0)=>[...lines].filter(l=>l[key]>0).sort((a,b)=>b[key]-a[key]||extra(b)-extra(a)||a.min-b.min||a.name.localeCompare(b.name));
 const totals=teamTotals(cup),semis=new Set([podium.champion,podium.runnerUp,podium.third,podium.fourth].filter(Boolean));
 const wall=totals.filter(t=>semis.has(t.code)).sort((a,b)=>a.ga/a.played-b.ga/b.played||a.code.localeCompare(b.code))[0];
 const keeper=wall?lines.filter(l=>l.team===wall.code&&l.pos==='GK').sort((a,b)=>b.min-a.min)[0]:null;
 const fair=totals.filter(t=>t.played>=4&&t.withStats).sort((a,b)=>(a.yc+3*a.rc)/a.played-(b.yc+3*b.rc)/b.played||a.code.localeCompare(b.code))[0];
 return {podium,goldenBoot:by('g',l=>l.a)[0]||null,assists:by('a',l=>l.g)[0]||null,goldenGlove:keeper?{...keeper,conceded:wall.ga,games:wall.played}:null,
  best:lines.filter(l=>l.gp>=4).map(l=>({...l,index:performanceIndex(l)})).sort((a,b)=>b.index-a.index||a.name.localeCompare(b.name)).slice(0,5),fairPlay:fair||null};
}
