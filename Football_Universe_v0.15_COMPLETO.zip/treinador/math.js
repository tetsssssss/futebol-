// Field coordinates are percentages of a 105 x 68 m pitch. Rendering is read-only.
export const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
export const lerp=(a,b,t)=>a+(b-a)*t;
export const distance=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
export const fieldDistance=(a,b)=>Math.hypot((a.x-b.x)*1.05,(a.y-b.y)*.68);
export const teamDirection=(s,side)=>(side===0?1:-1)*(s.half===2?-1:1);
export const localX=(s,side,x)=>teamDirection(s,side)===1?x:100-x;
export const worldX=(s,side,x)=>teamDirection(s,side)===1?x:100-x;
export const rating=(p,key)=>clamp(Number(p?.attrs?.[key]??p?.overall??65),0,100);
export function randomValue(s){let x=s.rngState|0;x^=x<<13;x^=x>>>17;x^=x<<5;s.rngState=x>>>0;return s.rngState/4294967296;}
export function seedValue(text){let value=2166136261;for(const c of String(text))value=Math.imul(value^c.charCodeAt(0),16777619);return value>>>0||1;}
export const nearestPlayer=(players,point,filter=()=>true)=>players.filter(p=>!p.dismissed&&filter(p)).sort((a,b)=>fieldDistance(a,point)-fieldDistance(b,point))[0];
export const round2=n=>Math.round(n*100)/100;
