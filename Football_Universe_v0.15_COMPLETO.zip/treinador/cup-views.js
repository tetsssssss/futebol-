// Páginas da Copa do Mundo no Modo Treinador. Funções puras: recebem o save e devolvem HTML.
// Identidade própria (dourado sobre azul-noite), sem marcas, troféus ou emblemas oficiais.
import {CUP_STAGES,cupRules,allCupMatches,groupOf,groupTable,thirdsTable,bracketColumns,campaign,cupPodium,cupAwards,teamTotals,PERFORMANCE_FORMULA} from './cup.js';
import {crest,portrait,fixtureRow,matchDetail} from './league-views.js';
import {playerRanking} from './match-summary.js';
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const btn=(action,label,extra='',attrs='')=>`<button class="btn ${extra}" data-action="${action}" ${attrs}>${label}</button>`;
const empty=text=>`<p class="empty">${esc(text)}</p>`;
// Código FIFA → ISO para o emoji de bandeira. Onde o sistema não desenha bandeiras (Windows), aparece a sigla.
const ISO={MEX:'MX',RSA:'ZA',KOR:'KR',CZE:'CZ',CAN:'CA',BIH:'BA',USA:'US',PAR:'PY',HAI:'HT',AUS:'AU',TUR:'TR',BRA:'BR',MAR:'MA',QAT:'QA',SUI:'CH',CIV:'CI',ECU:'EC',GER:'DE',CUW:'CW',NED:'NL',JPN:'JP',SWE:'SE',TUN:'TN',KSA:'SA',URU:'UY',ESP:'ES',CPV:'CV',IRN:'IR',NZL:'NZ',BEL:'BE',EGY:'EG',FRA:'FR',SEN:'SN',IRQ:'IQ',NOR:'NO',ARG:'AR',ALG:'DZ',AUT:'AT',JOR:'JO',GHA:'GH',PAN:'PA',CRO:'HR',POR:'PT',COD:'CD',UZB:'UZ',COL:'CO'};
const SUBDIVISION={SCO:'gbsct',ENG:'gbeng'};
export function flag(code){
 if(SUBDIVISION[code])return '\u{1F3F4}'+[...SUBDIVISION[code]].map(c=>String.fromCodePoint(0xE0000+c.charCodeAt(0))).join('')+'\u{E007F}';
 const iso=ISO[code];return iso?[...iso].map(c=>String.fromCodePoint(0x1F1E6+c.charCodeAt(0)-65)).join(''):'';
}
const nation=(team,extra='')=>`<span class="nation ${extra}"><span class="flag" aria-hidden="true">${flag(team.id)}</span>${crest(team)}<span class="nation-name">${esc(team.name)}</span></span>`;
const stageIndex=cup=>CUP_STAGES.indexOf(cup.stage);
const stepper=cup=>`<ol class="stepper" aria-label="Fases da Copa">${CUP_STAGES.map((s,i)=>`<li class="${i<stageIndex(cup)||cup.champion?'done':i===stageIndex(cup)?'now':''}"><span>${i+1}</span>${esc(s)}</li>`).join('')}</ol>`;
const cupHead=(save,title,subtitle)=>`<div class="cup-hero"><div><div class="eyebrow">COPA DO MUNDO ${save.cup.year||2026} · EDIÇÃO SIMULADA</div><h2>${esc(title)}</h2><p>${esc(subtitle)}</p></div>${stepper(save.cup)}</div>`;
const RESULT={W:'V',D:'E',L:'D'};
const campaignList=(save,code,getTeam)=>{const games=campaign(save.cup,code);return games.length?`<ol class="campaign">${games.map(g=>`<li><i class="f-${g.result}">${RESULT[g.result]}</i><span>${esc(g.round)}${g.group?' '+g.group:''}</span><b>${g.gf} : ${g.ga}${g.penalties?` <small>(pên. ${g.penalties.join('–')})</small>`:''}</b><span>${nation(getTeam(g.opponent))}</span></li>`).join('')}</ol>`:empty('Nenhuma partida disputada ainda.')};
const groupCard=(save,group,getTeam,compact=false)=>{const rows=groupTable(save.cup,group),thirds=thirdsTable(save.cup),done=rows.every(r=>r.played===3);
 return `<section class="panel groupcard ${save.cup.groups[group].includes(save.team)?'mine':''}"><h3>Grupo ${group}</h3><table class="grouptable"><thead><tr><th>#</th><th>Seleção</th><th>PTS</th><th>J</th>${compact?'':'<th>V</th><th>E</th><th>D</th>'}<th>SG</th><th>GP</th></tr></thead><tbody>${rows.map((r,i)=>{const third=i===2?thirds.find(t=>t.code===r.code):null,zone=i<2?'z-top':i===2?(third?.qualified?'z-top2':'z-mid'):'';
  return `<tr class="${zone} ${r.code===save.team?'mine':''}"><td class="pos">${i+1}</td><td>${nation(getTeam(r.code))}${i===2&&done?`<small class="tie"> ${third?.qualified?'· entre os 8 melhores terceiros':'· fora no ranking de terceiros'}</small>`:''}</td><td><b>${r.pts}</b></td><td>${r.played}</td>${compact?'':`<td>${r.w}</td><td>${r.d}</td><td>${r.l}</td>`}<td>${r.gd>0?'+':''}${r.gd}</td><td>${r.gf}</td></tr>`}).join('')}</tbody></table></section>`};

/** Leitura do próximo adversário a partir do que ele já fez no torneio. */
function scouting(save,code,getTeam){
 const totals=teamTotals(save.cup).find(t=>t.code===code),top=playerRanking(save.stats,'g',{teams:new Set([code]),limit:3});
 if(!totals?.played)return `<p class="muted">${esc(getTeam(code).name)} ainda não jogou neste torneio: não há o que analisar.</p>`;
 const per=v=>totals.withStats?(v/totals.withStats).toFixed(1):'—';
 return `<dl class="facts"><dt>Campanha</dt><dd>${totals.w}V ${totals.d}E ${totals.l}D · ${totals.gf} gols pró, ${totals.ga} contra</dd><dt>Finalizações por jogo</dt><dd>${per(totals.shots)}</dd><dt>xG por jogo</dt><dd>${per(totals.xg)}</dd><dt>Posse média</dt><dd>${totals.withStats?Math.round(totals.possession/totals.withStats)+'%':'—'}</dd><dt>Cartões</dt><dd>${totals.yc} amarelos · ${totals.rc} vermelhos</dd><dt>Quem decide</dt><dd>${top.length?top.map(l=>`${esc(l.name)} (${l.g})`).join(', '):'ninguém marcou ainda'}</dd></dl>`;
}
export function cupDashboard(save,getTeam,next,canAdvance){
 const cup=save.cup,me=getTeam(save.team),group=groupOf(cup,save.team),podium=cupPodium(cup),alive=cup.stage==='Grupos'||cup.matches.some(m=>m.home===save.team||m.away===save.team);
 const knockout=next&&next.round!=='Grupos',opponent=next?(next.home===save.team?next.away:next.home):null;
 const nextCard=next?`<div class="versus">${nation(getTeam(next.home),'big')}<span>VS</span>${nation(getTeam(next.away),'big')}</div><p class="muted">${esc(next.round)}${next.group?' · Grupo '+next.group:''}${next.date?' · '+esc(next.date):''}</p>${knockout?'<p class="stakes">Jogo eliminatório: empate leva à prorrogação e, se preciso, aos pênaltis. Quem perde está fora.</p>':''}<div class="actions">${btn('play-next','🎮 Entrar em campo','primary')}${btn('simulate-round','Simular a fase')}</div>`
  :canAdvance?`<p>Todos os jogos desta fase foram disputados.</p><div class="actions">${btn('next-stage','Avançar de fase','primary')}</div>`:podium?'<p>Torneio encerrado.</p>':`<p>${alive?'Sua seleção não joga nesta rodada da fase.':'Sua seleção está eliminada. Você pode acompanhar o restante do torneio.'}</p><div class="actions">${btn('simulate-round','Simular a fase')}</div>`;
 return cupHead(save,podium?`${getTeam(podium.champion).name} campeã do mundo`:`${me.name} na Copa`,podium?'Torneio encerrado. Veja a cerimônia e os prêmios.':'Fase de grupos com 12 chaves, 32 avos e mata-mata até a final: 104 partidas.')
 +(podium?ceremony(save,getTeam):'')
 +`<div class="two-cards"><section class="panel"><h3>Próximo jogo</h3>${nextCard}</section><section class="panel"><h3>${opponent?'Análise do adversário · '+esc(getTeam(opponent).name):'Sua campanha'}</h3>${opponent?scouting(save,opponent,getTeam):campaignList(save,save.team,getTeam)}</section></div>`
 +`<div class="three-cards">${group?groupCard(save,group,getTeam,true):''}<section class="panel"><h3>Campanha · ${esc(me.name)}</h3>${campaignList(save,save.team,getTeam)}</section><section class="panel"><h3>Artilharia</h3>${rank(playerRanking(save.stats,'g',{limit:6}),getTeam)}</section></div>`;
}
const rank=(rows,getTeam,unit='')=>rows.length?`<ol class="ranklist">${rows.map(l=>`<li>${portrait(l)}<span><b>${esc(l.name)}</b><small>${flag(l.team)} ${esc(getTeam(l.team).name)} · ${l.gp} j</small></span><strong>${l.value}${unit}</strong></li>`).join('')}</ol>`:empty('Sem registros ainda neste torneio.');

export function groupsView(save,getTeam){
 const cup=save.cup,rules=cupRules(cup),thirds=thirdsTable(cup),complete=thirds.every(r=>r.played===3);
 return cupHead(save,'Fase de grupos','Os dois primeiros de cada grupo e os oito melhores terceiros avançam aos 32 avos.')
 +`<div class="groupgrid">${Object.keys(cup.groups).map(g=>groupCard(save,g,getTeam)).join('')}</div>`
 +`<section class="panel"><h3>Ranking dos terceiros colocados${complete?'':' · parcial'}</h3><div class="tablewrap"><table class="standings"><thead><tr><th>#</th><th>Seleção</th><th>Grupo</th><th>PTS</th><th>J</th><th>SG</th><th>GP</th><th>Cartões</th></tr></thead><tbody>${thirds.map(r=>`<tr class="${r.qualified?'z-top2':'z-down'} ${r.code===save.team?'mine':''} ${r.position===rules.groups.bestThirds?'cutline':''}"><td class="pos">${r.position}</td><td>${nation(getTeam(r.code))}</td><td>${r.group}</td><td><b>${r.pts}</b></td><td>${r.played}</td><td>${r.gd>0?'+':''}${r.gd}</td><td>${r.gf}</td><td>${r.yc}🟨 ${r.rc}🟥</td></tr>`).join('')}</tbody></table></div>
 <p class="muted">${esc(rules.notes)} Fonte: ${esc(rules.source)}${rules.verified?'':' — ainda não conferido no regulamento oficial'}.</p></section>`;
}

const slot=(save,code,label,score,won,getTeam)=>code?`<div class="slot ${won?'won':''} ${code===save.team?'mine':''}">${nation(getTeam(code))}<b>${score??''}</b></div>`:`<div class="slot pending"><span class="muted">${esc(label)}</span><b></b></div>`;
const tie=(save,m,getTeam)=>`<div class="tie-box ${m.pending?'pending':''}" ${m.played?`data-action="match-detail" data-id="${esc(m.id)}" role="button" tabindex="0" title="Ver detalhes"`:''}>${slot(save,m.home,m.homeLabel,m.played?m.hg:null,m.winner&&m.winner===m.home,getTeam)}${slot(save,m.away,m.awayLabel,m.played?m.ag:null,m.winner&&m.winner===m.away,getTeam)}${m.penalties?`<small class="pens">pênaltis ${m.penalties.join(' : ')}</small>`:''}</div>`;
export function bracketView(save,view,getTeam){
 const {columns,third,tree}=bracketColumns(save.cup),started=columns[0].matches.some(m=>!m.pending);
 return cupHead(save,'Chave eliminatória','Dos 32 avos à final. Clique em um jogo disputado para ver os detalhes.')
 +`<section class="panel">${started?'':empty('A chave é montada ao fim da fase de grupos: 8 melhores primeiros contra terceiros, 4 primeiros contra segundos e 8 segundos entre si, sem repetir grupo.')}
 <div class="bracket ${tree?'':'flat'}" style="--cols:${columns.length}">${columns.map(c=>`<div class="bcol" data-count="${c.matches.length}"><h4>${esc(c.round)}</h4><div class="bcol-body">${c.matches.map(m=>tie(save,m,getTeam)).join('')}</div></div>`).join('')}</div>
 ${third?`<div class="thirdplace"><h4>Disputa do terceiro lugar</h4>${tie(save,third,getTeam)}</div>`:''}
 <p class="muted">${tree?'Chaveamento gerado pelo simulador; não reproduz a tabela oficial de alocação da FIFA.':'Esta Copa começou numa versão anterior: os confrontos seguem o chaveamento original, que não forma uma árvore contínua.'}</p></section>${matchDetail(save,view.detail,getTeam)}`;
}

export function cupCalendar(save,view,getTeam,playable,canAdvance){
 const cup=save.cup,list=cup.matches,dates=[...new Set(list.map(m=>m.date||''))].sort(),pending=list.some(m=>!m.played);
 const earlier=cup.history.slice().reverse().map(h=>`<details><summary>${esc(h.stage)} · ${h.matches.length} jogos</summary>${h.matches.map(m=>fixtureRow(save,m,getTeam,false)).join('')}</details>`).join('');
 return cupHead(save,'Calendário',`${cup.stage} · ${list.filter(m=>m.played).length}/${list.length} partidas disputadas · datas hipotéticas.`)
 +`<section class="panel"><div class="panelhead"><h3>${esc(cup.stage)}</h3><div class="actions">${pending?btn('simulate-round','Simular a fase inteira'):''}${canAdvance?btn('next-stage','Próxima fase','primary'):''}</div></div>${dates.map(d=>`<h4 class="dayhead">${d?esc(d):'Data a definir'}</h4>${list.filter(m=>(m.date||'')===d).map(m=>fixtureRow(save,m,getTeam,playable(m))).join('')}`).join('')}</section>${matchDetail(save,view.detail,getTeam)}${earlier?`<section class="panel"><h3>Fases anteriores</h3>${earlier}</section>`:''}`;
}

/** Cerimônia: pódio e prêmios, todos derivados dos resultados e das estatísticas do torneio. */
export function ceremony(save,getTeam){
 const a=cupAwards(save);if(!a)return '';const p=a.podium,final=p.final,award=(title,line,detail)=>`<div class="award"><small>${title}</small><b>${line}</b><span>${detail}</span></div>`,who=l=>`${flag(l.team)} ${esc(l.name)}`;
 return `<section class="panel ceremony"><div class="confetti" aria-hidden="true">${Array.from({length:28},(_,i)=>`<i style="--i:${i}"></i>`).join('')}</div>
 <div class="eyebrow">CERIMÔNIA DE ENCERRAMENTO</div><h2>${nation(getTeam(p.champion),'big')}</h2><p class="champline">Campeã do mundo · final: ${esc(getTeam(final.home).name)} ${final.hg} : ${final.ag} ${esc(getTeam(final.away).name)}${final.penalties?` (pênaltis ${final.penalties.join(' : ')})`:''}</p>
 <div class="podium"><div class="p2"><small>Vice</small>${nation(getTeam(p.runnerUp))}</div><div class="p1"><small>Campeã</small>${nation(getTeam(p.champion))}</div><div class="p3"><small>Terceiro lugar</small>${p.third?nation(getTeam(p.third)):'—'}</div></div>
 <div class="awards">${a.goldenBoot?award('Artilheiro',who(a.goldenBoot),`${a.goldenBoot.g} gols · ${a.goldenBoot.a} assistências em ${a.goldenBoot.gp} jogos`):''}${a.assists?award('Líder em assistências',who(a.assists),`${a.assists.a} assistências`):''}${a.goldenGlove?award('Melhor goleiro',who(a.goldenGlove),`${a.goldenGlove.conceded} gols sofridos em ${a.goldenGlove.games} jogos da seleção · ${a.goldenGlove.sv} defesas`):''}${a.best[0]?award('Melhor jogador',who(a.best[0]),`índice ${a.best[0].index}`):''}${a.fairPlay?award('Conduta',`${flag(a.fairPlay.code)} ${esc(getTeam(a.fairPlay.code).name)}`,`${a.fairPlay.yc} amarelos e ${a.fairPlay.rc} vermelhos em ${a.fairPlay.played} jogos`):''}</div>
 ${a.best.length?`<details><summary>Seleção dos melhores por índice de desempenho</summary><ol class="ranklist">${a.best.map(l=>`<li>${portrait(l)}<span><b>${esc(l.name)}</b><small>${flag(l.team)} ${esc(getTeam(l.team).name)} · ${l.g} gols, ${l.a} assistências, ${l.gp} jogos</small></span><strong>${l.index}</strong></li>`).join('')}</ol><p class="muted">Índice = ${esc(PERFORMANCE_FORMULA)}. Considera atletas com pelo menos 4 jogos.</p></details>`:''}</section>`;
}
