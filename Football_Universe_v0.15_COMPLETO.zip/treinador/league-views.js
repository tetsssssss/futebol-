// Páginas de competição do Modo Treinador. Funções puras: recebem o save e devolvem HTML.
// Todo número exibido vem de resultados confirmados, de `save.stats` ou do arquivo de partidas.
import {leagueOf,leagueTable,leagueTeams,leagueRules,leagueFixtures,divisionOf,divisionsOf,currentRound,matchdayFixtures,seasonFinished,seasonOutcome,positionHistory} from './league.js';
import {playerRanking,SHOT_OUTCOMES} from './match-summary.js';
import {photoURL,registeredPhoto} from './photos.js';
import {badgeURL} from '../src/media.js';
import {qualifyingFixtures,STAGE_LABEL} from './qualifiers.js';
import {continentalFixtures,continentalDone,fixtureCaption} from './continental.js';
const cupFixtures=save=>save.mode==='eliminatorias'?qualifyingFixtures(save.qual):[...save.cup.matches,...save.cup.history.flatMap(h=>h.matches||[])];
const fixtureLabel=(save,m)=>m.comp?fixtureCaption(m,save.continental?.season):save.mode==='copa'?m.round:save.mode==='eliminatorias'?(m.stage==='group'?`${m.zone} · Grupo ${m.group} · Rodada ${m.matchday}`:STAGE_LABEL[m.stage]):roundLabel(m);
export const DIV_NAME={A:'Série A',B:'Série B'};
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const safeColor=c=>/^#[0-9a-f]{6}$/i.test(c||'')?c:'#8dcbb8';
const btn=(action,label,extra='',attrs='')=>`<button class="btn ${extra}" data-action="${action}" ${attrs}>${label}</button>`;
const empty=text=>`<p class="empty">${esc(text)}</p>`;
/** Escudo real (assets/badges) quando existe; sem ele, a sigla sobre a cor da equipe. */
export const crest=team=>{const badge=badgeURL(team.id),text=esc((team.short||team.name||'?').slice(0,3));return `<i class="crest${badge?' has-badge':''}" style="background:${safeColor(team.color)}" aria-hidden="true">${text}${badge?`<img src="${esc(badge)}" alt="" loading="lazy" decoding="async" onerror="this.parentNode.classList.remove('has-badge');this.remove()">`:''}</i>`};
/** Retrato com fallback: iniciais sempre presentes; a foto, quando existe e carrega, cobre o avatar. */
export function portrait(player,px=64){
 const url=photoURL(player.photo?player:{id:player.id,...registeredPhoto(player.id)},px*2);
 const initials=String(player.name||'?').split(/\s+/).filter(Boolean).map(w=>w[0]).slice(0,2).join('').toUpperCase();
 const neutral=player.placeholder||/^Posição /.test(player.name||'');
 return `<span class="avatar" aria-hidden="true">${esc(neutral?player.position||player.pos||'–':initials)}${url?`<img loading="lazy" decoding="async" referrerpolicy="no-referrer" src="${esc(url)}" alt="" onerror="this.remove()">`:''}</span>`;
}
export const roundLabel=m=>m.stage==='playoff'?`Playoff de acesso · ${m.leg===1?'ida':'volta'}`:`Rodada ${m.round}`;
export const shownDivision=(save,wanted)=>wanted&&divisionsOf(save).includes(wanted)?wanted:divisionOf(save,save.team)||'A';
const divisionTabs=(save,active)=>`<div class="tabs" role="tablist">${divisionsOf(save).map(d=>`<button role="tab" aria-selected="${d===active}" class="tab ${d===active?'on':''}" data-action="view-division" data-id="${d}">${DIV_NAME[d]}</button>`).join('')}</div>`;
const competitionHeader=(save,division,extra='')=>{const league=leagueOf(save,division),rules=leagueRules(league),round=currentRound(league),done=leagueFixtures(league).filter(m=>m.played).length;
 return `<div class="comp-head"><div><div class="eyebrow">${esc(rules.country||'')} · ${rules.tier}ª DIVISÃO · TEMPORADA ${league.year}</div><h2>${esc(rules.name)}</h2><p class="muted">${round?esc(round.label):'Competição encerrada'} · ${done}/${leagueFixtures(league).length} jogos</p></div>${extra}</div>`};

export function seasonPanel(save,getTeam){
 if(!seasonFinished(save))return '';
 const o=seasonOutcome(save),names=ids=>ids.map(id=>esc(getTeam(id).name)).join(', ')||'—',waiting=save.continental&&!continentalDone(save.continental);
 return `<section class="panel season-end"><div class="panelhead"><h2>Temporada ${save.season} encerrada</h2>${waiting?btn('tab-conmebol','Concluir as Copas da Conmebol'):btn('next-season',`Iniciar temporada ${save.season+1}`,'primary')}</div>${waiting?'<p class="stakes">A virada de temporada espera a Libertadores e a Sul-Americana: as vagas da edição seguinte dependem dos campeões e das campanhas.</p>':''}
 <div class="outcome"><div><small>Campeão da Série A</small><b>🏆 ${esc(getTeam(o.championA).name)}</b></div><div><small>Campeão da Série B</small><b>🏆 ${esc(getTeam(o.championB).name)}</b></div>
 <div class="up"><small>Sobem para a Série A</small><b>${names(o.promoted)}</b></div><div class="down"><small>Caem para a Série B</small><b>${names(o.relegatedA)}</b></div>
 <div class="down"><small>Deixam a Série B</small><b>${names(o.relegatedB)}</b></div><div class="up"><small>Entram na Série B</small><b>${names(o.incoming)}</b></div></div>
 <p class="muted">A Série C não é simulada: quem deixa a Série B aguarda numa fila e retorna em temporadas seguintes. Ao avançar, calendários, estatísticas e cartões acumulados recomeçam; o histórico é preservado.</p></section>`;
}

export function fixtureRow(save,m,getTeam,playable){
 const home=getTeam(m.home),away=getTeam(m.away),entry=save.archive.find(x=>x.id===m.id);
 const action=!m.played?`<button class="smallbtn" data-action="play-match" data-id="${esc(m.id)}" ${playable?'':'disabled title="Aguarde a rodada atual"'}>Assistir 2D</button>`
  :`<span class="rowactions">${entry?.replay?.length?`<button class="smallbtn" data-action="watch-replay" data-id="${esc(m.id)}">Replay</button>`:''}<button class="smallbtn" data-action="match-detail" data-id="${esc(m.id)}">Detalhes</button></span>`;
 return `<div class="fixture ${m.home===save.team||m.away===save.team?'mine':''}"><span class="club">${crest(home)} ${esc(home.name)}</span><strong>${m.played?`${m.hg} : ${m.ag}`:'vs'}${m.penalties?`<small class="gamedate">pên. ${m.penalties.join('–')}</small>`:m.date?`<small class="gamedate">${esc(m.date.slice(5))}</small>`:''}</strong><span class="club">${crest(away)} ${esc(away.name)}</span>${action}</div>`;
}
const STAT_ROWS=[['Posse (%)','possession'],['Finalizações','shots'],['No alvo','onTarget'],['xG','xG'],['Passes certos','completedPasses'],['Passes tentados','passes'],['Desarmes','tackles'],['Interceptações','interceptions'],['Defesas','saves'],['Faltas','fouls'],['Escanteios','corners'],['Impedimentos','offsides'],['Amarelos','yellow'],['Vermelhos','red']];
export function shotMap(shots,sideColors=['#6ce3ae','#ffb86b']){
 if(!shots?.length)return empty('Sem dados espaciais de finalização para esta seleção.');
 // Meio-campo ofensivo normalizado: todas as finalizações atacam para a direita.
 const W=340,H=230,X=x=>(Math.max(50,x)-50)/50*W,Y=y=>y/100*H;
 return `<svg class="shotmap" viewBox="0 0 ${W} ${H}" role="img" aria-label="Mapa de finalizações: ${shots.length} chutes, ${shots.filter(s=>s[5]===3).length} gols"><rect width="${W}" height="${H}" rx="6" fill="#1d5a45"/><g fill="none" stroke="#d5f0d2" stroke-opacity=".55"><rect x="${W-.1571*2*W}" y="${.2035*H}" width="${.1571*2*W}" height="${.593*H}"/><rect x="${W-.0524*2*W}" y="${.3653*H}" width="${.0524*2*W}" height="${.2694*H}"/><path d="M0 0V${H}"/></g>${shots.map(([minute,side,x,y,xg,outcome])=>`<circle cx="${X(x).toFixed(1)}" cy="${Y(y).toFixed(1)}" r="${(3+Math.sqrt(xg)*.9).toFixed(1)}" fill="${outcome===3?sideColors[side]||'#fff':'none'}" stroke="${sideColors[side]||'#fff'}" stroke-width="1.6" opacity="${outcome===3?1:.75}"><title>${minute}' · xG ${(xg/100).toFixed(2)} · ${({off:'para fora',saved:'defendido',blocked:'bloqueado',goal:'gol'})[SHOT_OUTCOMES[outcome]]}</title></circle>`).join('')}</svg><p class="muted legend">Círculo cheio = gol · tamanho = xG do lance · posições reais da simulação.</p>`;
}
/** Crônica curta da partida, montada só com o que ficou registrado: placar, autores dos gols, posse, xG e cartões. */
export function matchNarrative(m,getTeam){
 const home=getTeam(m.home).name,away=getTeam(m.away).name,diff=m.hg-m.ag,total=m.hg+m.ag,st=m.st,parts=[];
 const winner=diff>0?home:away,loser=diff>0?away:home,hi=Math.max(m.hg,m.ag),lo=Math.min(m.hg,m.ag);
 parts.push(diff===0?(total?`${home} e ${away} empataram em ${m.hg} a ${m.ag}`:`${home} e ${away} ficaram no zero a zero`)+(m.penalties?`, e a decisão foi para os pênaltis: ${m.penalties[0]} a ${m.penalties[1]} para ${m.penalties[0]>m.penalties[1]?home:away}.`:'.'):`${winner} ${Math.abs(diff)>=3?'goleou':'venceu'} ${loser} por ${hi} a ${lo}${total===1?', pelo placar mínimo':''}.`);
 const goals=[...(m.scorers?.home||[]).map(g=>({...g,team:home,side:0})),...(m.scorers?.away||[]).map(g=>({...g,team:away,side:1}))].filter(g=>Number.isFinite(g.minute)).sort((a,b)=>a.minute-b.minute);
 if(goals.length){const by=new Map();for(const g of goals)by.set(g.name+'|'+g.team,[...(by.get(g.name+'|'+g.team)||[]),g.minute]);parts.push('Gols: '+[...by].map(([k,mins])=>`${k.split('|')[0]} (${mins.map(x=>x+"'").join(', ')})`).join(', ')+'.');
  const last=goals.at(-1);if(diff!==0&&last.minute>=80&&Math.abs(diff)===1&&last.side===(diff>0?0:1))parts.push(`O gol da vitória saiu aos ${last.minute} minutos.`);
  let h=0,a=0,turned=false,led=0;for(const g of goals){g.side?a++:h++;const now=Math.sign(h-a);if(now&&led&&now!==led)turned=true;if(now)led=now}if(turned&&diff!==0)parts.push(`${winner} saiu atrás e virou o jogo.`)}
 if(st?.possession){const [ph,pa]=st.possession;if(Math.abs(ph-pa)>=16)parts.push(`${ph>pa?home:away} ficou com a bola: ${Math.max(ph,pa)}% de posse.`);
  if(st.xG){const [xh,xa]=st.xG,xWin=diff>0?xh:xa,xLose=diff>0?xa:xh;if(diff!==0&&xLose>xWin+.6)parts.push(`O placar contrariou as chances criadas: xG de ${xh.toFixed(2)} a ${xa.toFixed(2)}.`);else if(diff===0&&Math.abs(xh-xa)>1)parts.push(`${xh>xa?home:away} criou mais (xG ${xh.toFixed(2)} a ${xa.toFixed(2)}), mas não transformou em vitória.`)}
  const reds=(st.red?.[0]||0)+(st.red?.[1]||0);if(reds)parts.push(reds===1?`Houve uma expulsão (${st.red[0]?home:away}).`:`Houve ${reds} expulsões.`)}
 return parts.join(' ');
}
export function matchDetail(save,id,getTeam){
 const m=(save.mode==='brasileirao'?[...divisionsOf(save).flatMap(d=>leagueFixtures(leagueOf(save,d))),...continentalFixtures(save.continental)]:cupFixtures(save)).find(x=>x.id===id&&x.played);
 if(!m)return '';
 const home=getTeam(m.home),away=getTeam(m.away),entry=save.archive.find(x=>x.id===id),colors=[safeColor(home.color),safeColor(away.color)==safeColor(home.color)?'#ffb86b':safeColor(away.color)];
 const stats=m.st?`<div class="statcompare">${STAT_ROWS.filter(([,k])=>m.st[k]).map(([label,k])=>{const [a,b]=m.st[k],total=a+b||1;return `<div class="cmp"><b>${a}</b><span>${label}<i><u style="width:${(a/total*100).toFixed(0)}%;background:${colors[0]}"></u><u style="width:${(b/total*100).toFixed(0)}%;background:${colors[1]}"></u></i></span><b>${b}</b></div>`}).join('')}</div>`:empty('Estatísticas coletivas não registradas para esta partida.');
 const timeline=entry?.events?.length?`<ol class="timeline">${entry.events.map(e=>`<li class="${e.side===1?'away':'home'} ev-${esc(e.type)}"><b>${e.minute}'</b> ${esc(e.text)}</li>`).join('')}</ol>`:empty(m.hg+m.ag?'Linha do tempo indisponível para partidas anteriores à v0.8.':'Sem gols, cartões ou substituições registrados.');
 return `<section class="panel detail" id="match-detail"><div class="panelhead"><h2>${crest(home)} ${esc(home.name)} ${m.hg} : ${m.ag} ${esc(away.name)} ${crest(away)}</h2>${btn('match-detail','Fechar','','data-id=""')}</div><p class="muted">${esc(fixtureLabel(save,m))}${m.date?' · '+esc(m.date):''}${m.penalties?` · pênaltis ${m.penalties.join(' : ')}`:''}</p><p class="narrative">${esc(matchNarrative(m,getTeam))}</p><div class="detailgrid"><div><h3>Estatísticas</h3>${stats}</div><div><h3>Linha do tempo</h3>${timeline}</div><div><h3>Mapa de finalizações</h3>${shotMap(entry?.shots,colors)}</div></div></section>`;
}

export function calendarView(save,view,getTeam){
 const division=shownDivision(save,view.division),league=leagueOf(save,division),total=league.rounds.length,open=currentRound(league),extra=league.playoff?2:0;
 const number=Math.min(total+extra,Math.max(1,view.round||open?.number||total+extra)),matches=number>total?league.playoff.legs[number-total-1]:league.rounds[number-1];
 const label=number>total?`Playoff de acesso · ${number-total===1?'ida':'volta'}`:`Rodada ${number}`,canPlay=id=>!!open?.matches.some(m=>m.id===id&&!m.played),pending=matchdayFixtures(save).some(m=>!m.played);
 const rounds=`<div class="rounds">${league.rounds.map((r,i)=>`<button data-action="open-round" data-id="${i+1}" class="round ${r.every(m=>m.played)?'done':''} ${i+1===number?'current':''}" aria-label="Rodada ${i+1}">${i+1}</button>`).join('')}${league.playoff?league.playoff.legs.map((l,i)=>`<button data-action="open-round" data-id="${total+i+1}" class="round wide ${l.every(m=>m.played)?'done':''} ${total+i+1===number?'current':''}">PO ${i?'volta':'ida'}</button>`).join(''):''}</div>`;
 return `<section class="panel">${competitionHeader(save,division,divisionTabs(save,division))}<div class="panelhead"><h3>${esc(label)} · ${matches.filter(m=>m.played).length}/${matches.length} partidas</h3><div class="actions">${pending?btn('simulate-round','Simular rodada (Séries A e B)'):''}</div></div>${matches.map(m=>fixtureRow(save,m,getTeam,canPlay(m.id))).join('')}</section>${matchDetail(save,view.detail,getTeam)}<section class="panel"><h3>Rodadas da temporada</h3>${rounds}<p class="muted">Calendário gerado pelo simulador (turno e returno com mandos invertidos). As datas são hipotéticas.</p></section>`;
}

const ZONE_CLASS={continental:'z-top',"continental-q":'z-top2',secondary:'z-mid',promotion:'z-top',playoff:'z-top2',relegation:'z-down'};
const CRITERIA={points:'',wins:'vitórias',goalDifference:'saldo de gols',goalsFor:'gols marcados',headToHead:'confronto direto',fewestReds:'menos vermelhos',fewestYellows:'menos amarelos',draw:'sorteio'};
const rankList=(rows,getTeam,unit)=>rows.length?`<ol class="ranklist">${rows.map(l=>`<li>${portrait(l)}<span><b>${esc(l.name)}</b><small>${esc(getTeam(l.team).short||l.team)} · ${l.gp} j</small></span><strong>${l.value}${unit||''}</strong></li>`).join('')}</ol>`:empty('Sem registros ainda nesta temporada.');
export function standingsView(save,view,getTeam){
 const division=shownDivision(save,view.division),league=leagueOf(save,division),rules=leagueRules(league),table=leagueTable(league),scope=['home','away'].includes(view.scope)?view.scope:'all',ids=new Set(leagueTeams(league));
 const rows=scope==='all'?table:table.map(r=>({...r,...r[scope],gd:r[scope].gf-r[scope].ga,form:[],zone:null,decidedBy:'points'})).sort((a,b)=>b.pts-a.pts||b.gd-a.gd||b.gf-a.gf||a.code.localeCompare(b.code));
 const body=rows.map((r,i)=>{const team=getTeam(r.code);return `<tr class="${r.code===save.team?'mine':''} ${ZONE_CLASS[r.zone]||''}"><td class="pos">${i+1}</td><td>${crest(team)} ${esc(team.name)}${CRITERIA[r.decidedBy]?`<small class="tie" title="Posição decidida por ${CRITERIA[r.decidedBy]}"> ⓘ</small>`:''}</td><td><b>${r.pts}</b></td><td>${r.played}</td><td>${r.w}</td><td>${r.d}</td><td>${r.l}</td><td>${r.gf}</td><td>${r.ga}</td><td>${r.gd>0?'+':''}${r.gd}</td><td>${r.played?Math.round(r.pts/(r.played*3)*100):0}%</td>${scope==='all'?`<td class="form">${r.form.map(f=>`<i class="f-${f}" title="${({W:'Vitória',D:'Empate',L:'Derrota'})[f]}">${({W:'V',D:'E',L:'D'})[f]}</i>`).join('')}</td>`:''}</tr>`}).join('');
 const played=table.some(r=>r.played),best=[...table].sort((a,b)=>b.gf-a.gf)[0],wall=[...table].sort((a,b)=>a.ga-b.ga)[0];
 const scopeSelect=`<label class="filter">Recorte <select id="table-scope">${[['all','Geral'],['home','Mandante'],['away','Visitante']].map(([v,n])=>`<option value="${v}" ${v===scope?'selected':''}>${n}</option>`).join('')}</select></label>`;
 return `<section class="panel">${competitionHeader(save,division,divisionTabs(save,division))}<div class="panelhead"><h3>Classificação${scope==='all'?'':scope==='home'?' · como mandante':' · como visitante'}</h3>${scopeSelect}</div>
 <div class="tablewrap"><table class="standings"><thead><tr><th>#</th><th>Clube</th><th>PTS</th><th>J</th><th>V</th><th>E</th><th>D</th><th>GP</th><th>GC</th><th>SG</th><th>%</th>${scope==='all'?'<th>Forma</th>':''}</tr></thead><tbody>${body}</tbody></table></div>
 ${scope==='all'?`<div class="zonelegend">${rules.zones.map(z=>`<span class="${ZONE_CLASS[z.key]||''}"><i></i>${esc(z.label)} (${z.from}${z.to>z.from?'–'+z.to:''}º)</span>`).join('')}</div>`:'<p class="muted">Recortes de mandante/visitante são ordenados por pontos, saldo e gols marcados.</p>'}
 <p class="muted">Desempate, nesta ordem: ${rules.tiebreakers.map(t=>CRITERIA[t]).join(' → ')}. ${esc(rules.notes||'')} ${rules.carriedFrom?`Regulamento de ${rules.carriedFrom} mantido para ${league.year}. `:''}Fonte: ${esc(rules.source)}${rules.verified?'':' — ainda não conferido no documento oficial'}.</p></section>
 <section class="panel"><div class="panelhead"><h3>Evolução da posição</h3><label class="filter">Clube <select id="evo-club">${[...ids].map(id=>getTeam(id)).sort((a,b)=>a.name.localeCompare(b.name)).map(t=>`<option value="${esc(t.id)}" ${t.id===(ids.has(view.club)?view.club:ids.has(save.team)?save.team:table[0].code)?'selected':''}>${esc(t.name)}</option>`).join('')}</select></label></div>${positionChart(league,ids.has(view.club)?view.club:ids.has(save.team)?save.team:table[0].code,getTeam)}</section>
 <div class="three-cards"><section class="panel"><h3>Artilharia</h3>${rankList(playerRanking(save.stats,'g',{teams:ids,limit:8}),getTeam)}</section><section class="panel"><h3>Assistências</h3>${rankList(playerRanking(save.stats,'a',{teams:ids,limit:8}),getTeam)}</section>
 <section class="panel"><h3>Destaques coletivos</h3>${played?`<dl class="facts"><dt>Melhor ataque</dt><dd>${esc(getTeam(best.code).name)} · ${best.gf} gols</dd><dt>Melhor defesa</dt><dd>${esc(getTeam(wall.code).name)} · ${wall.ga} sofridos</dd><dt>Média de gols</dt><dd>${(table.reduce((n,r)=>n+r.gf,0)/(table.reduce((n,r)=>n+r.played,0)/2)).toFixed(2)} por jogo</dd></dl>`:empty('Nenhuma partida disputada.')}</section></div>`;
}

/** Gráfico de linha da posição do clube rodada a rodada, com as zonas do regulamento ao fundo. */
export function positionChart(league,code,getTeam){
 const history=positionHistory(league,code),rules=leagueRules(league),n=leagueTeams(league).length,rounds=league.rounds.length;
 if(history.length<2)return empty('O gráfico aparece a partir da segunda rodada concluída.');
 const W=640,H=200,L=26,R=44,T=10,B=22,x=i=>L+(W-L-R)*i/(rounds-1),y=p=>T+(H-T-B)*(p-1)/(n-1),band={continental:'#4fd08f',"continental-q":'#58b7e8',secondary:'#e3b85a',promotion:'#4fd08f',playoff:'#58b7e8',relegation:'#ef6b6b'};
 const zones=(rules.zones||[]).map(z=>`<rect x="${L}" y="${(y(z.from)-(H-T-B)/(n-1)/2).toFixed(1)}" width="${W-L-R}" height="${((z.to-z.from+1)*(H-T-B)/(n-1)).toFixed(1)}" fill="${band[z.key]||'#55666e'}" opacity=".1"/>`).join('');
 const points=history.map((p,i)=>`${x(i).toFixed(1)},${y(p).toFixed(1)}`).join(' '),last=history.at(-1),best=Math.min(...history),worst=Math.max(...history);
 return `<svg class="poschart" viewBox="0 0 ${W} ${H}" role="img" aria-label="Evolução da posição de ${esc(getTeam(code).name)}: ${history.length} rodadas, atual ${last}º, melhor ${best}º, pior ${worst}º">${zones}${[1,Math.round(n/4),Math.round(n/2),Math.round(3*n/4),n].map(p=>`<text x="${L-6}" y="${(y(p)+3).toFixed(1)}" text-anchor="end">${p}</text><path d="M${L} ${y(p).toFixed(1)}H${W-R}" class="grid"/>`).join('')}${[1,10,19,29,38].filter(r=>r<=rounds).map(r=>`<text x="${x(r-1).toFixed(1)}" y="${H-6}" text-anchor="middle">${r}</text>`).join('')}<polyline points="${points}" class="line"/><circle cx="${x(history.length-1).toFixed(1)}" cy="${y(last).toFixed(1)}" r="4" class="dot"/><text x="${(x(history.length-1)+8).toFixed(1)}" y="${(y(last)+4).toFixed(1)}" class="now">${last}º</text></svg><p class="muted legend">Rodada no eixo horizontal, posição no vertical · atual ${last}º · melhor ${best}º · pior ${worst}º · faixas coloridas = zonas do regulamento.</p>`;
}
const PER90=[['g','Gols'],['a','Assistências'],['sh','Finalizações'],['sot','No alvo'],['xg','xG'],['tk','Desarmes'],['int','Interceptações']];
const duel=(label,a,b,fmt=v=>v)=>{const total=a+b||1;return `<div class="cmp"><b>${fmt(a)}</b><span>${label}<i><u style="width:${(a/total*100).toFixed(0)}%;background:var(--accent)"></u><u style="width:${(b/total*100).toFixed(0)}%;background:#ffb86b"></u></i></span><b>${fmt(b)}</b></div>`};
const pick=(id,list,current,label)=>`<label class="filter">${label} <select id="${id}">${list.map(([v,n])=>`<option value="${esc(v)}" ${v===current?'selected':''}>${esc(n)}</option>`).join('')}</select></label>`;
/** Comparativo de dois atletas por 90 minutos, a partir das linhas acumuladas da temporada ou do torneio. */
export function playerComparison(stats,view,teams,getTeam){
 const pool=Object.values(stats?.players||{}).filter(l=>(!teams||teams.has(l.team))&&l.min>=90).sort((a,b)=>b.min-a.min||a.name.localeCompare(b.name)).slice(0,60);
 if(pool.length<2)return empty('O comparativo precisa de pelo menos dois atletas com 90 minutos jogados.');
 const byGoals=[...pool].sort((a,b)=>b.g-a.g||b.a-a.a),A=pool.find(l=>l.id===view.cmpA)||byGoals[0],B=pool.find(l=>l.id===view.cmpB&&l.id!==A.id)||byGoals.find(l=>l.id!==A.id),options=[...pool].sort((a,b)=>a.name.localeCompare(b.name)).map(l=>[l.id,`${l.name} · ${getTeam(l.team).short||l.team}`]),per=(l,k)=>Math.round(l[k]/l.min*90*100)/100;
 const who=l=>`<div class="cmp-who">${portrait(l,44)}<span><b>${esc(l.name)}</b><small>${esc(getTeam(l.team).name)} · ${l.gp} jogos · ${l.min} min</small></span></div>`;
 return `<div class="actions">${pick('cmp-a',options,A.id,'Atleta A')}${pick('cmp-b',options,B.id,'Atleta B')}</div><div class="cmp-head">${who(A)}${who(B)}</div><div class="statcompare">${PER90.map(([k,label])=>duel(label+' / 90 min',per(A,k),per(B,k))).join('')}${A.pa>=20&&B.pa>=20?duel('Precisão de passe (%)',Math.round(A.pc/A.pa*100),Math.round(B.pc/B.pa*100)):''}${duel('Cartões (amarelos + vermelhos)',A.yc+A.rc,B.yc+B.rc)}</div><p class="muted legend">Valores por 90 minutos jogados. Entram atletas com pelo menos 90 minutos; a lista mostra os 60 com mais tempo em campo.</p>`;
}
/** Comparativo de duas equipes por jogo, a partir dos resumos das partidas confirmadas. */
export function teamComparison(rows,view,getTeam){
 const played=rows.filter(r=>r.withStats>0);if(played.length<2)return empty('O comparativo precisa de duas equipes com partidas registradas.');
 const A=played.find(r=>r.code===view.cmpTA)||played[0],B=played.find(r=>r.code===view.cmpTB&&r.code!==A.code)||played.find(r=>r.code!==A.code),options=[...played].sort((a,b)=>getTeam(a.code).name.localeCompare(getTeam(b.code).name)).map(r=>[r.code,getTeam(r.code).name]),per=(r,v)=>Math.round(v/r.withStats*10)/10,one=v=>v.toFixed(1);
 return `<div class="actions">${pick('cmpt-a',options,A.code,'Equipe A')}${pick('cmpt-b',options,B.code,'Equipe B')}</div><div class="cmp-head"><div class="cmp-who">${crest(getTeam(A.code))}<span><b>${esc(getTeam(A.code).name)}</b><small>${A.played} jogos</small></span></div><div class="cmp-who">${crest(getTeam(B.code))}<span><b>${esc(getTeam(B.code).name)}</b><small>${B.played} jogos</small></span></div></div><div class="statcompare">${duel('Gols por jogo',Math.round(A.gf/A.played*10)/10,Math.round(B.gf/B.played*10)/10,one)}${duel('Gols sofridos por jogo',Math.round(A.ga/A.played*10)/10,Math.round(B.ga/B.played*10)/10,one)}${duel('Finalizações por jogo',per(A,A.shots),per(B,B.shots),one)}${duel('No alvo por jogo',per(A,A.onTarget),per(B,B.onTarget),one)}${duel('xG por jogo',per(A,A.xg),per(B,B.xg),one)}${duel('xG contra por jogo',per(A,A.xga),per(B,B.xga),one)}${duel('Posse média (%)',Math.round(A.possession/A.withStats),Math.round(B.possession/B.withStats))}${duel('Precisão de passe (%)',A.passes?Math.round(A.completed/A.passes*100):0,B.passes?Math.round(B.completed/B.passes*100):0)}</div>`;
}
const METRICS=[['g','Gols'],['a','Assistências'],['sh','Finalizações'],['sot','Finalizações no alvo'],['xg','Gols esperados (xG)'],['passPct','Precisão de passe (%)'],['pc','Passes certos'],['tk','Desarmes'],['int','Interceptações'],['sv','Defesas'],['yc','Cartões amarelos'],['rc','Cartões vermelhos'],['min','Minutos jogados']];
function teamAggregates(fixtures,ids){
 const rows=new Map(ids.map(id=>[id,{code:id,played:0,gf:0,ga:0,shots:0,onTarget:0,xg:0,xga:0,possession:0,passes:0,completed:0,withStats:0}]));
 for(const m of fixtures){if(!m.played)continue;[[m.home,0,m.hg,m.ag],[m.away,1,m.ag,m.hg]].forEach(([id,i,gf,ga])=>{const r=rows.get(id);if(!r)return;r.played++;r.gf+=gf;r.ga+=ga;const st=m.st;if(st?.possession){r.withStats++;r.shots+=st.shots[i];r.onTarget+=st.onTarget[i];r.xg+=st.xG[i];r.xga+=st.xG[1-i];r.possession+=st.possession[i];r.passes+=st.passes[i];r.completed+=st.completedPasses[i]}})}
 return [...rows.values()];
}
export function statsView(save,view,getTeam){
 const league=save.mode==='brasileirao',division=league?shownDivision(save,view.division):null,metric=METRICS.find(m=>m[0]===view.metric)||METRICS[0],scope=view.scope==='team'?'team':'all';
 const ids=league?leagueTeams(leagueOf(save,division)):null,teams=scope==='team'?new Set([save.team]):ids?new Set(ids):null,rows=playerRanking(save.stats,metric[0],{teams,limit:25}),max=rows[0]?.value||1;
 const table=rows.length?`<div class="tablewrap"><table class="rank"><thead><tr><th>#</th><th>Jogador</th><th>Equipe</th><th>J</th><th>Min</th><th>${esc(metric[1])}</th></tr></thead><tbody>${rows.map((l,i)=>`<tr class="${l.team===save.team?'mine':''}"><td class="pos">${i+1}</td><td><span class="who">${portrait(l)} ${esc(l.name)}</span></td><td>${esc(getTeam(l.team).short||l.team)}</td><td>${l.gp}</td><td>${l.min||'—'}</td><td class="barcell"><i style="width:${Math.max(4,l.value/max*100).toFixed(0)}%"></i><b>${l.value}</b></td></tr>`).join('')}</tbody></table></div>`:empty('Ainda não há eventos registrados para esta métrica.');
 const fixtures=league?leagueFixtures(leagueOf(save,division)):cupFixtures(save),codes=ids||[...new Set(fixtures.flatMap(m=>[m.home,m.away]))];
 const agg=teamAggregates(fixtures,codes).filter(r=>r.played).sort((a,b)=>b.gf-a.gf||a.ga-b.ga),per=(v,r)=>r.withStats?(v/r.withStats).toFixed(1):'—';
 const collective=agg.length?`<div class="tablewrap"><table class="rank"><thead><tr><th>Equipe</th><th>J</th><th>Gols</th><th>Sofridos</th><th>Final./j</th><th>No alvo/j</th><th>xG/j</th><th>xG contra/j</th><th>Posse</th><th>Passe %</th><th>Conversão</th></tr></thead><tbody>${agg.map(r=>`<tr class="${r.code===save.team?'mine':''}"><td>${crest(getTeam(r.code))} ${esc(getTeam(r.code).name)}</td><td>${r.played}</td><td>${r.gf}</td><td>${r.ga}</td><td>${per(r.shots,r)}</td><td>${per(r.onTarget,r)}</td><td>${per(r.xg,r)}</td><td>${per(r.xga,r)}</td><td>${r.withStats?Math.round(r.possession/r.withStats)+'%':'—'}</td><td>${r.passes?Math.round(r.completed/r.passes*100)+'%':'—'}</td><td>${r.shots?Math.round(r.gf/r.shots*100)+'%':'—'}</td></tr>`).join('')}</tbody></table></div>`:empty('Nenhuma partida disputada.');
 const mine=save.archive.filter(e=>e.home===save.team||e.away===save.team),shots=mine.flatMap(e=>(e.shots||[]).filter(s=>s[1]===(e.home===save.team?0:1)).map(s=>[s[0],0,...s.slice(2)]));
 const select=(id,options,current)=>`<select id="${id}">${options.map(([v,n])=>`<option value="${v}" ${v===current?'selected':''}>${esc(n)}</option>`).join('')}</select>`;
 return `<section class="panel"><div class="comp-head"><div><div class="eyebrow">CENTRAL DE ESTATÍSTICAS · TEMPORADA ${save.season}</div><h2>${league?esc(leagueRules(leagueOf(save,division)).name):save.mode==='eliminatorias'?'Eliminatórias da Copa de 2030':'Copa do Mundo'}</h2><p class="muted">Números derivados dos eventos das partidas confirmadas. Nada é estimado.${save.stats?.partial?' Este save veio de uma versão anterior: partidas antigas contam apenas gols, assistências e cartões.':''}</p></div>${league?divisionTabs(save,division):''}</div>
 <div class="panelhead"><h3>Jogadores · ${esc(metric[1])}</h3><div class="actions"><label class="filter">Métrica ${select('stat-metric',METRICS,metric[0])}</label><label class="filter">Recorte ${select('stat-scope',[['all',league?'Divisão inteira':'Torneio'],['team',getTeam(save.team).name]],scope)}</label></div></div>${table}</section>
 <section class="panel"><h3>Equipes · eficiência ofensiva e defensiva</h3>${collective}</section>
 <div class="two-cards"><section class="panel"><h3>Comparar atletas</h3>${playerComparison(save.stats,view,ids?new Set(ids):null,getTeam)}</section><section class="panel"><h3>Comparar equipes</h3>${teamComparison(teamAggregates(fixtures,codes),view,getTeam)}</section></div>
 <div class="two-cards"><section class="panel"><h3>Mapa de finalizações · ${esc(getTeam(save.team).name)}</h3>${shotMap(shots,[safeColor(getTeam(save.team).color)])}</section>
 <section class="panel"><h3>Ainda indisponível</h3><ul class="pending"><li>Evolução de um atleta jogo a jogo (hoje só o acumulado é guardado)</li><li>Estatísticas por competição ao longo de várias temporadas</li><li>Mapas de passes e de calor</li></ul><p class="muted">Esses itens só aparecerão quando houver dados persistidos suficientes; nenhum valor é simulado para preencher a tela.</p></section></div>`;
}

export function historyView(save,getTeam){
 const seasons=[...(save.history||[])].reverse(),names=ids=>ids?.length?ids.map(id=>esc(getTeam(id).name)).join(', '):'—';
 const table=rows=>`<div class="tablewrap"><table><thead><tr><th>#</th><th>Clube</th><th>PTS</th><th>V</th><th>E</th><th>D</th><th>GP</th><th>GC</th></tr></thead><tbody>${rows.map(([code,pts,w,d,l,gf,ga],i)=>`<tr class="${code===save.team?'mine':''}"><td class="pos">${i+1}</td><td>${crest(getTeam(code))} ${esc(getTeam(code).name)}</td><td><b>${pts}</b></td><td>${w}</td><td>${d}</td><td>${l}</td><td>${gf}</td><td>${ga}</td></tr>`).join('')}</tbody></table></div>`;
 if(!seasons.length)return `<section class="panel"><h2>Histórico de temporadas</h2>${empty('Nenhuma temporada concluída neste universo. Ao encerrar a temporada atual, campeões, acessos, rebaixamentos e tabelas finais ficam registrados aqui.')}</section>`;
 return seasons.map(h=>`<section class="panel"><div class="comp-head"><div><div class="eyebrow">TEMPORADA SIMULADA</div><h2>${h.season}</h2></div></div>
 <div class="outcome"><div><small>Campeão da Série A</small><b>🏆 ${esc(getTeam(h.A.champion).name)}</b></div><div><small>Campeão da Série B</small><b>🏆 ${esc(getTeam(h.B.champion).name)}</b></div><div class="up"><small>Acesso à Série A</small><b>${names(h.B.promoted)}</b></div><div class="down"><small>Rebaixados da Série A</small><b>${names(h.A.relegated)}</b></div><div><small>Artilheiro da Série A</small><b>${h.scorers?.A?.[0]?`${esc(h.scorers.A[0][0])} · ${h.scorers.A[0][2]} gols`:'—'}</b></div><div><small>Artilheiro da Série B</small><b>${h.scorers?.B?.[0]?`${esc(h.scorers.B[0][0])} · ${h.scorers.B[0][2]} gols`:'—'}</b></div></div>
 ${h.B.playoff?`<p class="muted">Playoff de acesso: ${h.B.playoff.map(t=>`${esc(getTeam(t.home).name)} ${t.aggregate[0]}–${t.aggregate[1]} ${esc(getTeam(t.away).name)}${t.penalties?` (pên. ${t.penalties.join('–')})`:''}`).join(' · ')} (placar agregado).</p>`:''}
 <details><summary>Tabela final da Série A</summary>${table(h.A.table)}</details><details><summary>Tabela final da Série B</summary>${table(h.B.table)}</details></section>`).join('');
}
