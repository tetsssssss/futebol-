// Páginas da Libertadores e da Sul-Americana no Modo Treinador. Funções puras: recebem o save e devolvem HTML.
import {COMPETITIONS,STAGE_NAME,competitionRules,continentalMatchday,continentalFixtures,groupTable,stageTies,bracketColumns,clubStatus,clubCampaign,fixtureCaption} from './continental.js';
import {CONMEBOL_COUNTRIES,countryOf,CONMEBOL_SOURCE} from './conmebol.js';
import {crest,portrait,fixtureRow,matchDetail} from './league-views.js';
import {playerRanking} from './match-summary.js';
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const btn=(action,label,extra='',attrs='')=>`<button class="btn ${extra}" data-action="${action}" ${attrs}>${label}</button>`;
const empty=text=>`<p class="empty">${esc(text)}</p>`;
const club=(team)=>`<span class="nation">${crest(team)}<span class="nation-name">${esc(team.name)}</span></span>`;
const KEYS=['lib','sula'];
export const shownTournament=view=>KEYS.includes(view.cont)?view.cont:'lib';
const tabs=active=>`<div class="tabs" role="tablist">${KEYS.map(k=>`<button role="tab" aria-selected="${k===active}" class="tab ${k===active?'on':''}" data-action="view-continental" data-id="${k}">${COMPETITIONS[k].id==='libertadores'?'Libertadores':'Sul-Americana'}</button>`).join('')}</div>`;
const RESULT={W:'V',D:'E',L:'D'};
const TONE={champion:'up',alive:'up',waiting:'',out:'down'};
function statusLine(save,key,getTeam){
 const c=save.continental,s=clubStatus(c,key,save.team),name=competitionRules(c,key).short;
 return s?`<div class="${TONE[s.state]||''}"><small>${esc(name)}</small><b>${s.state==='champion'?'🏆 ':''}${esc(s.label)}</b></div>`:`<div><small>${esc(name)}</small><b>Não participa</b></div>`;
}
const head=(save,key,title,subtitle)=>{const c=save.continental,all=continentalFixtures(c),day=continentalMatchday(c),T=c[key],rules=competitionRules(c,key);
 return `<div class="cup-hero"><div><div class="eyebrow">CONMEBOL · ${esc(rules.name.toUpperCase())} · EDIÇÃO ${c.season} SIMULADA</div><h2>${esc(title)}</h2><p>${esc(subtitle)}</p></div><div class="status">${T.champion?'Encerrada':esc(T.stage?STAGE_NAME[T.stage]||'':'')}<br>${all.filter(m=>m.played).length}/${all.length} jogos criados · ${day?esc(day.label):'sem jogos pendentes'}</div></div>`};
const groupCard=(save,key,group,getTeam)=>{
 const c=save.continental,rows=groupTable(c,key,group),mine=rows.some(r=>r.code===save.team);
 const zone=i=>key==='lib'?(i<2?'z-top':i===2?'z-mid':''):(i===0?'z-top':i===1?'z-top2':'');
 return `<section class="panel groupcard ${mine?'mine':''}"><h3>Grupo ${group}</h3><table class="grouptable"><thead><tr><th>#</th><th>Clube</th><th>PTS</th><th>J</th><th>V</th><th>E</th><th>D</th><th>SG</th><th>GP</th></tr></thead><tbody>${rows.map((r,i)=>`<tr class="${zone(i)} ${r.code===save.team?'mine':''}"><td class="pos">${i+1}</td><td>${club(getTeam(r.code))}<small class="tie"> ${esc(CONMEBOL_COUNTRIES[countryOf(r.code)]||'')}</small></td><td><b>${r.pts}</b></td><td>${r.played}</td><td>${r.w}</td><td>${r.d}</td><td>${r.l}</td><td>${r.gd>0?'+':''}${r.gd}</td><td>${r.gf}</td></tr>`).join('')}</tbody></table></section>`;
};
const slot=(save,code,label,agg,won,getTeam)=>code?`<div class="slot ${won?'won':''} ${code===save.team?'mine':''}">${club(getTeam(code))}<b>${agg??''}</b></div>`:`<div class="slot pending"><span class="muted">${esc(label)}</span><b></b></div>`;
const tieBox=(save,t,getTeam)=>t.pending?`<div class="tie-box pending">${slot(save,null,t.firstLabel,null,false,getTeam)}${slot(save,null,t.secondLabel,null,false,getTeam)}</div>`
 :`<div class="tie-box">${slot(save,t.first,'',t.aggregate?t.aggregate[0]:null,t.winner===t.first,getTeam)}${slot(save,t.second,'',t.aggregate?t.aggregate[1]:null,t.winner===t.second,getTeam)}${t.penalties?`<small class="pens">pênaltis ${t.penalties.join(' : ')}</small>`:t.legs?.length&&t.legs.some(m=>m.played)&&!t.winner?'<small class="pens">1ª partida disputada</small>':''}</div>`;
function podium(save,key,getTeam){
 const T=save.continental[key];if(!T.champion)return '';const final=stageTies(T,'final')[0],game=final.legs[0];
 return `<section class="panel ceremony"><div class="eyebrow">CAMPEÃO · ${esc(competitionRules(save.continental,key).name.toUpperCase())}</div><h2>${club(getTeam(T.champion))}</h2><p class="champline">Final: ${esc(getTeam(game.home).name)} ${game.hg} : ${game.ag} ${esc(getTeam(game.away).name)}${game.penalties?` (pênaltis ${game.penalties.join(' : ')})`:''}</p></section>`;
}
export function continentalView(save,view,getTeam){
 const c=save.continental;if(!c)return `<section class="panel">${empty('Este save não tem os torneios continentais.')}</section>`;
 const key=shownTournament(view),T=c[key],rules=competitionRules(c,key),day=continentalMatchday(c),playable=new Set((day?.matches||[]).map(m=>m.id));
 const mine=continentalFixtures(c).filter(m=>!m.played&&(m.home===save.team||m.away===save.team)).sort((a,b)=>a.date.localeCompare(b.date))[0];
 const status=`<section class="panel"><h3>Seu clube nas Copas da Conmebol · ${esc(getTeam(save.team).name)}</h3><div class="outcome">${KEYS.map(k=>statusLine(save,k,getTeam)).join('')}</div>
  ${mine?`<h4 class="dayhead">Próxima partida</h4><div class="versus">${club(getTeam(mine.home))}<span>VS</span>${club(getTeam(mine.away))}</div><p class="muted">${esc(fixtureCaption(mine,c.season))} · ${esc(mine.date)}</p>${mine.stage!=='groups'&&mine.leg!==1?'<p class="stakes">Mata-mata: '+(mine.stage==='final'?'a final tem prorrogação e pênaltis.':'empate no agregado vai direto aos pênaltis, sem prorrogação.')+'</p>':''}<div class="actions">${playable.has(mine.id)?btn('play-match','🎮 Entrar em campo','primary',`data-id="${esc(mine.id)}"`):`<span class="muted">Aguarde: antes é preciso concluir ${day?esc(day.label)+' ('+esc(day.date)+')':'a fase atual'}.</span>`}</div>`:'<p class="muted">Seu clube não tem partidas pendentes nestes torneios.</p>'}
  <div class="actions">${day?btn('simulate-continental',`Simular ${esc(day.label)} · ${day.matches.length} jogos`):'<span class="muted">Os dois torneios foram encerrados.</span>'}</div></section>`;
 const ties=T.ties.length?COMPETITIONS[key].stages.filter(s=>s!=='groups'&&stageTies(T,s).length).map(s=>`<details ${s===T.stage?'open':''}><summary>${esc(STAGE_NAME[s])} · ${stageTies(T,s).length} ${s==='s1'?'jogos':'confrontos'}</summary>${stageTies(T,s).map(t=>t.legs.map(m=>fixtureRow(save,m,getTeam,playable.has(m.id))).join('')).join('')}</details>`).join(''):'';
 const bracket=T.seeds?`<section class="panel"><h3>Mata-mata · ${esc(rules.short)}</h3><div class="bracket" style="--cols:4">${bracketColumns(T).map(col=>`<div class="bcol" data-count="${col.ties.length}"><h4>${esc(STAGE_NAME[col.stage])}</h4><div class="bcol-body">${col.ties.map(t=>tieBox(save,t,getTeam)).join('')}</div></div>`).join('')}</div><p class="muted">Confrontos em ida e volta; quem tem a melhor campanha decide em casa. A final é jogo único. O agregado aparece em cada vaga.</p></section>`:'';
 const groups=T.groups?`<div class="groupgrid">${Object.keys(T.groups).map(g=>groupCard(save,key,g,getTeam)).join('')}</div><p class="muted">${key==='lib'?'1º e 2º vão às oitavas; o 3º cai para os playoffs da Sul-Americana.':'O 1º vai às oitavas; o 2º enfrenta um terceiro da Libertadores nos playoffs.'} Desempate: ${esc(rules.tiebreakers.join(' → '))}.</p>`:'';
 const scorers=playerRanking(T.stats,'g',{limit:8}),scorerList=scorers.length?`<ol class="ranklist">${scorers.map(l=>`<li>${portrait(l)}<span><b>${esc(l.name)}</b><small>${esc(getTeam(l.team).name)} · ${l.gp} j</small></span><strong>${l.value}</strong></li>`).join('')}</ol>`:empty('Sem gols registrados.');
 const camp=clubCampaign(T,save.team),campaign=camp.length?`<ol class="campaign">${camp.map(g=>`<li><i class="f-${g.result}">${RESULT[g.result]}</i><span>${esc(STAGE_NAME[g.stage])}${g.group?' '+g.group:''}${g.leg?(g.leg===1?' · ida':' · volta'):''}</span><b>${g.gf} : ${g.ga}${g.penalties?` <small>(pên. ${g.penalties.join('–')})</small>`:''}</b><span>${club(getTeam(g.opponent))}</span></li>`).join('')}</ol>`:empty('Seu clube ainda não jogou este torneio.');
 const next=day?`<section class="panel"><h3>Próximo dia de jogos · ${esc(day.date)}</h3>${day.matches.map(m=>`<h4 class="dayhead">${esc(fixtureCaption(m,c.season))}</h4>`+fixtureRow(save,m,getTeam,true)).join('')}</section>`:'';
 return head(save,key,key==='lib'?'Copa Libertadores':'Copa Sul-Americana',key==='lib'?'47 clubes de dez países, três fases preliminares, oito grupos e mata-mata até a final.':'Primeira fase em jogo único, grupos com os eliminados da Libertadores e playoffs contra os terceiros dela.')
 +`<div class="actions">${tabs(key)}</div>`+podium(save,key,getTeam)+status+groups+bracket
 +`<div class="two-cards"><section class="panel"><h3>Artilharia</h3>${scorerList}</section><section class="panel"><h3>Campanha · ${esc(getTeam(save.team).name)}</h3>${campaign}</section></div>`
 +(ties?`<section class="panel"><h3>Jogos por fase</h3>${ties}</section>`:'')+next+matchDetail(save,view.detail,getTeam)
 +`<p class="muted">${esc(rules.notes)} Fonte: ${esc(rules.source)} — ainda não conferido no regulamento oficial. ${esc(CONMEBOL_SOURCE)}.</p>`;
}
/** Resumo curto para a Central: situação do clube e próximo dia de jogos continental. */
export function continentalCard(save,getTeam){
 const c=save.continental;if(!c)return '';const day=continentalMatchday(c);
 return `<section class="panel"><div class="panelhead"><h3>Conmebol · ${c.season}</h3>${btn('tab-conmebol','Abrir')}</div><div class="outcome">${KEYS.map(k=>statusLine(save,k,getTeam)).join('')}</div><p class="muted">${day?esc(day.label)+' · '+esc(day.date)+' · '+day.matches.length+' jogos':'Libertadores e Sul-Americana encerradas.'}</p></section>`;
}
