import {changeTactics,reshape,setDuty} from './match-engine.js';
// Commands change the authoritative simulation; cameras and replay stay in the viewer.
export function applyCoachControl(match,side,id,value){
 if(id==='view-formation'){reshape(match,side,value);return true;}
 if(id==='view-duty'){const [playerId,duty]=String(value).split('|');setDuty(match,side,playerId,duty);return true;}
 const key={'view-mental':'mentality','view-pressure':'pressing','view-tempo':'tempo','view-instruction':'instruction','view-width':'width','view-line':'line','view-build':'buildUp'}[id];
 if(!key)return false;
 changeTactics(match,side,{[key]:['pressing','tempo','width','line'].includes(key)?Number(value):value});return true;
}
