// Regulamentos versionados por competição e temporada. Nada aqui é permanente:
// cada entrada vale a partir da sua temporada até existir outra mais recente.
// `verified:false` marca itens assumidos pelo simulador e ainda não conferidos no regulamento oficial.
const BR_TIEBREAKERS=['wins','goalDifference','goalsFor','headToHead','fewestReds','fewestYellows','draw'];
export const COMPETITION_RULES=[
 {id:'br-serie-a',season:2026,revision:2,name:'Brasileirão Série A',short:'Série A',country:'BRA',confederation:'CONMEBOL',tier:1,format:'double-round-robin',teams:20,
  points:{win:3,draw:1,loss:0},tiebreakers:BR_TIEBREAKERS,headToHead:{onlyTwoTeams:true},yellowLimit:3,
  zones:[{from:1,to:5,key:'continental',label:'Libertadores · fase de grupos'},{from:6,to:7,key:'continental-q',label:'Libertadores · 2ª fase preliminar'},{from:8,to:13,key:'secondary',label:'Sul-Americana'},{from:17,to:20,key:'relegation',label:'Rebaixamento'}],
  relegation:{count:4,to:'br-serie-b'},promotion:null,
  notes:'Sete vagas na Libertadores e seis na Sul-Americana saem todas da tabela: a Copa do Brasil não é simulada, então a vaga do campeão dela fica com o 5º colocado. Campeões continentais vigentes entram à parte e as vagas descem uma posição.',
  source:'Regulamento Específico da Competição · CBF 2026 (conforme divulgado pela imprensa)',verified:false},
 {id:'br-serie-b',season:2026,revision:1,name:'Brasileirão Série B',short:'Série B',country:'BRA',confederation:'CONMEBOL',tier:2,format:'double-round-robin',teams:20,
  points:{win:3,draw:1,loss:0},tiebreakers:BR_TIEBREAKERS,headToHead:{onlyTwoTeams:true},yellowLimit:3,
  zones:[{from:1,to:2,key:'promotion',label:'Acesso direto'},{from:3,to:6,key:'playoff',label:'Playoff de acesso'},{from:17,to:20,key:'relegation',label:'Rebaixamento'}],
  promotion:{direct:2,to:'br-serie-a',playoff:{pairs:[[3,6],[4,5]],legs:2,extraTime:false,tied:'higherSeed'}},relegation:{count:4,to:'br-serie-c'},
  notes:'Playoff em ida e volta (3º×6º e 4º×5º), segundo jogo na casa do melhor colocado. Placar agregado empatado classifica o clube de melhor campanha, sem pênaltis.',
  source:'Conselho Técnico da Série B · CBF 2026 (conforme Bahia Notícias, SporTV e Wikipédia, consultados em 12/10/2026)',verified:false},
 {id:'fifa-world-cup',season:2026,revision:1,name:'Copa do Mundo',short:'Copa',country:null,confederation:'FIFA',tier:1,format:'groups-knockout',teams:48,
  groups:{count:12,size:4,advance:2,bestThirds:8,headToHead:{onlyTwoTeams:false},thirdsTiebreakers:['goalDifference','goalsFor','fairPlay','draw']},points:{win:3,draw:1,loss:0},tiebreakers:['headToHead','goalDifference','goalsFor','fairPlay','draw'],yellowLimit:2,
  zones:[{from:1,to:2,key:'promotion',label:'Classificados aos 32 avos'},{from:3,to:3,key:'playoff',label:'Depende do ranking de terceiros'}],
  knockout:{stages:['32 avos','Oitavas','Quartas','Semifinais','Decisão'],extraTime:true,tied:'penalties',thirdPlace:true},totalMatches:104,
  notes:'Grupo: confronto direto (pontos, saldo, gols), saldo geral, gols, conduta (amarelo −1, vermelho −3) e sorteio no lugar do ranking da FIFA. Terceiros: pontos, saldo, gols, conduta, sorteio. O chaveamento dos 32 avos é do simulador e não reproduz a tabela oficial de alocação.',
  source:'Formato de 48 seleções · FIFA (critérios conforme guias de imprensa consultados em 12/10/2026)',verified:false},
 // Conmebol: vagas por país sem contar os campeões vigentes, que entram direto nos grupos da Libertadores.
 {id:'conmebol-libertadores',season:2026,revision:1,name:'Copa Libertadores',short:'Libertadores',country:null,confederation:'CONMEBOL',tier:1,format:'qualifying-groups-knockout',teams:47,
  berths:{ARG:{groups:5,second:1,first:0},BOL:{groups:2,second:1,first:1},BRA:{groups:5,second:2,first:0},CHI:{groups:2,second:2,first:0},COL:{groups:2,second:2,first:0},ECU:{groups:2,second:1,first:1},PAR:{groups:2,second:1,first:1},PER:{groups:2,second:1,first:1},URU:{groups:2,second:1,first:1},VEN:{groups:2,second:1,first:1}},
  groups:{count:8,size:4,advance:2},points:{win:3,draw:1,loss:0},tiebreakers:['headToHead','goalDifference','goalsFor','fewestReds','fewestYellows','draw'],headToHead:{onlyTwoTeams:false},yellowLimit:3,
  zones:[{from:1,to:2,key:'promotion',label:'Oitavas de final'},{from:3,to:3,key:'playoff',label:'Playoffs da Sul-Americana'}],
  knockout:{legs:2,extraTime:false,tied:'penalties',final:{legs:1,extraTime:true}},totalMatches:155,
  notes:'Três fases preliminares em ida e volta, oito grupos de quatro em turno e returno, mata-mata em ida e volta e final em jogo único. Agregado empatado vai direto aos pênaltis; só a final tem prorrogação. Sorteios, potes, mandos e datas são do simulador: o ranking de clubes da Conmebol não é reproduzido e o desempate final é por sorteio.',
  source:'Formato e vagas de 2026 · Conmebol (conforme a página da edição na Wikipédia, consultada em 12/10/2026)',verified:false},
 {id:'conmebol-sudamericana',season:2026,revision:1,name:'Copa Sul-Americana',short:'Sul-Americana',country:null,confederation:'CONMEBOL',tier:2,format:'qualifying-groups-knockout',teams:56,
  berths:{ARG:{groups:6,first:0},BOL:{groups:0,first:4},BRA:{groups:6,first:0},CHI:{groups:0,first:4},COL:{groups:0,first:4},ECU:{groups:0,first:4},PAR:{groups:0,first:4},PER:{groups:0,first:4},URU:{groups:0,first:4},VEN:{groups:0,first:4}},
  groups:{count:8,size:4,advance:1},points:{win:3,draw:1,loss:0},tiebreakers:['headToHead','goalDifference','goalsFor','fewestReds','fewestYellows','draw'],headToHead:{onlyTwoTeams:false},yellowLimit:3,
  zones:[{from:1,to:1,key:'promotion',label:'Oitavas de final'},{from:2,to:2,key:'playoff',label:'Playoffs contra os terceiros da Libertadores'}],
  knockout:{legs:2,extraTime:false,tied:'penalties',final:{legs:1,extraTime:true}},totalMatches:157,
  notes:'Primeira fase em jogo único entre clubes do mesmo país (empate vai aos pênaltis). Nos grupos entram os 16 vencedores, seis brasileiros, seis argentinos e os quatro eliminados na 3ª fase da Libertadores. Campeões de grupo vão às oitavas; os segundos enfrentam os terceiros dos grupos da Libertadores nos playoffs. Sorteios, mandos e datas são do simulador.',
  source:'Formato e vagas de 2026 · Conmebol (conforme a página da edição na Wikipédia, consultada em 12/10/2026)',verified:false}
];
export function rulesFor(id,season){
 const options=COMPETITION_RULES.filter(r=>r.id===id&&r.season<=season).sort((a,b)=>b.season-a.season||b.revision-a.revision);
 if(!options.length)throw Error(`Sem regulamento para ${id} em ${season}.`);
 return options[0].season===season?options[0]:{...options[0],carriedFrom:options[0].season};
}
export const zoneOf=(rules,position)=>rules.zones?.find(z=>position>=z.from&&position<=z.to)||null;
function hash(text){let h=2166136261;for(const c of String(text))h=Math.imul(h^c.charCodeAt(0),16777619)>>>0;return h}
const blank=code=>({code,played:0,w:0,d:0,l:0,gf:0,ga:0,gd:0,pts:0,yc:0,rc:0,form:[],home:{played:0,w:0,d:0,l:0,gf:0,ga:0,pts:0},away:{played:0,w:0,d:0,l:0,gf:0,ga:0,pts:0}});
function tally(table,matches,points){
 for(const m of matches){
  if(!m.played)continue;const a=table.get(m.home),b=table.get(m.away);if(!a||!b)continue;
  const sides=[[a,a.home,m.hg,m.ag,0],[b,b.away,m.ag,m.hg,1]];
  for(const [row,split,gf,ga,i] of sides){
   const result=gf>ga?'w':gf<ga?'l':'d',pts=result==='w'?points.win:result==='d'?points.draw:points.loss;
   for(const x of [row,split]){x.played++;x[result]++;x.gf+=gf;x.ga+=ga;x.pts+=pts}
   row.form.push(result.toUpperCase());row.yc+=m.st?.yellow?.[i]||0;row.rc+=m.st?.red?.[i]||0;
  }
 }
 for(const row of table.values())row.gd=row.gf-row.ga;
}
/** Classificação com critérios configuráveis. `matches` são os confrontos do calendário; só os disputados contam. */
export function rankTable(matches,codes,rules,salt=''){
 const points=rules.points||{win:3,draw:1,loss:0},table=new Map(codes.map(c=>[c,blank(c)]));tally(table,matches,points);
 const keyFor={
  wins:group=>new Map(group.map(r=>[r.code,[r.w]])),
  goalDifference:group=>new Map(group.map(r=>[r.code,[r.gd]])),
  goalsFor:group=>new Map(group.map(r=>[r.code,[r.gf]])),
  fewestReds:group=>new Map(group.map(r=>[r.code,[-r.rc]])),
  fewestYellows:group=>new Map(group.map(r=>[r.code,[-r.yc]])),
  fairPlay:group=>new Map(group.map(r=>[r.code,[-(r.yc+3*r.rc)]])),
  headToHead:group=>{
   if(rules.headToHead?.onlyTwoTeams&&group.length!==2)return null;
   const ids=group.map(r=>r.code),mini=new Map(ids.map(c=>[c,blank(c)]));tally(mini,matches.filter(m=>ids.includes(m.home)&&ids.includes(m.away)),points);
   // Sem todos os confrontos diretos disputados o critério ainda não se aplica.
   if([...mini.values()].some(r=>r.played===0))return null;
   return new Map(ids.map(c=>[c,[mini.get(c).pts,mini.get(c).gd,mini.get(c).gf]]));
  },
  draw:group=>new Map(group.map(r=>[r.code,[hash(`${salt}|${rules.id}|${r.code}`)]]))
 };
 const cmp=(a,b)=>{for(let i=0;i<a.length;i++)if(a[i]!==b[i])return b[i]-a[i];return 0};
 function resolve(group,index,reason){
  if(group.length<2){if(group[0])group[0].decidedBy=reason;return group}
  const criterion=rules.tiebreakers[index];if(!criterion)return [...group].sort((a,b)=>a.code.localeCompare(b.code)).map(r=>({...r,decidedBy:'ordem alfabética'}));
  const keys=keyFor[criterion]?.(group);if(!keys)return resolve(group,index+1,reason);
  const sorted=[...group].sort((a,b)=>cmp(keys.get(a.code),keys.get(b.code))),out=[];
  for(let i=0;i<sorted.length;){let j=i+1;while(j<sorted.length&&!cmp(keys.get(sorted[i].code),keys.get(sorted[j].code)))j++;out.push(...resolve(sorted.slice(i,j),index+1,j-i===sorted.length?reason:criterion));i=j}
  return out;
 }
 const byPoints=[...table.values()].sort((a,b)=>b.pts-a.pts),rows=[];
 for(let i=0;i<byPoints.length;){let j=i+1;while(j<byPoints.length&&byPoints[j].pts===byPoints[i].pts)j++;rows.push(...resolve(byPoints.slice(i,j),0,'points'));i=j}
 return rows.map((r,i)=>({...r,position:i+1,form:r.form.slice(-5),zone:zoneOf(rules,i+1)?.key||null}));
}
