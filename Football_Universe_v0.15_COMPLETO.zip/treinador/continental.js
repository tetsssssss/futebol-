// Torneios continentais de clubes da Conmebol: Libertadores e Sul-Americana na mesma temporada do universo de ligas.
// Vagas, sorteios, grupos, mata-mata em ida e volta e a passagem de clubes de um torneio para o outro.
// Opera sobre resultados confirmados; as partidas são jogadas pelo mesmo motor espacial das demais competições.
import {rulesFor,rankTable} from './rules.js';
import {CONMEBOL_COUNTRIES,ORDER_2026,HOLDERS_2026,countryOf} from './conmebol.js';
export const COMPETITIONS={lib:{id:'libertadores',ruleset:'conmebol-libertadores',prefix:'LIB',stages:['q1','q2','q3','groups','r16','qf','sf','final']},sula:{id:'sudamericana',ruleset:'conmebol-sudamericana',prefix:'SUL',stages:['s1','groups','po','r16','qf','sf','final']}};
export const STAGE_NAME={q1:'1ª fase preliminar',q2:'2ª fase preliminar',q3:'3ª fase preliminar',s1:'Primeira fase',groups:'Fase de grupos',po:'Playoffs',r16:'Oitavas de final',qf:'Quartas de final',sf:'Semifinais',final:'Final'};
const hash=text=>{let h=2166136261;for(const c of String(text))h=Math.imul(h^c.charCodeAt(0),16777619)>>>0;return h};
const byHash=(list,salt)=>[...list].sort((a,b)=>hash(`${salt}|${a}`)-hash(`${salt}|${b}`)||a.localeCompare(b));
const LETTERS='ABCDEFGH';
// Datas hipotéticas: três dias depois de uma rodada da liga, na ordem das janelas da Conmebol. [turno, semana].
const SLOTS={'lib:q1':[[0,0],[0,1]],'lib:q2':[[0,2],[0,3]],'lib:q3':[[0,4],[0,5]],'sula:s1':[[0,5]],groups:[[0,8],[0,9],[0,10],[0,12],[0,13],[0,15]],'sula:po':[[1,0],[1,1]],r16:[[1,3],[1,4]],qf:[[1,7],[1,8]],sf:[[1,11],[1,12]],'sula:final':[[1,15]],'lib:final':[[1,16]]};
const stageDates=(season,key,stage)=>(SLOTS[`${key}:${stage}`]||SLOTS[stage]).map(([half,week])=>new Date((half?Date.UTC(season,6,29):Date.UTC(season,0,28))+(week*7+3)*86400000).toISOString().slice(0,10));
export const competitionRules=(c,key)=>rulesFor(COMPETITIONS[key].ruleset,c.season);
export const tournaments=c=>[['lib',c.lib],['sula',c.sula]];
export const continentalFixtures=c=>c?[...c.lib.fixtures,...c.sula.fixtures]:[];
export const continentalDone=c=>!!(c.lib.champion&&c.sula.champion);
export const participants=T=>[...new Set(T.fixtures.flatMap(m=>[m.home,m.away]))];

/** Distribui as vagas da temporada. `order` traz, por país, os clubes por mérito; os campeões vigentes entram à parte. */
export function continentalEntry(order,holders,season){
 const L=rulesFor('conmebol-libertadores',season),S=rulesFor('conmebol-sudamericana',season),held=[...new Set([holders.libertadores,holders.sudamericana].filter(Boolean))];
 const entry={libertadores:{groups:[...held],second:[],first:[]},sudamericana:{groups:[],first:[]}},rank=Object.fromEntries(held.map(id=>[id,0]));
 for(const country of Object.keys(L.berths)){
  const list=(order[country]||[]).filter(id=>!held.includes(id)),b=L.berths[country],s=S.berths[country];let next=0,berth=0;
  const take=(count,target)=>{for(let k=0;k<count;k++){const id=list[next++];if(!id)throw Error(`Clubes insuficientes no diretório para as vagas de ${CONMEBOL_COUNTRIES[country]}.`);rank[id]=++berth;target.push(id)}};
  take(b.groups,entry.libertadores.groups);take(b.second,entry.libertadores.second);take(b.first,entry.libertadores.first);berth=0;
  take(s.groups,entry.sudamericana.groups);take(s.first,entry.sudamericana.first);
 }
 return {entry,rank};
}
// Quem tem a melhor vaga decide em casa; empate de vaga vai a sorteio.
const better=(c,a,b)=>(c.rank[a]??50)-(c.rank[b]??50)||hash(`${c.seed}|${a}`)-hash(`${c.seed}|${b}`);
const hostSecond=(c,[a,b])=>better(c,a,b)<=0?[b,a]:[a,b];
/** Sorteio de confrontos que evita clubes do mesmo país enquanto for possível. */
function drawPairs(c,teams,salt){
 if(teams.length%2)throw Error('Sorteio com número ímpar de clubes.');
 const solve=(left,strict)=>{if(!left.length)return [];const [a,...rest]=left;for(const b of rest){if(strict&&countryOf(a)===countryOf(b))continue;const tail=solve(rest.filter(x=>x!==b),strict);if(tail)return [[a,b],...tail]}return null};
 const pool=byHash(teams,`${c.seed}|${salt}`);return (solve(pool,true)||solve(pool,false)).map(p=>hostSecond(c,p));
}
/** Registra confrontos de uma fase. Em ida e volta, `second` é o mandante da volta; em jogo único, é o mandante. */
function addTies(c,key,stage,pairs,single=false){
 const T=c[key],dates=stageDates(c.season,key,stage),tag=`${COMPETITIONS[key].prefix}-${c.season}-${stage.toUpperCase()}`;
 pairs.forEach(([first,second],i)=>{
  const id=`${tag}-${i+1}`,base={comp:key,stage,tie:id,dateSource:'gerada pelo simulador',played:false};T.ties.push({id,stage,first,second,single});
  if(single)T.fixtures.push({id:`${id}-U`,...base,leg:0,home:second,away:first,date:dates[0]});
  else T.fixtures.push({id:`${id}-L1`,...base,leg:1,home:first,away:second,date:dates[0]},{id:`${id}-L2`,...base,leg:2,firstLeg:`${id}-L1`,home:second,away:first,date:dates[1]});
 });
 T.stage=stage;
}
/** Situação de um confronto: pernas, agregado, pênaltis e vencedor (nulo enquanto houver jogo pendente). */
export function tieResult(T,tie){
 const legs=T.fixtures.filter(m=>m.tie===tie.id);if(!legs.length||legs.some(m=>!m.played))return {...tie,legs,aggregate:null,penalties:null,winner:null,loser:null};
 const last=legs.at(-1),goals=code=>legs.reduce((n,m)=>n+(m.home===code?m.hg:m.ag),0),aggregate=[goals(tie.first),goals(tie.second)],pens=last.penalties||null;
 const winner=aggregate[0]!==aggregate[1]?(aggregate[0]>aggregate[1]?tie.first:tie.second):pens?(pens[0]>pens[1]?last.home:last.away):null;
 if(!winner)throw Error(`Confronto sem vencedor definido: ${tie.id}.`);
 return {...tie,legs,aggregate,penalties:pens,winner,loser:winner===tie.first?tie.second:tie.first};
}
export const stageTies=(T,stage)=>T.ties.filter(t=>t.stage===stage).map(t=>tieResult(T,t));
const stageDone=(T,stage)=>{const ties=stageTies(T,stage);return ties.length>0&&ties.every(t=>t.winner)};
const winnersOf=(T,stage)=>stageTies(T,stage).map(t=>t.winner),losersOf=(T,stage)=>stageTies(T,stage).map(t=>t.loser);
/** Sorteio dos grupos em quatro potes pela vaga de cada clube; `lastPot` reúne quem veio das fases anteriores. Evita o mesmo país no grupo. */
function startGroups(c,key,teams,lastPot){
 const T=c[key],salt=`${c.seed}|${key}`,seeded=[...teams.filter(id=>!lastPot.includes(id)).sort((a,b)=>better(c,a,b)),...byHash(lastPot,salt)],groups=Object.fromEntries([...LETTERS].map(l=>[l,[]]));
 if(seeded.length!==32||new Set(seeded).size!==32)throw Error('Fase de grupos requer 32 clubes distintos.');
 for(let pot=0;pot<4;pot++){
  const clubs=byHash(seeded.slice(pot*8,pot*8+8),`${salt}|pote${pot}`);
  const place=strict=>{const used=new Set(),out=[];const go=i=>{if(i===clubs.length)return true;for(const l of LETTERS){if(used.has(l)||strict&&groups[l].some(x=>countryOf(x)===countryOf(clubs[i])))continue;used.add(l);out[i]=l;if(go(i+1))return true;used.delete(l)}return false};return go(0)?out:null};
  const where=place(true)||place(false);clubs.forEach((id,i)=>groups[where[i]].push(id));
 }
 const dates=stageDates(c.season,key,'groups'),tag=`${COMPETITIONS[key].prefix}-${c.season}-G`,ROUNDS=[[[0,3],[1,2]],[[2,0],[3,1]],[[0,1],[3,2]]];
 for(const [group,codes] of Object.entries(groups))for(let day=0;day<6;day++)ROUNDS[day%3].forEach(([h,a],i)=>{const [home,away]=day<3?[codes[h],codes[a]]:[codes[a],codes[h]];
  T.fixtures.push({id:`${tag}-${group}-${day+1}-${i+1}`,comp:key,stage:'groups',group,matchday:day+1,home,away,date:dates[day],dateSource:'gerada pelo simulador',played:false})});
 T.groups=groups;T.stage='groups';
}
const groupsDone=T=>!!T.groups&&T.fixtures.every(m=>m.stage!=='groups'||m.played);
export const groupOfClub=(T,code)=>T.groups?Object.keys(T.groups).find(g=>T.groups[g].includes(code))||null:null;
export function groupTable(c,key,group){const T=c[key];return rankTable(T.fixtures.filter(m=>m.stage==='groups'&&m.group===group),T.groups[group],competitionRules(c,key),`${c.seed}|${key}|${group}`)}
/** Clubes que terminaram os grupos numa posição, do melhor para o pior (pontos, saldo, gols, sorteio). */
export function placed(c,key,position){
 return Object.keys(c[key].groups).map(g=>({...groupTable(c,key,g)[position-1],group:g})).sort((a,b)=>b.pts-a.pts||b.gd-a.gd||b.gf-a.gf||hash(`${c.seed}|${a.code}`)-hash(`${c.seed}|${b.code}`));
}
const BRACKET=[1,8,4,5,3,6,2,7]; // posição das oito chaves na árvore pelo cabeça de chave
// Emparelha cada cabeça de chave com o pior adversário disponível que não seja do mesmo grupo.
function pairOff(heads,others){
 const used=new Set(),out=[];
 const solve=i=>{if(i===heads.length)return true;for(let j=others.length-1;j>=0;j--){if(used.has(j)||others[j].group&&others[j].group===heads[i].group)continue;used.add(j);out[i]=others[j];if(solve(i+1))return true;used.delete(j)}return false};
 if(!solve(0))throw Error('Não foi possível montar as oitavas sem repetir grupo.');return out;
}
function startRoundOf16(c,key,heads,others){
 const T=c[key],rivals=pairOff(heads,others);T.seeds={};
 heads.forEach((h,i)=>{T.seeds[h.code]=i+1});others.forEach((o,i)=>{T.seeds[o.code]=9+i});
 addTies(c,key,'r16',BRACKET.map(seed=>[rivals[seed-1].code,heads[seed-1].code]));
}
function nextRound(c,key,stage,next){
 const T=c[key],w=winnersOf(T,stage),seed=id=>T.seeds?.[id]??99;
 addTies(c,key,next,Array.from({length:w.length/2},(_,i)=>seed(w[2*i])<=seed(w[2*i+1])?[w[2*i+1],w[2*i]]:[w[2*i],w[2*i+1]]),next==='final');
}
/** Cria os dois torneios da temporada com as primeiras fases sorteadas. */
export function createContinental(season=2026,order=ORDER_2026,holders=HOLDERS_2026,seed=`conmebol-${season}`){
 const {entry,rank}=continentalEntry(order,holders,season),blank=id=>({id,stage:null,groups:null,seeds:null,ties:[],fixtures:[],champion:null,stats:{season,players:{}}});
 const c={season,seed,holders:{...holders},order:structuredClone(order),entry,rank,lib:blank('libertadores'),sula:blank('sudamericana')};
 addTies(c,'lib','q1',drawPairs(c,entry.libertadores.first,'q1'));
 // Primeira fase da Sul-Americana: dois confrontos por país, em jogo único.
 const national=Object.keys(CONMEBOL_COUNTRIES).flatMap(country=>{const clubs=byHash(entry.sudamericana.first.filter(id=>countryOf(id)===country),`${seed}|s1`);return clubs.length?[[clubs[0],clubs[1]],[clubs[2],clubs[3]]]:[]});
 addTies(c,'sula','s1',national,true);
 return c;
}
/** Avança as fases depois de cada resultado: sorteios seguintes, grupos, transferências entre torneios e campeões. */
export function afterContinental(c){
 const L=c.lib,S=c.sula,e=c.entry;
 if(L.stage==='q1'&&stageDone(L,'q1'))addTies(c,'lib','q2',drawPairs(c,[...e.libertadores.second,...winnersOf(L,'q1')],'q2'));
 if(L.stage==='q2'&&stageDone(L,'q2'))addTies(c,'lib','q3',drawPairs(c,winnersOf(L,'q2'),'q3'));
 if(L.stage==='q3'&&stageDone(L,'q3'))startGroups(c,'lib',[...e.libertadores.groups,...winnersOf(L,'q3')],winnersOf(L,'q3'));
 // Os quatro eliminados na 3ª fase da Libertadores entram nos grupos da Sul-Americana.
 if(S.stage==='s1'&&stageDone(S,'s1')&&L.groups)startGroups(c,'sula',[...e.sudamericana.groups,...winnersOf(S,'s1'),...losersOf(L,'q3')],losersOf(L,'q3'));
 if(L.stage==='groups'&&groupsDone(L))startRoundOf16(c,'lib',placed(c,'lib',1),placed(c,'lib',2));
 // Playoffs da Sul-Americana: segundos dos grupos contra os terceiros dos grupos da Libertadores; o segundo colocado decide em casa.
 if(S.stage==='groups'&&groupsDone(S)&&groupsDone(L)){const seconds=placed(c,'sula',2),thirds=placed(c,'lib',3);addTies(c,'sula','po',seconds.map((r,i)=>[thirds[7-i].code,r.code]))}
 if(S.stage==='po'&&stageDone(S,'po')){const won=winnersOf(S,'po');startRoundOf16(c,'sula',placed(c,'sula',1),won.map(code=>({code,group:groupOfClub(S,code)})))}
 for(const [key,T] of tournaments(c)){
  for(const [stage,next] of [['r16','qf'],['qf','sf'],['sf','final']])if(T.stage===stage&&stageDone(T,stage))nextRound(c,key,stage,next);
  if(T.stage==='final'&&stageDone(T,'final')){T.champion=winnersOf(T,'final')[0];T.stage='done'}
 }
 return c;
}
/** Dia de jogos continental em aberto: as partidas pendentes de data mais antiga, nos dois torneios. */
export function continentalMatchday(c){
 const open=continentalFixtures(c).filter(m=>!m.played);if(!open.length)return null;
 const date=open.map(m=>m.date).sort()[0],matches=open.filter(m=>m.date===date);
 const names=[...new Set(matches.map(m=>rulesFor(COMPETITIONS[m.comp].ruleset,c.season).short))],same=new Set(matches.map(m=>m.stage)).size===1;
 const parts=[...new Set(matches.map(m=>`${rulesFor(COMPETITIONS[m.comp].ruleset,c.season).short}: ${stageCaption(m)}`))];
 return {date,matches,label:same?`${names.join(' e ')} · ${stageCaption(matches[0])}`:parts.join(' · ')};
}
const stageCaption=m=>m.stage==='groups'?`Fase de grupos, rodada ${m.matchday}`:`${STAGE_NAME[m.stage]}${m.leg?(m.leg===1?' · ida':' · volta'):''}`;
/** Legenda completa de uma partida continental. */
export const fixtureCaption=(m,season=2026)=>`${rulesFor(COMPETITIONS[m.comp].ruleset,season).short} · ${m.stage==='groups'?`Grupo ${m.group} · rodada ${m.matchday}`:stageCaption(m)}`;
/** Parâmetros de partida conforme o regulamento: agregado na volta, pênaltis sem prorrogação, final com prorrogação. */
export function continentalSetup(c,fixture){
 if(fixture.stage==='groups'||fixture.leg===1)return {knockout:false,options:{}};
 const rules=competitionRules(c,fixture.comp).knockout;
 if(fixture.stage==='final')return {knockout:true,options:{noExtraTime:!rules.final.extraTime}};
 if(fixture.leg===0)return {knockout:true,options:{noExtraTime:!rules.extraTime}};
 const first=c[fixture.comp].fixtures.find(m=>m.id===fixture.firstLeg);if(!first?.played)throw Error('A partida de ida ainda não foi disputada.');
 return {knockout:true,options:{aggregate:[first.ag,first.hg],noExtraTime:!rules.extraTime}};
}
/** Árvore do mata-mata para desenhar: uma coluna por fase, com vagas indefinidas descritas pela chave de origem. */
export function bracketColumns(T){
 const sizes=[['r16',8],['qf',4],['sf',2],['final',1]];
 return sizes.map(([stage,count],index)=>{const real=stageTies(T,stage);return {stage,ties:Array.from({length:count},(_,i)=>real[i]||{id:`${stage}-pendente-${i+1}`,stage,pending:true,
  firstLabel:index&&T.seeds?`Vencedor ${STAGE_NAME[sizes[index-1][0]]} ${2*i+1}`:'A definir',secondLabel:index&&T.seeds?`Vencedor ${STAGE_NAME[sizes[index-1][0]]} ${2*i+2}`:'A definir'})}});
}
/** Caminho de um clube num torneio, na ordem dos jogos. */
export function clubCampaign(T,code){
 return T.fixtures.filter(m=>m.played&&(m.home===code||m.away===code)).sort((a,b)=>a.date.localeCompare(b.date)).map(m=>{const home=m.home===code,gf=home?m.hg:m.ag,ga=home?m.ag:m.hg,pens=m.penalties?(home?m.penalties:[m.penalties[1],m.penalties[0]]):null;
  return {id:m.id,stage:m.stage,group:m.group||null,leg:m.leg||0,opponent:home?m.away:m.home,home,gf,ga,penalties:pens,result:gf>ga?'W':gf<ga?'L':pens?(pens[0]>pens[1]?'W':'L'):'D'}});
}
/** Onde o clube está em cada torneio: fase de entrada, fase atual ou em que fase caiu. */
export function clubStatus(c,key,code){
 const T=c[key],e=c.entry[COMPETITIONS[key].id],entered=Object.keys(e).find(stage=>e[stage].includes(code)),played=participants(T).includes(code);
 if(!entered&&!played)return null;
 if(T.champion===code)return {state:'champion',label:'Campeão'};
 const lost=T.ties.map(t=>tieResult(T,t)).find(t=>t.loser===code);if(lost)return {state:'out',label:`Eliminado · ${STAGE_NAME[lost.stage]}`};
 const group=groupOfClub(T,code);
 if(group&&groupsDone(T)){
  // Libertadores: 1º e 2º avançam e o 3º cai para a Sul-Americana. Sul-Americana: 1º vai às oitavas e o 2º aos playoffs.
  const position=groupTable(c,key,group).findIndex(r=>r.code===code)+1;
  if(key==='lib'&&position===3)return {state:'out',label:`3º do Grupo ${group} · vai à Sul-Americana`};
  if(position>2)return {state:'out',label:`Eliminado · ${position}º do Grupo ${group}`};
 }
 if(!played)return {state:'waiting',label:entered==='groups'?'Aguarda a fase de grupos':`Aguarda a ${STAGE_NAME[entered==='second'?'q2':key==='lib'?'q1':'s1']}`};
 return {state:'alive',label:T.stage==='done'?'Encerrado':STAGE_NAME[T.stage]||''};
}
export function continentalSummary(c){
 return Object.fromEntries(tournaments(c).map(([key,T])=>{const final=stageTies(T,'final')[0],game=final?.legs[0];
  return [COMPETITIONS[key].id,{champion:T.champion,runnerUp:final?.loser||null,score:game?.played?[game.home,game.hg,game.ag,game.away]:null,penalties:game?.penalties||null}]}));
}
// Campanha da edição encerrada: quanto mais longe, maior o valor. Ordena as vagas dos países cujas ligas não são simuladas.
const MERIT={lib:{q1:1,q2:2,q3:3,group4:4,group3:5,r16:7,qf:8,sf:9,final:10,champion:11},sula:{s1:.5,group4:2,group3:2,group2:3,po:3,r16:4,qf:5,sf:6,final:7,champion:8}};
export function continentalMerit(c){
 const merit={},set=(id,value)=>{merit[id]=Math.max(merit[id]??0,value)};
 for(const [key,T] of tournaments(c)){
  for(const id of participants(T))set(id,0);
  for(const t of T.ties.map(t=>tieResult(T,t)))if(t.loser)set(t.loser,MERIT[key][t.stage]);
  if(T.groups&&groupsDone(T))for(const g of Object.keys(T.groups))groupTable(c,key,g).forEach((r,i)=>{const value=MERIT[key][`group${i+1}`];if(value)set(r.code,value)});
  if(T.champion)set(T.champion,MERIT[key].champion);
 }
 return merit;
}
/** Ordem de vagas da temporada seguinte. Brasil: tabela final da Série A. Demais países: campanha continental anterior,
 * com rodízio declarado — o participante de pior campanha vai ao fim da fila e quem esperava entra. */
export function nextContinentalOrder(c,brazil){
 const merit=continentalMerit(c),order={BRA:[...brazil]};
 for(const [country,list] of Object.entries(c.order)){
  if(country==='BRA')continue;
  const played=list.filter(id=>id in merit).sort((a,b)=>merit[b]-merit[a]||list.indexOf(a)-list.indexOf(b)),idle=list.filter(id=>!(id in merit));
  order[country]=idle.length&&played.length?[...played.slice(0,-1),...idle,played.at(-1)]:[...played,...idle];
 }
 return order;
}
/** Edição seguinte: campeões vigentes com vaga própria e ordem de vagas recalculada. Sem edição anterior, parte da base de 2026. */
export function rollContinental(previous,season,brazil){
 if(!previous)return createContinental(season,{...ORDER_2026,BRA:[...brazil]},HOLDERS_2026);
 if(!continentalDone(previous))throw Error('Os torneios continentais ainda têm partidas pendentes.');
 return createContinental(season,nextContinentalOrder(previous,brazil),{libertadores:previous.lib.champion,sudamericana:previous.sula.champion});
}
export function validateContinental(c,known){
 if(!c||!Number.isInteger(c.season)||typeof c.seed!=='string'||!c.entry||!c.order||!c.rank||!c.lib||!c.sula)throw Error('Torneios continentais inválidos.');
 const ids=new Set();
 for(const [key,T] of tournaments(c)){
  const rules=competitionRules(c,key),e=c.entry[COMPETITIONS[key].id],entrants=Object.values(e).flat();
  if(!Array.isArray(T.fixtures)||!Array.isArray(T.ties)||![...COMPETITIONS[key].stages,'done'].includes(T.stage))throw Error('Torneio continental inválido.');
  if(new Set(entrants).size!==entrants.length||entrants.length!==rules.teams-(key==='sula'?12:0)||entrants.some(id=>!known.has(id)))throw Error('Participantes continentais inválidos.');
  if(T.groups&&(Object.keys(T.groups).length!==rules.groups.count||Object.values(T.groups).some(g=>!Array.isArray(g)||g.length!==rules.groups.size)||new Set(Object.values(T.groups).flat()).size!==32))throw Error('Grupos continentais inválidos.');
  if(T.fixtures.length>rules.totalMatches||T.champion&&T.stage!=='done')throw Error('Calendário continental inválido.');
  for(const m of T.fixtures){
   if(ids.has(m.id)||m.comp!==key||!known.has(m.home)||!known.has(m.away)||m.home===m.away||typeof m.played!=='boolean'||!/^\d{4}-\d{2}-\d{2}$/.test(m.date||''))throw Error('Confronto continental inválido.');ids.add(m.id);
   if(m.played&&(!Number.isInteger(m.hg)||!Number.isInteger(m.ag)||m.hg<0||m.ag<0||m.hg>30||m.ag>30))throw Error('Placar inválido');
  }
  for(const t of T.ties)if(!T.fixtures.some(m=>m.tie===t.id)||!known.has(t.first)||!known.has(t.second))throw Error('Chave continental inválida.');
 }
 return true;
}
