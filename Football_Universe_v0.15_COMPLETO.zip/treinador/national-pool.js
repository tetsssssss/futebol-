// Elencos de seleções a partir da "base de 2026": listas da Copa (48 seleções) + base EA FC 26 (demais atletas).
// Cada seleção recebe 23 convocados e uma pré-lista de até 17. Onde a base não tem atletas suficientes,
// as vagas ficam com posições neutras marcadas como tal — nenhum jogador é inventado.
import {attributeProfile,position} from '../copa/engine.js';
import {NATIONS,nationCode,cleanName} from './nations.js';
import {faceFile} from '../src/media.js';
export const SQUAD_SIZE=23,PRELIST_MIN=15,PRELIST_MAX=17,POOL_VERSION=1;
const LINES={GK:['GK'],DEF:['CB','LB','RB','LWB','RWB'],MID:['CM','DM','AM','LM','RM'],FWD:['ST','CF','LW','RW']},QUOTA={GK:3,DEF:7,MID:7,FWD:6};
const lineOf=p=>Object.keys(LINES).find(k=>LINES[k].includes(p.position))||'MID',best=(a,b)=>(b.overall||0)-(a.overall||0)||a.name.localeCompare(b.name);
const GK_KEYS=new Set(['reflexes','handling','oneOnOnes','aerialReach','command','distribution','kicking']);
/** Vaga neutra: identifica uma posição sem atleta na base. Atributos planos, sem identidade. */
export function neutralPlayer(code,pos,index,keys){return {id:`${code}-slot-${index}`,name:`Posição ${pos} ${index+1}`,code,position:pos,number:index+1,overall:60,attrs:Object.fromEntries(keys.map(k=>[k,GK_KEYS.has(k)?(pos==='GK'?64:15):60])),placeholder:true,basis:'Sem atleta na base'}}
/** "KIM Seunggyu" / "WEVERTON" → "Kim Seunggyu" / "Weverton": só muda a caixa das palavras em maiúsculas. */
export const tidyName=name=>String(name||'').split(/\s+/).map(t=>t.length>1&&t===t.toUpperCase()?t[0]+t.slice(1).toLowerCase():t).join(' ');
const num=v=>{const n=Number(v);return Number.isFinite(n)&&String(v??'')!==''?n:null};
export function playerFromRow(code,row,keys){
 return {id:`ea-${row.player_id}`,name:row.long_name||row.short_name,shortName:row.short_name||null,code,position:position(row.player_positions),number:num(row.nation_jersey_number)||0,overall:num(row.overall)||60,potential:num(row.potential),age:num(row.age),born:row.dob||null,
  height:num(row.height_cm),foot:row.preferred_foot||null,club:row.club_name||null,league:row.league_name||null,joined:row.club_joined_date||null,reputation:num(row.international_reputation),
  photo:row.player_face_url||null,photoSource:row.player_face_url?'EA FC 26 / SoFIFA':null,attrs:attributeProfile(row,keys),basis:'Base EA FC 26'};
}
/** Casa os nomes da lista oficial ("Jose Maria GIMENEZ", "KIM Minjae") com a base ("José María Giménez de Vargas", "Min-jae Kim").
 * Exige o sobrenome inteiro e algum sinal do prenome; empates entre candidatos ficam sem casar, para não trocar atletas. */
export function matchListed(listed,rows){
 const squash=tokens=>tokens.join(''),candidates=rows.map(row=>{const long=cleanName(row.long_name).split(' ').filter(Boolean),short=cleanName(row.short_name).split(' ').filter(Boolean);return {row,long:new Set(long),short,all:squash(long),names:[long.join(' '),short.join(' ')],keeper:/GK/.test(row.player_positions||'')}});
 const options=[];
 listed.forEach((p,index)=>{
  const raw=String(p.name||'').split(/\s+/).filter(Boolean),upper=raw.filter(t=>t.length>1&&t===t.toUpperCase()&&/[A-ZÀ-Ý]/.test(t)),family=(upper.length?upper:raw.slice(-1)).flatMap(t=>cleanName(t).split(' ')).filter(Boolean),given=raw.filter(t=>!(upper.length?upper:raw.slice(-1)).includes(t)).flatMap(t=>cleanName(t).split(' ')).filter(Boolean),keeper=position(p.pos)==='GK';
  if(!family.length)return;
  for(const c of candidates){
   if(!family.every(t=>c.long.has(t)||c.short.includes(t)))continue;
   const hits=given.filter(t=>c.long.has(t)).length,joined=given.length>0&&c.all.includes(squash(given)),initial=given.length>0&&c.short[0]?.length===1&&c.short[0]===given[0][0];
   if(given.length&&!hits&&!joined&&!initial)continue;
   options.push({index,row:c.row,score:family.length*3+hits*2+(joined?2:0)+(initial?1:0)+(c.keeper===keeper?1:-5)+(c.names.includes(cleanName(p.name))?10:0)});
  }
 });
 const out=new Map(),used=new Set(),best=new Map();
 for(const o of options){const b=best.get(o.index);if(!b||o.score>b.score)best.set(o.index,{score:o.score,count:1});else if(o.score===b.score)b.count++}
 for(const o of options.sort((a,b)=>b.score-a.score)){const b=best.get(o.index);if(out.has(o.index)||used.has(o.row.player_id)||o.score<b.score||b.count>1||o.score<4)continue;out.set(o.index,o.row);used.add(o.row.player_id)}
 return out;
}
function pickSquad(players){
 const pool=[...players].sort(best),squad=[];
 for(const line of Object.keys(QUOTA))squad.push(...pool.filter(p=>lineOf(p)===line).slice(0,QUOTA[line]));
 const used=new Set(squad.map(p=>p.id));squad.push(...pool.filter(p=>!used.has(p.id)).slice(0,SQUAD_SIZE-squad.length));
 return squad.slice(0,SQUAD_SIZE);
}
function pickReserve(rest){
 const pool=[...rest].sort(best),keeper=pool.find(p=>p.position==='GK'),out=keeper?[keeper]:[];
 for(const p of pool){if(out.length>=PRELIST_MAX)break;if(p!==keeper)out.push(p)}return out.sort(best);
}
function completeSquad(code,real,keys){
 // Completa até 23 com vagas neutras, garantindo ao menos três goleiros e gente suficiente em cada linha para montar um time.
 const squad=[...real];let slot=0;const need={GK:3,DEF:6,MID:6,FWD:4},fill={GK:'GK',DEF:['CB','CB','RB','LB','CB','RB','LB'],MID:['CM','DM','AM','CM','DM','CM','AM'],FWD:['ST','RW','LW','ST','RW','LW']};
 for(const line of Object.keys(need)){let have=squad.filter(p=>lineOf(p)===line).length,i=0;while(have<need[line]&&squad.length<SQUAD_SIZE){squad.push(neutralPlayer(code,line==='GK'?'GK':fill[line][i++%fill[line].length],slot++,keys));have++}}
 const cycle=['CB','CM','ST','RB','LB','DM','AM','RW','LW'];let c=0;while(squad.length<SQUAD_SIZE)squad.push(neutralPlayer(code,cycle[c++%cycle.length],slot++,keys));
 return squad;
}
function numbered(squad){const taken=new Set();let next=1;return squad.map(p=>{let n=p.number>0&&p.number<100&&!taken.has(p.number)?p.number:0;if(!n){while(taken.has(next))next++;n=next}taken.add(n);return {...p,number:n}})}
export const squadPower=squad=>{const top=[...squad].sort((a,b)=>b.overall-a.overall).slice(0,11);return Math.round(top.reduce((n,p)=>n+p.overall,0)/top.length*10)/10};
/** Monta os elencos de todas as federações. `fifa` são as listas da Copa de 2026 por código; `rows` é a base de atletas. */
export function buildNationalPool(fifa,rows,keys,builtAt=null){
 const byNation=new Map();for(const row of rows||[]){const code=nationCode(row.nationality_name);if(!code)continue;if(!byNation.has(code))byNation.set(code,[]);byNation.get(code).push(row)}
 const nations={};
 for(const {code} of NATIONS){
  const eligible=byNation.get(code)||[],listed=fifa?.[code]?.players||[];let called=[],others;
  if(listed.length){
   const pairs=matchListed(listed,eligible),matched=new Set();
   called=listed.map((p,i)=>{const row=pairs.get(i),pos=position(p.pos);if(row)matched.add(row.player_id);
    const base=row?playerFromRow(code,row,keys):{id:`fifa-${code}-${p.id||i}`,name:tidyName(p.name),code,position:pos,overall:65,attrs:attributeProfile({overall:65,player_positions:pos,player_id:p.id||i},keys),estimated:true,basis:'Lista da Copa 2026 · atributos estimados por posição'};
    return {...base,position:pos,number:Number(p.shirt)||base.number||0,captain:Boolean(p.captain),photo:p.picture||base.photo||null,photoSource:p.picture?'FIFA':base.photoSource||null,listed2026:true}});
   others=eligible.filter(r=>!matched.has(r.player_id)).map(r=>playerFromRow(code,r,keys));
  }else others=eligible.map(r=>playerFromRow(code,r,keys));
  let core=listed.length?pickSquad(called):pickSquad(others);
  // Sem três goleiros na base: abre vaga tirando os atletas de linha de menor avaliação, e a vaga vira goleiro neutro.
  const missing=Math.max(0,3-core.filter(p=>p.position==='GK').length),overflow=core.length+missing-SQUAD_SIZE;
  if(overflow>0){const drop=new Set([...core].filter(p=>p.position!=='GK').sort((a,b)=>a.overall-b.overall).slice(0,overflow).map(p=>p.id));core=core.filter(p=>!drop.has(p.id))}
  const coreIds=new Set(core.map(p=>p.id));
  const rest=[...called.filter(p=>!coreIds.has(p.id)),...others.filter(p=>!coreIds.has(p.id))],squad=numbered(core.length<SQUAD_SIZE?completeSquad(code,core,keys):core);
  const reserve=pickReserve(rest),real=squad.filter(p=>!p.placeholder).length+reserve.length;
  nations[code]={code,squad,reserve,real,placeholders:squad.filter(p=>p.placeholder).length,keepers:[...squad,...reserve].filter(p=>p.position==='GK'&&!p.placeholder).length,
   complete:squad.every(p=>!p.placeholder)&&reserve.length>=PRELIST_MIN,power:squadPower(squad),from2026List:listed.length>0};
 }
 return {version:POOL_VERSION,builtAt,source:'Listas da Copa 2026 + base EA FC 26',nations};
}
/** Resumo de cobertura: quantas seleções têm 23 + pré-lista reais, por confederação. */
export function poolCoverage(pool){
 const out={total:0,complete:0,partial:0,empty:0,players:0,photos:0,local:0,listPhotos:0,estimated:0,byConfederation:{}};
 for(const n of NATIONS){const e=pool.nations[n.code],c=out.byConfederation[n.confederation]??={total:0,complete:0,partial:0,empty:0};out.total++;c.total++;const kind=!e||!e.real?'empty':e.complete?'complete':'partial';out[kind]++;c[kind]++;
  if(e)for(const p of [...e.squad,...e.reserve])if(!p.placeholder){out.players++;if(p.photo)out.photos++;if(faceFile(p))out.local++;if(p.photoSource==='FIFA')out.listPhotos++;if(p.estimated)out.estimated++}}
 return out;
}
export function validatePool(pool){
 if(!pool||pool.version!==POOL_VERSION||!pool.nations||typeof pool.nations!=='object')throw Error('Base de seleções inválida.');
 for(const n of NATIONS){const e=pool.nations[n.code];if(!e||e.squad?.length!==SQUAD_SIZE||!Array.isArray(e.reserve)||e.reserve.length>PRELIST_MAX)throw Error(`Elenco inválido: ${n.code}`);
  const ids=[...e.squad,...e.reserve].map(p=>p.id);if(new Set(ids).size!==ids.length)throw Error(`Atleta repetido: ${n.code}`);if(!e.squad.some(p=>p.position==='GK'))throw Error(`Sem goleiro: ${n.code}`);
  for(const p of [...e.squad,...e.reserve])if(!p.name||!p.position||!p.attrs||Object.values(p.attrs).some(v=>!Number.isInteger(v)||v<0||v>100))throw Error(`Ficha inválida: ${n.code}/${p.name}`)}
 return true;
}
