// Diretório de clubes da Conmebol fora do Brasil e ordem de vagas da edição de 2026.
// Participantes e fase de entrada de 2026 conforme as páginas das edições na Wikipédia (consultadas em 12/10/2026).
// Elencos não cadastrados: os clubes jogam com posições neutras. Cor = identidade visual; sem cor declarada, usa-se uma cor derivada do id.
import {fallbackColor} from './nations.js';
export const CONMEBOL_COUNTRIES={ARG:'Argentina',BOL:'Bolívia',BRA:'Brasil',CHI:'Chile',COL:'Colômbia',ECU:'Equador',PAR:'Paraguai',PER:'Peru',URU:'Uruguai',VEN:'Venezuela'};
// Por país, na ordem de vaga de 2026: Libertadores primeiro, depois Sul-Americana. `RESERVES` são clubes reais que não jogaram em 2026.
const FOREIGN={
 ARG:[['ar-lanus','Lanús','LAN','#7a1f3d'],['ar-platense','Platense','PLA','#7a5a3a'],['ar-estudiantes','Estudiantes de La Plata','EST','#d8323a'],['ar-independiente-rivadavia','Independiente Rivadavia','IRV','#2c5fb0'],['ar-rosario-central','Rosario Central','ROS','#f2c230'],['ar-boca-juniors','Boca Juniors','BOC','#1f4e9c'],['ar-argentinos-juniors','Argentinos Juniors','ARJ','#d6323b'],
  ['ar-river-plate','River Plate','RIV','#ededed'],['ar-racing','Racing','RAC','#7fbfe9'],['ar-deportivo-riestra','Deportivo Riestra','RIE','#e8e8e8'],['ar-san-lorenzo','San Lorenzo','SLO','#2a4f9f'],['ar-tigre','Tigre','TIG','#2c4fa0'],['ar-barracas-central','Barracas Central','BAR','#d8323a']],
 BOL:[['bo-always-ready','Always Ready','ALW','#d8323a'],['bo-bolivar','Bolívar','BLV','#6fb4e8'],['bo-nacional-potosi','Nacional Potosí','NPO','#d8323a'],['bo-the-strongest','The Strongest','STR','#f2c230'],
  ['bo-san-antonio','San Antonio Bulo Bulo','SAB'],['bo-blooming','Blooming','BLO','#6fb4e8'],['bo-independiente-petrolero','Independiente Petrolero','IPE'],['bo-guabira','Guabirá','GUA','#d8323a']],
 CHI:[['cl-coquimbo-unido','Coquimbo Unido','COQ','#f2c230'],['cl-universidad-catolica','Universidad Católica (CHI)','UCA','#efefef'],['cl-ohiggins',"O'Higgins",'OHI','#6fb4e8'],['cl-huachipato','Huachipato','HUA','#2c5fb0'],
  ['cl-universidad-de-chile','Universidad de Chile','UCH','#2a4f9f'],['cl-audax-italiano','Audax Italiano','AUD','#2f8f5b'],['cl-palestino','Palestino','PLT','#efefef'],['cl-cobresal','Cobresal','COB','#f08a2e']],
 COL:[['co-santa-fe','Santa Fe','SFE','#d8323a'],['co-junior','Junior','JUN','#d8323a'],['co-deportes-tolima','Deportes Tolima','TOL','#8a2a48'],['co-independiente-medellin','Independiente Medellín','DIM','#d8323a'],
  ['co-atletico-nacional','Atlético Nacional','ATN','#2f9e5b'],['co-america-de-cali','América de Cali','AMC','#d6282f'],['co-atletico-bucaramanga','Atlético Bucaramanga','BUC','#f2c230'],['co-millonarios','Millonarios','MIL','#2a4f9f']],
 ECU:[['ec-independiente-del-valle','Independiente del Valle','IDV','#2f4fa0'],['ec-ldu-quito','LDU Quito','LDU','#efefef'],['ec-barcelona','Barcelona (EQU)','BSC','#f2d13a'],['ec-universidad-catolica','Universidad Católica (EQU)','UCE','#6fb4e8'],
  ['ec-orense','Orense','ORE'],['ec-libertad','Libertad (EQU)','LFC'],['ec-macara','Macará','MAC','#6fb4e8'],['ec-deportivo-cuenca','Deportivo Cuenca','CUE','#d8323a']],
 PAR:[['py-cerro-porteno','Cerro Porteño','CER','#2c4fa0'],['py-libertad','Libertad (PAR)','LIB','#efefef'],['py-guarani','Guaraní','GRN','#f2c230'],['py-2-de-mayo','2 de Mayo','2DM','#2c5fb0'],
  ['py-sportivo-trinidense','Sportivo Trinidense','TRI','#f2c230'],['py-nacional','Nacional (PAR)','NAP','#efefef'],['py-recoleta','Recoleta','REC'],['py-olimpia','Olimpia','OLI','#efefef']],
 PER:[['pe-universitario','Universitario','UNI','#f3e7c0'],['pe-cusco','Cusco','CUS','#c9a44a'],['pe-sporting-cristal','Sporting Cristal','SCR','#6fb4e8'],['pe-alianza-lima','Alianza Lima','ALI','#2a3f7f'],
  ['pe-alianza-atletico','Alianza Atlético','AAT'],['pe-melgar','Melgar','MEL','#c9333b'],['pe-deportivo-garcilaso','Deportivo Garcilaso','GAR'],['pe-cienciano','Cienciano','CIE','#d8323a']],
 URU:[['uy-nacional','Nacional (URU)','NAC','#efefef'],['uy-penarol','Peñarol','PEN','#f2c230'],['uy-liverpool','Liverpool (URU)','LIV','#2c4fa0'],['uy-juventud','Juventud de Las Piedras','JLP'],
  ['uy-defensor-sporting','Defensor Sporting','DEF','#7a4fa0'],['uy-boston-river','Boston River','BOS'],['uy-racing','Racing (URU)','RCM'],['uy-montevideo-city-torque','Montevideo City Torque','MCT','#7fbfe9']],
 VEN:[['ve-universidad-central','Universidad Central','UCV'],['ve-deportivo-la-guaira','Deportivo La Guaira','DLG','#f08a2e'],['ve-carabobo','Carabobo','CBO','#8a2a48'],['ve-deportivo-tachira','Deportivo Táchira','TAC','#f2c230'],
  ['ve-puerto-cabello','Academia Puerto Cabello','APC'],['ve-monagas','Monagas','MON','#2c5fb0'],['ve-caracas','Caracas','CCS','#c2313a'],['ve-metropolitanos','Metropolitanos','MET','#7a4fa0']]
};
const RESERVES={
 ARG:[['ar-velez-sarsfield','Vélez Sarsfield','VEL','#efefef'],['ar-independiente','Independiente','IND','#d6282f'],['ar-talleres','Talleres','TAL','#2a4a8f']],
 BOL:[['bo-oriente-petrolero','Oriente Petrolero','ORI','#2f9e5b'],['bo-aurora','Aurora','AUR','#6fb4e8']],
 CHI:[['cl-colo-colo','Colo-Colo','CCL','#efefef'],['cl-nublense','Ñublense','NUB','#d8323a']],
 COL:[['co-once-caldas','Once Caldas','ONC','#efefef'],['co-deportivo-cali','Deportivo Cali','CAL','#2f9e5b']],
 ECU:[['ec-emelec','Emelec','EME','#2c5fb0'],['ec-aucas','Aucas','AUC','#f2c230']],
 PAR:[['py-sportivo-luqueno','Sportivo Luqueño','LUQ','#2c5fb0'],['py-sportivo-ameliano','Sportivo Ameliano','AML']],
 PER:[['pe-sport-huancayo','Sport Huancayo','SHU','#d8323a'],['pe-atletico-grau','Atlético Grau','GRA']],
 URU:[['uy-danubio','Danubio','DAN','#efefef'],['uy-cerro-largo','Cerro Largo','CLA','#2c5fb0']],
 VEN:[['ve-estudiantes-de-merida','Estudiantes de Mérida','EDM','#d8323a'],['ve-zamora','Zamora','ZAM','#efefef']]
};
const club=(country,reserve)=>([id,name,short,color])=>({id,name,short,color:color||fallbackColor(id),country,reserve});
export const CONMEBOL_CLUBS=Object.keys(FOREIGN).flatMap(country=>[...FOREIGN[country].map(club(country,false)),...RESERVES[country].map(club(country,true))]);
const COUNTRY_OF=new Map(CONMEBOL_CLUBS.map(c=>[c.id,c.country]));
/** País do clube: os de fora vêm do diretório; qualquer outro id pertence ao universo de ligas brasileiro. */
export const countryOf=id=>COUNTRY_OF.get(id)||'BRA';
// Campeões de 2025, que entram na Libertadores de 2026 com vaga própria.
export const HOLDERS_2026={libertadores:'flamengo',sudamericana:'ar-lanus'};
// Ordem de vagas de 2026 (sem os campeões vigentes). Brasil: Copa do Brasil e Série A de 2025, depois os seis da Sul-Americana.
export const ORDER_2026={
 BRA:['flamengo','corinthians','palmeiras','cruzeiro','mirassol','fluminense','botafogo','bahia','sao-paulo','gremio','bragantino','atletico-mg','santos','vasco'],
 ...Object.fromEntries(Object.keys(FOREIGN).map(country=>[country,[...FOREIGN[country],...RESERVES[country]].map(c=>c[0])]))
};
export const CONMEBOL_SOURCE='Participantes e fases de entrada de 2026: páginas "2026 Copa Libertadores" e "2026 Copa Sudamericana" da Wikipédia, consultadas em 12/10/2026';
