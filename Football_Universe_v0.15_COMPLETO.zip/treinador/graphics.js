import {clamp,lerp} from './math.js';
export function cameraTransform(width,height,camera){
 const margin=Math.max(18,width*.038),scale=Math.min((width-margin*2)/105,(height-margin*2)/68)/(camera.mode==='broadcast'?1.08:1),cx=width/2,cy=height/2;
 return (x,y,z=0)=>{const yy=(y-camera.y)*.68,xx=(x-camera.x)*1.05,depth=camera.mode==='broadcast'?(.86+(y/100)*.22):1;return {x:cx+xx*scale*camera.zoom*depth,y:cy+yy*scale*camera.zoom*(camera.mode==='broadcast'?.87:1)-z*scale*.8,scale:scale*camera.zoom*depth};};
}
export function strokePath(ctx,project,points,close=false){ctx.beginPath();points.forEach(([x,y],i)=>{const p=project(x,y);i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y)});if(close)ctx.closePath();ctx.stroke();}
export function circlePath(ctx,project,x,y,r){const points=Array.from({length:49},(_,i)=>[x+Math.cos(i*Math.PI/24)*r/1.05,y+Math.sin(i*Math.PI/24)*r/.68]);strokePath(ctx,project,points);}
export function fillPitch(ctx,project,width,height){
 ctx.fillStyle='#081b20';ctx.fillRect(0,0,width,height);
 for(let i=0;i<20;i++){const points=[[i*5,0],[(i+1)*5,0],[(i+1)*5,100],[i*5,100]].map(([x,y])=>project(x,y));ctx.beginPath();points.forEach((p,j)=>j?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.closePath();ctx.fillStyle=i%2?'#22634c':'#266e52';ctx.fill();}
 ctx.strokeStyle='#f1fbeef2';ctx.lineWidth=1.6;strokePath(ctx,project,[[0,0],[100,0],[100,100],[0,100]],true);strokePath(ctx,project,[[50,0],[50,100]]);circlePath(ctx,project,50,50,9.15);
 for(const side of [0,1]){const x=side?100:0,dir=side?-1:1;strokePath(ctx,project,[[x,20.35],[x+dir*15.71,20.35],[x+dir*15.71,79.65],[x,79.65]]);strokePath(ctx,project,[[x,36.53],[x+dir*5.24,36.53],[x+dir*5.24,63.47],[x,63.47]]);const spot=project(x+dir*10.48,50);ctx.beginPath();ctx.arc(spot.x,spot.y,1.7,0,7);ctx.fillStyle='#d5f0d2';ctx.fill();
  // Penalty arc is the portion outside the box.
  const arc=[];for(let i=0;i<=28;i++){const a=-.92+i*1.84/28;arc.push([x+dir*(10.48+Math.cos(a)*9.15/1.05),50+Math.sin(a)*9.15/.68])}strokePath(ctx,project,arc);
  ctx.strokeStyle='#effff6';ctx.lineWidth=2.4;strokePath(ctx,project,[[x,44.62],[x-dir*2,44.62],[x-dir*2,55.38],[x,55.38]]);ctx.strokeStyle='#e2f5ee45';ctx.lineWidth=.6;for(let j=1;j<6;j++)strokePath(ctx,project,[[x,44.62+j*1.79],[x-dir*2,44.62+j*1.79]]);ctx.strokeStyle='#f1fbeef2';ctx.lineWidth=1.6;
 }
 for(const [x,y] of [[0,0],[0,100],[100,0],[100,100]]){const pts=[];for(let i=0;i<=12;i++){const a=i*Math.PI/24;pts.push([x+(x===100?-1:1)*Math.cos(a)/1.05,y+(y===100?-1:1)*Math.sin(a)/.68])}strokePath(ctx,project,pts);}
 const center=project(50,50);ctx.beginPath();ctx.arc(center.x,center.y,1.7,0,7);ctx.fillStyle='#e5f9e1';ctx.fill();
}
export function kitColors(home,away){const rgb=c=>[1,3,5].map(i=>parseInt((c||'#7098aa').slice(i,i+2),16)||0),a=rgb(home),b=rgb(away);return [home||'#e64f63',Math.hypot(...a.map((v,i)=>v-b[i]))<125?'#f2e7bc':away||'#c6e7ff'];}
/** Uniformes das duas equipes (principal, secundária, padrão). Se as camisas se confundem, a visitante usa a cor secundária ou um tom neutro. */
export function resolveKits(teams){
 const rgb=c=>[1,3,5].map(i=>parseInt(String(c||'#7098aa').slice(i,i+2),16)||0),far=(a,b)=>Math.hypot(...rgb(a).map((v,i)=>v-rgb(b)[i]))>=125,hex=c=>/^#[0-9a-f]{6}$/i.test(c||'');
 const kit=t=>{const colors=t?.kit?.colors||[t?.color];return {c1:hex(colors[0])?colors[0]:'#e64f63',c2:hex(colors[1])?colors[1]:null,pattern:t?.kit?.pattern||'solid'}};
 const home=kit(teams[0]),away=kit(teams[1]);
 if(!far(home.c1,away.c1)){
  if(away.c2&&far(home.c1,away.c2))Object.assign(away,{c1:away.c2,c2:away.c1});
  else Object.assign(away,{c1:far(home.c1,'#f2e7bc')?'#f2e7bc':'#1d252b',c2:null,pattern:'solid'});
 }
 if(home.c2&&!far(home.c1,home.c2)&&home.pattern!=='solid')home.pattern='solid';
 return [home,away];
}
export function easedCamera(camera,view,dt){
 const danger=view.ball.x<20||view.ball.x>80,track=camera.mode==='ball'||camera.autoFocus&&danger;
 const targetX=track?clamp(view.ball.x,32,68):50,targetY=track?clamp(view.ball.y,38,62):50,ease=1-Math.exp(-dt*2.3);
 camera.x=lerp(camera.x,targetX,ease);camera.y=lerp(camera.y,targetY,ease);camera.zoom=lerp(camera.zoom,camera.requestedZoom*(camera.autoFocus&&danger?1.08:1),ease);return camera;
}
