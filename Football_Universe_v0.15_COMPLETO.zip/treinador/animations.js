// Procedural, replaceable player sprites. Animation consumes a pose, never writes match state.
export function drawPlayer(ctx,point,p,options){
 const {color,time,selected,carrier,names,accent,pattern}=options,r=Math.max(6.4,Math.min(13,point.scale*1.4)),cycle=Math.sin(time*17+p.slot),moving=['run','press','carry','dribble','sweep'].includes(p.visual),fall=p.visual==='fall',save=p.visual==='save',kick=['pass','cross','shoot','distribute','tackle'].includes(p.visual),header=p.visual==='header',celebrate=p.visual==='celebrate';
 const px=point.x,py=point.y-(header?Math.abs(Math.sin(time*8))*r*.65:0)-(celebrate?Math.abs(Math.sin(time*9+p.slot))*r*.55:0);
 ctx.save();ctx.translate(px,py);ctx.fillStyle='#00141070';ctx.beginPath();ctx.ellipse(1,r*.45,r*1.1,r*.5,0,0,7);ctx.fill();
 if(selected||carrier){ctx.strokeStyle=selected?'#a9f7ff':'#ffe44d';ctx.lineWidth=selected?2.6:2.8;ctx.beginPath();ctx.arc(0,0,r+4,0,7);ctx.stroke();if(carrier){ctx.fillStyle='#ffe44d';ctx.strokeStyle='#08151c';ctx.lineWidth=1.2;ctx.beginPath();ctx.moveTo(0,-r-5);ctx.lineTo(-5,-r-13);ctx.lineTo(5,-r-13);ctx.closePath();ctx.fill();ctx.stroke()}}
 ctx.rotate(p.angle||0);if(fall)ctx.rotate(1.1);if(save){const style=p.saveStyle||'dive';if(['dive','fullStretch','parry'].includes(style)){ctx.rotate(style==='fullStretch'?.35:-.3);ctx.scale(style==='fullStretch'?2:1.6,.65)}else if(style==='closeSave')ctx.scale(.9,1.5);else if(style==='claim')ctx.translate(r*.4,0);}
 ctx.strokeStyle='#0b1826';ctx.lineWidth=r*.45;ctx.lineCap='round';ctx.beginPath();ctx.moveTo(-r*.35,-r*.35);ctx.lineTo(-r*(kick?-1.7:.8)+(moving?cycle*r*.6:0),-r*.45);ctx.moveTo(-r*.35,r*.35);ctx.lineTo(-r*.85-(moving?cycle*r*.6:0),r*.45);ctx.stroke();
 ctx.strokeStyle=p.role==='GK'?'#ffe6b3':'#d2a885';ctx.lineWidth=r*.3;ctx.beginPath();ctx.moveTo(0,-r*.7);ctx.lineTo(celebrate||save?r*.6:-r*.2,-r*(celebrate||save?1.8:1.1));ctx.moveTo(0,r*.7);ctx.lineTo(celebrate||save?r*.6:-r*.2,r*(celebrate||save?1.8:1.1));ctx.stroke();
 ctx.fillStyle=color;ctx.strokeStyle='#effcf8';ctx.lineWidth=1;ctx.beginPath();ctx.roundRect(-r*.75,-r*.68,r*1.45,r*1.36,r*.35);ctx.fill();
 if(accent&&pattern&&pattern!=='solid'){ctx.save();ctx.clip();ctx.fillStyle=accent;const x0=-r*.75,y0=-r*.68,w=r*1.45,h=r*1.36;
  if(pattern==='stripes')for(let k=0;k<5;k+=2)ctx.fillRect(x0,y0+k*h/5,w,h/5);
  else if(pattern==='hoops')for(let k=0;k<4;k+=2)ctx.fillRect(x0+k*w/4,y0,w/4,h);
  else if(pattern==='halves')ctx.fillRect(x0,y0,w,h/2);
  else if(pattern==='checks')for(let i=0;i<4;i++)for(let j=0;j<4;j++)if((i+j)%2===0)ctx.fillRect(x0+i*w/4,y0+j*h/4,w/4,h/4);
  else if(pattern==='sash'){ctx.beginPath();ctx.moveTo(x0,y0+h*.15);ctx.lineTo(x0+w*.3,y0);ctx.lineTo(x0+w,y0+h*.85);ctx.lineTo(x0+w*.7,y0+h);ctx.closePath();ctx.fill()}
  ctx.restore()}
 ctx.beginPath();ctx.roundRect(-r*.75,-r*.68,r*1.45,r*1.36,r*.35);ctx.stroke();
 ctx.fillStyle='#0b243580';ctx.fillRect(-r*.08,-r*.6,r*.22,r*1.2);
 if(p.role==='GK'){ctx.fillStyle='#8ff0a4';for(const sy of [-1,1]){const gx=celebrate||save?r*.6:-r*.2,gy=r*(celebrate||save?1.8:1.1)*sy;ctx.beginPath();ctx.arc(gx,gy,r*.24,0,7);ctx.fill()}}
 ctx.fillStyle='#e0ba96';ctx.beginPath();ctx.arc(r*.72,0,r*.33,0,7);ctx.fill();
 ctx.fillStyle='#ffffffb0';ctx.beginPath();ctx.moveTo(r*1.65,0);ctx.lineTo(r*1.18,-r*.24);ctx.lineTo(r*1.18,r*.24);ctx.fill();ctx.restore();
 ctx.font=`800 ${Math.max(8,r*.87)}px system-ui`;ctx.textAlign='center';ctx.lineWidth=2.5;ctx.strokeStyle='#08151c';ctx.strokeText(String(p.number||p.slot+1),px,py+3);ctx.fillStyle='#fff';ctx.fillText(String(p.number||p.slot+1),px,py+3);
 if(p.cards){ctx.fillStyle='#ffe259';ctx.fillRect(px+r,py-r,3,5)}
 if(p.cardShow){const bob=Math.sin(time*6)*2;ctx.save();ctx.translate(px,py-r*2.3+bob);ctx.rotate(-.12);ctx.fillStyle=p.cardShow==='red'?'#e5483f':'#ffd93b';ctx.strokeStyle='#08151c';ctx.lineWidth=1.2;ctx.fillRect(-5,-8,10,15);ctx.strokeRect(-5,-8,10,15);ctx.restore()}
 if(fall||p.visual==='complain'){ctx.font='800 13px system-ui';ctx.lineWidth=3;ctx.strokeStyle='#08151c';ctx.fillStyle=fall?'#ffd0a0':'#fff4a8';ctx.strokeText(fall?'!':'?',px,py-r*1.7);ctx.fillText(fall?'!':'?',px,py-r*1.7)}
 if(names||selected||carrier){const label=p.name?.startsWith('Posição')?p.role:p.name?.split(' ').slice(-1)[0]||p.id;ctx.font='600 10px system-ui';const width=ctx.measureText(label).width;ctx.fillStyle='#071820df';ctx.fillRect(px-width/2-4,py+r+5,width+8,15);ctx.fillStyle='#e7fff6';ctx.fillText(label,px,py+r+16);}
}

