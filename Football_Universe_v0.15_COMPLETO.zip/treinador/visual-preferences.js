const KEY='fu-match-visual-preferences';
const DEFAULTS=Object.freeze({visual:'25d',camera:'broadcast',names:true,zoom:1});
const validCamera=value=>['broadcast','tactical','ball'].includes(value);
function normalize(value={}){
 return {
  visual:value.visual==='2d'?'2d':'25d',
  camera:validCamera(value.camera)?value.camera:'broadcast',
  names:typeof value.names==='boolean'?value.names:true,
  zoom:Number.isFinite(value.zoom)&&value.zoom>=1&&value.zoom<=1.8?value.zoom:1
 };
}
export function readMatchVisualPreferences(storage){
 try{
  storage??=globalThis.localStorage;
  const raw=storage?.getItem(KEY);
  return raw?normalize(JSON.parse(raw)):{...DEFAULTS};
 }catch{return {...DEFAULTS}}
}
export function writeMatchVisualPreferences(storage,current,patch){
 const next=normalize({...current,...patch});
 try{storage??=globalThis.localStorage;storage?.setItem(KEY,JSON.stringify(next))}catch{/* Preferências são opcionais e nunca bloqueiam a partida. */}
 return next;
}
