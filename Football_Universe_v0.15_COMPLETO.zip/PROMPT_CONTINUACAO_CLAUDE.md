# Prompt para Claude — continuidade do Football Universe v0.7

Você está continuando o projeto Football Universe v0.7, um jogo de gestão de futebol em JavaScript/Canvas 2D. Leia primeiro `README.md`, `RELATORIO_DESENVOLVIMENTO.md`, `CHANGELOG.md` e os arquivos de `treinador/`.

## Objetivo

Continue a evolução do modo Treinador 2D preservando o estado oficial da partida. Não reescreva o projeto do zero e não substitua controles funcionais por mockups.

## Verificação inicial

Execute:

```text
npm test
npm run build
```

O projeto usa Node.js 20+ e não exige dependências para execução. O servidor local é iniciado com `npm start`.

## O que já está implementado

- Motor determinístico com 2.700 passos, estado validado e migração de save v1.
- Canvas 2D com campo, bola, 22 atletas, câmeras, zoom, foco, nomes e seleção.
- Movimento com formação, apoio, cobertura, pressão, desgaste e transições.
- Passes, dribles, cruzamentos, chutes, bloqueios, defesas, faltas, cartões, impedimentos e reinícios.
- HUD com placar, relógio, estatísticas e relato ao vivo.
- Controles de pausa, velocidades 1x/2x/4x/8x, próximo lance, formação, mentalidade, pressão, ritmo, instrução e substituições.
- Replays curtos reais da mesma simulação, sem alterar o resultado oficial.
- Brasileirão com 380 jogos e Copa com 104 jogos, usando o mesmo motor.
- Saves em IndexedDB com revisão, migração, exportação/importação e detecção de conflito entre abas.

## Pendentes prioritários

1. Refinar sprites procedurais e animações de goleiros, faltas, cartões e comemorações.
2. Calibrar frequência de ações e estatísticas com seeds variadas, sem inserir eventos falsos.
3. Melhorar IA de marcação, arbitragem, suspensões e lesões.
4. Implementar prorrogação e visualização detalhada de pênaltis em mata-mata.
5. Completar cadastros de clubes e seleções com procedência verificável.
6. Validar em aparelhos móveis físicos, Safari e Firefox.

## Regras

- Preserve a separação entre estado, motor, movimento, renderer, HUD, controles, replay e storage.
- O renderer e o replay não podem alterar placar, RNG, calendário ou estatísticas.
- Toda mudança de save deve passar por `validateSave`/`validateMatchState`.
- Mantenha as classificações honestas: IMPLEMENTADO, PARCIAL, PROTÓTIPO, PENDENTE ou DEFINITIVO.
- Adicione testes significativos para cada mudança e atualize `README.md`, `CHANGELOG.md` e `RELATORIO_DESENVOLVIMENTO.md`.
- Ao terminar, gere novamente `dist`, execute os testes e entregue um ZIP completo sem `node_modules`, `.git` ou temporários.
