// Validador local do snapshot: node tools/validate-world.mjs [arquivo.json]
import {readFileSync} from 'node:fs';import {resolve} from 'node:path';
import {validateWorld} from '../src/core.js';
const path=resolve(process.argv[2]||'data/demo-world.json');
try{const data=JSON.parse(readFileSync(path,'utf8'));validateWorld(data);console.log(`VALIDADO ${path}: ${data.players.length} atletas, ${data.clubs.length} clubes, ${data.fixtures.length} fixtures.`);}catch(e){console.error('INVALIDO:',e.message);process.exitCode=1;}
