// Gera um snapshot JSON com jogadores e clubes reais; ratings ainda provisórios. Rode: node tools/export-world.mjs
import {writeFileSync} from 'node:fs';
import {createInitialWorld,ATTRIBUTE_GROUPS} from '../src/data.js';
const json=v=>JSON.stringify(v,null,2)+'\n';
writeFileSync(new URL('../data/demo-world.json',import.meta.url),json(createInitialWorld()));
writeFileSync(new URL('../data/attribute-groups.json',import.meta.url),json(ATTRIBUTE_GROUPS));
console.log('Snapshot de demonstração e catálogo de atributos exportados.');
