// Baixa as fotos originais dos atletas para assets/faces (WebP) e atualiza data/media.json + src/media-index.js.
// Fontes: EA FC 26 / SoFIFA (rosto de cada atleta), listas oficiais da Copa 2026 (FIFA) e, só onde falta, o manifesto do Wikimedia Commons.
// Uso: node tools/fetch-faces.mjs [--dir pasta com players.csv e rosters.json] [--only ea|fifa|clubs]
// O servidor da SoFIFA só responde com o cabeçalho Referer do próprio site; por isso o download é feito aqui, uma vez, e o app usa os arquivos locais.
import {readFileSync,writeFileSync,existsSync} from 'node:fs';
import {join} from 'node:path';
import {ROOT,loadSharp,ensureDir,download,sleep,readMedia,writeMedia} from './media-lib.mjs';
import {parseCSV,SOURCES} from '../copa/data-loader.js';
import {buildNationalPool} from '../treinador/national-pool.js';
import {INITIAL_PLAYERS,ATTRIBUTE_KEYS} from '../src/data.js';
import {cleanName} from '../treinador/nations.js';
const args=process.argv.slice(2),opt=n=>{const i=args.indexOf('--'+n);return i>=0?args[i+1]:null},dir=opt('dir'),only=opt('only');
const sharp=loadSharp(),SOFIFA={Referer:'https://sofifa.com/'};
const text=async(file,url)=>dir&&existsSync(join(dir,file))?readFileSync(join(dir,file),'utf8'):Buffer.from(await download(url)).toString('utf8');
const rows=parseCSV(await text('players.csv',SOURCES.ea)),fifa=JSON.parse(await text('rosters.json',SOURCES.fifa));
const pool=buildNationalPool(fifa,rows,ATTRIBUTE_KEYS),players=Object.values(pool.nations).flatMap(n=>[...n.squad,...n.reserve]).filter(p=>!p.placeholder);
const media=readMedia(),outEA=ensureDir(join(ROOT,'assets/faces/ea')),outFifa=ensureDir(join(ROOT,'assets/faces/fifa')),outClub=ensureDir(join(ROOT,'assets/faces/club'));
const webp=(buf,px)=>sharp(buf).resize(px,px,{fit:'cover',position:'top'}).webp({quality:80}).toBuffer();
const eaId=url=>{const m=/\/players\/(\d{1,3})\/(\d{3})\/\d+_\d+\.png/.exec(url||'');return m?Number(m[1]+m[2]):null};
const fifaId=url=>{const m=/\/transform\/([0-9a-f-]{36})\//.exec(url||'');return m?m[1]:null};
async function pool_(items,worker,size=8){let i=0,done=0;await Promise.all(Array.from({length:size},async()=>{while(i<items.length){const item=items[i++];try{await worker(item)}catch(e){console.warn('  falhou',item.label||item,e.message)}if(++done%200===0)console.log('  ',done,'/',items.length)}}))}
const report={ea:0,fifa:0,clubs:0,missing:[]};
if(!only||only==='ea'){
 const ids=[...new Set(players.map(p=>eaId(p.photo)).filter(Boolean))];console.log('SoFIFA:',ids.length,'rostos');
 await pool_(ids.filter(id=>!existsSync(join(outEA,id+'.webp'))),async id=>{
  const buf=await download(`https://cdn.sofifa.net/players/${String(id).padStart(6,'0').slice(0,3)}/${String(id).padStart(6,'0').slice(3)}/26_120.png`,SOFIFA);
  writeFileSync(join(outEA,id+'.webp'),await webp(buf,120));});
 media.faces.ea=ids.filter(id=>existsSync(join(outEA,id+'.webp')));report.ea=media.faces.ea.length;
}
if(!only||only==='fifa'){
 const urls=new Map(players.map(p=>[fifaId(p.photo),p.photo]).filter(([id,u])=>id&&/digitalhub/.test(u)));console.log('FIFA:',urls.size,'retratos');
 await pool_([...urls.keys()].filter(id=>!existsSync(join(outFifa,id+'.webp'))),async id=>{
  const base=urls.get(id).split('?')[0];writeFileSync(join(outFifa,id+'.webp'),await webp(await download(`${base}?io=transform:fill,width:240,height:240`),160));});
 media.faces.fifa=[...urls.keys()].filter(id=>existsSync(join(outFifa,id+'.webp')));report.fifa=media.faces.fifa.length;
}
if(!only||only==='clubs'){
 // Atletas dos clubes cadastrados. A base EA FC 26 NÃO serve aqui: a liga brasileira não é licenciada nela e os nomes dos atletas são fictícios.
 // Fica o manifesto do Wikimedia Commons; o resto vem de tools/fetch-faces-extra.mjs.
 const manifest=JSON.parse(readFileSync(join(ROOT,'data/verified-photo-manifest.json'),'utf8'));
 media.faces.byPlayer={};
 for(const p of INITIAL_PLAYERS){
  const wiki=manifest.find(m=>m.club===p.clubId&&cleanName(m.name)===cleanName(p.name));
  if(wiki){try{writeFileSync(join(outClub,p.id+'.webp'),await webp(await download(wiki.url.replace(/width=\d+/,'width=400')),160));media.faces.byPlayer[p.id]='club/'+p.id;report.clubs++;continue}catch(e){console.warn('  wikimedia falhou',p.name,e.message)}}
  report.missing.push(`${p.clubId}/${p.name}`);
 }
}
writeMedia(media);
writeFileSync(join(ROOT,'qa/media-faces-report.json'),JSON.stringify({...report,totalPlayers:players.length},null,1));
console.log(JSON.stringify({...report,missing:report.missing.length},null,1));
if(report.missing.length)console.log('Sem foto:',report.missing.join('; '));
