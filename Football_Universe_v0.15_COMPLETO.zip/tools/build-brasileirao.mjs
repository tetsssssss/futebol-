// Monta o elenco real dos 20 clubes da Série A 2026 e grava data/brasileirao-2026.json e src/league-data.js.
// Entradas versionadas: data/tm-squads-2026.json (elencos, números, nascimento, valor: Transfermarkt), data/tm-clubs-2026.json (estádio e técnico),
// data/ea-history-2026.json (avaliações reais do EA/FIFA mais recentes encontradas para o atleta; ver tools/extract-ea-history.mjs).
// Atributos: com avaliação real do EA/FIFA → perfil real daquela edição, evoluído até hoje pela idade e combinado com o valor de mercado atual;
// sem avaliação → estimado pelo valor de mercado (curva calibrada nos 18 mil atletas do EA FC 26) e pela posição. Cada atleta registra qual dos dois.
// Uso: node tools/build-brasileirao.mjs
import {readFileSync,writeFileSync,existsSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import {ATTRIBUTE_KEYS,ATTRIBUTE_GROUPS} from '../src/attributes.js';
import {attributeProfile} from '../copa/engine.js';
import {cleanName} from '../treinador/nations.js';
import {SERIE_A_2026} from '../treinador/league.js';
import {CURATED} from './kits-curated.mjs';
const P=p=>fileURLToPath(new URL('../'+p,import.meta.url));
const tm=JSON.parse(readFileSync(P('data/tm-squads-2026.json'),'utf8')),meta=JSON.parse(readFileSync(P('data/tm-clubs-2026.json'),'utf8')),history=JSON.parse(readFileSync(P('data/ea-history-2026.json'),'utf8'));
const NOW=2026.8; // outubro de 2026
const clamp=(v,lo=15,hi=96)=>Math.max(lo,Math.min(hi,Math.round(v)));
const hash=s=>{let h=2166136261;for(const c of String(s))h=Math.imul(h^c.charCodeAt(0),16777619)>>>0;return h};
const noise=(id,key,span=4)=>(hash(id+'|'+key)%(span*2+1))-span;
// Curva valor de mercado → avaliação, ajustada por mínimos quadrados em 18.016 atletas do EA FC 26: [1, ln(valor), idade, idade², goleiro, ln(valor)·goleiro]
const W=[-10.67483,5.03019,-0.10253,0.01374,3.81021,-0.21363];
const fromValue=(value,age,gk)=>{const v=Math.max(value||0,150000),a=age||25,x=[1,Math.log(v),a,a*a,gk?1:0,Math.log(v)*(gk?1:0)];return x.reduce((s,t,i)=>s+t*W[i],0)};
const POS={Goalkeeper:'GK','Centre-Back':'CB','Left-Back':'LB','Right-Back':'RB','Defensive Midfield':'DM','Central Midfield':'CM','Attacking Midfield':'AM','Left Winger':'LW','Right Winger':'RW','Centre-Forward':'ST','Second Striker':'ST','Right Midfield':'RW','Left Midfield':'LW'};
const EA_POS={GK:'GK',CB:'CB',LB:'LB',RB:'RB',DM:'CDM',CM:'CM',AM:'CAM',LW:'LW',RW:'RW',ST:'ST'};
const NAT_PT={Brazil:'Brasil',Argentina:'Argentina',Uruguay:'Uruguai',Colombia:'Colômbia',Paraguay:'Paraguai',Chile:'Chile',Ecuador:'Equador',Venezuela:'Venezuela',Peru:'Peru',Bolivia:'Bolívia',Portugal:'Portugal',Spain:'Espanha',Italy:'Itália',France:'França',Germany:'Alemanha',Netherlands:'Países Baixos',England:'Inglaterra',Mexico:'México',Panama:'Panamá','Costa Rica':'Costa Rica','Cabo Verde':'Cabo Verde','Cape Verde':'Cabo Verde',Angola:'Angola',Nigeria:'Nigéria',Senegal:'Senegal',Morocco:'Marrocos',Haiti:'Haiti',Jamaica:'Jamaica',Japan:'Japão',Canada:'Canadá','United States':'Estados Unidos',Belgium:'Bélgica',Croatia:'Croácia',Serbia:'Sérvia',Poland:'Polônia'};
const FOOT={right:'Direito',left:'Esquerdo',both:'Ambidestro'};
const TECH=['firstTouch','shortPass','longPass','finishing','dribbling','crossing','heading','tackling','marking','technique','ballControl','volleys','weakFoot'],GK_KEYS=ATTRIBUTE_GROUPS.find(g=>g.id==='goalkeeper').entries.map(e=>e[0]);
// Deslocamento (pontos sobre a avaliação) por função. O que não aparece fica na avaliação.
const OFFSETS={
 ST:{finishing:8,heading:3,volleys:4,dribbling:-2,shortPass:-8,longPass:-18,crossing:-12,tackling:-28,marking:-30,technique:-3,offBall:7,positioning:4,composure:3,strength:2,pace:1,defensiveCover:-25,compactness:-20,pressing:-6,penalties:5},
 AM:{finishing:-2,shortPass:5,dribbling:6,crossing:-2,heading:-20,tackling:-22,marking:-25,technique:6,ballControl:5,volleys:-3,vision:7,offBall:3,longPass:1,freeKicks:2,defensiveCover:-22,compactness:-12},
 LW:{dribbling:8,crossing:4,finishing:0,shortPass:-2,longPass:-8,heading:-18,tackling:-25,marking:-28,pace:7,acceleration:8,agility:4,offBall:3,strength:-6,defensiveCover:-22,overlapping:3},
 RW:{dribbling:8,crossing:4,finishing:0,shortPass:-2,longPass:-8,heading:-18,tackling:-25,marking:-28,pace:7,acceleration:8,agility:4,offBall:3,strength:-6,defensiveCover:-22,overlapping:3},
 CM:{shortPass:6,longPass:3,dribbling:-3,finishing:-10,heading:-10,tackling:0,marking:-4,crossing:-6,vision:3,stamina:3,tempoControl:3,transition:3,workRate:4},
 DM:{tackling:6,marking:5,shortPass:2,dribbling:-12,finishing:-20,crossing:-14,heading:0,pressing:5,stamina:3,positioning:5,defensiveCover:6,workRate:5,strength:3},
 CB:{tackling:6,marking:8,heading:7,shortPass:-8,longPass:-6,dribbling:-20,finishing:-30,crossing:-22,technique:-15,firstTouch:-10,ballControl:-10,strength:6,jumping:4,positioning:6,defensiveCover:7,compactness:6,pace:-6,acceleration:-8,offBall:-18,vision:-8},
 RB:{crossing:5,pace:4,stamina:5,dribbling:-8,finishing:-22,heading:-8,shortPass:-4,tackling:0,marking:0,overlapping:8,defensiveCover:2,offBall:-8},
 LB:{crossing:5,pace:4,stamina:5,dribbling:-8,finishing:-22,heading:-8,shortPass:-4,tackling:0,marking:0,overlapping:8,defensiveCover:2,offBall:-8},
 GK:{}
};
const DEFENSIVE=new Set(['tackling','marking','positioning','defensiveCover','compactness','pressing']);
const AGING=new Set(['pace','acceleration','agility']);
const FIXED=new Set(ATTRIBUTE_GROUPS.filter(g=>['behavioral','relationships','adaptation','reputation','condition'].includes(g.id)).flatMap(g=>g.entries.map(e=>e[0])));
function estimatedAttrs(id,position,overall,age,value){
 const out={};
 for(const key of ATTRIBUTE_KEYS){
  let v;
  if(GK_KEYS.includes(key))v=position==='GK'?overall+noise(id,key,3):Math.min(26,overall-45)+noise(id,key,3);
  else if(position==='GK')v=(key==='weakFoot'?44:overall-34)+noise(id,key,5);
  else{
   v=overall+(OFFSETS[position][key]||0)+noise(id,key);
   if(AGING.has(key)&&age>29)v-=(age-29)*1.5;
   if(key==='stamina'&&age>30)v-=(age-30);
   if(['decisions','composure','anticipation','concentration','leadership','positioning','tempoControl'].includes(key))v+=Math.max(-4,Math.min(6,(age-25)*.8));
   if(key==='weakFoot')v=40+(hash(id)%4)*10;
  }
  if(key==='domestic')v=45+Math.log10(Math.max(value,1e5)/1e5)*18;
  if(key==='international')v=35+Math.log10(Math.max(value,1e5)/1e5)*17;
  if(FIXED.has(key)&&!['domestic','international'].includes(key))v=60+noise(id,key,10)+(overall-65)*.25;
  out[key]=clamp(v);
 }
 return out;
}
const scoreOf=(attrs,pos)=>{const keys=pos==='GK'?['reflexes','handling','oneOnOnes','aerialReach','distribution','decisions','composure']:pos==='ST'?['finishing','firstTouch','offBall','composure','acceleration','strength','decisions']:pos==='CB'?['marking','tackling','heading','positioning','strength','anticipation','defensiveCover']:['firstTouch','shortPass','decisions','positioning','stamina','pace','teamwork'];return Math.round(keys.reduce((s,k)=>s+(attrs[k]||0),0)/keys.length)};
/** Ajusta os atributos de jogo (não os comportamentais) até a avaliação calculada pelo app bater com a alvo. */
function calibrate(attrs,pos,target){
 for(let i=0;i<4;i++){const s=scoreOf(attrs,pos),d=target-s;if(d===0)break;
  for(const k of ATTRIBUTE_KEYS){if(FIXED.has(k))continue;if(GK_KEYS.includes(k)&&pos!=='GK')continue;attrs[k]=clamp(attrs[k]+d)}}
 return attrs;
}
/** Evolui uma avaliação de uma edição antiga até hoje: jovens caminham ao potencial, veteranos perdem ritmo. */
function age(row,editionYear){
 const ratedAt=editionYear-.3,years=Math.max(0,NOW-ratedAt),born=new Date(row.dob).getFullYear()+.5;let o=Number(row.overall),pot=Math.max(Number(row.potential)||o,o),a=ratedAt-born;
 for(let y=0;y<Math.round(years);y++){a+=1;if(a<24)o+=Math.max(.6,(pot-o)*.3);else if(a<=28)o+=pot>o?.3:0;else if(a<=30)o-=.8;else if(a<=32)o-=1.6;else o-=2.3;if(a<24)pot=Math.max(pot,o)}
 return {overall:o,years:Math.round(years)};
}
// Ids da versão anterior (4 clubes) são mantidos para quem já tem save: data/old-player-ids.json.
const oldIds=new Map(Object.entries(JSON.parse(readFileSync(P('data/old-player-ids.json'),'utf8'))));
const NAMES={'athletico-pr':'Club Athletico Paranaense','atletico-mg':'Clube Atlético Mineiro',bahia:'Esporte Clube Bahia',botafogo:'Botafogo de Futebol e Regatas',chapecoense:'Associação Chapecoense de Futebol',corinthians:'Sport Club Corinthians Paulista',coritiba:'Coritiba Foot Ball Club',cruzeiro:'Cruzeiro Esporte Clube',flamengo:'Clube de Regatas do Flamengo',fluminense:'Fluminense Football Club',gremio:'Grêmio Foot-Ball Porto Alegrense',internacional:'Sport Club Internacional',mirassol:'Mirassol Futebol Clube',palmeiras:'Sociedade Esportiva Palmeiras',bragantino:'Red Bull Bragantino',remo:'Clube do Remo',santos:'Santos Futebol Clube','sao-paulo':'São Paulo Futebol Clube',vasco:'Club de Regatas Vasco da Gama',vitoria:'Esporte Clube Vitória'};
const CITY={'athletico-pr':['Curitiba','PR'],'atletico-mg':['Belo Horizonte','MG'],bahia:['Salvador','BA'],botafogo:['Rio de Janeiro','RJ'],chapecoense:['Chapecó','SC'],corinthians:['São Paulo','SP'],coritiba:['Curitiba','PR'],cruzeiro:['Belo Horizonte','MG'],flamengo:['Rio de Janeiro','RJ'],fluminense:['Rio de Janeiro','RJ'],gremio:['Porto Alegre','RS'],internacional:['Porto Alegre','RS'],mirassol:['Mirassol','SP'],palmeiras:['São Paulo','SP'],bragantino:['Bragança Paulista','SP'],remo:['Belém','PA'],santos:['Santos','SP'],'sao-paulo':['São Paulo','SP'],vasco:['Rio de Janeiro','RJ'],vitoria:['Salvador','BA']};
const toIso=s=>{const m=/(\d\d)[/.](\d\d)[/.](\d{4})/.exec(s||'');return m?`${m[3]}-${m[2]}-${m[1]}`:null};
const clubs=[],players=[];const totals={};
for(const [,name,short] of SERIE_A_2026){} // ordem do cadastro da liga
for(const [id,list] of Object.entries(tm.squads))totals[id]=list.reduce((s,p)=>s+(p.value||0),0);
const maxTotal=Math.max(...Object.values(totals)),minTotal=Math.min(...Object.values(totals));
for(const [id,,short] of SERIE_A_2026){
 const squad=tm.squads[id];if(!Array.isArray(squad)||squad.length<18)throw Error('Elenco ausente: '+id);
 const m=meta[id]||{},kit=CURATED[id]||['#d3202f','#111111'],tmId=tm.ids[id];
 const rel=(totals[id]-minTotal)/(maxTotal-minTotal||1);
 clubs.push({id,name:NAMES[id],short,city:CITY[id][0],region:CITY[id][1],colors:[kit[0],kit[1]],budget:Math.round((4e6+totals[id]*.25)/1e5)*1e5,reputation:Math.round(55+Math.sqrt(rel)*33),manager:m.coach||'A confirmar',ground:m.stadium||'A confirmar',tm:tmId,
  verifiedRosterSource:`https://www.transfermarkt.com/-/kader/verein/${tmId}/plus/1`,squadValue:totals[id]});
 const taken=new Set(squad.map(p=>Number(p.num)).filter(n=>n>0&&n<100));let spare=60;
 squad.forEach(p=>{
  const position=POS[p.pos]||'CM',gk=position==='GK',hist=history[id+'|'+p.tm];
  const key=cleanName(p.name),pid=oldIds.get(id+'|'+key)||`${id}-t${p.tm}`;
  const valueOverall=fromValue(p.value,p.age,gk);
  let target,attrs,basis,edition=null;
  if(hist){
   const ed=2000+Number(hist.edition),aged=age(hist,ed);edition=Number(hist.edition);
   target=clamp(.55*aged.overall+.45*valueOverall,40,90);
   const base=attributeProfile({...hist,player_positions:EA_POS[position]},ATTRIBUTE_KEYS);
   attrs={};for(const k of ATTRIBUTE_KEYS)attrs[k]=base[k];
   // atributos físicos acompanham a idade desde a edição
   const extra=Math.max(0,(p.age||25)-(Number(hist.age)||25));
   for(const k of ATTRIBUTE_KEYS)if(AGING.has(k))attrs[k]=clamp(attrs[k]-Math.max(0,extra-3)*1.2);
   basis='ea-historico';
  }else{target=clamp(valueOverall,38,88);attrs=estimatedAttrs(pid,position,target,p.age||25,p.value||0);basis='estimado-valor-de-mercado'}
  attrs=calibrate(attrs,position,target);
  let number=Number(p.num);if(!(number>0&&number<100)){while(taken.has(spare))spare++;number=spare;taken.add(spare)}
  players.push({id:pid,tm:p.tm,clubId:id,name:p.name,number,numberProvisional:!(Number(p.num)>0),position,born:p.born,age:p.age,nationality:NAT_PT[p.nat[0]]||p.nat[0]||'A confirmar',height:p.height,foot:FOOT[p.foot]||'A confirmar',
   contractEnd:toIso(p.contract),value:p.value||0,overall:target,basis,edition,img:p.img,attrs:ATTRIBUTE_KEYS.map(k=>attrs[k])});
 });
}
const ids=new Set();for(const p of players){if(ids.has(p.id))throw Error('id repetido '+p.id);ids.add(p.id)}
writeFileSync(P('data/brasileirao-2026.json'),JSON.stringify({builtAt:new Date().toISOString().slice(0,10),keys:ATTRIBUTE_KEYS,clubs,players}));
const js=`// Gerado por tools/build-brasileirao.mjs. Não editar à mão.\n// Clubes e elencos da Série A 2026 (Transfermarkt); atributos: avaliação real do EA/FIFA evoluída até hoje ou estimativa pelo valor de mercado (campo basis).\nexport const LEAGUE_BUILT=${JSON.stringify(new Date().toISOString().slice(0,10))};\nexport const LEAGUE_CLUBS=${JSON.stringify(clubs)};\n// [id, clube, nome, número, número provisório?, posição, nascimento, idade, nacionalidade, altura, pé, fim do contrato, valor €, avaliação, base, edição EA, id Transfermarkt, atributos na ordem de ATTRIBUTE_KEYS]\nexport const LEAGUE_PLAYERS=${JSON.stringify(players.map(p=>[p.id,p.clubId,p.name,p.number,p.numberProvisional?1:0,p.position,p.born,p.age,p.nationality,p.height,p.foot,p.contractEnd,p.value,p.overall,p.basis==='ea-historico'?'ea':'est',p.edition,p.tm,p.attrs]))};\n`;
writeFileSync(P('src/league-data.js'),js);
const real=players.filter(p=>p.basis==='ea-historico').length;
console.log({clubes:clubs.length,atletas:players.length,comAvaliacaoReal:real,estimados:players.length-real,bytesJs:js.length});
for(const c of clubs){const sq=players.filter(p=>p.clubId===c.id).sort((a,b)=>b.overall-a.overall);console.log(c.short.padEnd(4),String(sq.length).padStart(2),'top11',Math.round(sq.slice(0,11).reduce((s,p)=>s+p.overall,0)/11),'melhor',sq[0].name,sq[0].overall,'valor',(c.squadValue/1e6).toFixed(0)+'M',c.manager)}
// imagens a baixar
writeFileSync(P('data/brasileirao-portraits.json'),JSON.stringify(players.map(p=>({id:p.id,tm:p.tm,img:p.img,club:p.clubId,name:p.name}))));
