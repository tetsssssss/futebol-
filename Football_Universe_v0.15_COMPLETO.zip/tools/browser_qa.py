"""Smoke tests reais sobre dist/index.html. Sem rede e sem bibliotecas do app."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import json
root=Path(__file__).resolve().parents[1]
html=(root/'dist/index.html').read_text()
messages=[]
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True, executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage','--no-zygote'])
 for width in (360,390,768,1440,1920):
  page=browser.new_page(viewport={'width':width,'height':900},accept_downloads=True)
  page.set_default_timeout(3000)
  print('QA WIDTH',width,flush=True)
  errors=[];page.on('pageerror', lambda err: errors.append(str(err)))
  page.evaluate("""() => {const mem={};Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>mem[k]??null,setItem:(k,v)=>mem[k]=String(v),removeItem:k=>delete mem[k]}})}""")
  page.set_content(html,wait_until='load',timeout=20000)
  assert 'Bem-vindo ao seu universo' in page.locator('h1').inner_text(), ('home',width,errors)
  page.locator('[data-action="navigate"][data-target="editor"]').last.click()
  assert page.locator('#edit-player-profile').count()==1
  page.locator('#ep-name').fill('Caio Validação QA')
  page.locator('#edit-player-profile button[type="submit"]').click()
  assert page.locator('#ep-name').input_value()=='Caio Validação QA'
  page.locator('#ec-budget').fill('3500000')
  page.locator('#edit-club-profile button[type="submit"]').click()
  assert page.locator('#ec-budget').input_value()=='3500000'
  page.locator('[data-action="navigate"][data-target="calendar"]').first.click()
  page.locator('#training-focus').select_option('Ataque')
  page.locator('#training-intensity').select_option('Alta')
  assert page.locator('#training-focus').input_value()=='Ataque'
  page.locator('[data-action="advance-week"]').first.click()
  page.locator('[data-action="navigate"][data-target="competitions"]').first.click()
  assert '2/6 partidas' in page.locator('.grid.cols-3').first.inner_text()
  assert page.locator('.fixture-score').first.inner_text()!='×'
  page.locator('[data-action="navigate"][data-target="saves"]').last.click()
  page.locator('[data-action="save-slot"][data-slot="slot1"]').click()
  assert 'Salvo em' in page.locator('.save-item').first.inner_text()
  page.locator('[data-action="load-slot"][data-slot="slot1"]').click()
  page.locator('[data-action="navigate"][data-target="players"]').first.click()
  page.locator('[data-tab="attrs"]').first.click()
  assert page.locator('.attribute-row').count()==70
  dims=page.evaluate('() => ({vw:innerWidth,w:document.documentElement.scrollWidth})')
  if dims['w']>dims['vw']+1:
   offenders=page.evaluate('''() => [...document.querySelectorAll('*')].map(e=>({tag:e.tagName,cl:e.className,x:e.getBoundingClientRect().right,w:e.scrollWidth,own:e.clientWidth})).filter(x=>x.x>innerWidth+2).sort((a,b)=>b.x-a.x).slice(0,12)''')
   print('OVERFLOW',width,dims,offenders,flush=True)
  assert dims['w']<=dims['vw']+1,(width,dims)
  assert not errors,(width,errors)
  if width in (390,1440):page.screenshot(path=str(root/f'docs/preview-v02-{width}.png'),full_page=True)
  messages.append(f'{width}px: editor identidade e clube, treinos, resultados e tabela, save/load, atributos e responsividade = OK')
  page.close()
 # Migração real de autosave v1 + rejeição de upload adulterado, sem apagar mundo atual.
 legacy=json.loads((root/'data/demo-world.json').read_text())
 legacy['schemaVersion']=1;legacy.pop('training',None);legacy.pop('scoutQuality',None)
 if legacy:
  page=browser.new_page(viewport={'width':1440,'height':900})
  page.set_default_timeout(4000)
  rec=json.dumps({'autosave':{'savedAt':'2026-10-09T00:00:00Z','world':legacy}},ensure_ascii=False)
  page.evaluate('''({rec})=>{const mem={'football-universe-v01':rec};Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>mem[k]??null,setItem:(k,v)=>mem[k]=String(v),removeItem:k=>delete mem[k]}})}''',{'rec':rec})
  page.set_content(html,wait_until='load')
  page.locator('[data-action="navigate"][data-target="saves"]').last.click()
  assert '2' in page.locator('.field-list').last.inner_text()
  corrupted=json.loads(json.dumps(legacy));corrupted['clubs'][1]['id']=corrupted['clubs'][0]['id']
  page.locator('#import-file').set_input_files({'name':'mundo-corrompido.json','mimeType':'application/json','buffer':json.dumps(corrupted).encode()})
  assert 'inválido' in page.locator('#notification').inner_text().lower() or 'duplicado' in page.locator('#notification').inner_text().lower()
  assert page.locator('.field-list').last.inner_text().find('2')>=0
  messages.append('Migração de autosave v1 → v2 e importação inválida rejeitada sem perda do mundo = OK')
  page.close()
 browser.close()
(root/'docs/BROWSER_QA_V02.txt').write_text('\n'.join(messages)+'\nChromium com HTML portátil carregado por set_content; sem validar roteamento HTTP.\n')
print('\n'.join(messages))
