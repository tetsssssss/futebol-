/** Download OPTIONAL licensed Wikimedia portraits for a self-contained offline build.
 * Reuses a curated list of actual portrait IDs with authors/licences; never web-scrapes unknown portraits.
 * Run on a computer with Internet: node tools/download-faces.mjs
 * Only valid JPEG/PNG files are saved; failures are logged, never replaced by made-up images.
 */
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {resolve} from 'node:path';
const photos=JSON.parse(readFileSync(new URL('../data/verified-photo-manifest.json',import.meta.url),'utf8'));
mkdirSync(new URL('../assets/faces/',import.meta.url),{recursive:true});
let ok=0, failed=0;
for (const pic of photos){
 const clubDir=new URL(`../assets/faces/${pic.club}-`,import.meta.url);
 const data=JSON.parse(readFileSync(new URL('../data/real-rosters-2026.json',import.meta.url),'utf8'));
 const arr=data.players.filter(p=>p.clubId===pic.club);
 const index=arr.findIndex(p=>p.name===pic.name);
 if(index<0){failed++;console.warn('Name not in roster',pic.name);continue}
 const outfile=new URL(`../assets/faces/${pic.club}-p${index+1}.jpg`,import.meta.url);
 try{
  const res=await fetch(pic.url,{headers:{'User-Agent':'FootballUniverse/0.4 (personal noncommercial; Wikimedia credited)'}});
  if(!res.ok)throw new Error(`HTTP ${res.status}`);
  const bytes=new Uint8Array(await res.arrayBuffer());
  const jpeg=bytes[0]===0xff&&bytes[1]===0xd8, png=bytes[0]===0x89&&bytes[1]===0x50;
  if(!jpeg&&!png)throw new Error('Resposta não é uma imagem');
  if(bytes.byteLength>6_000_000)throw new Error('Imagem excede 6 MB');
  // PNG is also supported by browsers despite .jpg basename; build detects magic bytes.
  writeFileSync(outfile,bytes);console.log('BAIXADA',pic.name);ok++;
 }catch(err){console.warn('SEM FOTO',pic.name,err.message);failed++}
}
console.log(`Resultado: ${ok} fotografias baixadas, ${failed} indisponíveis. Nenhuma foto sintética gerada.`);
if(failed)process.exitCode=2;
