// Aplica data/media-overrides.json: fotos encontradas e conferidas à mão (nome + clube/nacionalidade) em fontes que não têm API aberta,
// como o Transfermarkt. Cada item: {kind:'club'|'ea', key, name, url, source, page, check}. `check` registra o que foi conferido.
// Uso: node tools/apply-face-overrides.mjs
import {readFileSync,writeFileSync,existsSync} from 'node:fs';
import {join} from 'node:path';
import {ROOT,loadSharp,ensureDir,download,readMedia,writeMedia} from './media-lib.mjs';
const sharp=loadSharp(),outEA=ensureDir(join(ROOT,'assets/faces/ea')),outClub=ensureDir(join(ROOT,'assets/faces/club')),sourcesFile=join(ROOT,'data/media-sources.json');
const list=JSON.parse(readFileSync(join(ROOT,'data/media-overrides.json'),'utf8')),media=readMedia(),have=new Set(media.faces.ea);
const sources=existsSync(sourcesFile)?JSON.parse(readFileSync(sourcesFile,'utf8')):{};
let ok=0;const failed=[];
for(const o of list){
 try{
  const buf=await download(o.url,{Referer:'https://www.transfermarkt.com/'});
  const img=await sharp(buf).resize(120,120,{fit:'cover',position:'top'}).webp({quality:80}).toBuffer();
  if(o.kind==='ea'){writeFileSync(join(outEA,o.key+'.webp'),img);have.add(Number(o.key))}
  else{writeFileSync(join(outClub,o.key+'.webp'),img);media.faces.byPlayer[o.key]='club/'+o.key}
  sources[o.kind+':'+o.key]={name:o.name,source:o.source,page:o.page,check:o.check};ok++;
 }catch(e){failed.push(`${o.key}/${o.name}: ${e.message}`)}
}
media.faces.ea=[...have];writeMedia(media);writeFileSync(sourcesFile,JSON.stringify(sources,null,1));
console.log({aplicadas:ok,falhas:failed});
