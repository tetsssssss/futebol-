from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]
html=(root/'dist/index.html').read_text()
checks=[]
with sync_playwright() as pw:
 browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage','--no-zygote'])
 for width in (390,768,1440):
  page=browser.new_page(viewport={'width':width,'height':850})
  page.set_default_timeout(6000)
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.route('https://commons.wikimedia.org/**',lambda r:r.abort()) # offline behavior must degrade safely
  page.evaluate("() => {const d={};Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>d[k]??null,setItem:(k,v)=>d[k]=String(v),removeItem:k=>delete d[k]}})}")
  page.set_content(html,wait_until='load')
  assert 'Bem-vindo' in page.locator('h1').inner_text()
  assert 'Flamengo' in page.locator('body').inner_text()
  page.locator('[data-action="navigate"][data-target="players"]').first.click()
  assert page.locator('.player-name').inner_text()=='Lucas Paquetá'
  assert 'foto real' in page.locator('.photo-license').inner_text().lower()
  assert 'commons' in page.locator('.photo-license').inner_text().lower()
  assert 'real' in page.locator('body').inner_text().lower()
  page.locator('[data-tab="attrs"]').first.click()
  assert page.locator('.attribute-row').count()==70
  page.locator('#club-select').select_option('palmeiras')
  assert page.locator('#club-select').input_value()=='palmeiras'
  page.locator('[data-action="navigate"][data-target="scouting"]').first.click()
  assert '107 atletas reais' in page.locator('body').inner_text()
  page.locator('[data-action="navigate"][data-target="calendar"]').first.click()
  page.locator('[data-action="advance-week"]').first.click()
  page.locator('[data-action="navigate"][data-target="competitions"]').first.click()
  assert '2/12 partidas' in page.locator('body').inner_text()
  dim=page.evaluate('() => ({inner:innerWidth,scroll:document.documentElement.scrollWidth})')
  assert dim['scroll']<=dim['inner']+2,(width,dim)
  assert not errors,(width,errors)
  if width in (390,1440):page.screenshot(path=str(root/f'docs/preview-v04-{width}.png'),full_page=True)
  checks.append(f'{width}px: 107 atletas, imagem CC com fonte, fallback offline, 70 atributos, clube e calendário: OK')
  print(checks[-1],flush=True)
  page.close()
 browser.close()
(root/'docs/BROWSER_QA_V04.txt').write_text('\n'.join(checks)+'\nFotos externas não baixadas localmente; verificação cobriu fallback offline e endereços dos retratos.\n')
print('Browser QA concluído')
