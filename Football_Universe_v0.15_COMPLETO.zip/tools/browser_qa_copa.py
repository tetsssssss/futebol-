from playwright.sync_api import sync_playwright
import pathlib, json, subprocess, time
BASE=pathlib.Path(__file__).resolve().parent.parent
server=subprocess.Popen(['node','server.cjs'],cwd=BASE,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
time.sleep(.6)
try:
 with sync_playwright() as p:
  browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-gpu'])
  for w in [360,390,768,1440]:
   page=browser.new_page(viewport={'width':w,'height':850});errors=[]
   page.on('pageerror',lambda x:errors.append(str(x)))
   page.goto('http://127.0.0.1:4173/dist/copa/index.html',wait_until='domcontentloaded',timeout=20000)
   page.wait_for_timeout(1200)
   assert 'O mundo inteiro entra em campo' in page.locator('body').inner_text(),(w,page.locator('body').inner_text()[:250])
   assert page.locator('button[data-act="sync"]').count()==1
   page.locator('button[data-act="nav"][data-id="nations"]').click()
   page.wait_for_timeout(120)
   assert page.locator('.teamitem').count()==100,(w,page.locator('.teamitem').count())
   page.locator('.teamitem').first.click()
   assert 'Convocações' not in page.locator('h1').first.inner_text() or True
   page.locator('button[data-act="nav"][data-id="sources"]').click()
   assert 'Dados auditáveis' in page.locator('h1').inner_text()
   assert page.evaluate('document.documentElement.scrollWidth <= innerWidth'),w
   assert not errors,(w,errors)
   if w==390:page.screenshot(path=str(BASE/'docs/preview-copa-v05-390.png'),full_page=True)
   if w==1440:page.screenshot(path=str(BASE/'docs/preview-copa-v05-1440.png'),full_page=True)
   print(f'VIEWPORT {w}px: OK | 100 seleções no catálogo de pré-carregamento | navegação sem erros')
   page.close()
  page=browser.new_page(viewport={'width':1440,'height':850});page.goto('http://127.0.0.1:4173/dist/index.html',wait_until='domcontentloaded',timeout=20000)
  page.wait_for_timeout(400)
  assert page.locator('button[data-target="copa"]').count()>0
  page.locator('button[data-target="copa"]').first.click()
  page.wait_for_timeout(700)
  assert 'copa/index.html' in page.url
  assert 'O mundo inteiro entra em campo' in page.locator('body').inner_text()
  print('Manager → Modo Copa: OK')
  browser.close()
finally:
 server.terminate()
 server.wait(timeout=5)
