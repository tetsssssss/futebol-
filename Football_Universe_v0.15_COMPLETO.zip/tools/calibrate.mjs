// Calibração do motor: roda N partidas com sementes variadas e resume o que a simulação produz.
// Uso: node tools/calibrate.mjs [partidas] > qa/<versao>/calibration.json
import {clubTeams,startMatch,stepMatch} from '../treinador/engine.js';
import {summarizeMatch} from '../treinador/match-summary.js';
import {localX} from '../treinador/math.js';
const teams=clubTeams(),N=Number(process.argv[2]||60),sum={},keys=['shots','onTarget','passes','completedPasses','fouls','corners','saves','tackles','interceptions','dribbles','crosses','offsides','yellow','red','xG'];
let goals=0,draws=0,homeWins=0;const g=[],byRole={},shotsByRole={},assistsByRole={},shape={samples:0,width:0,length:0,line:0},passKinds={};
export function teamShape(s,side){ // largura e comprimento do bloco (jogadores de linha) e altura da linha defensiva, em % do campo
 const outfield=s.squads[side].playing.filter(p=>!p.dismissed&&p.role!=='GK'),xs=outfield.map(p=>localX(s,side,p.x)).sort((a,b)=>a-b),ys=outfield.map(p=>p.y);
 return {width:Math.max(...ys)-Math.min(...ys),length:xs.at(-1)-xs[0],line:(xs[0]+xs[1])/2};
}
for(let n=0;n<N;n++){const a=teams[(n*7)%teams.length],b=teams[(n*7+3+n%5)%teams.length];if(a.id===b.id)continue;
 const s=startMatch(a,b,'cal-'+n,false,{recordReplay:false});
 while(!s.finished){stepMatch(s);if(s.tick%25===0&&!s.restart)for(const side of [0,1]){const t=teamShape(s,side);shape.samples++;shape.width+=t.width;shape.length+=t.length;shape.line+=t.line}}
 for(const k of keys)sum[k]=(sum[k]||0)+s.stats[k][0]+s.stats[k][1];
 const t=s.score[0]+s.score[1];goals+=t;g.push(t);if(s.score[0]===s.score[1])draws++;if(s.score[0]>s.score[1])homeWins++;
 const roles=new Map(s.squads.flatMap(q=>[...q.playing,...(q.out||[])]).map(p=>[p.id,p.role||p.position]));
 for(const l of Object.values(summarizeMatch(s).lines)){const r=roles.get(l.id)||l.pos||'?';byRole[r]=(byRole[r]||0)+l.g;shotsByRole[r]=(shotsByRole[r]||0)+l.sh;assistsByRole[r]=(assistsByRole[r]||0)+l.a}
 for(const k of ['short','medium','long','switch','through','back','firstTime','oneTwo','assist','shortDistribution','longDistribution'])passKinds[k]=(passKinds[k]||0)+(s.actionCounts[k]||0);
 sum.poss0=(sum.poss0||0)+s.stats.possession[0]/(s.stats.possession[0]+s.stats.possession[1]);sum.n=(sum.n||0)+1}
const n=sum.n,share=o=>Object.fromEntries(Object.entries(o).sort((a,b)=>b[1]-a[1]).map(([k,v])=>[k,+(v/Object.values(o).reduce((x,y)=>x+y,0)).toFixed(3)]));
const out={matches:n,goals:+(goals/n).toFixed(2),goalsMax:Math.max(...g),draws:+(draws/n).toFixed(2),homeWins:+(homeWins/n).toFixed(2),possHomeAvg:+(sum.poss0/n).toFixed(2)};
for(const k of keys)out[k]=+(sum[k]/n).toFixed(2);
out.passAcc=+(sum.completedPasses/sum.passes).toFixed(2);out.shotOnTargetRate=+(sum.onTarget/sum.shots).toFixed(2);
out.goalShareByRole=share(byRole);out.shotShareByRole=share(shotsByRole);out.assistShareByRole=share(assistsByRole);out.passKindShare=share(passKinds);
out.shape={width:+(shape.width/shape.samples).toFixed(1),length:+(shape.length/shape.samples).toFixed(1),defensiveLine:+(shape.line/shape.samples).toFixed(1)};
console.log(JSON.stringify(out,null,1));
