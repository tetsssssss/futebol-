// Baixa escudos (federações e clubes) e a imagem do uniforme principal para assets/badges e assets/kits (WebP),
// extrai cores e padrão do uniforme (campos ci/pi; tools/resolve-kits.mjs decide as cores finais c/p) e atualiza data/media.json + src/media-index.js.
// Fonte: TheSportsDB (chave pública de teste). Uso: node tools/fetch-teams.mjs [--cache pasta] [--only id1,id2]
import {readFileSync,writeFileSync,existsSync} from 'node:fs';
import {join} from 'node:path';
import {ROOT,loadSharp,ensureDir,download,sleep,readMedia,writeMedia} from './media-lib.mjs';
import {NATIONS,cleanName} from '../treinador/nations.js';
import {CONMEBOL_CLUBS} from '../treinador/conmebol.js';
import {CLUB_DIRECTORY} from '../treinador/league.js';
const args=process.argv.slice(2),opt=n=>{const i=args.indexOf('--'+n);return i>=0?args[i+1]:null};
const cacheDir=ensureDir(opt('cache')||join(ROOT,'qa/tsdb-cache')),only=opt('only')?.split(',');
const sharp=loadSharp(),outBadge=ensureDir(join(ROOT,'assets/badges')),outKit=ensureDir(join(ROOT,'assets/kits'));
const COUNTRY={ARG:'Argentina',BOL:'Bolivia',CHI:'Chile',COL:'Colombia',ECU:'Ecuador',PAR:'Paraguay',PER:'Peru',URU:'Uruguay',VEN:'Venezuela',BRA:'Brazil'};
// Consultas alternativas para nomes que a base escreve de outro jeito.
const QUERY={'bo-the-strongest':['Strongest','The Strongest','Strongest La Paz','Club The Strongest'],'cl-ohiggins':["O'Higgins",'O Higgins','CD O Higgins'],'cl-colo-colo':['Colo-Colo','Colo Colo'],'co-santa-fe':['Independiente Santa Fe','Santa Fe'],'co-junior':['Atletico Junior','Junior Barranquilla','Junior FC'],
 'ec-barcelona':['Barcelona SC','Barcelona Guayaquil'],'ec-universidad-catolica':['Universidad Catolica Quito','Universidad Catolica del Ecuador','Universidad Catolica'],'ec-libertad':['Libertad FC','Libertad Loja'],'py-libertad':['Libertad Asuncion','Club Libertad','Libertad'],'py-guarani':['Guarani Asuncion','Club Guarani','Guarani'],
 'py-nacional':['Club Nacional Asuncion','Nacional Asuncion','Club Nacional'],'py-olimpia':['Olimpia Asuncion','Club Olimpia','Olimpia'],'uy-nacional':['Club Nacional de Football','Nacional Montevideo','Nacional'],'uy-liverpool':['Liverpool Montevideo','Liverpool FC Montevideo'],
 'uy-juventud':['Juventud de Las Piedras','Juventud'],'uy-racing':['Racing Club de Montevideo','Racing Montevideo'],'ve-zamora':['Zamora FC','Zamora'],GEO:['Sakartvelo','Georgia'],TLS:['East Timor','Timor-Leste','Timor Leste'],
 'athletico-pr':['Athletico Paranaense','Athletico PR','Atletico Paranaense'],'bragantino':['Red Bull Bragantino','Bragantino'],'vasco':['Vasco da Gama'],'atletico-mg':['Atletico Mineiro','Atlético Mineiro'],
 'athletic':['Athletic Club Brazil','Athletic Club','Athletic-MG'],'sport':['Sport Recife','Sport Club do Recife'],'america-mg':['America Mineiro','América Mineiro'],'botafogo-sp':['Botafogo SP','Botafogo-SP'],'operario-pr':['Operario PR','Operário Ferroviário','Operario-PR'],
 'avai':['Avai','Avaí'],'sao-bernardo':['Sao Bernardo','São Bernardo'],'vila-nova':['Vila Nova'],'crb':['CRB','Clube de Regatas Brasil'],'ceara':['Ceara','Ceará'],'cuiaba':['Cuiaba','Cuiabá'],'goias':['Goias','Goiás'],'nautico':['Nautico','Náutico'],
 'ferroviaria':['Ferroviaria','Ferroviária'],'volta-redonda':['Volta Redonda'],'mirassol':['Mirassol'],'remo':['Remo'],'chapecoense':['Chapecoense'],'novorizontino':['Novorizontino','Grêmio Novorizontino'],'criciuma':['Criciuma','Criciúma'],'londrina':['Londrina'],
 'ponte-preta':['Ponte Preta','AA Ponte Preta'],'juventude':['Juventude','EC Juventude']};
const tsdb=async q=>{const f=join(cacheDir,cleanName(q).replace(/ /g,'_')+'.json');if(existsSync(f))return JSON.parse(readFileSync(f,'utf8'));
 await sleep(2100);const buf=await download('https://www.thesportsdb.com/api/v1/json/3/searchteams.php?t='+encodeURIComponent(q));
 let data;try{data=JSON.parse(buf.toString('utf8'))}catch{data={teams:null}}writeFileSync(f,JSON.stringify(data));return data};
const nationQueries=n=>[...new Set([...(QUERY[n.code]||[]),...n.aliases.slice().reverse(),n.name])];
/** Identifica o time pedido entre os resultados; devolve null em vez de arriscar um escudo trocado. */
function pick(results,queries,{country,national}){
 const names=queries.map(cleanName),teams=(results||[]).filter(t=>t.strSport==='Soccer');
 const scored=teams.map(t=>{const n=cleanName(t.strTeam),alt=cleanName(t.strTeamAlternate||'').split(' , ').concat(String(t.strTeamAlternate||'').split(',').map(cleanName));
  let s=0;if(names.includes(n))s=10;else if(names.some(q=>alt.includes(q)))s=7;else if(names.some(q=>n.includes(q)||q.includes(n)))s=4;
  const c=cleanName(t.strCountry||'');
  if(national){if(/\b(u\s?\d\d|women|olympic|wfc)\b/i.test(t.strTeam))s=0;if(!/world cup|friendl|qualif|nations|cup of nations|asian cup|gold cup|copa america|euro/i.test(`${t.strLeague} ${t.strLeague2} ${t.strLeague3} ${t.strLeague4}`))s=Math.min(s,3)}
  else if(country&&c!==cleanName(country))s=0;
  return {t,s}}).filter(x=>x.s>0).sort((a,b)=>b.s-a.s);
 return scored[0]?.s>=(national?7:4)?scored[0].t:null;
}
/** Cores e padrão a partir da imagem do uniforme: quantiza o tronco da camisa e conta transições entre as duas cores dominantes. */
async function analyzeKit(buf){
 const {data,info}=await sharp(buf).resize(120,120,{fit:'contain',background:{r:0,g:0,b:0,alpha:0}}).ensureAlpha().raw().toBuffer({resolveWithObject:true}),W=info.width,H=info.height;
 const px=(x,y)=>{const i=(y*W+x)*4;return data[i+3]<140?null:[data[i],data[i+1],data[i+2]]};
 const x0=Math.round(W*.3),x1=Math.round(W*.7),y0=Math.round(H*.3),y1=Math.round(H*.75),hist=new Map();
 for(let y=y0;y<y1;y++)for(let x=x0;x<x1;x++){const p=px(x,y);if(!p)continue;const k=p.map(v=>v>>5).join(',');const e=hist.get(k)||{n:0,s:[0,0,0]};e.n++;p.forEach((v,i)=>e.s[i]+=v);hist.set(k,e)}
 const bins=[...hist.values()].map(e=>({n:e.n,c:e.s.map(v=>Math.round(v/e.n))})).sort((a,b)=>b.n-a.n),dist=(a,b)=>Math.hypot(a[0]-b[0],a[1]-b[1],a[2]-b[2]);
 if(!bins.length)return null;const c1=bins[0].c,total=bins.reduce((n,b)=>n+b.n,0);
 const second=bins.find(b=>dist(b.c,c1)>70&&b.n/total>.06),c2=second?second.c:null;
 const label=p=>{if(!p)return -1;const a=dist(p,c1),b=c2?dist(p,c2):1e9;return Math.min(a,b)>90?-1:a<=b?0:1};
 const transitions=seq=>{let t=0,last=-1;for(const v of seq){if(v<0)continue;if(last>=0&&v!==last)t++;last=v}return t},med=a=>a.sort((x,y)=>x-y)[a.length>>1]||0;
 const rowsT=[],colsT=[];
 for(let y=y0;y<y1;y++){const seq=[];for(let x=x0;x<x1;x++)seq.push(label(px(x,y)));rowsT.push(transitions(seq))}
 for(let x=x0;x<x1;x++){const seq=[];for(let y=y0;y<y1;y++)seq.push(label(px(x,y)));colsT.push(transitions(seq))}
 const hx=med(rowsT),hy=med(colsT),share=second?second.n/total:0;let pattern='solid';
 if(c2&&share>.1){if(hx>=3&&hx>hy)pattern='stripes';else if(hy>=3&&hy>hx)pattern='hoops';else if(hx===1&&hy<=1)pattern='halves';else if(hx>=1&&hy>=1)pattern='sash';else pattern='solid'}
 const hex=c=>'#'+c.map(v=>v.toString(16).padStart(2,'0')).join('');
 return {c:[hex(c1),...(c2?[hex(c2)]:[])],p:pattern};
}
const wanted=[...CLUB_DIRECTORY.map(c=>({id:c.id,name:c.name,queries:QUERY[c.id]||[c.name],country:'Brazil'})),
 ...CONMEBOL_CLUBS.map(c=>({id:c.id,name:c.name,queries:[...(QUERY[c.id]||[]),c.name.replace(/\s*\(.*\)$/,''),c.name],country:COUNTRY[c.country]})),
 ...NATIONS.map(n=>({id:n.code,name:n.name,queries:nationQueries(n),national:true}))].filter(t=>!only||only.includes(t.id));
const media=readMedia(),log={ok:0,noTeam:[],noBadge:[],noKit:[]};
for(const t of wanted){
 let team=null;
 for(const q of t.queries){const r=await tsdb(q);team=pick(r.teams,t.queries,t);if(team)break}
 if(!team){log.noTeam.push(`${t.id} ${t.name}`);continue}
 const entry=media.teams[t.id]={tsdb:team.idTeam,n:team.strTeam};
 const official=[team.strColour1,team.strColour2,team.strColour3].filter(c=>/^#[0-9a-f]{6}$/i.test(c||'')).map(c=>c.toLowerCase());if(official.length)entry.o=official;
 try{if(team.strBadge){writeFileSync(join(outBadge,t.id+'.webp'),await sharp(await download(team.strBadge)).resize(128,128,{fit:'contain',background:{r:0,g:0,b:0,alpha:0}}).webp({quality:85}).toBuffer());entry.b=1}else log.noBadge.push(t.id)}catch(e){log.noBadge.push(t.id+' '+e.message)}
 try{if(team.strEquipment){const kit=await download(team.strEquipment);{const a=await analyzeKit(kit);if(a){entry.ci=a.c;entry.pi=a.p}}
   writeFileSync(join(outKit,t.id+'.webp'),await sharp(kit).resize(160,160,{fit:'contain',background:{r:0,g:0,b:0,alpha:0}}).webp({quality:82}).toBuffer());entry.k=1}else log.noKit.push(t.id)}catch(e){log.noKit.push(t.id+' '+e.message)}
 log.ok++;if(log.ok%25===0){console.log(log.ok,'/',wanted.length);writeMedia(media)}
}
writeMedia(media);
writeFileSync(join(ROOT,'qa/media-teams-report.json'),JSON.stringify({total:wanted.length,...log},null,1));
console.log(JSON.stringify({total:wanted.length,ok:log.ok,noTeam:log.noTeam,noBadge:log.noBadge,noKit:log.noKit},null,1));
