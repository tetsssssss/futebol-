"""Smoke test browser real com Playwright/Chromium, sem rede."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import json
root=Path(__file__).resolve().parents[1]
html=(root/'dist/index.html').read_text()
rows=[]
with sync_playwright() as pw:
 browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage','--no-zygote'])
 for width in [390,768,1440]:
  page=browser.new_page(viewport={'width':width,'height':900},accept_downloads=True)
  page.set_default_timeout(6000)
  errs=[]
  page.on('pageerror',lambda err:errs.append(str(err)))
  page.evaluate("""() => {const mem={};Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>mem[k]??null,setItem:(k,v)=>mem[k]=String(v),removeItem:k=>delete mem[k]}})}""")
  page.set_content(html,wait_until='load')
  assert 'Bem-vindo' in page.locator('h1').inner_text()
  page.locator('[data-action="navigate"][data-target="calendar"]').first.click()
  assert page.locator('#individual-training-form').count()==1
  page.locator('#individual-player').select_option('aurora-p2')
  page.locator('#individual-focus').select_option('Ataque')
  page.locator('#individual-training-form [type="submit"]').click()
  assert 'Ataque' in page.locator('#individual-player').inner_text()
  # Test reschedule of f1 without fixture collision.
  page.locator('#fixture-id').select_option('f1')
  page.locator('#fixture-date').fill('2026-10-11')
  page.locator('#reschedule-form [type="submit"]').click()
  assert '11 de out.' in page.locator('.fixture').first.inner_text().lower() or page.locator('#reschedule-form').count()==1
  page.locator('[data-action="navigate"][data-target="scouting"]').first.click()
  assert 'R$ 30 mil' in page.locator('.panel').last.inner_text() or '30 mil' in page.locator('body').inner_text()
  page.locator('[data-action="observe"]').first.click()
  assert page.locator('[data-action="cancel-observe"]').count()>=1
  page.locator('[data-action="cancel-observe"]').first.click()
  assert 'cancelada' in page.locator('#notification').inner_text().lower()
  page.locator('[data-action="navigate"][data-target="competitions"]').first.click()
  assert '0/12 partidas' in page.locator('.grid.cols-3').first.inner_text()
  assert page.locator('[data-action="complete-season"]').is_disabled()
  # Simulate 6 weeks (12 fixtures), close and archive season.
  for _ in range(6):
   page.locator('[data-action="navigate"][data-target="calendar"]').first.click()
   page.locator('[data-action="advance-week"]').first.click()
  page.locator('[data-action="navigate"][data-target="competitions"]').first.click()
  assert '12/12 partidas' in page.locator('.grid.cols-3').first.inner_text()
  assert not page.locator('[data-action="complete-season"]').is_disabled()
  page.locator('[data-action="complete-season"]').click()
  assert '2026 · Campeão' in page.locator('body').inner_text()
  page.locator('[data-action="navigate"][data-target="saves"]').last.click()
  page.locator('[data-action="save-slot"][data-slot="slot1"]').click()
  page.locator('[data-action="load-slot"][data-slot="slot1"]').click()
  page.locator('[data-action="navigate"][data-target="players"]').first.click()
  page.locator('[data-tab="attrs"]').first.click()
  assert page.locator('.attribute-row').count()==70
  dims=page.evaluate('() => ({view:innerWidth,scroll:document.documentElement.scrollWidth})')
  assert dims['scroll']<=dims['view']+1,(width,dims)
  assert not errs,(width,errs)
  if width in (390,1440):page.screenshot(path=str(root/f'docs/preview-v03-{width}.png'),full_page=True)
  rows.append(f'{width}px: calendário editável, treino individual, scouting cancelável, 12 jogos, temporada histórica, saves, ficha e responsividade OK')
  print(rows[-1],flush=True)
  page.close()
 # V2 save (six fixtures) migration in browser
 page=browser.new_page(viewport={'width':1440,'height':900})
 snap=json.loads((root/'data/demo-world.json').read_text())
 snap['schemaVersion']=2;snap['fixtures']=snap['fixtures'][:6];snap.pop('seasonHistory');snap['training'].pop('individual')
 rec=json.dumps({'autosave':{'savedAt':'2026-10-09T00:00:00Z','world':snap}})
 page.evaluate("""({rec})=>{const mem={'football-universe-v01':rec};Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>mem[k]??null,setItem:(k,v)=>mem[k]=String(v),removeItem:k=>delete mem[k]}})}""",{'rec':rec})
 page.set_content(html,wait_until='load')
 page.locator('[data-action="navigate"][data-target="competitions"]').first.click()
 assert '0/12 partidas' in page.locator('.grid.cols-3').first.inner_text()
 broken=json.loads(json.dumps(snap));broken['clubs'][1]['id']=broken['clubs'][0]['id']
 page.locator('[data-action="navigate"][data-target="saves"]').last.click()
 page.locator('#import-file').set_input_files({'name':'corrompido.json','mimeType':'application/json','buffer':json.dumps(broken).encode()})
 assert 'duplicado' in page.locator('#notification').inner_text().lower()
 page.locator('[data-action="navigate"][data-target="competitions"]').first.click()
 assert '0/12 partidas' in page.locator('.grid.cols-3').first.inner_text()
 rows.append('Navegador: migração v2→v3 e rejeição de importação adulterada sem perda do mundo = OK')
 page.close()
 browser.close()
(root/'docs/BROWSER_QA_V03.txt').write_text('\n'.join(rows)+'\nHTML carregado via set_content; roteamento HTTP não avaliado.\n')
print('QA BROWSER v0.3: OK')
