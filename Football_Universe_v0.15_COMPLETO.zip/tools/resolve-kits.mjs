// Decide as cores e o padrão finais do uniforme principal de cada equipe e grava em data/media.json (c = [principal, secundária], p = padrão).
// Ordem de confiança: tabela curada (clubes brasileiros) > imagem do uniforme, quando concorda com a cor de identidade da equipe >
// cor de identidade (seleções da Copa, cores declaradas dos clubes) > cores oficiais do cadastro. Nunca inventa padrão sem imagem que o confirme.
// Uso: node tools/resolve-kits.mjs
import {readMedia,writeMedia} from './media-lib.mjs';
import {NATION_COLORS} from '../treinador/engine.js';
import {CLUB_DIRECTORY} from '../treinador/league.js';
import {CONMEBOL_CLUBS} from '../treinador/conmebol.js';
import {fallbackColor} from '../treinador/nations.js';
import {CURATED} from './kits-curated.mjs';
const media=readMedia(),rgb=c=>[1,3,5].map(i=>parseInt(c.slice(i,i+2),16)),dist=(a,b)=>Math.hypot(...rgb(a).map((v,i)=>v-rgb(b)[i])),agree=(a,b)=>a&&b&&dist(a,b)<120;
const base={};
for(const [id,c] of Object.entries(NATION_COLORS))base[id]=c;
for(const c of CLUB_DIRECTORY)base[c.id]=c.color;
for(const c of CONMEBOL_CLUBS)if(c.color&&c.color!==fallbackColor(c.id))base[c.id]=c.color;
const stats={curated:0,image:0,identity:0,official:0,none:0};
for(const [id,t] of Object.entries(media.teams)){
 if(t.ci===undefined&&t.c){t.ci=t.c;t.pi=t.p}
 const cur=CURATED[id],ci=t.ci||[],official=t.o||[];
 if(cur){t.c=[cur[0],cur[1]];t.p=cur[2];stats.curated++;continue}
 const ref=base[id]||official[0]||null;
 if(ci.length&&(!ref||agree(ci[0],ref))){const main=base[id]||ci[0]; // a cor de identidade, mais limpa que o tom da foto
  t.c=ci.length>1?[main,ci[1]]:[main];t.p=ci.length>1?t.pi||'solid':'solid';stats.image++}
 else if(ci.length>1&&agree(ci[1],ref)){t.c=[base[id]||ci[1],ci[0]];t.p=t.pi||'solid';stats.image++}
 else if(ref){const second=official.find(c=>dist(c,ref)>90)||null;t.c=second?[ref,second]:[ref];t.p='solid';stats[base[id]?'identity':'official']++}
 else{delete t.c;delete t.p;stats.none++}
}
writeMedia(media);
console.log(stats);
