from playwright.sync_api import sync_playwright
from pathlib import Path
import json
base=Path(__file__).resolve().parents[1]
html=(base/'dist'/'treinador'/'index.html').read_text()
report=[]
storage="""() => {const store = {}; Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem(k){return store[k]??null},setItem(k,v){store[k]=String(v)},removeItem(k){delete store[k]},clear(){Object.keys(store).forEach(k=>delete store[k])}}});}"""
with sync_playwright() as p:
  browser=p.chromium.launch(headless=True, executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-gpu','--disable-dev-shm-usage'])
  for width,height in [(390,844),(768,900),(1440,900)]:
    errs=[]
    page=browser.new_page(viewport={'width':width,'height':height})
    page.on('pageerror',lambda e:errs.append(str(e)))
    page.evaluate(storage)
    page.set_content(html,wait_until='domcontentloaded',timeout=15000)
    page.wait_for_timeout(200)
    assert page.get_by_text('Começar carreira de treinador').count()==1,'Tela inicial não abriu'
    page.locator('[data-action="create-league"]').click()
    assert 'Brasileirão' in page.locator('.status').inner_text()
    page.locator('[data-action="play-next"]').click()
    assert page.locator('#pitch').count()==1
    page.locator('#mental').select_option('attacking')
    assert page.locator('#mental').input_value()=='attacking'
    page.locator('#sub-out').select_option(index=2)
    page.locator('#sub-in').select_option(index=1)
    page.locator('[data-action="sub"]').click()
    assert '1/5' in page.locator('h3').all_inner_texts()[1]
    page.locator('[data-action="step5"]').click()
    assert "5'" in page.locator('.scoreline').inner_text(),page.locator('.scoreline').inner_text()
    if width==1440: page.screenshot(path=str(base/'docs'/'preview-v06-2d-desktop.png'),full_page=True)
    if width==390: page.screenshot(path=str(base/'docs'/'preview-v06-2d-mobile.png'),full_page=True)
    page.locator('[data-action="finish-game"]').click()
    page.locator('[data-action="register-game"]').click()
    assert page.locator('.fixture .pill').count()==1,'Partida deveria ser concluída'
    page.locator('[data-action="tab-classificacao"]').click()
    assert page.locator('table tbody tr').count()==20
    overflow=page.evaluate('document.documentElement.scrollWidth > innerWidth')
    page.close()
    cup=browser.new_page(viewport={'width':width,'height':height})
    cup.on('pageerror',lambda e:errs.append(str(e)))
    cup.evaluate(storage)
    cup.set_content(html,wait_until='domcontentloaded',timeout=15000)
    cup.wait_for_timeout(150)
    cup.locator('[data-action="create-cup"]').click()
    assert 'Copa do Mundo' in cup.locator('.status').inner_text()
    cup.locator('[data-action="play-next"]').click()
    assert cup.locator('#pitch').count()==1
    cup.locator('[data-action="step1"]').click()
    cup.locator('[data-action="tab-calendario"]').click()
    assert cup.locator('.fixture').count()==72
    overflow=overflow or cup.evaluate('document.documentElement.scrollWidth > innerWidth')
    report.append({'width':width,'league':True,'cup':True,'browser_errors':errs,'horizontal_overflow':overflow})
    cup.close()
  browser.close()
print(json.dumps(report,ensure_ascii=False,indent=2))
assert all(not i['browser_errors'] and not i['horizontal_overflow'] for i in report)
