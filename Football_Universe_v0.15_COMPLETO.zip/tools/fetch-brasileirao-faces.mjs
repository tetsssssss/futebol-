// Baixa os retratos do Transfermarkt dos atletas de data/brasileirao-portraits.json para assets/faces/club (WebP) e atualiza o índice.
// Atleta sem retrato lá (default.jpg) mantém a foto que já tinha, se tiver, ou fica com avatar.
// Uso: node tools/fetch-brasileirao-faces.mjs
import {readFileSync,writeFileSync,existsSync} from 'node:fs';
import {join} from 'node:path';
import {ROOT,loadSharp,ensureDir,download,readMedia,writeMedia} from './media-lib.mjs';
const sharp=loadSharp(),out=ensureDir(join(ROOT,'assets/faces/club'));
const list=JSON.parse(readFileSync(join(ROOT,'data/brasileirao-portraits.json'),'utf8')),media=readMedia(),old=media.faces.byPlayer||{};
const sourcesFile=join(ROOT,'data/media-sources.json'),sources=existsSync(sourcesFile)?JSON.parse(readFileSync(sourcesFile,'utf8')):{};
const next={};let ok=0,none=0,failed=0,kept=0;
async function one(p){
 if(old[p.id]===('club/'+p.id)&&existsSync(join(out,p.id+'.webp'))){next[p.id]=old[p.id];ok++;return} // já baixado: retomada
 await new Promise(r=>setTimeout(r,250));
 const file=(p.img||'').replace(/^medium\//,'').replace(/^small\//,'').replace(/^big\//,'');
 if(!file||/^default/.test(file)){if(old[p.id]){next[p.id]=old[p.id];kept++}else none++;return}
 try{
  const buf=await download('https://img.a.transfermarkt.technology/portrait/big/'+file.split('?')[0],{Referer:'https://www.transfermarkt.com/'});
  writeFileSync(join(out,p.id+'.webp'),await sharp(buf).resize(120,120,{fit:'cover',position:'top'}).webp({quality:80}).toBuffer());
  next[p.id]='club/'+p.id;sources['club:'+p.id]={name:p.name,source:'Transfermarkt',page:'https://www.transfermarkt.com/-/profil/spieler/'+p.tm,check:'elenco oficial do clube na página do Transfermarkt'};ok++;
 }catch(e){if(old[p.id]){next[p.id]=old[p.id];kept++}else failed++}
}
let i=0;await Promise.all(Array.from({length:3},async()=>{while(i<list.length)await one(list[i++])}));
media.faces.byPlayer=next;writeMedia(media);writeFileSync(sourcesFile,JSON.stringify(sources,null,1));
console.log({retratos:ok,mantidas:kept,semRetrato:none,falhas:failed,total:list.length});
