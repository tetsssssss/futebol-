// Diagnóstico de fluxo de jogo: onde as posses acontecem, como terminam e que passes se perdem.
// Uso: node tools/diagnose.mjs [partidas]
import {clubTeams,startMatch,stepMatch} from '../treinador/engine.js';
import {localX} from '../treinador/math.js';
const teams=clubTeams(),N=Number(process.argv[2]||12),zone=x=>x<33?'defesa':x<66?'meio':'ataque';
const time={defesa:0,meio:0,ataque:0},launched={},lost={},ends={},entries={n:0,shots:0};let ticks=0,possessions=0;
for(let n=0;n<N;n++){
 const s=startMatch(teams[(n*7)%20],teams[(n*7+3+n%5)%20],'diag-'+n,false,{recordReplay:false});let last=null,seq=0,owner=s.possession,reached=false;
 while(!s.finished){
  const before=s.action;stepMatch(s);ticks++;time[zone(localX(s,s.possession,s.ball.x))]++;
  if(s.action&&s.action!==before&&['pass','cross','distribution'].includes(s.action.kind)){last={kind:s.action.subtype,zone:zone(localX(s,s.action.side,s.action.from.x)),side:s.action.side};const k=last.zone+'/'+last.kind;launched[k]=(launched[k]||0)+1}
  for(const e of s.events.slice(seq)){
   if(e.type==='interception'&&last){const k=last.zone+'/'+last.kind;lost[k]=(lost[k]||0)+1}
   if(e.type==='shot'&&reached){entries.shots++;reached=false}
  }
  seq=s.events.length;
  if(localX(s,s.possession,s.ball.x)>66&&!reached&&s.possession===owner){reached=true;entries.n++}
  if(s.possession!==owner){possessions++;const why=s.events.slice(-3).map(e=>e.type).find(t=>['interception','tackle','save','goal','foul','offside','goalKick','throwIn','corner','block'].includes(t))||'outro';ends[why]=(ends[why]||0)+1;owner=s.possession;reached=false}
 }
}
const per=o=>Object.fromEntries(Object.entries(o).sort((a,b)=>b[1]-a[1]).map(([k,v])=>[k,+(v/N).toFixed(1)]));
const risk=Object.fromEntries(Object.keys(launched).filter(k=>launched[k]>N*2).sort((a,b)=>(lost[b]||0)/launched[b]-(lost[a]||0)/launched[a]).map(k=>[k,`${Math.round(100*(lost[k]||0)/launched[k])}% de ${(launched[k]/N).toFixed(1)}`]));
console.log(JSON.stringify({partidas:N,tempoPorZona:Object.fromEntries(Object.entries(time).map(([k,v])=>[k,+(v/ticks).toFixed(2)])),possesPorJogo:+(possessions/N).toFixed(1),fimDaPosse:per(ends),entradasNoTercoFinal:+(entries.n/N).toFixed(1),entradasQueViramChute:+(entries.shots/entries.n).toFixed(2),interceptacaoPorTipoDePasse:risk},null,1));
