// Utilidades das ferramentas de mídia (fotos, escudos e uniformes): carregamento do sharp, índice e pausas.
// Uso interno de tools/fetch-faces.mjs e tools/fetch-teams.mjs. Requer `sharp` (npm i --no-save sharp) ou SHARP_DIR apontando para uma pasta que o tenha.
import {readFileSync,writeFileSync,existsSync,mkdirSync} from 'node:fs';
import {createRequire} from 'node:module';
import {join,resolve,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
export const ROOT=resolve(dirname(fileURLToPath(import.meta.url)),'..');
export const MEDIA_JSON=join(ROOT,'data/media.json'),MEDIA_JS=join(ROOT,'src/media-index.js');
export const sleep=ms=>new Promise(r=>setTimeout(r,ms));
export function loadSharp(){
 for(const base of [ROOT+'/',process.env.SHARP_DIR?process.env.SHARP_DIR+'/':null]){if(!base)continue;try{return createRequire(base+'x.js')('sharp')}catch{}}
 throw Error('sharp não encontrado. Rode `npm i --no-save sharp` na pasta do projeto ou defina SHARP_DIR.');
}
export const ensureDir=dir=>{mkdirSync(dir,{recursive:true});return dir};
export function readMedia(){return existsSync(MEDIA_JSON)?JSON.parse(readFileSync(MEDIA_JSON,'utf8')):{faces:{ea:[],fifa:[],byPlayer:{}},teams:{}}}
/** Grava data/media.json e o módulo src/media-index.js que o navegador importa (sem depender de JSON import). */
export function writeMedia(media){
 media.faces.ea=[...new Set(media.faces.ea)].sort((a,b)=>a-b);media.faces.fifa=[...new Set(media.faces.fifa)].sort();
 writeFileSync(MEDIA_JSON,JSON.stringify(media));
 const js=`// Gerado por tools/fetch-faces.mjs e tools/fetch-teams.mjs. Não editar à mão.\n// faces.ea: ids numéricos da SoFIFA; faces.fifa: uuids das listas da Copa; faces.byPlayer: atleta de clube → arquivo.\n// teams[id]: b=escudo, k=uniforme, c=[principal,secundária], p=padrão, o=cores oficiais.\nexport const MEDIA_INDEX=${JSON.stringify(media)};\n`;
 writeFileSync(MEDIA_JS,js);
}
/** Baixa uma URL como Buffer; repete quando há limite de requisições. */
export async function download(url,headers={},tries=4){
 for(let i=0;i<tries;i++){
  try{const r=await fetch(url,{headers:{'User-Agent':'Mozilla/5.0 FootballUniverse-personal',...headers}});
   if(r.status===429||r.status>=500){await sleep(2500*(i+1));continue}
   if(!r.ok)throw Error('HTTP '+r.status);return Buffer.from(await r.arrayBuffer())}
  catch(e){if(i===tries-1)throw e;await sleep(1500)}
 }
 throw Error('falha ao baixar '+url);
}
