// Procura, numa base histórica de FIFA/EA FC (sofifa, todas as edições, vários GB), os atletas dos elencos de data/tm-squads-2026.json.
// Casamento: mesma data de nascimento + nacionalidade + termos do nome; fica a edição mais recente de cada atleta.
// Só as colunas usadas por attributeProfile() são guardadas em data/ea-history-2026.json.
// Uso: node tools/extract-ea-history.mjs <caminho do male_players.csv>   (ex.: huggingface.co/datasets/jsulz/FIFA23, ~5 GB)
import {createReadStream,readFileSync,writeFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import {cleanName} from '../treinador/nations.js';
import {EA_COLUMNS} from '../copa/data-loader.js';
const csv=process.argv[2];if(!csv)throw Error('Informe o caminho do CSV.');
const squads=JSON.parse(readFileSync(new URL('../data/tm-squads-2026.json',import.meta.url),'utf8')).squads;
const COMMON=new Set(['silva','santos','souza','sousa','oliveira','pereira','lima','gomes','ferreira','costa','rodrigues','alves','carvalho','junior','filho','neto','jose','joao','luiz','luis','paulo','pedro','lucas','gabriel','matheus']);
const byDob=new Map();
for(const [club,list] of Object.entries(squads))for(const p of list){if(p.born)(byDob.get(p.born)||byDob.set(p.born,[]).get(p.born)).push({key:club+'|'+p.tm,toks:cleanName(p.name).split(' ').filter(Boolean),nat:new Set(p.nat.map(cleanName))})}
const wanted=[...new Set([...EA_COLUMNS,'fifa_version','fifa_update','long_name','short_name','dob','nationality_name','club_name'])];
let header=null,idx={},row=[],cell='',q=false,rows=0;const hits=new Map();
function onRow(r){
 if(!header){header=r;r.forEach((c,i)=>idx[c]=i);return}
 rows++;const cands=byDob.get(r[idx.dob]);if(!cands)return;
 const ea=new Set(cleanName(r[idx.long_name]+' '+r[idx.short_name]).split(' ')),nat=cleanName(r[idx.nationality_name]);
 for(const c of cands){
  if(!c.nat.has(nat))continue;
  const common=c.toks.filter(t=>ea.has(t)),strong=common.filter(t=>!COMMON.has(t));
  if(!(common.length>=2||strong.length>=1||(c.toks.length===1&&common.length===1)))continue;
  const ver=Number(r[idx.fifa_version])*100+Number(r[idx.fifa_update]||0),prev=hits.get(c.key);
  if(!prev||ver>prev.ver)hits.set(c.key,{ver,row:Object.fromEntries(wanted.filter(w=>idx[w]!==undefined).map(w=>[w,r[idx[w]]]))});
 }
}
for await(const chunk of createReadStream(csv,{encoding:'utf8',highWaterMark:1<<22})){
 for(let i=0;i<chunk.length;i++){const ch=chunk[i];
  if(ch==='"'){if(q&&chunk[i+1]==='"'){cell+='"';i++}else q=!q}
  else if(ch===','&&!q){row.push(cell);cell=''}
  else if((ch==='\n'||ch==='\r')&&!q){if(ch==='\r'&&chunk[i+1]==='\n')i++;row.push(cell);cell='';if(row.length>5)onRow(row);row=[]}
  else cell+=ch}
}
const out=Object.fromEntries([...hits].map(([k,v])=>[k,{edition:Math.floor(v.ver/100),...v.row}]));
writeFileSync(fileURLToPath(new URL('../data/ea-history-2026.json',import.meta.url)),JSON.stringify(out));
const byEd={};for(const v of Object.values(out))byEd[v.edition]=(byEd[v.edition]||0)+1;
console.log({linhas:rows,casados:hits.size,porEdicao:byEd});
