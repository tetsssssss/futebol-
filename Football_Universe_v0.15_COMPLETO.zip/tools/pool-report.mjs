// Relatório de cobertura dos elencos de seleções a partir de arquivos locais da base de 2026.
// Uso: node tools/pool-report.mjs <pasta com players.csv e rosters.json>
import {readFileSync} from 'node:fs';
import {parseCSV} from '../copa/data-loader.js';
import {ATTRIBUTE_KEYS} from '../src/data.js';
import {buildNationalPool,poolCoverage,validatePool} from '../treinador/national-pool.js';
import {NATIONS} from '../treinador/nations.js';
const dir=process.argv[2];if(!dir){console.error('Informe a pasta com players.csv e rosters.json');process.exit(1)}
const fifa=JSON.parse(readFileSync(dir+'/rosters.json','utf8')),rows=parseCSV(readFileSync(dir+'/players.csv','utf8'));
const pool=buildNationalPool(fifa,rows,ATTRIBUTE_KEYS);validatePool(pool);
const coverage=poolCoverage(pool),ranked=NATIONS.map(n=>pool.nations[n.code]).filter(e=>e.real>=11).sort((a,b)=>b.power-a.power);
console.log(JSON.stringify({coverage,strongest:ranked.slice(0,12).map(e=>`${e.code} ${e.power}`),weakestWithData:ranked.slice(-6).map(e=>`${e.code} ${e.power}`),bytes:JSON.stringify(pool).length,
 partial:NATIONS.filter(n=>{const e=pool.nations[n.code];return e.real&&!e.complete}).map(n=>`${n.code}:${pool.nations[n.code].real}r/${pool.nations[n.code].placeholders}n/${pool.nations[n.code].keepers}gk`).join(' ')},null,1));
