// Auditoria de fotos: cobertura por fonte, referências inválidas e duplicadas.
// Uso: node tools/audit-photos.mjs [pasta com players.csv e rosters.json]  (sem pasta, audita só os clubes cadastrados)
import {readFileSync} from 'node:fs';
import {INITIAL_PLAYERS,ATTRIBUTE_KEYS} from '../src/data.js';
import {auditPhotos,photoURL} from '../treinador/photos.js';
const dir=process.argv[2],report={clubes:auditPhotos(INITIAL_PLAYERS)};
if(dir){const {parseCSV}=await import('../copa/data-loader.js'),{buildNationalPool}=await import('../treinador/national-pool.js');
 const pool=buildNationalPool(JSON.parse(readFileSync(dir+'/rosters.json','utf8')),parseCSV(readFileSync(dir+'/players.csv','utf8')),ATTRIBUTE_KEYS),players=Object.values(pool.nations).flatMap(n=>[...n.squad,...n.reserve]);
 report.selecoes=auditPhotos(players);report.exemplo=photoURL(players.find(p=>photoURL(p)),96);
 report.selecoesCompletasComFoto=Object.values(pool.nations).filter(n=>n.squad.every(p=>photoURL(p))).length}
for(const part of Object.values(report))if(part?.duplicates){part.duplicateCount=part.duplicates.length;part.duplicates=part.duplicates.slice(0,5)}
console.log(JSON.stringify(report,null,1));
