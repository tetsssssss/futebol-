"""Football Universe - biblioteca 3D inicial (bola, gol, campo, árbitro, arquibancada).

Uso (Blender 4.2+ / 5.x, sem interface):
    blender --background --factory-startup --python tools/blender/build_assets.py -- [pasta_de_saida]

Gera, para cada asset, a fonte editável em assets/3d/src/<nome>.blend e o modelo em assets/3d/<nome>.glb,
além de assets/3d/manifest.json com dimensões e contagem de triângulos medidas na malha exportada.

Convenções: 1 unidade = 1 metro; Z para cima no Blender (o exportador glTF converte para Y para cima);
origem no chão, no centro do objeto; o campo tem o comprimento no eixo X. Nomes com prefixo FU_.
"""
import bpy, bmesh, json, math, os, sys
from mathutils import Matrix, Vector

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
argv = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
OUT = os.path.abspath(argv[0]) if argv else os.path.join(ROOT, "assets", "3d")
SRC = os.path.join(OUT, "src")
os.makedirs(SRC, exist_ok=True)


def reset():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scene = bpy.context.scene
    scene.unit_settings.system = "METRIC"
    scene.unit_settings.scale_length = 1.0


def material(name, color, roughness=0.8, alpha=1.0, metallic=0.0):
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    bsdf = mat.node_tree.nodes.get("Principled BSDF")
    bsdf.inputs["Base Color"].default_value = (*color, 1.0)
    bsdf.inputs["Roughness"].default_value = roughness
    bsdf.inputs["Metallic"].default_value = metallic
    bsdf.inputs["Alpha"].default_value = alpha
    if alpha < 1.0:
        mat.surface_render_method = "BLENDED"
        mat.use_backface_culling = False
    mat.diffuse_color = (*color, alpha)
    return mat


def obj_from_bmesh(name, bm, materials, smooth=False):
    mesh = bpy.data.meshes.new(name + "_mesh")
    bm.normal_update()
    bm.to_mesh(mesh)
    bm.free()
    for mat in materials:
        mesh.materials.append(mat)
    for poly in mesh.polygons:
        poly.use_smooth = smooth
    obj = bpy.data.objects.new(name, mesh)
    bpy.context.scene.collection.objects.link(obj)
    return obj


def box(bm, center, size, mat=0):
    made = bmesh.ops.create_cube(bm, size=1.0, matrix=Matrix.Translation(center) @ Matrix.Diagonal((*size, 1.0)))
    for face in {f for v in made["verts"] for f in v.link_faces}:
        face.material_index = mat
    return made["verts"]


def tube(bm, start, end, radius, segments=10, mat=0, radius_end=None):
    """Cilindro (ou tronco de cone) entre dois pontos."""
    start, end = Vector(start), Vector(end)
    axis = end - start
    rotation = Vector((0, 0, 1)).rotation_difference(axis.normalized()).to_matrix().to_4x4()
    matrix = Matrix.Translation((start + end) / 2) @ rotation
    made = bmesh.ops.create_cone(bm, cap_ends=True, segments=segments, radius1=radius,
                                 radius2=radius if radius_end is None else radius_end, depth=axis.length, matrix=matrix)
    for face in {f for v in made["verts"] for f in v.link_faces}:
        face.material_index = mat
    return made["verts"]


def quad(bm, points, mat=0):
    face = bm.faces.new([bm.verts.new(p) for p in points])
    face.material_index = mat
    return face


# --------------------------------------------------------------------------- bola
def build_ball():
    radius = 0.11  # bola tamanho 5: circunferência de 68-70 cm
    bm = bmesh.new()
    bmesh.ops.create_icosphere(bm, subdivisions=3, radius=radius)
    # 12 painéis escuros centrados nos vértices do icosaedro: leitura clássica com rotação visível.
    phi = (1 + 5 ** 0.5) / 2
    centers = [Vector(v).normalized() for v in
               [(0, s1, s2 * phi) for s1 in (-1, 1) for s2 in (-1, 1)] +
               [(s1, s2 * phi, 0) for s1 in (-1, 1) for s2 in (-1, 1)] +
               [(s2 * phi, 0, s1) for s1 in (-1, 1) for s2 in (-1, 1)]]
    for face in bm.faces:
        direction = face.calc_center_median().normalized()
        face.material_index = 1 if max(direction.dot(c) for c in centers) > 0.93 else 0
    for vert in bm.verts:
        vert.co.z += radius  # origem no ponto de contato com o chão
    ball = obj_from_bmesh("FU_Ball", bm, [material("FU_Ball_White", (0.93, 0.93, 0.9), 0.45),
                                          material("FU_Ball_Dark", (0.05, 0.06, 0.08), 0.45)], smooth=True)
    return [ball]


# --------------------------------------------------------------------------- gol
def build_goal():
    width, height, depth_top, depth_base, post = 7.32, 2.44, 0.8, 2.0, 0.06  # medidas internas regulamentares
    half = width / 2 + post
    bm = bmesh.new()
    for side in (-1, 1):
        tube(bm, (0, side * half, 0), (0, side * half, height + post), post, 12)                    # traves
        tube(bm, (0, side * half, height + post), (-depth_top, side * half, height + post), 0.025, 8, 1)  # suporte superior
        tube(bm, (-depth_top, side * half, height + post), (-depth_base, side * half, 0), 0.025, 8, 1)    # suporte traseiro
        tube(bm, (0, side * half, 0.025), (-depth_base, side * half, 0.025), 0.025, 8, 1)                 # base lateral
    tube(bm, (0, -half, height + post), (0, half, height + post), post, 12)                         # travessão
    tube(bm, (-depth_base, -half, 0.025), (-depth_base, half, 0.025), 0.025, 8, 1)                  # base traseira
    tube(bm, (-depth_top, -half, height + post), (-depth_top, half, height + post), 0.025, 8, 1)    # barra superior
    frame = obj_from_bmesh("FU_Goal_Frame", bm, [material("FU_Goal_White", (0.95, 0.95, 0.95), 0.35),
                                                 material("FU_Goal_Support", (0.55, 0.58, 0.6), 0.5, metallic=0.6)], smooth=True)
    # Rede simplificada: painéis separados da estrutura para permitir animação futura no gol.
    net = bmesh.new()
    top, y0, y1 = height + post, -half, half
    quad(net, [(0, y0, top), (0, y1, top), (-depth_top, y1, top), (-depth_top, y0, top)])                 # teto
    quad(net, [(-depth_top, y0, top), (-depth_top, y1, top), (-depth_base, y1, 0), (-depth_base, y0, 0)])  # fundo
    for y in (y0, y1):
        quad(net, [(0, y, 0), (0, y, top), (-depth_top, y, top), (-depth_base, y, 0)])                     # laterais
    net_obj = obj_from_bmesh("FU_Goal_Net", net, [material("FU_Goal_Net", (0.92, 0.94, 0.96), 0.9, alpha=0.28)])
    net_obj.parent = frame
    return [frame, net_obj]


# --------------------------------------------------------------------------- campo
def ring(bm, center, radius, width, start=0.0, end=math.tau, segments=48, z=0.0):
    count = max(4, int(segments * abs(end - start) / math.tau))
    for i in range(count):
        a0, a1 = start + (end - start) * i / count, start + (end - start) * (i + 1) / count
        inner, outer = radius - width / 2, radius + width / 2
        quad(bm, [(center[0] + math.cos(a) * r, center[1] + math.sin(a) * r, z)
                  for a, r in ((a0, inner), (a0, outer), (a1, outer), (a1, inner))])


def line(bm, start, end, width, z):
    start, end = Vector((*start, z)), Vector((*end, z))
    direction = (end - start).normalized()
    normal = Vector((-direction.y, direction.x, 0)) * width / 2
    extend = direction * width / 2  # cantos fechados
    quad(bm, [start - extend - normal, end + extend - normal, end + extend + normal, start - extend + normal])


def build_pitch():
    length, width, margin, mark, z = 105.0, 68.0, 5.0, 0.12, 0.01
    hl, hw = length / 2, width / 2
    grass = bmesh.new()
    stripes = 20
    for i in range(stripes):  # faixas de corte alternadas, uma face cada
        x0, x1 = -hl + length * i / stripes, -hl + length * (i + 1) / stripes
        quad(grass, [(x0, -hw, 0), (x1, -hw, 0), (x1, hw, 0), (x0, hw, 0)], i % 2)
    for x0, x1, y0, y1 in ((-hl - margin, hl + margin, -hw - margin, -hw), (-hl - margin, hl + margin, hw, hw + margin),
                           (-hl - margin, -hl, -hw, hw), (hl, hl + margin, -hw, hw)):  # entorno do gramado
        quad(grass, [(x0, y0, 0), (x1, y0, 0), (x1, y1, 0), (x0, y1, 0)], 2)
    grass_obj = obj_from_bmesh("FU_Pitch_Grass", grass, [material("FU_Grass_Light", (0.16, 0.42, 0.2), 0.95),
                                                         material("FU_Grass_Dark", (0.13, 0.36, 0.17), 0.95),
                                                         material("FU_Grass_Surround", (0.1, 0.27, 0.14), 0.95)])
    lines = bmesh.new()
    for a, b in (((-hl, -hw), (hl, -hw)), ((-hl, hw), (hl, hw)), ((-hl, -hw), (-hl, hw)), ((hl, -hw), (hl, hw)), ((0, -hw), (0, hw))):
        line(lines, a, b, mark, z)
    ring(lines, (0, 0), 9.15, mark, z=z)                      # círculo central
    ring(lines, (0, 0), 0.11, 0.22, segments=12, z=z)         # marca central
    for side in (-1, 1):
        goal_line = side * hl
        for depth, half in ((16.5, 20.16), (5.5, 9.16)):      # grande área e pequena área
            x = goal_line - side * depth
            line(lines, (goal_line, -half), (x, -half), mark, z)
            line(lines, (goal_line, half), (x, half), mark, z)
            line(lines, (x, -half), (x, half), mark, z)
        spot = (goal_line - side * 11.0, 0)
        ring(lines, spot, 0.11, 0.22, segments=12, z=z)       # marca do pênalti
        reach = math.acos(5.5 / 9.15)                          # meia-lua: só o trecho fora da grande área
        middle = math.pi if side == 1 else 0.0
        ring(lines, spot, 9.15, mark, middle - reach, middle + reach, z=z)
        for corner_y in (-1, 1):                               # quartos de círculo dos escanteios
            base = {(-1, -1): 0.0, (-1, 1): -math.pi / 2, (1, -1): math.pi / 2, (1, 1): math.pi}[(side, corner_y)]
            ring(lines, (goal_line, corner_y * hw), 1.0, mark, base, base + math.pi / 2, z=z)
    lines_obj = obj_from_bmesh("FU_Pitch_Lines", lines, [material("FU_Pitch_Line", (0.94, 0.96, 0.92), 0.9)])
    lines_obj.parent = grass_obj
    return [grass_obj, lines_obj]


# --------------------------------------------------------------------------- árbitro
BONES = {  # nome: (cabeça, cauda, pai)
    "root": ((0, 0, 0), (0, 0, 0.2), None),
    "spine": ((0, 0, 0.95), (0, 0, 1.45), "root"),
    "head": ((0, 0, 1.5), (0, 0, 1.8), "spine"),
    "upper_arm.L": ((0, 0.24, 1.42), (0, 0.27, 1.12), "spine"), "forearm.L": ((0, 0.27, 1.12), (0, 0.28, 0.84), "upper_arm.L"),
    "upper_arm.R": ((0, -0.24, 1.42), (0, -0.27, 1.12), "spine"), "forearm.R": ((0, -0.27, 1.12), (0, -0.28, 0.84), "upper_arm.R"),
    "thigh.L": ((0, 0.1, 0.95), (0, 0.1, 0.5), "root"), "shin.L": ((0, 0.1, 0.5), (0, 0.1, 0.06), "thigh.L"),
    "thigh.R": ((0, -0.1, 0.95), (0, -0.1, 0.5), "root"), "shin.R": ((0, -0.1, 0.5), (0, -0.1, 0.06), "thigh.R"),
}
SKIN, SHIRT, SHORTS, SOCKS, BOOTS = range(5)


def build_human(prefix="FU_Referee", mat="FU_Ref", shirt=(0.9, 0.86, 0.12), shorts=(0.05, 0.05, 0.06), socks=(0.06, 0.06, 0.07)):
    """Figura humana de baixo polígono com esqueleto. Árbitro e jogador compartilham a mesma construção;
    os materiais <mat>_Shirt/_Shorts/_Socks existem para o renderizador recolorir o uniforme."""
    bm = bmesh.new()
    weights = {}

    def part(bone, build):
        # Referências a vértices do bmesh expiram quando a malha cresce: guardamos índices.
        first = len(bm.verts)
        build()
        weights.setdefault(bone, []).extend(range(first, len(bm.verts)))

    part("spine", lambda: tube(bm, (0, 0, 0.93), (0, 0, 1.46), 0.15, 10, SHIRT, radius_end=0.19))      # tronco
    part("root", lambda: tube(bm, (0, 0, 0.8), (0, 0, 0.98), 0.17, 10, SHORTS, radius_end=0.155))       # quadril e calção
    part("head", lambda: tube(bm, (0, 0, 1.46), (0, 0, 1.54), 0.05, 8, SKIN))                           # pescoço
    first_face = len(bm.faces)
    part("head", lambda: bmesh.ops.create_icosphere(bm, subdivisions=2, radius=0.105, matrix=Matrix.Translation((0, 0, 1.66))))
    bm.faces.ensure_lookup_table()
    for index in range(first_face, len(bm.faces)):
        bm.faces[index].material_index = SKIN
    for side, suffix in ((1, "L"), (-1, "R")):
        part("upper_arm." + suffix, lambda: tube(bm, (0, side * 0.24, 1.42), (0, side * 0.27, 1.12), 0.05, 8, SHIRT))
        part("forearm." + suffix, lambda: tube(bm, (0, side * 0.27, 1.12), (0, side * 0.28, 0.84), 0.042, 8, SKIN, radius_end=0.036))
        part("thigh." + suffix, lambda: tube(bm, (0, side * 0.1, 0.95), (0, side * 0.1, 0.5), 0.08, 8, SHORTS, radius_end=0.06))
        part("shin." + suffix, lambda: tube(bm, (0, side * 0.1, 0.5), (0, side * 0.1, 0.1), 0.055, 8, SOCKS, radius_end=0.045))
        part("shin." + suffix, lambda: box(bm, (0.05, side * 0.1, 0.045), (0.24, 0.09, 0.09), BOOTS))   # chuteira
    body = obj_from_bmesh(prefix + "_Body", bm, [material(mat + "_Skin", (0.78, 0.6, 0.47), 0.7),
                                                  material(mat + "_Shirt", shirt, 0.7),
                                                  material(mat + "_Shorts", shorts, 0.7),
                                                  material(mat + "_Socks", socks, 0.7),
                                                  material(mat + "_Boots", (0.02, 0.02, 0.02), 0.5)], smooth=True)
    for bone, indices in weights.items():
        body.vertex_groups.new(name=bone).add(indices, 1.0, "REPLACE")
    # Esqueleto simples: cada parte segue um osso (pesos rígidos), pronto para animações de corrida e gestos.
    data = bpy.data.armatures.new(prefix + "_Rig_data")
    rig = bpy.data.objects.new(prefix + "_Rig", data)
    bpy.context.scene.collection.objects.link(rig)
    bpy.context.view_layer.objects.active = rig
    bpy.ops.object.mode_set(mode="EDIT")
    for name, (head_pos, tail_pos, parent) in BONES.items():
        bone = data.edit_bones.new(name)
        bone.head, bone.tail = head_pos, tail_pos
        if parent:
            bone.parent = data.edit_bones[parent]
    bpy.ops.object.mode_set(mode="OBJECT")
    body.parent = rig
    body.modifiers.new("Armature", "ARMATURE").object = rig
    return [rig, body]


# --------------------------------------------------------------------------- bandeira de escanteio
def build_corner_flag():
    bm = bmesh.new()
    tube(bm, (0, 0, 0), (0, 0, 1.5), 0.02, 8, 0)                                   # haste de 1,5 m (altura mínima regulamentar)
    quad(bm, [(0, 0, 1.5), (0.4, 0, 1.36), (0, 0, 1.2)], 1)                        # flâmula
    flag = obj_from_bmesh("FU_Corner_Flag", bm, [material("FU_Flag_Pole", (0.93, 0.93, 0.9), 0.5),
                                                 material("FU_Flag_Cloth", (0.95, 0.78, 0.1), 0.8)])
    flag.data.materials[1].use_backface_culling = False
    return [flag]


# --------------------------------------------------------------------------- arquibancada
def build_stand(detailed=True):
    width, rows, tread, rise, base = 10.0, 8, 0.8, 0.4, 0.6
    concrete = bmesh.new()
    for row in range(rows):  # degraus maciços: cada fileira é um bloco até o chão
        top = base + rise * (row + 1)
        box(concrete, (-(row + 0.5) * tread, 0, top / 2), (tread, width, top))
    depth = rows * tread
    box(concrete, (0.1, 0, base / 2 + 0.25), (0.2, width, base + 0.5), 1)                         # mureta frontal
    box(concrete, (-depth - 0.15, 0, (base + rise * rows + 2.2) / 2), (0.3, width, base + rise * rows + 2.2), 1)  # parede de fundo
    roof_z = base + rise * rows + 2.6
    box(concrete, (-depth / 2 - 0.2, 0, roof_z), (depth + 1.6, width, 0.18), 2)                   # cobertura
    for y in (-width / 2 + 0.3, width / 2 - 0.3):
        tube(concrete, (-depth - 0.15, y, 0), (-depth - 0.15, y, roof_z), 0.14, 8, 2)             # pilares
    name = "FU_Stand_Module" if detailed else "FU_Stand_Module_LOD1"
    stand = obj_from_bmesh(name, concrete, [material("FU_Stand_Concrete", (0.52, 0.54, 0.56), 0.9),
                                            material("FU_Stand_Wall", (0.3, 0.33, 0.36), 0.9),
                                            material("FU_Stand_Roof", (0.16, 0.19, 0.22), 0.6, metallic=0.4)])
    seats = bmesh.new()
    per_row = 18
    sector = per_row // 2
    for row in range(rows):
        top, x = base + rise * (row + 1), -(row + 0.5) * tread - 0.12
        if detailed:
            for seat in range(per_row):  # assento + encosto; dois setores separados por um corredor central
                y = (seat - (per_row - 1) / 2) * 0.5 + (0.25 if seat >= sector else -0.25)
                box(seats, (x + 0.08, y, top + 0.05), (0.38, 0.42, 0.06), row % 2)
                box(seats, (x - 0.14, y, top + 0.24), (0.06, 0.42, 0.36), row % 2)
        else:
            for sign in (-1, 1):         # LOD1: uma faixa de assentos por setor
                box(seats, (x, sign * (width / 4 + 0.125), top + 0.18), (0.44, sector * 0.5 - 0.08, 0.36), row % 2)
    seats_obj = obj_from_bmesh(name.replace("Module", "Seats"), seats, [material("FU_Seat_A", (0.12, 0.45, 0.3), 0.6),
                                                                         material("FU_Seat_B", (0.1, 0.36, 0.25), 0.6)])
    seats_obj.parent = stand
    return [stand, seats_obj]


# --------------------------------------------------------------------------- exportação
def measure(objects):
    depsgraph = bpy.context.evaluated_depsgraph_get()
    triangles, low, high = 0, Vector((1e9,) * 3), Vector((-1e9,) * 3)
    for obj in objects:
        if obj.type != "MESH":
            continue
        mesh = obj.evaluated_get(depsgraph).to_mesh()
        mesh.calc_loop_triangles()
        triangles += len(mesh.loop_triangles)
        for vert in mesh.vertices:
            world = obj.matrix_world @ vert.co
            low, high = Vector(map(min, low, world)), Vector(map(max, high, world))
    return triangles, [round(v, 3) for v in (high - low)]


def export(name, builder):
    reset()
    objects = builder()
    bpy.context.view_layer.update()
    triangles, size = measure(objects)
    bpy.ops.wm.save_as_mainfile(filepath=os.path.join(SRC, name + ".blend"), compress=True)
    glb = os.path.join(OUT, name + ".glb")
    bpy.ops.export_scene.gltf(filepath=glb, export_format="GLB", export_yup=True, export_apply=False,
                              export_animations=False, export_cameras=False, export_lights=False)
    return {"file": name + ".glb", "source": "src/" + name + ".blend", "objects": [o.name for o in objects],
            "materials": sorted({s.material.name for o in objects for s in o.material_slots if s.material}),
            "triangles": triangles, "sizeMeters": {"x": size[0], "y": size[1], "z": size[2]},
            "bytes": os.path.getsize(glb)}


ASSETS = [("ball", build_ball), ("goal", build_goal), ("pitch", build_pitch), ("referee", build_human),
          ("player", lambda: build_human("FU_Player", "FU_Player", (0.92, 0.92, 0.92), (0.8, 0.8, 0.8), (0.88, 0.88, 0.88))),
          ("corner_flag", build_corner_flag),
          ("stand_module", lambda: build_stand(True)), ("stand_module_lod1", lambda: build_stand(False))]

manifest = {"generator": "tools/blender/build_assets.py", "blender": bpy.app.version_string, "units": "metros",
            "axes": "fonte Blender com Z para cima; GLB exportado com Y para cima; comprimento do campo no eixo X",
            "assets": {name: export(name, builder) for name, builder in ASSETS}}
with open(os.path.join(OUT, "manifest.json"), "w", encoding="utf-8") as handle:
    json.dump(manifest, handle, ensure_ascii=False, indent=1)
print("FU_ASSETS_OK", json.dumps({k: (v["triangles"], v["bytes"]) for k, v in manifest["assets"].items()}))
