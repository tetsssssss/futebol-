// Segunda rodada de fotos: atletas que a SoFIFA não tem (arquivo 404) e os atletas dos clubes cadastrados, procurados em TheSportsDB e Wikipédia/Commons.
// Só aceita a imagem quando o nome casa por inteiro e há uma confirmação (clube, nacionalidade ou descrição de jogador de futebol);
// sem certeza, o atleta fica sem foto (avatar): nenhum rosto de outra pessoa entra.
// Seleções: assets/faces/ea/<id SoFIFA>.webp. Clubes: assets/faces/club/<id>.webp. Procedência em data/media-sources.json.
// Uso: node tools/fetch-faces-extra.mjs [--dir pasta com players.csv e rosters.json] [--limit N]
import {readFileSync,writeFileSync,existsSync} from 'node:fs';
import {join} from 'node:path';
import {ROOT,loadSharp,ensureDir,download,sleep,readMedia,writeMedia} from './media-lib.mjs';
import {parseCSV,SOURCES} from '../copa/data-loader.js';
import {buildNationalPool} from '../treinador/national-pool.js';
import {INITIAL_PLAYERS,ATTRIBUTE_KEYS} from '../src/data.js';
import {cleanName,NATION} from '../treinador/nations.js';
const args=process.argv.slice(2),opt=n=>{const i=args.indexOf('--'+n);return i>=0?args[i+1]:null},dir=opt('dir'),limit=Number(opt('limit'))||Infinity;
const sharp=loadSharp(),outEA=ensureDir(join(ROOT,'assets/faces/ea')),outClub=ensureDir(join(ROOT,'assets/faces/club')),sourcesFile=join(ROOT,'data/media-sources.json');
const text=async(file,url)=>dir&&existsSync(join(dir,file))?readFileSync(join(dir,file),'utf8'):Buffer.from(await download(url)).toString('utf8');
const rows=parseCSV(await text('players.csv',SOURCES.ea)),fifa=JSON.parse(await text('rosters.json',SOURCES.fifa));
const pool=buildNationalPool(fifa,rows,ATTRIBUTE_KEYS),media=readMedia(),have=new Set(media.faces.ea);
const sources=existsSync(sourcesFile)?JSON.parse(readFileSync(sourcesFile,'utf8')):{};
const eaId=url=>{const m=/\/players\/(\d{1,3})\/(\d{3})\//.exec(url||'');return m?Number(m[1]+m[2]):null};
const CLUB_TOKEN={'athletico-pr':'athletico','atletico-mg':'atletico mineiro',bahia:'bahia',botafogo:'botafogo',chapecoense:'chapecoense',corinthians:'corinthians',coritiba:'coritiba',cruzeiro:'cruzeiro',flamengo:'flamengo',fluminense:'fluminense',gremio:'gremio',internacional:'internacional',mirassol:'mirassol',palmeiras:'palmeiras',bragantino:'bragantino',remo:'remo',santos:'santos','sao-paulo':'sao paulo',vasco:'vasco',vitoria:'vitoria'};
const todo=[];
for(const p of INITIAL_PLAYERS)if(!media.faces.byPlayer[p.id])todo.push({kind:'club',key:p.id,name:p.name,club:CLUB_TOKEN[p.clubId],country:'brazil'});
for(const [code,n] of Object.entries(pool.nations))for(const p of [...n.squad,...n.reserve]){
 if(p.placeholder)continue;const id=eaId(p.photo);
 if(id&&!have.has(id)&&!todo.some(t=>t.key===id&&t.kind==='ea'))todo.push({kind:'ea',key:id,name:p.name,short:p.shortName,code,country:cleanName((NATION[code]?.aliases||[]).at(-1)||code)});
}
console.log('Sem foto local:',todo.length);
// Nome em alfabeto latino: a base às vezes anexa o nome nativo ("Maxim NikolovВладимир...").
const latin=name=>String(name).replace(/[^\u0000-ɏ\s'.-].*$/,'').trim();
const tokens=n=>cleanName(n).split(' ').filter(Boolean);
/** Mesmo nome: último e primeiro termos iguais (ou nome único idêntico); prenome abreviado pelo início também vale. */
const same=(a,b)=>{const x=tokens(a),y=tokens(b);if(!x.length||!y.length)return false;if(x.length===1||y.length===1)return x.join(' ')===y.join(' ');return x.at(-1)===y.at(-1)&&(x[0]===y[0]||x[0].startsWith(y[0])||y[0].startsWith(x[0]))};
async function json(url){await sleep(1100);try{return JSON.parse((await download(url)).toString('utf8'))}catch{return null}}
/** Um nome contém o outro (todos os termos do menor aparecem no maior): "Andrew" ⊂ "Andrew da Silva Ventura". Só vale com confirmação de clube ou nacionalidade. */
const contains=(a,b)=>{const x=tokens(a),y=tokens(b),[small,big]=x.length<=y.length?[x,y]:[y,x];return small.length>0&&small.every(t=>big.includes(t))};
async function viaSportsDB(t){
 const full=latin(t.name),parts=tokens(full).filter(w=>w.length>3),queries=[...new Set([full,t.short&&latin(t.short),...(parts.length>1?[parts.at(-1)]:[]),...(t.kind==='club'?parts:[])].filter(Boolean))];
 for(const q of queries){
  const r=await json('https://www.thesportsdb.com/api/v1/json/3/searchplayers.php?p='+encodeURIComponent(q));
  const cands=(r?.player||[]).filter(p=>p.strSport==='Soccer'&&(p.strCutout||p.strThumb||p.strRender));
  const teamOK=p=>t.club&&[p.strTeam,p.strTeam2].some(x=>cleanName(x||'').includes(t.club));
  const nationOK=p=>t.country&&cleanName(p.strNationality||'')===t.country;
  let hit=null;
  if(t.kind==='club')hit=cands.find(p=>teamOK(p)&&(same(p.strPlayer,full)||contains(p.strPlayer,full)));
  else hit=cands.find(p=>nationOK(p)&&(same(p.strPlayer,full)||(tokens(full).length>1&&contains(p.strPlayer,full)&&tokens(p.strPlayer).length>1)))||(cands.filter(p=>same(p.strPlayer,full)).length===1&&tokens(full).length>1?cands.find(p=>same(p.strPlayer,full)):null);
  if(hit)return {url:hit.strCutout||hit.strThumb||hit.strRender,source:'TheSportsDB',page:`https://www.thesportsdb.com/player/${hit.idPlayer}`};
 }
 return null;
}
async function viaWikipedia(t){
 if(tokens(t.name).length<2)return null; // nome único é ambíguo demais para a busca por texto
 const q=latin(t.name),r=await json('https://en.wikipedia.org/w/api.php?action=query&format=json&generator=search&gsrlimit=4&gsrsearch='+encodeURIComponent(q+' footballer')+'&prop=pageimages|description|extracts&piprop=thumbnail&pithumbsize=500&exintro=1&explaintext=1&exlimit=4');
 const pages=Object.values(r?.query?.pages||{}).sort((a,b)=>a.index-b.index);
 // Confirma a pessoa: o texto de abertura precisa citar o clube cadastrado (clubes) ou a nacionalidade (seleções). Homônimos famosos entram fácil.
 const confirmed=p=>{const text=cleanName(p.extract||'');return t.kind==='club'?text.includes(t.club):Boolean(t.country)&&text.includes(t.country.slice(0,5))};
 const hit=pages.find(p=>p.thumbnail&&/footballer|football player|soccer/i.test(p.description||'')&&same(p.title.replace(/\s*\(.*\)$/,''),q)&&confirmed(p));
 return hit?{url:hit.thumbnail.source,source:'Wikipédia/Wikimedia Commons',page:'https://en.wikipedia.org/wiki/'+encodeURIComponent(hit.title.replaceAll(' ','_'))}:null;
}
let done=0,found=0;const failed=[];
const save=()=>{media.faces.ea=[...have];writeMedia(media);writeFileSync(sourcesFile,JSON.stringify(sources,null,1))};
for(const t of todo.slice(0,limit)){
 let hit=null;
 for(const finder of [viaSportsDB,viaWikipedia]){try{hit=await finder(t)}catch{hit=null}if(hit)break}
 if(hit){try{const buf=await download(hit.url),img=await sharp(buf).trim({threshold:2}).resize(120,120,{fit:'cover',position:'top'}).webp({quality:80}).toBuffer();
   if(t.kind==='ea'){writeFileSync(join(outEA,t.key+'.webp'),img);have.add(t.key)}else{writeFileSync(join(outClub,t.key+'.webp'),img);media.faces.byPlayer[t.key]='club/'+t.key}
   sources[t.kind+':'+t.key]={name:t.name,source:hit.source,page:hit.page};found++}catch(e){failed.push(`${t.key}/${t.name} (${e.message})`)}}
 else failed.push(`${t.kind==='ea'?t.code:t.club}/${t.name}`);
 if(++done%50===0){console.log(done,'/',todo.length,'achadas',found);save()}
}
save();
writeFileSync(join(ROOT,'qa/media-faces-extra-report.json'),JSON.stringify({pendentes:todo.length,achadas:found,semFoto:failed},null,1));
console.log({pendentes:todo.length,achadas:found,semFoto:failed.length});
