// Football Universe - cria/atualiza a coleção de variáveis "Football Universe" num arquivo Figma.
// Executar pela Plugin API (por exemplo, pela ferramenta use_figma do conector Figma). Idempotente por nome.
// Arquivo de destino criado em 12/10/2026: https://www.figma.com/design/A6wrEWlSaZP7FwEqE4vM9I
// (ainda vazio: a criação das variáveis foi recusada pelo limite de chamadas do plano Starter).
// Os valores espelham design/tokens.json e o :root de treinador/style.css.
const hex = h => ({ r: parseInt(h.slice(1, 3), 16) / 255, g: parseInt(h.slice(3, 5), 16) / 255, b: parseInt(h.slice(5, 7), 16) / 255 });
const BG = ['FRAME_FILL', 'SHAPE_FILL'], TEXT = ['TEXT_FILL'], STROKE = ['STROKE_COLOR'];
const tokens = [
  ['color/bg/base', 'COLOR', hex('#0b121b'), BG, '--bg'],
  ['color/bg/surface', 'COLOR', hex('#15232f'), BG, '--surface'],
  ['color/bg/surface-2', 'COLOR', hex('#182c37'), BG, '--surface-2'],
  ['color/border/default', 'COLOR', hex('#2b3c46'), STROKE, '--line'],
  ['color/text/primary', 'COLOR', hex('#edf7f5'), TEXT, '--text'],
  ['color/text/muted', 'COLOR', hex('#9cbbc1'), TEXT, '--muted'],
  ['color/accent/default', 'COLOR', hex('#6ce3ae'), [...BG, ...TEXT, ...STROKE], '--accent'],
  ['color/accent/ink', 'COLOR', hex('#0c2823'), TEXT, '--accent-ink'],
  ['color/zone/up', 'COLOR', hex('#4fd08f'), [...BG, ...STROKE], '--up'],
  ['color/zone/up-2', 'COLOR', hex('#58b7e8'), [...BG, ...STROKE], '--up2'],
  ['color/zone/mid', 'COLOR', hex('#e3b85a'), [...BG, ...STROKE], '--mid'],
  ['color/zone/down', 'COLOR', hex('#ef6b6b'), [...BG, ...STROKE], '--down'],
  ['radius/panel', 'FLOAT', 14, ['CORNER_RADIUS'], '--radius'],
  ['spacing/gap', 'FLOAT', 16, ['GAP'], '--gap'],
];
const collections = await figma.variables.getLocalVariableCollectionsAsync();
let collection = collections.find(c => c.name === 'Football Universe');
if (!collection) { collection = figma.variables.createVariableCollection('Football Universe'); collection.renameMode(collection.modes[0].modeId, 'Dark'); }
const modeId = collection.modes[0].modeId;
const existing = (await figma.variables.getLocalVariablesAsync()).filter(v => v.variableCollectionId === collection.id);
const out = {};
for (const [name, type, value, scopes, css] of tokens) {
  let v = existing.find(x => x.name === name);
  if (!v) v = figma.variables.createVariable(name, collection, type);
  v.setValueForMode(modeId, value);
  v.scopes = scopes;
  v.setVariableCodeSyntax('WEB', `var(${css})`);
  out[name] = v.id;
}
return { collectionId: collection.id, modeId, count: Object.keys(out).length, variables: out };
