// Uniformes titulares curados à mão (clubes brasileiros e algumas seleções): [principal, secundária, padrão].
const W='#f2f2f2',K='#111111',R='#d3202f',G='#1f8a4c',B='#1b4fa3',Y='#f2c230';
/** Uniforme titular dos clubes brasileiros (conhecimento do próprio cadastro; confira em caso de dúvida): [principal, secundária, padrão]. */
export const CURATED={
 'athletico-pr':[R,K,'stripes'],'atletico-mg':[K,W,'stripes'],bahia:['#1b6bc4',R,'stripes'],botafogo:[K,W,'stripes'],chapecoense:[G,W,'solid'],corinthians:[W,K,'solid'],coritiba:['#0e7a4a',W,'solid'],cruzeiro:[B,W,'solid'],
 flamengo:[R,K,'hoops'],fluminense:['#8b1d3b','#0b6b3a','stripes'],gremio:['#1a8fd1',K,'stripes'],internacional:[R,W,'solid'],mirassol:[Y,'#0b7a3a','solid'],palmeiras:['#0b6b3a',W,'solid'],bragantino:[W,R,'solid'],remo:['#102a5c',W,'solid'],
 santos:[W,K,'solid'],'sao-paulo':[W,R,'hoops'],vasco:[K,W,'sash'],vitoria:[R,K,'stripes'],
 'america-mg':[G,W,'solid'],athletic:[K,W,'stripes'],'atletico-go':[R,K,'stripes'],avai:['#1d5fa8',W,'stripes'],ceara:[K,W,'stripes'],crb:[R,W,'stripes'],criciuma:[Y,K,'solid'],cuiaba:[G,Y,'solid'],fortaleza:['#1f4fa8',R,'stripes'],goias:[G,W,'solid'],
 juventude:[G,W,'stripes'],londrina:['#2b78c9',W,'stripes'],nautico:[R,W,'stripes'],novorizontino:[Y,K,'solid'],'operario-pr':[K,W,'stripes'],'ponte-preta':[K,W,'stripes'],'sao-bernardo':[Y,K,'solid'],sport:[R,K,'hoops'],'vila-nova':[R,W,'solid'],
 ferroviaria:['#7a1f3d',W,'solid'],amazonas:[Y,K,'solid'],'volta-redonda':[Y,K,'solid'],paysandu:['#4aa3df',W,'stripes'],
 // Seleções cujo padrão a imagem reconhece mal (xadrez, listras largas) ou cujo uniforme titular a imagem não traz.
 ARG:['#75aadb',W,'stripes'],PAR:[R,W,'stripes'],CRO:[R,W,'checks'],USA:[W,'#1f2742','solid'],SEN:[W,G,'solid'],AUT:[R,W,'solid'],TUN:[W,R,'solid'],ALG:[W,G,'solid'],EGY:[R,W,'solid'],IRN:[W,R,'solid']
};
