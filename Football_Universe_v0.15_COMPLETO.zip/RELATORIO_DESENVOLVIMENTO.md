# Relatório de desenvolvimento — v0.7

## Adendo de integração arquitetural — v0.15 / CP001–CP024 (2026-10-22)

A camada `architecture/world` adapta o catálogo de Série A para snapshot de intercâmbio validado, identidade com aliases explícitos, auditoria de referências, regras declarativas, verificação local de assets, merge-plan e handoff. Não grava no catálogo nem em saves. CP017–CP024 torna 257 definições consultáveis e mapeia atributos/contexto do jogo para intenção/markers. Não substitui o motor oficial nem altera RNG, eventos, disponibilidade ou formato de save.

O snapshot observado contém 20 clubes, 673 atletas e 70 atributos por atleta; regras oficiais adicionais, calendário auditado e importação dos planos regionais permanecem pendentes de fonte/identidade revisada. Definições de animação não significam clipe presente, e incidentes não geram diagnóstico/duração médica. Relatórios de teste e hash de entrega: `qa/architecture/DELIVERY.md`.

Data: 09/10/2026. Base: Football_Universe_v0.6_Treinador_2D_Brasileirao_Copa_2026-10-09.zip. A base foi extraída em pasta própria e preservada em Git antes das alterações.

## Implementado — IMPLEMENTADO

Transmissão Canvas 2D conectada ao motor oficial do modo treinador, nas duas competições. Inclui 22 atletas, bola, formação, ocupação de espaço, pressão, cobertura, desgaste, ações técnicas, colisões aproximadas, interrupções e reposições. Movimento e resultados compartilham um único estado; o desenho não calcula gols.

Quatro formações, mentalidade, pressão, ritmo, instruções, seleção de atleta, cinco substituições, pausa, velocidades, câmeras, zoom, foco e avanço para lances. HUD contém relógio, placar, cores das equipes, posse, passes, finalizações, defesas, faltas, cartões, escanteios e relato destacado.

Replays gravados de gols, chances, defesas, faltas, cruzamentos e outros eventos. Até dez clipes por jogo e cinco jogos com replays no arquivo. Replay não avança relógio, RNG ou competição. Resultado confirmado atualiza tabelas e calendário.

Save transacional, migração v1, exportação/importação, detecção de conflito entre abas e recuperação após falha de escrita.

## v0.7.1 — prorrogação e pênaltis (IMPLEMENTADO)

Empate no tempo normal em jogo eliminatório da Copa inicia prorrogação de 30 minutos (3.600 passos) no mesmo estado oficial, com pausa sugerida no início e no intervalo. Persistindo o empate, ocorre disputa de pênaltis cobrança a cobrança, registrada no relato e em `state.shootout`. Resultado e `penalties` seguem para o calendário. Testado por unidade e por harness de HUD no navegador (`qa/v071/shootout-harness.html`; painel revela cobranças em 1,1 s cada); ainda sem QA visual dedicada da cobrança no campo (PARCIAL: o painel mostra cada cobrança, mas a bola/cobrador não são animados no campo).

## Melhorias

O visualizador antigo redesenhava todo o DOM e avançava por minutos. Agora há loop contínuo, passos fixos e interpolação. Estados técnicos alimentam animações procedurais diferentes. Campo, animações, HUD, controles, motor e replay estão em módulos separados. Replays e fila são limitados para conter crescimento de memória e armazenamento.

## Problemas encontrados e corrigidos

- Substituído podia retornar: removido do banco e registrado como utilizado.
- Troca podia deixar configuração de goleiro inválida: validação antes de aplicar.
- Save podia associar jogo ao confronto errado: validação de IDs das equipes.
- Renderização reconstruía a interface: atualização localizada e cancelamento do loop ao navegar.
- LocalStorage tinha pouca capacidade para clipes: substituído por IndexedDB, mantendo original para migração.
- Nova competição aberta a partir de replay permanecia na tela antiga: estado de navegação reiniciado.
- Resize apagava renderização estática: último quadro redesenhado.
- Associação de fotografia a Rossi não confirmada: removida da base visual.

## Testes executados

- `npm test`: suíte de unidade/integração, incluindo temporada completa de 380 jogos e Copa completa de 104 jogos; log em `qa/v07/unit-tests.txt`.
- `tools/browser-qa.cjs`: controles, formações, substituição, velocidades, câmeras, save/reload exato, replay imutável, arquivo, importação inválida, grupos da Copa, falha de escrita, conflito entre abas e build em 390/768 px. Desktop em 1440 px. Relatório JSON com cada verificação.
- `tools/actions-qa.cjs`: cinco partidas determinísticas com instruções diferentes. Os 22 atletas se moveram; passes, dribles, cruzamentos, chutes, defesas e faltas foram capturados no Canvas. Todas as cinco variantes de cruzamento, sete contextos de drible, distribuição curta/longa, tabela e profundidade apareceram. Captura `action-gallery.png` inspecionada.
- `tools/performance-qa.cjs`: partida completa em 8×, intervalo retomado, 90:00, sem exceções JavaScript. Execução medida: 68,808 s, 6.865 quadros; mediana de intervalo 10 ms, percentil 95 de 10,1 ms. Chrome headless no desktop desta sessão; resultado não equivale a teste em celular físico nem a certificação de FPS universal.
- Build: três HTMLs portáteis gerados com o código atual. Capturas desktop, mobile e replay inspecionadas.

## O que ainda falta

**PROTÓTIPO:** refinamento artístico de atletas e goleiros, IA de marcação, resposta física e calibração de frequências/estatísticas. Animações são procedurais, substituíveis por sprites melhores.

**PARCIAL:** dados reais de elencos e atributos; calendário oficial completo. Os 16 clubes sem cadastro usam posições neutras, e seleções dependem de sincronização externa para nomes reais. Catálogo nacional externo não é transportado integralmente no backup do treinador.

**PENDENTE:** lesões, suspensão entre jogos, arbitragem integral, animação/visualização no campo das cobranças de desempate (a lógica e o relato já existem). Não foram feitos testes em aparelhos móveis físicos, Safari/Firefox, acessibilidade com leitor de tela nem sessões de várias horas. Retenção limitada de replays é intencional.

**DEFINITIVO:** nenhuma classificação definitiva foi atribuída ao conjunto do produto.

## Recomendações

Usar servidor local ou hospedagem estática com origem estável, exportar saves antes de trocar de navegador/origem e revisar os elencos importados. Manter os parâmetros técnicos provisórios identificados na interface.

## Próxima etapa

Refinar sprites e leitura das disputas, calibrar o motor com distribuições de jogo, completar cadastros com procedência e validar desempenho em aparelhos móveis reais. A base modular já permite essas evoluções.

## v0.7.1 — calibração, disciplina, lesões e marcação

**IMPLEMENTADO:** calibração com 100 partidas (antes/depois em `qa/v071/calibration-*.json`); lesões em jogo e substituição forçada; suspensões e lesões entre jogos persistidas no save; marcação por referência; cartões, luvas e comemoração nos sprites; teste de calibração com faixas amplas.

**PARCIAL:** o motor gera ~150 passes por jogo (futebol real ~800) e ~4,7 escanteios (real ~10): a cadência de decisão é mais lenta que a real. Gols ~2,9 por jogo, um pouco acima da média típica. Arbitragem segue simplificada (um árbitro implícito, sem vantagem nem VAR). Acúmulo de amarelos não zera após fases da Copa. Lesão sem substituição disponível mantém o atleta em campo com desgaste alto.

**NÃO FEITO (exige dados ou hardware externos):** cadastros verificáveis dos 16 clubes e seleções sem elenco; validação em celulares físicos, Safari e Firefox; `tools/browser-qa.cjs` não executou aqui por dependência de navegador ausente. Verificação visual foi feita no navegador integrado (cartão amarelo no campo e harness de pênaltis).


## v0.8.0 — Auditoria e fundação de competições (12/10/2026)

### Diagnóstico (base v0.7.1, 63 testes passando)

1. Não existia Série B. A liga era fixa em 20 clubes e na temporada 2026: sem acesso, rebaixamento, histórico ou temporada seguinte.
2. O gerador de calendário dava a um clube os 19 jogos do turno em casa (e a outro, 19 fora). O total de 19 mandos por clube escondia o defeito.
3. Cada partida gravava ~65 KB no save (relato completo no confronto e de novo no arquivo): ~25 MB por temporada, regravados a cada 2,5 s durante o jogo.
4. Desempate fixo (pontos, saldo, gols, ordem alfabética), diferente do regulamento.
5. Nenhuma estatística individual era persistida além do nome de quem fez gol.
6. Rebotes e sobras recuperados contavam como passe certo e podiam gerar assistência para quem bloqueou o chute.
7. Só 4 de 20 clubes têm elenco; os demais usam posições neutras idênticas (geral 65).
8. Manager (`src/`), Copa (`copa/`) e Treinador (`treinador/`) são três aplicações com saves e motores separados; só o Treinador usa o motor espacial.
9. `assets/faces` está vazio: as 14 fotos catalogadas são links externos para o Wikimedia Commons.

### Validação

- `npm test`: 78 testes, 78 aprovados (63 anteriores + 15 novos).
- `npm run build`: três HTMLs gerados; `dist/treinador/index.html` carregado no navegador sem erros de console.
- Navegador (1280 px e 375 px): migração automática de um save v0.7 com partida em andamento, confirmação do resultado, 6 rodadas simuladas nas duas divisões (~2,5 s por rodada de 20 jogos), Tabela A/B, recortes, Calendário, Detalhes, Estatísticas, Histórico e troca para um clube da Série B. Sem rolagem horizontal em 375 px.
- Medição: 133 ms por partida simulada; 3,1 KB por partida no save (antes ~65 KB).

### Pendências e próximo incremento

Itens 7, 8 e 9 do diagnóstico continuam abertos. Próximo passo recomendado: evolução do 2D (inteligência tática e calibração de quem finaliza), usando as estatísticas desta versão como instrumento de medida.


## v0.13.0 — Fase 6: Libertadores e Sul-Americana (12/10/2026)

**IMPLEMENTADO:** os dois torneios continentais por temporada, jogados pelo motor espacial, com vagas de 2026, sorteios, grupos, mata-mata em ida e volta, transferência de clubes entre os torneios e virada de temporada condicionada ao fim das copas; telas e save migrado. Validação: `npm test` (126 testes, 9 novos), simulação completa dos 312 jogos no navegador sem erros de console e partida real pelo motor com ida e volta.

**PARCIAL:** vagas fora do Brasil por rodízio (ligas nacionais não simuladas); sorteio por mérito de vaga e não pelo ranking da Conmebol; elencos estrangeiros neutros; regulamentos não conferidos no documento oficial.

**PENDENTE:** Copa do Brasil, Recopa, Supercopa, Mundial de Clubes, calendário entrelaçado com a liga, e a estrutura europeia (próxima etapa).
