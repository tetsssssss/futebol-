import test from 'node:test';import assert from 'node:assert/strict';
import {startWorldCup,teamsForWorldCup,currentFixtures,startMatch,finishMatch,commitResult,nextWorldCupStage,fixtureSetup,validateSave,fitnessFor,recordFitness,clubTeams,startBrazil,NATION_COLORS} from '../treinador/engine.js';
import {QUALIFIED,winner} from '../copa/engine.js';
import {groupTable,thirdsTable,roundOf32,advanceCup,bracketColumns,campaign,cupPodium,cupAwards,teamTotals,groupOf,allCupMatches,cupRules,performanceIndex} from '../treinador/cup.js';
import {matchNarrative,positionChart} from '../treinador/league-views.js';
import {makeLeague,afterResult,positionHistory,leagueTable} from '../treinador/league.js';
import {flag} from '../treinador/cup-views.js';

const teams=new Map(teamsForWorldCup().map(t=>[t.id,t]));
// Resultados determinísticos sem o motor: servem só para testar regras de grupo, terceiros e chave.
function fillStage(cup,decide=()=>null){for(const m of cup.matches){if(m.played)continue;let h=0;for(const c of cup.seed+m.id)h=Math.imul(h^c.charCodeAt(0),16777619)>>>0;const forced=decide(m);let hg=forced?forced[0]:h%4,ag=forced?forced[1]:(h>>>8)%3,penalties=null;if(m.round!=='Grupos'&&hg===ag)penalties=h%2?[5,4]:[3,4];Object.assign(m,{played:true,hg,ag,penalties,st:{yellow:[h%3,(h>>>4)%3],red:[0,0]}})}return cup}
const group=(codes,matches,seed='t')=>({seed,year:2026,stage:'Grupos',groups:{A:codes},matches:matches.map(([home,away,hg,ag,cards],i)=>({id:'G-'+i,round:'Grupos',group:'A',home,away,played:true,hg,ag,st:{yellow:cards||[0,0],red:[0,0]}})),history:[]});

test('grupo: confronto direto vale antes do saldo de gols geral',()=>{
 // A e B terminam com 6 pontos; B tem saldo melhor, mas A venceu o confronto direto.
 const cup=group(['a','b','c','d'],[['a','b',1,0],['a','c',1,0],['d','a',2,0],['b','c',4,0],['b','d',3,0],['c','d',1,1]]);
 const t=groupTable(cup,'A'),a=t.find(r=>r.code==='a'),b=t.find(r=>r.code==='b');assert.equal(a.pts,b.pts);assert.ok(b.gd>a.gd);assert.ok(a.position<b.position);assert.equal(a.decidedBy,'headToHead');
});
test('grupo: três empatados usam a minitabela entre eles e depois a conduta',()=>{
 // a>b, b>c, c>a (todos 1 a 0) e todos vencem d por 1 a 0: minitabela idêntica, saldo e gols iguais; decide a conduta.
 const cup=group(['a','b','c','d'],[['a','b',1,0,[4,0]],['b','c',1,0,[1,0]],['c','a',1,0,[0,0]],['a','d',1,0],['b','d',1,0],['c','d',1,0]]);
 const t=groupTable(cup,'A');assert.deepEqual(t.slice(0,3).map(r=>r.pts),[6,6,6]);assert.deepEqual(t.map(r=>r.code),['c','b','a','d']);assert.equal(t[0].decidedBy,'fairPlay');
});
test('terceiros: oito melhores avançam por pontos, saldo, gols e conduta, sem confronto direto',()=>{
 const cup=fillStage(startWorldCup().cup),thirds=thirdsTable(cup);
 assert.equal(thirds.length,12);assert.equal(thirds.filter(r=>r.qualified).length,8);assert.equal(new Set(thirds.map(r=>r.group)).size,12);
 for(let i=1;i<12;i++){const a=thirds[i-1],b=thirds[i];assert.ok(a.pts>b.pts||a.pts===b.pts&&(a.gd>b.gd||a.gd===b.gd&&a.gf>=b.gf),'ordem dos terceiros')}
 for(const r of thirds)assert.equal(groupTable(cup,r.group)[2].code,r.code);
});
test('32 avos: 32 seleções distintas, nenhum confronto do mesmo grupo e primeiros protegidos',()=>{
 const cup=fillStage(startWorldCup().cup),ties=roundOf32(cup),codes=ties.flatMap(m=>[m.home,m.away]);
 assert.equal(ties.length,16);assert.equal(new Set(codes).size,32);assert.deepEqual(ties.map(m=>m.id),Array.from({length:16},(_,i)=>`R32-${i+1}`));
 for(const m of ties)assert.notEqual(groupOf(cup,m.home),groupOf(cup,m.away),'mesmo grupo nos 32 avos');
 const firsts=new Set(Object.keys(cup.groups).map(g=>groupTable(cup,g)[0].code)),thirds=new Set(thirdsTable(cup).filter(r=>r.qualified).map(r=>r.code));
 assert.ok(ties.every(m=>!(firsts.has(m.home)&&firsts.has(m.away))),'dois primeiros não se cruzam nos 32 avos');assert.equal(ties.filter(m=>thirds.has(m.away)&&firsts.has(m.home)).length,8);
 assert.deepEqual(roundOf32(structuredClone(cup)),ties,'chave determinística');
});
test('chave em árvore: cada fase junta vencedores vizinhos até a final; terceiro lugar com os perdedores das semifinais',()=>{
 let cup=fillStage(startWorldCup().cup);assert.throws(()=>advanceCup({...cup,matches:cup.matches.map((m,i)=>i?m:{...m,played:false})}));
 const sizes={'32 avos':16,'Oitavas':8,'Quartas':4,'Semifinais':2};let previous=null;
 for(const stage of Object.keys(sizes)){cup=advanceCup(cup);assert.equal(cup.stage,stage);assert.equal(cup.matches.length,sizes[stage]);
  if(previous)cup.matches.forEach((m,i)=>assert.deepEqual([m.home,m.away],[winner(previous[2*i]),winner(previous[2*i+1])]));
  fillStage(cup);previous=cup.matches}
 const semis=cup.matches;cup=advanceCup(cup);assert.equal(cup.stage,'Decisão');const final=cup.matches.find(m=>m.id==='FINAL'),third=cup.matches.find(m=>m.id==='THIRD');
 assert.deepEqual([final.home,final.away],semis.map(winner));assert.deepEqual([third.home,third.away],semis.map(m=>m.home===winner(m)?m.away:m.home));
 fillStage(cup);cup.champion=winner(final);assert.equal(allCupMatches(cup).length,104);assert.throws(()=>advanceCup(cup));
 const b=bracketColumns(cup);assert.deepEqual(b.columns.map(c=>c.matches.length),[16,8,4,2,1]);assert.ok(b.tree);assert.ok(b.columns.every(c=>c.matches.every(m=>!m.pending&&m.winner)));assert.equal(b.third.id,'THIRD');
 const p=cupPodium(cup);assert.equal(p.champion,cup.champion);assert.equal(new Set([p.champion,p.runnerUp,p.third,p.fourth]).size,4);
 const path=campaign(cup,cup.champion);assert.equal(path.length,8,'campeã joga 3 de grupo + 5 eliminatórios');assert.ok(path.slice(3).every(g=>g.result==='W'));assert.equal(campaign(cup,p.runnerUp).at(-1).result,'L');
});
test('chave antes de existir: vagas pendentes descrevem de onde virá cada seleção',()=>{
 const cup=startWorldCup().cup,b=bracketColumns(cup);assert.ok(b.columns.every(c=>c.matches.every(m=>m.pending)));assert.equal(b.columns[1].matches[0].homeLabel,'Vencedor 32 avos 1');assert.equal(b.columns[1].matches[3].awayLabel,'Vencedor 32 avos 8');assert.equal(b.third,null);
});
test('Copa completa com o motor real: 104 jogos, campeã, prêmios derivados das estatísticas e save válido',()=>{
 const save=startWorldCup();assert.equal(save.cup.bracket,'v2');let played=0;
 for(let i=0;i<7;i++){for(const m of [...currentFixtures(save)]){const rule=fixtureSetup(save,m),home=teams.get(m.home),away=teams.get(m.away);commitResult(save,m,finishMatch(startMatch(home,away,'wc|'+m.id,rule.knockout,{...rule.options,recordReplay:false,fatigue:{...fitnessFor(save,home,m.date),...fitnessFor(save,away,m.date)}})));played++}if(save.cup.stage==='Decisão')break;nextWorldCupStage(save)}
 assert.equal(played,104);assert.ok(save.cup.champion);assert.ok(validateSave(save));assert.ok(validateSave(JSON.parse(JSON.stringify(save))));
 const knockout=allCupMatches(save.cup).filter(m=>m.round!=='Grupos');assert.equal(knockout.length,32);assert.ok(knockout.every(m=>winner(m)),'todo mata-mata tem vencedor');assert.ok(knockout.every(m=>m.hg!==m.ag||m.penalties));
 const a=cupAwards(save),goals=allCupMatches(save.cup).reduce((n,m)=>n+m.hg+m.ag,0),lines=Object.values(save.stats.players);
 assert.equal(lines.reduce((n,l)=>n+l.g,0),goals);assert.equal(a.goldenBoot.g,Math.max(...lines.map(l=>l.g)));assert.equal(a.assists.a,Math.max(...lines.map(l=>l.a)));
 assert.equal(a.goldenGlove.pos,'GK');assert.ok([a.podium.champion,a.podium.runnerUp,a.podium.third,a.podium.fourth].includes(a.goldenGlove.team));
 assert.ok(a.best.length===5&&a.best.every((l,i,list)=>l.gp>=4&&l.index===performanceIndex(l)&&(!i||list[i-1].index>=l.index)));
 const totals=teamTotals(save.cup);assert.equal(totals.reduce((n,t)=>n+t.played,0),208);assert.equal(totals.reduce((n,t)=>n+t.gf,0),goals);assert.equal(totals.find(t=>t.code===a.podium.champion).played,8);
 assert.equal(cupAwards(startWorldCup()),null,'sem campeã não há prêmios');
});
test('condição física: desgaste acompanha o atleta entre jogos próximos e some com o descanso',()=>{
 const save=startWorldCup(),m=currentFixtures(save)[0],home=teams.get(m.home),away=teams.get(m.away),s=finishMatch(startMatch(home,away,'fit',false,{recordReplay:false}));
 const starter=s.squads[0].playing.find(p=>p.role!=='GK'&&!p.inTick),end=starter.fatigue;assert.ok(end>5,'titular termina desgastado: '+end);commitResult(save,m,s);
 const day=n=>new Date(Date.parse(m.date)+n*86400000).toISOString().slice(0,10),soon=fitnessFor(save,home,day(3))[starter.id],later=fitnessFor(save,home,day(6))[starter.id]||0;
 assert.ok(soon>0&&soon<end,'três dias depois ainda há desgaste: '+soon);assert.ok(later<soon);assert.equal(fitnessFor(save,home,day(30))[starter.id],undefined,'um mês depois está recuperado');
 const unused=s.squads[0].bench[0];assert.equal(fitnessFor(save,home,day(3))[unused.id],undefined,'quem não jogou segue descansado');
 const next=startMatch(home,away,'fit-2',false,{recordReplay:false,fatigue:fitnessFor(save,home,day(3))});assert.equal(next.squads[0].playing.find(p=>p.id===starter.id).fatigue,soon);
 const rested=startMatch(home,away,'fit-2',false,{recordReplay:false});assert.equal(rested.squads[0].playing.find(p=>p.id===starter.id).fatigue,0);
 assert.ok(validateSave(save));const bad=structuredClone(save);bad.fitness[starter.id].f=999;assert.throws(()=>validateSave(bad));
 // Na liga, com uma semana entre rodadas, o desgaste herdado é pequeno.
 const league=startBrazil(),f=currentFixtures(league)[0],clubs=new Map(clubTeams().map(t=>[t.id,t]));commitResult(league,f,finishMatch(startMatch(clubs.get(f.home),clubs.get(f.away),'lg',false,{recordReplay:false})));
 const week=new Date(Date.parse(f.date)+7*86400000).toISOString().slice(0,10);assert.ok(Object.values(fitnessFor(league,clubs.get(f.home),week)).every(v=>v<12));
});
test('crônica da partida usa só o que foi registrado',()=>{
 const get=id=>({name:{a:'Alfa',b:'Beta'}[id]});
 const win=matchNarrative({home:'a',away:'b',hg:2,ag:1,scorers:{home:[{name:'Rui',minute:70},{name:'Rui',minute:88}],away:[{name:'Zé',minute:10}]},st:{possession:[62,38],xG:[1.9,.7],red:[0,1]}},get);
 assert.match(win,/Alfa venceu Beta por 2 a 1/);assert.match(win,/Rui \(70', 88'\)/);assert.match(win,/Zé \(10'\)/);assert.match(win,/saiu atrás e virou/);assert.match(win,/gol da vitória saiu aos 88/);assert.match(win,/62% de posse/);assert.match(win,/uma expulsão \(Beta\)/);
 assert.match(matchNarrative({home:'a',away:'b',hg:0,ag:4,scorers:{home:[],away:[]}},get),/Beta goleou Alfa por 4 a 0/);
 assert.match(matchNarrative({home:'a',away:'b',hg:1,ag:1,penalties:[3,4],scorers:{home:[],away:[]}},get),/empataram em 1 a 1, e a decisão foi para os pênaltis: 3 a 4 para Beta/);
 assert.match(matchNarrative({home:'a',away:'b',hg:0,ag:1,scorers:{home:[],away:[]},st:{possession:[50,50],xG:[2.4,.3],red:[0,0]}},get),/contrariou as chances criadas/);
 const plain=matchNarrative({home:'a',away:'b',hg:0,ag:0},get);assert.match(plain,/zero a zero/);assert.doesNotMatch(plain,/posse|xG|Gols:/);
});
test('evolução da posição: uma posição por rodada concluída, coerente com a tabela',()=>{
 const league=makeLeague();assert.deepEqual(positionHistory(league,'flamengo'),[]);
 for(let r=0;r<5;r++)for(const m of league.rounds[r]){let h=0;for(const c of m.id)h=Math.imul(h^c.charCodeAt(0),16777619)>>>0;Object.assign(m,{played:true,hg:h%4,ag:(h>>>8)%3})}afterResult(league);
 const history=positionHistory(league,'flamengo');assert.equal(history.length,5);assert.ok(history.every(p=>Number.isInteger(p)&&p>=1&&p<=20));assert.equal(history.at(-1),leagueTable(league).find(r=>r.code==='flamengo').position);
 league.rounds[6][0].played=true;Object.assign(league.rounds[6][0],{hg:1,ag:0});assert.equal(positionHistory(league,'flamengo').length,5,'rodada incompleta não entra');
 const svg=positionChart(league,'flamengo',id=>({name:id}));assert.match(svg,/<polyline/);assert.match(svg,new RegExp(`atual ${history.at(-1)}º`));
 assert.match(positionChart(makeLeague(),'flamengo',id=>({name:id})),/segunda rodada/);
});
test('identidade das seleções: cor e bandeira para as 48 classificadas',()=>{
 for(const code of QUALIFIED){assert.match(NATION_COLORS[code]||'',/^#[0-9a-f]{6}$/,code);assert.ok(flag(code).length>=4,code);assert.equal(teams.get(code).color,NATION_COLORS[code])}
 assert.equal(flag('BRA'),'\u{1F1E7}\u{1F1F7}');assert.equal(flag('XXX'),'');assert.equal(cupRules({year:2026}).groups.bestThirds,8);
});
