import test from 'node:test';
import assert from 'node:assert/strict';
import {readMatchVisualPreferences,writeMatchVisualPreferences} from '../treinador/visual-preferences.js';

function memoryStorage(initial={}){const data=new Map(Object.entries(initial));return {getItem:key=>data.get(key)??null,setItem:(key,value)=>data.set(key,String(value)),data};}

test('a partida prefere transmissão 2.5D, nomes e câmera de transmissão sem valor salvo',()=>{
 assert.deepEqual(readMatchVisualPreferences(memoryStorage()),{visual:'25d',camera:'broadcast',names:true,zoom:1});
});

test('preferências reconhecem 2D, câmera tática e zoom e descartam valores inválidos',()=>{
 const storage=memoryStorage({'fu-match-visual-preferences':JSON.stringify({visual:'2d',camera:'tactical',names:false,zoom:1.4})});
 assert.deepEqual(readMatchVisualPreferences(storage),{visual:'2d',camera:'tactical',names:false,zoom:1.4});
 storage.setItem('fu-match-visual-preferences',JSON.stringify({visual:'webgl',camera:'free',names:'yes',zoom:9}));
 assert.deepEqual(readMatchVisualPreferences(storage),{visual:'25d',camera:'broadcast',names:true,zoom:1});
});

test('grava preferência de apresentação sem incluir estado da partida',()=>{
 const storage=memoryStorage(),before={score:[1,0],tick:12};
 const saved=writeMatchVisualPreferences(storage,{visual:'25d',camera:'broadcast',names:true,zoom:1},{visual:'2d',camera:'ball'});
 assert.deepEqual(saved,{visual:'2d',camera:'ball',names:true,zoom:1});
 assert.deepEqual(JSON.parse(storage.getItem('fu-match-visual-preferences')),saved);
 assert.deepEqual(before,{score:[1,0],tick:12});
});
