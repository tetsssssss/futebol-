import test from 'node:test';import assert from 'node:assert/strict';
import {photoURL,rawPhoto,auditPhotos,setPhotoRegistry,registeredPhoto,PHOTO_SOURCES} from '../treinador/photos.js';
import {portrait,playerComparison,teamComparison} from '../treinador/league-views.js';
import {INITIAL_PLAYERS} from '../src/data.js';
import {blankLine} from '../treinador/match-summary.js';

const fifa='https://digitalhub.fifa.com/transform/abc-123/TESTE_Fulano_1',ea='https://cdn.sofifa.net/players/000/001/26_120.png',wiki='https://commons.wikimedia.org/wiki/Special:FilePath/Teste.jpg?width=600';
test('fotos: só fontes que carregam viram endereço, já no tamanho pedido',()=>{
 assert.equal(photoURL({photo:fifa},96),fifa+'?io=transform:fill,width:96,height:96');assert.equal(photoURL({photo:fifa+'?x=1'},64),fifa+'?io=transform:fill,width:64,height:64');
 assert.equal(photoURL({photo:wiki},120),'https://commons.wikimedia.org/wiki/Special:FilePath/Teste.jpg?width=120');assert.equal(photoURL({photo:{url:wiki}},80).endsWith('width=80'),true);
 assert.equal(photoURL({photo:ea}),null,'fonte bloqueada vira avatar, sem requisição perdida');assert.equal(PHOTO_SOURCES['cdn.sofifa.net'].usable,false);
 assert.equal(photoURL({photo:'https://exemplo.invalid/a.png'},50),'https://exemplo.invalid/a.png','fonte desconhecida é tentada como está');
 for(const bad of [null,'','http://inseguro/a.png','javascript:alert(1)','https://x/"><script>',{url:5}])assert.equal(photoURL({photo:bad}),null);assert.equal(photoURL(null),null);
 assert.ok(photoURL({photo:fifa},99999).includes('width:512'));assert.ok(photoURL({photo:fifa},1).includes('width:32'));assert.equal(rawPhoto({photo:fifa}),fifa);
});
test('retrato: iniciais sempre presentes; foto por cima quando existe; posição no lugar das iniciais em vaga neutra',()=>{
 const withPhoto=portrait({id:'a',name:'Fulano de Tal',photo:fifa});assert.match(withPhoto,/class="avatar"/);assert.match(withPhoto,/>FD</);assert.match(withPhoto,/<img[^>]+width:128,height:128/);assert.match(withPhoto,/loading="lazy"/);assert.match(withPhoto,/onerror="this\.remove\(\)"/);
 const none=portrait({id:'b',name:'Beltrano Silva'});assert.match(none,/>BS</);assert.doesNotMatch(none,/<img/);assert.doesNotMatch(portrait({id:'c',name:'Sicrano',photo:ea}),/<img/);
 assert.match(portrait({id:'d',name:'Posição ST 11',position:'ST',placeholder:true}),/>ST</);assert.doesNotMatch(portrait({id:'e',name:'<b>x</b> y'}),/<b>/);
 // Linhas de estatística não carregam foto: o retrato encontra pelo id nos elencos registrados.
 assert.equal(setPhotoRegistry([{roster:[{id:'p1',photo:fifa},{id:'p2'}],reserve:[{id:'p3',photo:wiki}]}]),2);assert.deepEqual(registeredPhoto('p1'),{photo:fifa});assert.equal(registeredPhoto('p2'),null);
 assert.match(portrait({id:'p3',name:'Reserva Um'}),/<img[^>]+Teste\.jpg\?width=128/);assert.doesNotMatch(portrait({id:'p2',name:'Sem Foto'}),/<img/);setPhotoRegistry([]);assert.doesNotMatch(portrait({id:'p1',name:'Depois'}),/<img/);
});
test('auditoria: conta fontes, bloqueadas, ausentes, inválidas e fotos repetidas entre atletas',()=>{
 const a=auditPhotos([{id:'1',photo:fifa},{id:'2',photo:fifa+'?io=x'},{id:'3',photo:ea},{id:'4'},{id:'5',photo:'ftp://x'},{id:'6',photo:wiki},{id:'7',photo:fifa,placeholder:true},{id:'8',photo:'https://outro.invalid/z.png'}]);
 assert.deepEqual([a.total,a.usable,a.blocked,a.missing,a.invalid,a.unknownSource],[7,3,1,1,1,1]);assert.equal(a.duplicates.length,1);assert.deepEqual(a.duplicates[0].ids,['1','2']);assert.equal(a.coverage,42.9);
 const clubs=auditPhotos(INITIAL_PLAYERS);assert.equal(clubs.total,INITIAL_PLAYERS.length);assert.equal(clubs.invalid,0);assert.equal(clubs.duplicates.length,0,'nenhuma foto repetida no cadastro de clubes');assert.equal(clubs.usable+clubs.missing,clubs.total);
});
const line=(id,name,team,extra)=>({...blankLine(id,name,team,'ST'),gp:4,min:360,...extra}),get=id=>({name:'Time '+id,short:id});
test('comparativo de atletas: valores por 90 minutos, só com tempo de jogo suficiente',()=>{
 const stats={players:{a:line('a','Ana','x',{g:8,a:2,sh:20,sot:10,xg:5,pa:100,pc:80}),b:line('b','Bia','y',{g:2,a:4,sh:8,sot:4,xg:1.5,pa:200,pc:190,min:180,gp:2}),c:line('c','Curta','x',{g:3,min:45,gp:1})}};
 const html=playerComparison(stats,{},null,get);assert.match(html,/Ana/);assert.match(html,/Bia/);assert.doesNotMatch(html,/Curta/,'menos de 90 minutos fica fora');
 assert.match(html,/<b>2<\/b><span>Gols \/ 90 min/);assert.match(html,/Gols \/ 90 min[\s\S]*?<b>1<\/b>/);assert.match(html,/<b>80<\/b><span>Precisão de passe \(%\)[\s\S]*?<b>95<\/b>/);
 const swapped=playerComparison(stats,{cmpA:'b',cmpB:'a'},null,get);assert.ok(swapped.indexOf('Bia')<swapped.indexOf('Ana · x')||swapped.includes('value="b" selected'));
 assert.match(playerComparison(stats,{},new Set(['x']),get),/pelo menos dois atletas/);assert.match(playerComparison({players:{}},{},null,get),/pelo menos dois atletas/);assert.match(playerComparison(stats,{cmpA:'a',cmpB:'a'},null,get),/Bia/,'não compara o atleta com ele mesmo');
});
test('comparativo de equipes: médias por jogo a partir dos resumos das partidas',()=>{
 const rows=[{code:'x',played:4,gf:8,ga:2,shots:60,onTarget:24,xg:7.2,xga:2.4,possession:240,passes:400,completed:320,withStats:4},{code:'y',played:2,gf:1,ga:5,shots:16,onTarget:4,xg:1.4,xga:4,possession:80,passes:100,completed:70,withStats:2},{code:'z',played:1,gf:0,ga:0,withStats:0}];
 const html=teamComparison(rows,{},get);assert.match(html,/Time x/);assert.match(html,/Time y/);assert.doesNotMatch(html,/Time z/);assert.match(html,/<b>2\.0<\/b><span>Gols por jogo[\s\S]*?<b>0\.5<\/b>/);assert.match(html,/<b>15\.0<\/b><span>Finalizações por jogo[\s\S]*?<b>8\.0<\/b>/);assert.match(html,/<b>60<\/b><span>Posse média \(%\)[\s\S]*?<b>40<\/b>/);assert.match(html,/<b>80<\/b><span>Precisão de passe \(%\)[\s\S]*?<b>70<\/b>/);
 assert.match(teamComparison(rows.slice(1),{},get),/duas equipes/);
});
