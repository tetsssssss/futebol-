import test from 'node:test';
import assert from 'node:assert/strict';
import {clubTeams,startMatch,stepMatch,finishMatch,setTactics,substitute,changeFormation,startBrazil,currentFixtures,validateSave,commitResult,migrateCoachSave} from '../treinador/engine.js';
import {validateMatchState,SHAPES} from '../treinador/match-state.js';
import {captureView,blendViews,replayView} from '../treinador/replay.js';
import {planPass,planCross,planShot} from '../treinador/decisions.js';
const teams=clubTeams(),fresh=seed=>startMatch(teams[8],teams[13],seed,false,{recordReplay:false});
test('reload durante trajetória preserva resultado, eventos e RNG',()=>{const a=fresh('reload-flight');while(!a.action||a.action.kind!=='pass')stepMatch(a);stepMatch(a);validateMatchState(a);const b=JSON.parse(JSON.stringify(a));assert.deepEqual(finishMatch(a),finishMatch(b));});
test('formações reorganizam funções sem teletransportar ou trocar o portador',()=>{const s=fresh('shapes');for(let i=0;i<60;i++)stepMatch(s);for(const shape of Object.keys(SHAPES)){const positions=new Map(s.squads[0].playing.map(p=>[p.id,[p.x,p.y]])),id=s.squads[s.possession].playing[s.carrier].id;changeFormation(s,0,shape);assert.equal(s.squads[0].formation,shape);for(const p of s.squads[0].playing)assert.deepEqual([p.x,p.y],positions.get(p.id));assert.equal(s.squads[s.possession].playing[s.carrier].id,id);validateMatchState(s);}});
test('instruções produzem diferenças reais na simulação determinística',()=>{const a=fresh('tactical'),b=fresh('tactical');setTactics(b,0,{mentality:'attacking',pressing:95,tempo:95,instruction:'wide'});for(let i=0;i<600;i++){stepMatch(a);stepMatch(b)}assert.notDeepEqual(a.squads[0].playing.map(p=>[p.x,p.y]),b.squads[0].playing.map(p=>[p.x,p.y]));assert.notDeepEqual(a.stats,b.stats);assert.throws(()=>setTactics(b,0,{instruction:'invented'}));});
test('substituições preservam goleiro e proíbem retorno',()=>{const s=fresh('subs'),q=s.squads[0],out=q.playing.find(p=>p.role!=='GK'),gk=q.bench.find(p=>p.position==='GK'),incoming=q.bench.find(p=>p.position!=='GK');assert.throws(()=>substitute(s,0,out.id,gk.id));substitute(s,0,out.id,incoming.id);assert(!q.bench.some(p=>p.id===out.id));assert.throws(()=>substitute(s,0,incoming.id,out.id));validateMatchState(s);});
test('intervalo troca lado; fim tem relógio exato e replay limitado',()=>{const s=startMatch(teams[8],teams[13],'replay');while(s.tick<1350)stepMatch(s);assert(s.pauseSuggested);assert.equal(s.half,2);assert.equal(s.clock,2700);finishMatch(s);validateMatchState(s);assert.equal(s.clock,5400);assert(s.replay.clips.length>0&&s.replay.clips.length<=10);assert(s.replay.clips.some(c=>c.type==='goal'));for(const c of s.replay.clips){assert(c.frames.length<=70);assert(c.frames.length>1);assert(c.labels);}const snapshot=JSON.stringify(s);const clip=s.replay.clips[0];replayView(clip,clip.at,clip.labels);blendViews(captureView(s),captureView(s),.5);assert.equal(JSON.stringify(s),snapshot);});
test('importação rejeita trajetória e quadros corrompidos antes de executar',()=>{const s=fresh('validation');while(!s.action)stepMatch(s);const bad=structuredClone(s);bad.action.to.x=NaN;assert.throws(()=>validateMatchState(bad));const other=structuredClone(s);other.clock=100;assert.throws(()=>validateMatchState(other));const replay=structuredClone(s);replay.replay.clips=[{at:0,label:'bad',frames:[{}]}];assert.throws(()=>validateMatchState(replay));});
test('resultado de outro confronto não entra no calendário',()=>{const save=startBrazil(),fixture=currentFixtures(save)[0],s=fresh('wrong');save.current={fixtureId:fixture.id,match:s};assert.throws(()=>validateSave(save));assert.throws(()=>commitResult(save,fixture,finishMatch(s)));});
test('ações técnicas têm trajetórias distintas por contexto',()=>{const s=fresh('technical'),p=s.squads[0].playing[10];s.possession=0;s.carrier=10;p.x=85;p.y=15;s.ball={...s.ball,x:p.x,y:p.y};const crosses=new Set();for(let i=0;i<80;i++)crosses.add(planCross(s,p).subtype);assert.equal(crosses.size,5);const shot=planShot(s,p,'power');assert.equal(shot.kind,'shot');assert(shot.duration>0);s.tactics[0].instruction='through';const pass=planPass(s,p);assert(pass.targetId);assert.notDeepEqual(pass.to,shot.to);});
test('save novo migra sem alterar a partida em curso',()=>{const save=startBrazil(),f=currentFixtures(save)[0];save.current={fixtureId:f.id,match:startMatch(teams.find(t=>t.id===f.home),teams.find(t=>t.id===f.away),'migrate')};for(let i=0;i<200;i++)stepMatch(save.current.match);assert.deepEqual(migrateCoachSave(save),save);});
test('save espacial v1 preserva minuto, placar e escalação na migração',()=>{const save=startBrazil(),f=currentFixtures(save)[0],m=startMatch(teams.find(t=>t.id===f.home),teams.find(t=>t.id===f.away),'legacy');for(let i=0;i<300;i++)stepMatch(m);const ids=m.squads.map(q=>q.playing.map(p=>p.id));m.version=1;m.tick=20;m.minute=10;save.current={fixtureId:f.id,match:m};const migrated=migrateCoachSave(save);assert.equal(migrated.current.match.clock,600);assert.deepEqual(migrated.current.match.score,m.score);assert.deepEqual(migrated.current.match.squads.map(q=>new Set(q.playing.map(p=>p.id))),ids.map(q=>new Set(q)));assert(migrated.current.match.legacyMigrated);validateSave(migrated);});
test('mata-mata empatado vai à prorrogação e depois a pênaltis cobrança a cobrança',()=>{
 let tied=0,shootouts=0,seen;
 for(let n=0;n<30&&!seen;n++){
  const s=startMatch(teams[8],teams[13],'et-'+n,true,{recordReplay:false});
  while(!s.finished&&!(s.tick===2700)&&s.tick<2700)stepMatch(s);
  if(s.finished||s.score[0]!==s.score[1]){assert.equal(s.tick,2700);assert.equal(s.endTick,2700);continue}
  tied++;assert.equal(s.endTick,3600);assert.equal(s.finished,false);assert.equal(s.half,3);assert(s.pauseSuggested);validateMatchState(s);
  const copy=JSON.parse(JSON.stringify(s));finishMatch(s);finishMatch(copy);assert.deepEqual(s,copy);
  validateMatchState(s);assert.equal(s.tick,3600);assert.equal(s.clock,7200);
  if(s.shootout){shootouts++;seen=s;}
 }
 assert(tied>0,'nenhum empate nas sementes testadas');
 assert(seen,'nenhuma disputa de pênaltis nas sementes testadas');
 assert.notEqual(seen.penalties[0],seen.penalties[1]);
 assert.equal(seen.shootout.filter(k=>k.scored&&k.side===0).length,seen.penalties[0]);
 assert.equal(seen.shootout.filter(k=>k.scored&&k.side===1).length,seen.penalties[1]);
 assert(seen.events.filter(e=>e.type==='penalty').length===seen.shootout.length);
 assert(seen.events.some(e=>e.type==='extratime'));
});
test('partida de grupos não tem prorrogação',()=>{const s=finishMatch(startMatch(teams[8],teams[13],'et-0',false,{recordReplay:false}));assert.equal(s.tick,2700);assert.equal(s.shootout,null);assert(!s.penalties);});
import {applyMatchDiscipline,availableTeam,unavailableMap,validateDiscipline} from '../treinador/discipline.js';
test('cartões acumulados, vermelho e lesão geram indisponibilidade que expira jogo a jogo',()=>{
 const home=teams[8],away=teams[13],[a,b,c]=home.roster.map(p=>p.id);
 const save={mode:'brasileirao',team:home.id};
 const ev=(type,side,playerId,extra={})=>({type,side,playerId,...extra});
 applyMatchDiscipline(save,{home:home.id,away:away.id,events:[ev('card',0,a,{color:'yellow'}),ev('card',0,b,{color:'red'}),ev('injury',0,c,{matches:2})]});
 let gone=unavailableMap(save,home.id);assert.equal(gone[b].kind,'suspended');assert.equal(gone[c].left,2);assert(!gone[a]);assert.equal(save.discipline.yellows[a],1);
 assert(!availableTeam(home,save).roster.some(p=>p.id===b||p.id===c));assert.equal(availableTeam(home,save).roster.length,home.roster.length-2);
 applyMatchDiscipline(save,{home:home.id,away:away.id,events:[ev('card',0,a,{color:'yellow'})]});
 gone=unavailableMap(save,home.id);assert(!gone[b]);assert.equal(gone[c].left,1);assert.equal(gone[a],undefined);
 applyMatchDiscipline(save,{home:home.id,away:away.id,events:[ev('card',0,a,{color:'yellow'})]});
 gone=unavailableMap(save,home.id);assert.equal(gone[a].kind,'suspended');assert(!gone[c]);assert.equal(save.discipline.yellows[a],0);
 assert(validateDiscipline(save.discipline));assert.throws(()=>validateDiscipline({yellows:{x:-1},suspended:{},injured:{}}));
});
test('lesão em jogo gera substituição forçada, preserva goleiro e mantém determinismo',()=>{
 let found=0;
 for(let n=0;n<40&&found<2;n++){
  const s=finishMatch(startMatch(teams[8],teams[13],'inj-'+n,false,{recordReplay:false}));
  const inj=s.events.filter(e=>e.type==='injury');if(!inj.length)continue;found++;
  validateMatchState(s);
  for(const e of inj){assert(e.matches>=1&&e.matches<=4);assert([0,1].includes(e.side))}
  for(const squad of s.squads)assert.equal(squad.playing.filter(p=>!p.dismissed&&p.role==='GK').length,1);
  assert.deepEqual(finishMatch(startMatch(teams[8],teams[13],'inj-'+n,false,{recordReplay:false})).events,s.events);
 }
 assert(found>0,'nenhuma lesão em 40 partidas');
});
test('commitResult grava disciplina no save e validateSave aceita após várias rodadas',()=>{
 const save=startBrazil();let rounds=0;
 while(rounds<6){const f=currentFixtures(save).filter(m=>!m.played);if(!f.length)break;
  for(const m of f){const home=availableTeam(teams.find(t=>t.id===m.home),save),away=availableTeam(teams.find(t=>t.id===m.away),save);
   commitResult(save,m,finishMatch(startMatch(home,away,'disc-'+m.id,false,{recordReplay:false})))}
  rounds++}
 assert(save.discipline);validateSave(save);
 const total=Object.values(save.discipline.yellows).reduce((a,b)=>a+b,0)+Object.keys(save.discipline.suspended).length;assert(total>0);
});
test('calibração: estatísticas agregadas ficam em faixas plausíveis de futebol',()=>{
 const sum={goals:0,fouls:0,offsides:0,yellow:0,red:0,shots:0,xG:0},N=16;
 for(let n=0;n<N;n++){const s=finishMatch(startMatch(teams[(n*3)%20],teams[(n*3+7)%20],'cal-'+n,false,{recordReplay:false}));
  sum.goals+=s.score[0]+s.score[1];for(const k of ['fouls','offsides','yellow','red','shots','xG'])sum[k]+=s.stats[k][0]+s.stats[k][1]}
 const avg=k=>sum[k]/N;
 assert(avg('goals')>1.5&&avg('goals')<4.2,'gols '+avg('goals'));
 assert(avg('fouls')>10&&avg('fouls')<35,'faltas '+avg('fouls'));
 assert(avg('offsides')<8,'impedimentos '+avg('offsides'));
 assert(avg('yellow')>1&&avg('yellow')<7,'amarelos '+avg('yellow'));
 assert(avg('red')<1,'vermelhos '+avg('red'));
 assert(avg('shots')>12&&avg('shots')<40,'finalizações '+avg('shots'));
 assert(avg('xG')<avg('goals')*2.2,'xG '+avg('xG'));
});
