import test from 'node:test';import assert from 'node:assert/strict';
import {rulesFor} from '../treinador/rules.js';
import {CONMEBOL_CLUBS,ORDER_2026,HOLDERS_2026,countryOf} from '../treinador/conmebol.js';
import {createContinental,continentalEntry,afterContinental,continentalMatchday,continentalFixtures,continentalSetup,continentalDone,participants,tieResult,stageTies,groupTable,groupOfClub,clubStatus,clubCampaign,bracketColumns,nextContinentalOrder,rollContinental,validateContinental,continentalMerit} from '../treinador/continental.js';
import {CLUB_DIRECTORY} from '../treinador/league.js';
import {startBrazil,universeTeams,fixtureSetup,startMatch,finishMatch,commitResult,validateSave,migrateCoachSave,advanceUniverse,seasonReady} from '../treinador/engine.js';
import {afterResult,matchdayFixtures} from '../treinador/league.js';

const known=new Set([...CLUB_DIRECTORY,...CONMEBOL_CLUBS].map(c=>c.id));
// Preenche resultados sem o motor: placar determinístico; mata-mata empatado no agregado recebe pênaltis.
function score(m){let h=0;for(const c of m.id)h=Math.imul(h^c.charCodeAt(0),16777619)>>>0;return [h%4,(h>>>8)%3]}
function playDay(c){
 const day=continentalMatchday(c);if(!day)return false;
 for(const m of day.matches){
  const [hg,ag]=score(m);let penalties=null;
  if(m.leg===0||m.leg===2||m.stage==='final'){
   const first=c[m.comp].fixtures.find(x=>x.id===m.firstLeg),before=first?[first.ag,first.hg]:[0,0];
   if(hg+before[0]===ag+before[1])penalties=(hash(m.id)%2)?[5,4]:[3,4];
  }
  Object.assign(m,{played:true,hg,ag,penalties,st:{yellow:[hg%3,ag%3],red:[0,0]}});
  afterContinental(c);
 }
 return true;
}
const hash=text=>{let h=2166136261;for(const c of String(text))h=Math.imul(h^c.charCodeAt(0),16777619)>>>0;return h};
function playAll(c){let guard=0;while(playDay(c)){if(++guard>400)throw Error('laço sem fim')}return c}

test('vagas de 2026: 47 clubes na Libertadores e 44 por mérito na Sul-Americana, sem repetição e com os campeões vigentes',()=>{
 const {entry}=continentalEntry(ORDER_2026,HOLDERS_2026,2026),L=entry.libertadores,S=entry.sudamericana;
 assert.equal(L.groups.length,28);assert.equal(L.second.length,13);assert.equal(L.first.length,6);assert.equal(S.groups.length,12);assert.equal(S.first.length,32);
 const all=[...Object.values(L).flat(),...Object.values(S).flat()];assert.equal(new Set(all).size,all.length,'ninguém em dois torneios na entrada');assert.ok(all.every(id=>known.has(id)));
 assert.ok(L.groups.includes('flamengo')&&L.groups.includes('ar-lanus'),'campeões de 2025 entram nos grupos');
 const by=(list,country)=>list.filter(id=>countryOf(id)===country).length;
 assert.equal(by(L.groups,'ARG'),6);assert.equal(by(L.groups,'BRA'),6);assert.equal(by(L.second,'BRA'),2);assert.equal(by(S.groups,'BRA'),6);assert.equal(by(S.groups,'ARG'),6);
 assert.deepEqual(L.first.map(countryOf).sort(),['BOL','ECU','PAR','PER','URU','VEN']);assert.ok(L.second.includes('botafogo')&&L.second.includes('bahia'));
 assert.equal(rulesFor('conmebol-libertadores',2027).carriedFrom,2026);
});
test('torneios completos: 155 e 157 jogos, campeões, grupos sem repetir país e chave em árvore',()=>{
 const c=createContinental(2026);assert.ok(validateContinental(c,known));assert.equal(c.lib.fixtures.length,6);assert.equal(c.sula.fixtures.length,16);
 playAll(c);assert.ok(validateContinental(c,known));assert.equal(continentalDone(c),true);
 assert.equal(c.lib.fixtures.length,155);assert.equal(c.sula.fixtures.length,157);assert.ok(c.lib.champion&&c.sula.champion);assert.equal(c.lib.stage,'done');
 for(const key of ['lib','sula']){
  const T=c[key];assert.equal(Object.keys(T.groups).length,8);
  for(const [g,codes] of Object.entries(T.groups)){assert.equal(codes.length,4);assert.equal(new Set(codes.map(countryOf)).size,4,`${key} grupo ${g} repete país`);assert.equal(groupTable(c,key,g).length,4)}
  assert.deepEqual(['r16','qf','sf','final'].map(s=>stageTies(T,s).length),[8,4,2,1]);
  const final=stageTies(T,'final')[0];assert.equal(final.winner,T.champion);assert.equal(final.legs.length,1);
  const cols=bracketColumns(T);assert.deepEqual(cols.map(col=>col.ties.length),[8,4,2,1]);assert.ok(cols.every(col=>col.ties.every(t=>!t.pending)));
 }
 // O campeão da Libertadores sai dos 28 diretos ou dos 4 vencedores da 3ª fase: pode ser qualquer clube, mas só um.
 assert.ok(participants(c.lib).includes(c.lib.champion));assert.notEqual(c.lib.champion,undefined);
});
test('transferências entre torneios: os 4 eliminados da 3ª fase da Libertadores e os 8 terceiros jogam a Sul-Americana',()=>{
 const c=createContinental(2026);playAll(c);
 const lostQ3=stageTies(c.lib,'q3').map(t=>t.loser),thirds=Object.keys(c.lib.groups).map(g=>groupTable(c,'lib',g)[2].code);
 assert.equal(lostQ3.length,4);for(const id of lostQ3)assert.ok(Object.values(c.sula.groups).flat().includes(id),'cai da 3ª fase e entra nos grupos');
 const po=stageTies(c.sula,'po'),poClubs=po.flatMap(t=>[t.first,t.second]);assert.equal(po.length,8);
 for(const id of thirds)assert.ok(poClubs.includes(id),'terceiro da Libertadores nos playoffs');
 const seconds=Object.keys(c.sula.groups).map(g=>groupTable(c,'sula',g)[1].code);for(const id of seconds)assert.ok(poClubs.includes(id));
 assert.ok(po.every(t=>thirds.includes(t.first)&&seconds.includes(t.second)),'segundo colocado decide em casa contra um terceiro');
 const r16=stageTies(c.sula,'r16').flatMap(t=>[t.first,t.second]),winners=Object.keys(c.sula.groups).map(g=>groupTable(c,'sula',g)[0].code);
 for(const id of winners)assert.ok(r16.includes(id));assert.equal(new Set(r16).size,16);
});
test('regulamento por jogo: ida normal, volta com agregado, sem prorrogação e final com prorrogação',()=>{
 const c=createContinental(2026),m1=c.lib.fixtures.find(m=>m.leg===1),m2=c.lib.fixtures.find(m=>m.leg===2);
 assert.deepEqual(continentalSetup(c,m1),{knockout:false,options:{}});assert.throws(()=>continentalSetup(c,m2),/ida/);
 Object.assign(m1,{played:true,hg:2,ag:1});assert.deepEqual(continentalSetup(c,m2),{knockout:true,options:{aggregate:[1,2],noExtraTime:true}});
 const single=c.sula.fixtures[0];assert.deepEqual(continentalSetup(c,single),{knockout:true,options:{noExtraTime:true}});
 const done=playAll(createContinental(2026)),final=done.lib.fixtures.find(m=>m.stage==='final');
 assert.deepEqual(continentalSetup(done,final),{knockout:true,options:{noExtraTime:false}});
 // agregado empatado: decide o pênalti; a vaga melhor (mandante da volta) NÃO vence por critério de campanha
 const T={fixtures:[{tie:'x',home:'a',away:'b',played:true,hg:1,ag:0},{tie:'x',home:'b',away:'a',played:true,hg:1,ag:0,penalties:[3,5]}]},r=tieResult(T,{id:'x',first:'a',second:'b'});
 assert.deepEqual(r.aggregate,[1,1]);assert.equal(r.winner,'a');
});
test('o mesmo clube não cai duas vezes e a campanha do clube bate com os jogos',()=>{
 const c=playAll(createContinental(2026));
 for(const [key,T] of [['lib',c.lib],['sula',c.sula]]){
  const losers=T.ties.map(t=>tieResult(T,t).loser);assert.equal(new Set(losers).size,losers.length);
  const champ=T.champion;assert.equal(clubStatus(c,key,champ).state,'champion');assert.ok(!losers.includes(champ));
  const games=clubCampaign(T,champ);assert.ok(games.length>=8);assert.ok(games.every(g=>['W','D','L'].includes(g.result)));
 }
 const merit=continentalMerit(c);assert.equal(Math.max(...Object.values(merit)),Math.max(merit[c.lib.champion],merit[c.sula.champion]));
});
test('partidas reais pelo motor: ida e volta com agregado, resultado e estatística no torneio',()=>{
 const save=startBrazil(),teams=new Map(universeTeams().map(t=>[t.id,t])),c=save.continental;
 const play=f=>{const {knockout,options}=fixtureSetup(save,f);return commitResult(save,f,finishMatch(startMatch(teams.get(f.home),teams.get(f.away),`t|${f.id}`,knockout,{...options,recordReplay:false})))};
 const first=continentalMatchday(c).matches;assert.equal(first.length,3);first.forEach(play);
 assert.ok(first.every(m=>m.played&&Number.isInteger(m.hg)));assert.ok(validateSave(save));
 assert.equal(Object.keys(save.stats.players).length,0,'a artilharia da liga não recebe jogos continentais');assert.ok(Object.keys(c.lib.stats.players).length>20);
 const second=continentalMatchday(c).matches;assert.ok(second.every(m=>m.leg===2));second.forEach(play);
 const q1=stageTies(c.lib,'q1');assert.ok(q1.every(t=>t.winner));assert.equal(c.lib.stage,'q2');assert.equal(c.lib.ties.filter(t=>t.stage==='q2').length,8);
 const tie=q1[0];assert.equal(tie.aggregate[0]+tie.aggregate[1],tie.legs[0].hg+tie.legs[0].ag+tie.legs[1].hg+tie.legs[1].ag);
 assert.ok(validateSave(JSON.parse(JSON.stringify(save))));
});
test('virada de temporada: exige os torneios encerrados, campeões vigentes entram direto e o Brasil usa a tabela final',()=>{
 const save=startBrazil();
 for(const league of [save.league,save.serieB]){for(const round of league.rounds)for(const m of round){const [hg,ag]=score(m);Object.assign(m,{played:true,hg,ag,st:{yellow:[0,0],red:[0,0]}})}afterResult(league)}
 let guard=0;while(!save.serieB.playoff.winners){for(const leg of save.serieB.playoff.legs)for(const m of leg){if(m.played)continue;const [hg,ag]=score(m);Object.assign(m,{played:true,hg:hg+1,ag,st:{yellow:[0,0],red:[0,0]}});afterResult(save.serieB)}if(++guard>3)break}
 assert.equal(seasonReady(save),false);assert.throws(()=>advanceUniverse(save),/Libertadores/);
 playAll(save.continental);assert.equal(seasonReady(save),true);
 const previous=save.continental,champions=[previous.lib.champion,previous.sula.champion];
 const result=advanceUniverse(save);assert.equal(save.season,2027);assert.equal(save.continental.season,2027);
 assert.deepEqual(save.history.at(-1).continental.libertadores.champion,champions[0]);assert.deepEqual(result.continental.sudamericana.champion,champions[1]);
 const e=save.continental.entry;assert.ok(e.libertadores.groups.includes(champions[0])&&e.libertadores.groups.includes(champions[1]),'campeões vigentes entram nos grupos');
 assert.ok(validateSave(save));assert.equal(save.continental.lib.fixtures.length,6);
 assert.throws(()=>rollContinental(save.continental,2028,[]),/pendentes/,'não rola para a edição seguinte com partidas pendentes');
});
test('rodízio dos demais países: o pior participante dá lugar a quem esperava',()=>{
 const c=playAll(createContinental(2026)),order=nextContinentalOrder(c,ORDER_2026.BRA),merit=continentalMerit(c);
 for(const country of Object.keys(order)){assert.equal(new Set(order[country]).size,order[country].length);assert.equal(order[country].length,c.order[country].length)}
 const list=ORDER_2026.BOL,played=list.filter(id=>id in merit).sort((x,y)=>merit[y]-merit[x]||list.indexOf(x)-list.indexOf(y)),idle=list.filter(id=>!(id in merit));
 assert.ok(idle.length>0&&played.length>0);assert.equal(order.BOL.at(-1),played.at(-1),'o pior participante vai ao fim da fila');
 for(const id of idle)assert.ok(order.BOL.indexOf(id)<order.BOL.length-1);assert.deepEqual(order.BOL.slice(0,played.length-1),played.slice(0,-1),'quem foi melhor mantém a ordem');
});
test('save de versão anterior (sem torneios continentais) migra e ganha a edição de 2026',()=>{
 const old=startBrazil();delete old.continental;const m=migrateCoachSave(old);assert.ok(m.continental.lib.fixtures.length>0);assert.ok(validateSave(m));
 const bad=structuredClone(m);bad.continental.lib.fixtures[0].home=bad.continental.lib.fixtures[0].away;assert.throws(()=>validateSave(bad));
 assert.ok(matchdayFixtures(m).length>0&&groupOfClub(m.continental.lib,'flamengo')===null);
});
