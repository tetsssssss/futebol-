import test from 'node:test';import assert from 'node:assert/strict';
import {clubTeams,startMatch,stepMatch,finishMatch,setTactics,setPlayerDuty} from '../treinador/engine.js';
import {validateMatchState} from '../treinador/match-state.js';
import {teamShape,offsideLine} from '../treinador/movement.js';
import {laneClearance,shotQuality,planShot,planThrough} from '../treinador/decisions.js';
import {localX} from '../treinador/math.js';
import {summarizeMatch} from '../treinador/match-summary.js';
const teams=clubTeams(),fresh=seed=>startMatch(teams[8],teams[13],seed,false,{recordReplay:false});
// Mede a forma média do time 0 em jogo corrido; `when` filtra por posse (true = com a bola).
function measure(seed,tactics,{when=null,ticks=1300,prepare=()=>{}}={}){
 const s=fresh(seed);if(tactics)setTactics(s,0,tactics);prepare(s);const sum={width:0,length:0,line:0,n:0};
 for(let i=0;i<ticks;i++){stepMatch(s);if(i%5||s.restart||(when!==null&&(s.possession===0)!==when))continue;const t=teamShape(s,0);sum.width+=t.width;sum.length+=t.length;sum.line+=t.line;sum.n++}
 return {width:sum.width/sum.n,length:sum.length/sum.n,line:sum.line/sum.n,state:s};
}
const SEEDS=['shape-a','shape-b','shape-c'],avg=(key,tactics,opts)=>SEEDS.reduce((n,seed)=>n+measure(seed,tactics,opts)[key],0)/SEEDS.length;

test('largura: a instrução muda a amplitude real da equipe com a bola',()=>{
 const narrow=avg('width',{width:25},{when:true}),wide=avg('width',{width:95},{when:true});
 assert.ok(wide>narrow+10,`largura 95 → ${wide.toFixed(1)}; largura 25 → ${narrow.toFixed(1)}`);
});
test('linha defensiva: linha alta defende mais longe do próprio gol',()=>{
 const low=avg('line',{line:20},{when:false}),high=avg('line',{line:95},{when:false});
 assert.ok(high>low+6,`linha 95 → ${high.toFixed(1)}; linha 20 → ${low.toFixed(1)}`);
});
test('compactação: o bloco sem a bola não se estica além de meio campo',()=>{
 const length=avg('length',null,{when:false});assert.ok(length<46,`comprimento médio sem a bola ${length.toFixed(1)}`);
 assert.ok(avg('length',null,{})<50);
});
test('saída de bola: direta usa mais passes longos; curta mantém mais a posse em passes curtos',()=>{
 const count=(build)=>{let long=0,short=0,total=0;for(const seed of SEEDS){const s=fresh('build-'+seed);setTactics(s,0,{buildUp:build});setTactics(s,1,{buildUp:build});finishMatch(s);const c=s.actionCounts;long+=(c.long||0)+(c.longDistribution||0)+(c.switch||0);short+=(c.short||0)+(c.shortDistribution||0);total+=s.stats.passes[0]+s.stats.passes[1]}return {long:long/total,short:short/total}};
 const direct=count('direct'),curta=count('short');
 assert.ok(direct.long>curta.long*1.5,`longos: direta ${direct.long.toFixed(3)} × curta ${curta.long.toFixed(3)}`);assert.ok(curta.short>direct.short,`curtos: curta ${curta.short.toFixed(3)} × direta ${direct.short.toFixed(3)}`);
});
test('função individual: "atacar" adianta o atleta e "defender" o segura, na mesma partida',()=>{
 const position=duty=>{let total=0;for(const seed of SEEDS){const s=fresh('duty-'+seed),p=s.squads[0].playing.find(x=>x.role==='CM');setPlayerDuty(s,0,p.id,duty);let sum=0,n=0;for(let i=0;i<1200;i++){stepMatch(s);if(i%5===0&&!s.restart){const now=s.squads[0].playing.find(x=>x.id===p.id);if(now&&!now.dismissed){sum+=localX(s,0,now.x);n++}}}total+=sum/n}return total/SEEDS.length};
 const attack=position('attack'),defend=position('defend');assert.ok(attack>defend+4,`atacar ${attack.toFixed(1)} × defender ${defend.toFixed(1)}`);
 const s=fresh('duty-rules'),keeper=s.squads[0].playing.find(p=>p.role==='GK');assert.throws(()=>setPlayerDuty(s,0,keeper.id,'attack'));assert.throws(()=>setPlayerDuty(s,0,s.squads[0].playing[5].id,'inventada'));assert.throws(()=>setPlayerDuty(s,0,'ninguem','attack'));
 setPlayerDuty(s,0,s.squads[0].playing[5].id,'defend');assert.ok(validateMatchState(s));assert.equal(s.events.at(-1).type,'tactics');
});
test('instruções novas são validadas, têm padrão e partidas antigas continuam válidas',()=>{
 const s=fresh('legacy-tactics');assert.deepEqual([s.tactics[0].width,s.tactics[0].line,s.tactics[0].buildUp],[55,50,'mixed']);
 assert.throws(()=>setTactics(s,0,{buildUp:'tiki-taka'}));assert.throws(()=>setTactics(s,0,{width:'larga'}));
 setTactics(s,0,{width:500,line:-3});assert.deepEqual([s.tactics[0].width,s.tactics[0].line],[95,20]);
 // Estado gravado antes da v0.9: sem largura, linha, saída de bola nem função individual.
 const old=fresh('legacy-tactics');for(const t of old.tactics){delete t.width;delete t.line;delete t.buildUp}for(let i=0;i<200;i++)stepMatch(old);
 assert.ok(validateMatchState(old));const copy=JSON.parse(JSON.stringify(old));assert.deepEqual(finishMatch(old),finishMatch(copy));assert.ok(validateMatchState(old));
 const bad=fresh('bad');bad.tactics[0].buildUp='x';assert.throws(()=>validateMatchState(bad));const bad2=fresh('bad2');bad2.squads[0].playing[3].duty='x';assert.throws(()=>validateMatchState(bad2));
});
test('atacantes jogam no limite da última linha sem viver em impedimento',()=>{
 const s=fresh('shoulder');let ahead=0,n=0;
 for(let i=0;i<1300;i++){stepMatch(s);if(i%5||s.restart||s.possession!==0)continue;const line=offsideLine(s,0);for(const p of s.squads[0].playing)if(p.role==='ST'&&!p.dismissed&&s.squads[0].playing[s.carrier]?.id!==p.id){n++;if(localX(s,0,p.x)>line+1.5)ahead++}}
 assert.ok(n>50);assert.ok(ahead/n<.2,`centroavante além da linha em ${(100*ahead/n).toFixed(0)}% das amostras`);
});
test('leitura de jogo: linha de passe fechada é medida e a posição de chute tem valor decrescente com a distância',()=>{
 const from={x:40,y:50},to={x:60,y:50},rival=(x,y,extra={})=>({x,y,role:'CM',dismissed:false,...extra});
 assert.ok(laneClearance(from,to,[rival(50,50)])<.01);assert.ok(Math.abs(laneClearance(from,to,[rival(50,60)])-6.8)<.01);
 assert.equal(laneClearance(from,to,[rival(40.5,50)]),99,'marcador colado no passador não fecha a linha');assert.equal(laneClearance(from,to,[rival(50,50,{dismissed:true})]),99);
 const s=fresh('quality');assert.ok(shotQuality(s,0,{x:90,y:50})>shotQuality(s,0,{x:78,y:50}));assert.ok(shotQuality(s,0,{x:90,y:50})>shotQuality(s,0,{x:90,y:80}));assert.equal(shotQuality(s,0,{x:50,y:50}),0);
});
test('bola parada: falta frontal é cobrada pelo melhor batedor e vale menos que um chute de jogo corrido',()=>{
 const s=fresh('freekick'),p=s.squads[0].playing.find(x=>x.role==='AM');Object.assign(p,{x:80,y:50});s.ball={...s.ball,x:80,y:50};s.possession=0;
 const open=planShot(structuredClone(s),p,'placed'),dead=planShot(structuredClone(s),p,'placed',true);assert.ok(dead.xG<open.xG*.7,`falta ${dead.xG} × jogo ${open.xG}`);assert.ok(dead.xG<=.14);
 // Em partidas completas: quem cobra falta direta é sempre o atleta de linha com o maior atributo de faltas em campo.
 let kicks=0;for(const seed of SEEDS){const m=fresh('fk-'+seed);while(!m.finished){const before=m.eventSequence;stepMatch(m);const e=m.events.find(x=>x.id>before&&x.type==='freeKick'&&x.text.startsWith('Cobrança direta'));if(!e)continue;const shot=m.events.find(x=>x.id>e.id&&x.type==='shot');if(!shot)continue;kicks++;const squad=m.squads[e.side].playing.filter(x=>!x.dismissed&&x.role!=='GK'),best=Math.max(...squad.map(x=>x.attrs?.freeKicks??x.overall??65)),taker=squad.find(x=>x.id===shot.playerId);assert.ok(taker,'cobrador está em campo');assert.equal(taker.attrs?.freeKicks??taker.overall??65,best)}}
 assert.ok(kicks>0,'houve cobranças diretas para conferir');
});
test('distribuição de gols e ritmo: faixas medidas ficam registradas como contrato de calibração',()=>{
 const byRole={},N=24;let goals=0,shots=0,passes=0,completed=0,length=0,samples=0;
 for(let n=0;n<N;n++){const s=startMatch(teams[(n*7)%20],teams[(n*7+3+n%5)%20],'cal-'+n,false,{recordReplay:false});while(!s.finished){stepMatch(s);if(s.tick%25===0&&!s.restart){length+=teamShape(s,0).length+teamShape(s,1).length;samples+=2}}
  const roles=new Map(s.squads.flatMap(q=>[...q.playing,...(q.out||[])]).map(p=>[p.id,p.role||p.position]));for(const l of Object.values(summarizeMatch(s).lines))byRole[roles.get(l.id)]=(byRole[roles.get(l.id)]||0)+l.g;
  goals+=s.score[0]+s.score[1];shots+=s.stats.shots[0]+s.stats.shots[1];passes+=s.stats.passes[0]+s.stats.passes[1];completed+=s.stats.completedPasses[0]+s.stats.completedPasses[1]}
 const scorers=Object.entries(byRole).filter(([,g])=>g>0).length,st=(byRole.ST||0)/goals;
 assert.ok(goals/N>1.5&&goals/N<3.4,'gols por jogo '+(goals/N).toFixed(2));assert.ok(shots/N>13&&shots/N<32,'finalizações '+(shots/N).toFixed(1));
 assert.ok(completed/passes>.7&&completed/passes<.9,'precisão de passe '+(completed/passes).toFixed(2));assert.ok(length/samples<42,'bloco médio '+(length/samples).toFixed(1));
 assert.ok(scorers>=5,'funções que marcaram: '+scorers);assert.ok(st<.66,'participação do centroavante nos gols '+st.toFixed(2));
 const mids=((byRole.CM||0)+(byRole.DM||0)+(byRole.AM||0)+(byRole.RW||0)+(byRole.LW||0))/goals;assert.ok(mids>.3,'gols de meias e pontas '+mids.toFixed(2));assert.ok(goals/N>2.1,'ataque não pode voltar a travar: '+(goals/N).toFixed(2));
});
test('bola em profundidade: o passe vai para o espaço atrás da última linha e o impedimento é julgado no passe',()=>{
 let found=0,offside=0,onside=0;
 for(const seed of ['thr-a','thr-b','thr-c','thr-d']){const s=fresh(seed);
  for(let i=0;i<2600&&found<40;i++){stepMatch(s);if(s.restart||s.action||i%3)continue;const side=s.possession,p=s.squads[side].playing[s.carrier];if(!p||p.role==='GK')continue;
   const probe=structuredClone(s),carrier=probe.squads[side].playing[probe.carrier],pass=planThrough(probe,carrier);if(!pass)continue;found++;
   const line=offsideLine(s,side),runner=s.squads[side].playing.find(x=>x.id===pass.targetId);
   assert.equal(pass.subtype,'through');assert.ok(['ST','RW','LW','RM','LM','AM'].includes(runner.role));assert.ok(localX(s,side,pass.to.x)>line+3,'alvo atrás da linha');assert.ok(localX(s,side,p.x)<=line-4,'passador atrás da linha');
   assert.equal(pass.offside,localX(s,side,runner.x)>line+.3);pass.offside?offside++:onside++}}
 assert.ok(found>=10,'oportunidades encontradas: '+found);assert.ok(onside>0,'há rupturas em posição legal');
});
test('profundidade muda o jogo: instruir bolas em profundidade gera mais passes desse tipo do que manter a posse',()=>{
 const count=instruction=>{let n=0;for(const seed of SEEDS){const s=fresh('deep-'+seed);setTactics(s,0,{instruction});setTactics(s,1,{instruction});finishMatch(s);n+=s.actionCounts.through||0}return n};
 const through=count('through'),retain=count('retain');assert.ok(through>retain+4,`em profundidade ${through} × posse ${retain}`);
});
