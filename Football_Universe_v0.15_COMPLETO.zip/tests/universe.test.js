import test from 'node:test';import assert from 'node:assert/strict';import {readFileSync,statSync} from 'node:fs';
import {rulesFor,rankTable,COMPETITION_RULES} from '../treinador/rules.js';
import {makeLeague,leagueTable,leagueTeams,afterResult,currentRound,matchdayFixtures,seasonFinished,seasonOutcome,advanceSeason,SERIE_B_2026,FEEDER_2026} from '../treinador/league.js';
import {summarizeMatch,playerRanking} from '../treinador/match-summary.js';
import {startBrazil,startWorldCup,universeTeams,clubTeams,currentFixtures,startMatch,finishMatch,commitResult,fixtureSetup,validateSave,migrateCoachSave,BRAZIL_2026} from '../treinador/engine.js';

const rules=rulesFor('br-serie-a',2026);
const game=(home,away,hg,ag,st)=>({id:`${home}-${away}`,home,away,played:true,hg,ag,...(st?{st}:{})});
const order=(matches,codes,r=rules)=>rankTable(matches,codes,r,2026).map(x=>x.code);
// Preenche resultados determinísticos sem passar pelo motor: serve apenas para testar regras de tabela e temporada.
function fill(league,bias=()=>0){for(const round of league.rounds)for(const m of round){if(m.played)continue;let h=0;for(const c of m.id)h=Math.imul(h^c.charCodeAt(0),16777619)>>>0;Object.assign(m,{played:true,hg:(h%4)+bias(m.home),ag:((h>>>8)%3)+bias(m.away),st:{yellow:[h%3,(h>>>4)%3],red:[0,0]}})}return afterResult(league)}
const teams=new Map(universeTeams().map(t=>[t.id,t]));
function play(save,fixture){const {knockout,options}=fixtureSetup(save,fixture);return commitResult(save,fixture,finishMatch(startMatch(teams.get(fixture.home),teams.get(fixture.away),`t|${fixture.id}`,knockout,{...options,recordReplay:false})))}

test('regulamentos são versionados: temporada sem regra própria herda a mais recente e registra a origem',()=>{
 assert.equal(rulesFor('br-serie-b',2026).promotion.direct,2);assert.equal(rulesFor('br-serie-b',2029).carriedFrom,2026);
 assert.throws(()=>rulesFor('br-serie-a',2025));assert.throws(()=>rulesFor('liga-inexistente',2026));
 for(const r of COMPETITION_RULES)assert.ok(r.id&&Number.isInteger(r.season)&&Number.isInteger(r.revision)&&Array.isArray(r.tiebreakers)&&typeof r.verified==='boolean');
});
test('desempate: vitórias valem antes do saldo de gols',()=>{
 // A: 2V 1D (7 pts, saldo +2) · B: 2V 1D (7 pts, saldo +5) -> saldo decide; C com mais vitórias e mesmo total fica à frente
 const m=[game('a','x',1,0),game('a','y',1,0),game('a','z',0,0),game('b','x',3,0),game('b','y',2,0),game('b','z',0,0)];
 assert.deepEqual(order(m,['a','b','x','y','z']).slice(0,2),['b','a']);
 const n=[game('c','x',1,0),game('c','y',1,0),game('x','c',9,0),game('d','x',0,0),game('d','y',0,0),game('d','z',0,0),game('d','w',0,0),game('d','v',0,0),game('d','u',0,0)];
 const t=rankTable(n,['c','d','x','y','z','w','v','u'],rules,2026),c=t.find(r=>r.code==='c'),d=t.find(r=>r.code==='d');
 assert.equal(c.pts,d.pts);assert.ok(c.gd<d.gd);assert.ok(c.position<d.position);assert.equal(c.decidedBy,'wins');
});
test('desempate: confronto direto só entre dois clubes e com os dois jogos disputados',()=>{
 const base=[game('a','c',1,0),game('b','c',1,0)];
 const full=[...base,game('a','b',0,1),game('b','a',0,0)];
 assert.deepEqual(order(full,['a','b','c']).slice(0,2),['b','a']);
 // Com o critério desligado, a mesma tabela cai no sorteio determinístico
 const noH2H={...rules,tiebreakers:rules.tiebreakers.filter(x=>x!=='headToHead')};
 const three=[game('a','b',1,0),game('b','c',1,0),game('c','a',1,0)];
 assert.deepEqual(order(three,['a','b','c']),order(three,['a','b','c'],noH2H),'três clubes empatados ignoram o confronto direto');
 assert.deepEqual(order(three,['a','b','c']),order(three,['c','b','a']),'sorteio não depende da ordem de entrada');
});
test('desempate: menos cartões vermelhos e amarelos decidem quando o resto empata',()=>{
 const m=[game('a','c',1,0,{yellow:[1,0],red:[1,0]}),game('b','d',1,0,{yellow:[5,0],red:[0,0]})];
 const t=rankTable(m,['a','b','c','d'],rules,2026);assert.equal(t[0].code,'b');assert.equal(t[0].decidedBy,'fewestReds');
 const y=[game('a','c',1,0,{yellow:[3,0],red:[0,0]}),game('b','d',1,0,{yellow:[1,0],red:[0,0]})];
 assert.equal(rankTable(y,['a','b','c','d'],rules,2026)[0].decidedBy,'fewestYellows');
});
test('tabela expõe zonas do regulamento, forma recente e desempenho de mandante/visitante',()=>{
 const league=fill(makeLeague()),table=leagueTable(league);
 assert.deepEqual(table.slice(0,4).map(r=>r.zone),Array(4).fill('continental'));assert.deepEqual(table.slice(-4).map(r=>r.zone),Array(4).fill('relegation'));
 for(const r of table){assert.equal(r.played,38);assert.equal(r.home.played,19);assert.equal(r.away.played,19);assert.equal(r.home.pts+r.away.pts,r.pts);assert.equal(r.form.length,5)}
 assert.equal(table.reduce((n,r)=>n+r.gf,0),table.reduce((n,r)=>n+r.ga,0));
});
test('Série B 2026: 20 clubes distintos da Série A, 38 rodadas e 380 jogos no mesmo save',()=>{
 const save=startBrazil(),b=save.serieB,all=b.rounds.flat(),ids=leagueTeams(b);
 assert.equal(ids.length,20);assert.equal(b.rounds.length,38);assert.equal(all.length,380);assert.equal(new Set(all.map(m=>m.id)).size,380);
 assert.ok(ids.every(id=>!BRAZIL_2026.some(c=>c.id===id)));assert.deepEqual([...ids].sort(),SERIE_B_2026.map(c=>c[0]).sort());
 for(const id of ids){assert.equal(all.filter(m=>m.home===id).length,19);assert.equal(all.filter(m=>m.away===id).length,19)}
 assert.ok(!save.league.rounds.flat().some(m=>all.some(x=>x.id===m.id)));assert.ok(validateSave(save));
});
test('treinar um clube da Série B usa o calendário da Série B; a rodada do universo reúne as duas divisões',()=>{
 const save=startBrazil();assert.equal(matchdayFixtures(save).length,20);
 save.team='sport';assert.ok(validateSave(save));assert.ok(currentFixtures(save).every(m=>m.id.startsWith('B-')));
 for(const f of [...save.league.rounds[0]])Object.assign(f,{played:true,hg:1,ag:0});afterResult(save.league);
 assert.ok(matchdayFixtures(save).every(m=>m.id.startsWith('B-')),'divisão atrasada joga primeiro');assert.equal(matchdayFixtures(save).length,10);
});
test('resumo da partida: linhas individuais somam exatamente as estatísticas oficiais do jogo',()=>{
 const [a,b]=clubTeams(),s=finishMatch(startMatch(a,b,'summary-seed',false,{recordReplay:false})),sum=summarizeMatch(s),lines=Object.values(sum.lines);
 const total=(key,team)=>lines.filter(l=>l.team===team).reduce((n,l)=>n+l[key],0);
 [a.id,b.id].forEach((team,i)=>{
  assert.equal(total('g',team),s.score[i]);assert.equal(total('sh',team),s.stats.shots[i]);assert.equal(total('sot',team),s.stats.onTarget[i]);
  assert.equal(total('pa',team),s.stats.passes[i]);assert.equal(total('pc',team),s.stats.completedPasses[i]);assert.equal(total('yc',team),s.stats.yellow[i]);assert.equal(total('rc',team),s.stats.red[i]);
  assert.equal(total('sv',team),s.stats.saves[i]);assert.equal(total('tk',team),s.stats.tackles[i]);assert.ok(Math.abs(total('xg',team)-s.stats.xG[i])<.011);
  assert.ok(total('min',team)<=11*90&&total('min',team)>=11*90-90*(s.stats.red[i]+1));
 });
 assert.ok(lines.every(l=>l.min>=1&&l.min<=90&&l.gp===1));
 assert.equal(sum.shots.length,s.stats.shots[0]+s.stats.shots[1]);assert.equal(sum.shots.filter(x=>x[5]===3).length,s.score[0]+s.score[1]);
 assert.ok(sum.shots.every(([m,side,x,y,xg])=>x>=0&&x<=100&&y>=0&&y<=100&&[0,1].includes(side)&&xg>0));
 assert.equal(sum.shots.filter(x=>x[5]===1).length,s.stats.saves[0]+s.stats.saves[1]);
 assert.deepEqual(sum.st.possession.reduce((x,y)=>x+y),100);
});
test('rodadas reais nas duas divisões: estatísticas acumuladas batem com os placares e o save fica compacto',()=>{
 const save=startBrazil();let played=0;
 for(let r=0;r<2;r++)for(const f of [...matchdayFixtures(save)]){play(save,f);played++}
 assert.equal(played,40);assert.ok(validateSave(save));
 const fixtures=[...save.league.rounds.flat(),...save.serieB.rounds.flat()].filter(m=>m.played),goals=fixtures.reduce((n,m)=>n+m.hg+m.ag,0);
 assert.equal(Object.values(save.stats.players).reduce((n,l)=>n+l.g,0),goals);
 assert.equal(playerRanking(save.stats,'g',{limit:500}).reduce((n,l)=>n+l.g,0),goals);
 const onlyB=new Set(leagueTeams(save.serieB));assert.ok(playerRanking(save.stats,'g',{teams:onlyB}).every(l=>onlyB.has(l.team)));
 assert.ok(fixtures.every(m=>m.st&&!m.coachLog&&m.st.possession[0]+m.st.possession[1]===100));
 const bytes=JSON.stringify(save).length/played;assert.ok(bytes<12000,`save usa ${Math.round(bytes)} bytes por jogo`);
 assert.deepEqual(JSON.parse(JSON.stringify(save)),save);
});
test('mata-mata de ida e volta: agregado empatado vai direto aos pênaltis, sem prorrogação',()=>{
 const [a,b]=clubTeams();
 for(let i=0,seen=0;i<40&&seen<2;i++){
  const plain=finishMatch(startMatch(a,b,'agg-'+i,false,{recordReplay:false})),[h,g]=plain.score,agg=h>=g?[0,h-g]:[g-h,0];
  const tied=finishMatch(startMatch(a,b,'agg-'+i,true,{recordReplay:false,aggregate:agg,noExtraTime:true}));
  assert.deepEqual(tied.score,plain.score,'agregado não altera o jogo');assert.equal(tied.tick,2700);assert.ok(tied.penalties&&tied.penalties[0]!==tied.penalties[1]);
  const ahead=finishMatch(startMatch(a,b,'agg-'+i,true,{recordReplay:false,aggregate:[agg[0]+1,agg[1]],noExtraTime:true}));
  assert.equal(ahead.penalties,null);assert.equal(ahead.tick,2700);seen++;
 }
});
test('temporada completa: playoff da Série B, acessos, rebaixamentos, histórico e calendário seguinte',()=>{
 const save=startBrazil();fill(save.league);fill(save.serieB);
 assert.equal(save.league.completed,true);assert.equal(seasonFinished(save),false,'playoff ainda pendente');
 const tableB=leagueTable(save.serieB),po=save.serieB.playoff;
 assert.deepEqual(po.pairs,[[tableB[2].code,tableB[5].code],[tableB[3].code,tableB[4].code]]);
 assert.deepEqual(po.legs[0].map(m=>[m.home,m.away]),[[tableB[5].code,tableB[2].code],[tableB[4].code,tableB[3].code]],'ida na casa do pior colocado');
 assert.equal(currentRound(save.serieB).number,39);assert.throws(()=>advanceSeason(save));
 assert.throws(()=>fixtureSetup(save,po.legs[1][0]),'volta exige a ida disputada');assert.equal(rulesFor('br-serie-b',2026).promotion.playoff.tied,'higherSeed');
 save.team=po.pairs[0][0];assert.equal(currentFixtures(save).length,2);
 for(const f of [...matchdayFixtures(save)])play(save,f);assert.equal(currentRound(save.serieB).number,40);
 for(const f of [...matchdayFixtures(save)])play(save,f);
 assert.equal(seasonFinished(save),true);assert.equal(po.winners.length,2);
 po.ties.forEach((t,i)=>{assert.ok(po.pairs[i].includes(t.winner));assert.equal(t.penalties,null,'playoff da Série B não tem pênaltis');assert.equal(t.home,po.pairs[i][0],'melhor campanha decide em casa');assert.equal(t.winner,t.aggregate[0]>=t.aggregate[1]?t.home:t.away,'agregado empatado classifica a melhor campanha')});
 assert.deepEqual(fixtureSetup(save,po.legs[1][0]),{knockout:false,options:{}});
 const tableA=leagueTable(save.league),o=seasonOutcome(save),goalsBefore=Object.values(save.stats.players).reduce((n,l)=>n+l.g,0);
 assert.deepEqual(o.relegatedA,tableA.slice(-4).map(r=>r.code));assert.deepEqual(o.promoted,[tableB[0].code,tableB[1].code,...po.winners]);assert.deepEqual(o.relegatedB,tableB.slice(-4).map(r=>r.code));
 assert.ok(goalsBefore>=0);
 const before=JSON.parse(JSON.stringify(save)),result=advanceSeason(save);
 assert.equal(save.season,2027);assert.equal(result.nextSeason,2027);
 const nextA=leagueTeams(save.league),nextB=leagueTeams(save.serieB);
 assert.equal(nextA.length,20);assert.equal(nextB.length,20);assert.ok(o.promoted.every(c=>nextA.includes(c)));assert.ok(o.relegatedA.every(c=>nextB.includes(c)));
 assert.ok(o.relegatedB.every(c=>!nextA.includes(c)&&!nextB.includes(c)));assert.ok(FEEDER_2026.every(c=>nextB.includes(c[0])));assert.deepEqual(save.pool,o.relegatedB);
 assert.equal(new Set([...nextA,...nextB,...save.pool]).size,44,'nenhum clube some nem se duplica');
 assert.ok([...save.league.rounds.flat(),...save.serieB.rounds.flat()].every(m=>!m.played&&m.id.includes('-2027-')&&m.date.startsWith('2027')));
 assert.equal(save.league.rounds.length,38);assert.equal(save.serieB.playoff,null);
 const h=save.history.at(-1);assert.equal(h.season,2026);assert.equal(h.A.champion,tableA[0].code);assert.equal(h.A.table.length,20);assert.deepEqual(h.A.table[0].slice(0,2),[tableA[0].code,tableA[0].pts]);
 assert.deepEqual(h.B.promoted,o.promoted);assert.equal(h.B.playoff.length,2);assert.deepEqual(h.A.rules,{id:'br-serie-a',season:2026,revision:2});
 assert.deepEqual(save.stats,{season:2027,players:{}});assert.deepEqual(save.archive,[]);
 assert.ok(nextA.includes(save.team)||nextB.includes(save.team));assert.ok(validateSave(save));assert.ok(validateSave(JSON.parse(JSON.stringify(save))));
 assert.equal(before.season,2026);assert.throws(()=>advanceSeason(save),'nova temporada ainda não terminou');
 // A temporada seguinte usa o regulamento herdado e continua jogável
 play(save,matchdayFixtures(save)[0]);assert.ok(validateSave(save));
});
test('clube controlado rebaixado da Série B para fora das divisões é substituído, sem save inválido',()=>{
 const save=startBrazil();fill(save.league);fill(save.serieB);for(let i=0;i<2;i++)for(const f of [...matchdayFixtures(save)])play(save,f);
 save.team=seasonOutcome(save).relegatedB[0];const r=advanceSeason(save);assert.equal(r.teamReassigned,true);assert.ok(validateSave(save));
});
test('save anterior à v0.8 migra: resultados preservados, Série B criada e relato compactado',()=>{
 const save=startBrazil(),[a,b]=[save.league.rounds[0][0].home,save.league.rounds[0][0].away],f=save.league.rounds[0][0];
 const s=finishMatch(startMatch(teams.get(a),teams.get(b),'legacy-v07',false,{recordReplay:false}));
 // Formato gravado pela v0.7.1: relato completo duplicado no confronto e no arquivo, sem Série B nem estatísticas.
 Object.assign(f,{played:true,hg:s.score[0],ag:s.score[1],penalties:null,scorers:{home:[],away:[]},coachLog:{events:s.events.filter(e=>!['pass','dribble'].includes(e.type)),shots:s.stats.shots,onTarget:s.stats.onTarget,passes:s.stats.passes}});
 const legacy={mode:'brasileirao',league:{kind:'league',year:2026,round:1,rounds:save.league.rounds,completed:false,champion:null},team:'flamengo',current:null,season:2026,archive:[{id:f.id,home:a,away:b,score:[...s.score],events:s.events.filter(e=>!['pass','dribble','cross'].includes(e.type)),replay:[]}]};
 const sizeBefore=JSON.stringify(legacy).length,migrated=migrateCoachSave(legacy),m=migrated.league.rounds[0][0];
 assert.equal(migrated.schema,3);assert.equal(leagueTeams(migrated.serieB).length,20);assert.equal(migrated.pool.length,4);assert.deepEqual([m.hg,m.ag],s.score);assert.equal(m.coachLog,undefined);
 assert.deepEqual(m.st.shots,s.stats.shots);assert.deepEqual(m.st.yellow,s.stats.yellow);
 assert.equal(Object.values(migrated.stats.players).reduce((n,l)=>n+l.g,0),s.score[0]+s.score[1]);assert.equal(migrated.stats.partial,true);
 assert.ok(migrated.archive[0].events.every(e=>['goal','card','injury','substitution'].includes(e.type)));
 assert.ok(JSON.stringify(migrated).length<sizeBefore+JSON.stringify(migrated.serieB).length,'migração não aumenta o relato');
 assert.equal(leagueTable(migrated.league).reduce((n,r)=>n+r.played,0),2);assert.equal(legacy.serieB,undefined,'original intacto');
 assert.deepEqual(migrateCoachSave(migrated),migrated,'migração é idempotente');
});
test('Copa: saves novos e antigos passam a acumular estatísticas individuais',()=>{
 const cup=startWorldCup();assert.equal(cup.schema,3);assert.ok(validateSave(cup));
 const old=startWorldCup();delete old.schema;delete old.stats;const m=migrateCoachSave(old);assert.equal(m.schema,3);assert.deepEqual(m.stats.players,{});
});
test('mandos de campo: ninguém joga mais de 3 partidas seguidas em casa ou fora e cada turno tem 9 ou 10 mandos',()=>{
 for(const league of [makeLeague(),makeLeague(SERIE_B_2026.map(c=>c[0]),2027,'B')]){
  assert.deepEqual(league.rounds[19].map(m=>[m.home,m.away]),league.rounds[0].map(m=>[m.away,m.home]),'returno inverte o turno');
  for(const id of leagueTeams(league)){let run=0,last=null,firstHalf=0;league.rounds.forEach((round,i)=>{const home=round.find(m=>m.home===id||m.away===id).home===id;if(i<19&&home)firstHalf++;run=home===last?run+1:1;last=home;assert.ok(run<=3,`${id}: ${run} mandos iguais seguidos`)});assert.ok(firstHalf===9||firstHalf===10)}
 }
 assert.deepEqual(makeLeague().rounds[0].slice(0,2).map(m=>[m.home,m.away]),[['atletico-mg','palmeiras'],['internacional','athletico-pr']],'primeira rodada divulgada preservada');
});
test('tokens de design: design/tokens.json espelha as variáveis CSS de treinador/style.css',()=>{
 const css=readFileSync(new URL('../treinador/style.css',import.meta.url),'utf8'),json=JSON.parse(readFileSync(new URL('../design/tokens.json',import.meta.url),'utf8')),root=css.match(/:root\{(--bg[^}]+)\}/)[1],vars=Object.fromEntries(root.split(';').map(x=>x.split(':')));
 let count=0;const walk=node=>{for(const [key,value] of Object.entries(node)){if(key.startsWith('$'))continue;if(value.$value){assert.equal(vars[value.$extensions.css],value.$value,key);count++}else walk(value)}};walk(json);
 assert.equal(count,Object.keys(vars).length,'todo token do CSS está no JSON');
});
test('assets 3D: manifesto do Blender corresponde aos GLB e .blend versionados, em escala de metros',()=>{
 const at=p=>new URL('../assets/3d/'+p,import.meta.url),m=JSON.parse(readFileSync(at('manifest.json'),'utf8'));
 assert.deepEqual(Object.keys(m.assets),['ball','goal','pitch','referee','player','corner_flag','stand_module','stand_module_lod1']);
 for(const a of Object.values(m.assets)){const glb=readFileSync(at(a.file));assert.equal(glb.toString('latin1',0,4),'glTF');assert.equal(glb.readUInt32LE(8),glb.length);assert.equal(glb.length,a.bytes);assert.ok(statSync(at(a.source)).size>1000);assert.ok(a.triangles>0&&a.triangles<5000);assert.ok(a.objects.every(n=>n.startsWith('FU_')));
  const json=JSON.parse(glb.toString('utf8',20,20+glb.readUInt32LE(12)));assert.ok(a.objects.every(n=>json.nodes.some(x=>x.name===n)),a.file+' contém os objetos nomeados')}
 const s=m.assets;assert.ok(Math.abs(s.ball.sizeMeters.z-.22)<.01);assert.ok(Math.abs(s.pitch.sizeMeters.x-115)<.01&&Math.abs(s.pitch.sizeMeters.y-78)<.01);assert.ok(s.goal.sizeMeters.y>7.32&&s.goal.sizeMeters.y<7.7&&s.goal.sizeMeters.z>2.44&&s.goal.sizeMeters.z<2.6);assert.ok(s.referee.sizeMeters.z>1.7&&s.referee.sizeMeters.z<1.9);
 const rig=JSON.parse((g=>g.toString('utf8',20,20+g.readUInt32LE(12)))(readFileSync(at('referee.glb'))));assert.equal(rig.skins.length,1);assert.equal(rig.skins[0].joints.length,11,'esqueleto de 11 ossos exportado');
 const kit=JSON.parse((g=>g.toString('utf8',20,20+g.readUInt32LE(12)))(readFileSync(at('player.glb'))));assert.ok(['FU_Player_Shirt','FU_Player_Shorts','FU_Player_Socks'].every(n=>kit.materials.some(x=>x.name===n)),'materiais de uniforme recoloríveis');assert.equal(kit.skins[0].joints.length,11);
 const view=readFileSync(new URL('../treinador/viewer.js',import.meta.url),'utf8');assert.ok(!/^import[^;]*renderer-25d/m.test(view)&&view.includes("import('./renderer-25d.js')"),'2.5D é carregado sob demanda e não entra no pacote de dist');
 assert.ok(s.stand_module_lod1.triangles<s.stand_module.triangles/5,'LOD1 é bem mais leve');
});
