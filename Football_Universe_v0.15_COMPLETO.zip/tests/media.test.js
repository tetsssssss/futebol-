import test from 'node:test';
import assert from 'node:assert/strict';
import {existsSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import {MEDIA_INDEX} from '../src/media-index.js';
import {faceFile,faceURL,badgeURL,kitURL,kitOf,mediaCounts} from '../src/media.js';
import {parseCSV,FICTIONAL_LEAGUES,FICTIONAL_CLUBS} from '../copa/data-loader.js';
import {resolveKits} from '../treinador/graphics.js';
import {photoURL} from '../treinador/photos.js';
import {crest} from '../treinador/league-views.js';
const asset=p=>fileURLToPath(new URL('../assets/'+p,import.meta.url));

test('índice de mídia: todo arquivo indexado existe em assets/', () => {
 for(const id of MEDIA_INDEX.faces.ea)assert.ok(existsSync(asset(`faces/ea/${id}.webp`)),`rosto SoFIFA ${id}`);
 for(const id of MEDIA_INDEX.faces.fifa)assert.ok(existsSync(asset(`faces/fifa/${id}.webp`)),`retrato FIFA ${id}`);
 for(const [player,file] of Object.entries(MEDIA_INDEX.faces.byPlayer))assert.ok(existsSync(asset(`faces/${file}.webp`)),`atleta ${player}`);
 for(const [id,t] of Object.entries(MEDIA_INDEX.teams)){if(t.b)assert.ok(existsSync(asset(`badges/${id}.webp`)),`escudo ${id}`);if(t.k)assert.ok(existsSync(asset(`kits/${id}.webp`)),`uniforme ${id}`)}
 assert.ok(mediaCounts().ea>0);
});

test('foto local tem prioridade; sem arquivo, cai nas regras antigas e no avatar', () => {
 const id=MEDIA_INDEX.faces.ea[0];
 assert.equal(faceFile({id:'ea-'+id}),'ea/'+id);
 assert.equal(faceFile({id:'x',photo:`https://cdn.sofifa.net/players/${String(id).padStart(6,'0').slice(0,3)}/${String(id).padStart(6,'0').slice(3)}/26_120.png`}),'ea/'+id);
 assert.match(photoURL({id:'ea-'+id},96),new RegExp(`faces/ea/${id}\\.webp$`));
 assert.equal(faceURL({id:'ea-1',photo:'https://cdn.sofifa.net/players/000/001/26_120.png'}),null);
 assert.equal(photoURL({id:'ea-1',photo:'https://cdn.sofifa.net/players/000/001/26_120.png'}),null);
 assert.equal(faceFile(null),null);
 const [club,file]=Object.entries(MEDIA_INDEX.faces.byPlayer)[0]||[];if(club)assert.equal(faceFile({id:club}),file);
});

test('liga brasileira da base EA é descartada: nomes e rostos gerados, não pessoas reais', () => {
 assert.ok(FICTIONAL_LEAGUES.has('Série A'));
 const csv='player_id,long_name,short_name,player_positions,nationality_name,league_name\n1,Pessoa Real,P. Real,ST,Argentina,Liga Profesional de Fútbol\n2,Nome Gerado,N. Gerado,ST,Brazil,Série A\n3,Italiano Real,I. Real,CM,Italy,Serie A\n';
 assert.deepEqual(parseCSV(csv).map(r=>r.player_id),['1','3']);
});

test('escudos e uniformes: usa o arquivo quando existe e a sigla colorida quando não existe', () => {
 const withBadge=Object.keys(MEDIA_INDEX.teams).find(id=>MEDIA_INDEX.teams[id].b);
 if(withBadge){assert.match(badgeURL(withBadge),/badges\/.+\.webp$/);assert.match(crest({id:withBadge,short:'ABC',color:'#112233'}),/<img src="[^"]*badges\//)}
 assert.equal(badgeURL('time-inexistente'),null);assert.equal(kitURL('time-inexistente'),null);
 const html=crest({id:'time-inexistente',short:'ABC',color:'#112233'});assert.doesNotMatch(html,/<img/);assert.match(html,/ABC/);
 assert.deepEqual(kitOf('time-inexistente','#123456'),{colors:['#123456','#123456'],pattern:'solid'});
});

test('uniformes em campo: camisas parecidas trocam a visitante pela cor secundária ou por um tom neutro', () => {
 const [home,away]=resolveKits([{color:'#d62e43',kit:{colors:['#d62e43','#111111'],pattern:'stripes'}},{color:'#d52d42',kit:{colors:['#d52d42','#ffffff'],pattern:'solid'}}]);
 assert.equal(home.pattern,'stripes');assert.equal(away.c1,'#ffffff');
 const [,neutral]=resolveKits([{color:'#2a4f9f'},{color:'#2c4fa0'}]);assert.equal(neutral.c1,'#f2e7bc');
 const [h2,a2]=resolveKits([{color:'#d62e43'},{color:'#2a4f9f'}]);assert.equal(h2.c1,'#d62e43');assert.equal(a2.c1,'#2a4f9f');
});
