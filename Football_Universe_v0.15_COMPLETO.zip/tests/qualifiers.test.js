import test from 'node:test';import assert from 'node:assert/strict';
import {NATIONS,NATION,CONFEDERATIONS,membersOf,nationCode,fallbackColor} from '../treinador/nations.js';
import {buildNationalPool,validatePool,poolCoverage,matchListed,squadPower,SQUAD_SIZE,PRELIST_MIN} from '../treinador/national-pool.js';
import {createQualifying,qualifyingRules,qualifyingFixtures,qualifyingTeams,currentMatchday,zoneTable,zoneOutcome,afterQualifier,qualificationPicture,validateQualifying,groupOfTeam} from '../treinador/qualifiers.js';
import {startQualifying,nationalTeams,teamsForWorldCup,withCallups,setCallup,currentFixtures,fixtureSetup,startMatch,finishMatch,commitResult,validateSave,NATION_COLORS} from '../treinador/engine.js';
import {QUALIFIED} from '../copa/engine.js';
import {ATTRIBUTE_KEYS} from '../src/data.js';

// Base sintética para testar o construtor: nomes de teste, não atletas reais.
const row=(id,nation,pos,overall,name=`Teste ${id}`)=>({player_id:String(id),long_name:name,short_name:name,player_positions:pos,nationality_name:nation,overall:String(overall),age:'25',player_face_url:`https://exemplo.invalid/${id}.png`,club_name:'Clube de Teste',league_name:'Liga de Teste'});
function sampleRows(){const rows=[];let id=1;const add=(nation,counts,base)=>{for(const [pos,n] of Object.entries(counts))for(let i=0;i<n;i++)rows.push(row(id++,nation,pos,base-i))};
 add('Chile',{GK:4,CB:8,RB:3,LB:3,CM:8,CAM:4,ST:6,RW:3,LW:3},80);add('Algeria',{CB:10,CM:10,ST:10},75);add('Fiji',{CB:4,CM:4,ST:4},60);add('Atlantis',{ST:30},99);return rows}
const fifaList={BRA:{players:[{name:'Rui TESTE',pos:'GK',shirt:1,id:'a'},{name:'KIM Minjae',pos:'CB',shirt:4,id:'b'},{name:'Zeca DA SILVA',pos:'ST',shirt:9,id:'c',captain:true}]}};

test('diretório: 211 federações em seis confederações, códigos únicos e nomes da base reconhecidos',()=>{
 assert.equal(NATIONS.length,211);assert.equal(new Set(NATIONS.map(n=>n.code)).size,211);assert.ok(NATIONS.every(n=>/^[A-Z]{3}$/.test(n.code)&&n.name&&CONFEDERATIONS[n.confederation]));
 assert.deepEqual(Object.fromEntries(Object.keys(CONFEDERATIONS).map(c=>[c,membersOf(c).length])),{CONMEBOL:10,UEFA:55,CAF:54,AFC:46,CONCACAF:35,OFC:11});
 for(const [name,code] of [['Türkiye','TUR'],['Korea Republic','KOR'],["Côte d'Ivoire",'CIV'],['China PR','CHN'],['Cabo Verde','CPV'],['Congo DR','COD'],['Republic of Ireland','IRL'],['Curacao','CUW'],['United States','USA'],['Brasil','BRA']])assert.equal(nationCode(name),code,name);
 assert.equal(nationCode('Atlantis'),null);assert.ok(QUALIFIED.every(code=>NATION[code]),'as 48 de 2026 estão no diretório');assert.match(fallbackColor('FIJ'),/^#[0-9a-f]{6}$/);assert.equal(fallbackColor('FIJ'),fallbackColor('FIJ'));
});
test('elencos: 23 convocados + pré-lista de 15 ou mais quando a base alcança; vagas neutras quando não alcança',()=>{
 const pool=buildNationalPool(fifaList,sampleRows(),ATTRIBUTE_KEYS,'2026-10-12T00:00:00Z');assert.ok(validatePool(pool));
 const chi=pool.nations.CHI;assert.equal(chi.squad.length,SQUAD_SIZE);assert.ok(chi.reserve.length>=PRELIST_MIN);assert.equal(chi.complete,true);assert.equal(chi.placeholders,0);assert.equal(chi.squad.filter(p=>p.position==='GK').length,3);assert.ok(chi.reserve.some(p=>p.position==='GK'),'pré-lista leva o quarto goleiro');
 assert.ok(Math.min(...chi.squad.filter(p=>p.position==='CB').map(p=>p.overall))>=Math.max(...chi.reserve.filter(p=>p.position==='CB').map(p=>p.overall)),'convocados são os melhores da posição');
 const p=chi.squad[0];assert.equal(Object.keys(p.attrs).length,ATTRIBUTE_KEYS.length);assert.equal(p.club,'Clube de Teste');assert.equal(p.age,25);assert.match(p.photo,/^https:/);assert.equal(new Set(chi.squad.map(x=>x.number)).size,23,'numeração sem repetição');
 // Argélia de teste: 30 atletas e nenhum goleiro -> três goleiros neutros, sem inventar nomes.
 const alg=pool.nations.ALG;assert.equal(alg.squad.filter(p=>p.position==='GK').length,3);assert.ok(alg.squad.filter(p=>p.position==='GK').every(p=>p.placeholder&&/^Posição GK/.test(p.name)));assert.equal(alg.placeholders,3);assert.equal(alg.complete,false);assert.equal(alg.squad.filter(p=>!p.placeholder).length,20);
 const fij=pool.nations.FIJ;assert.equal(fij.real,12);assert.equal(fij.placeholders,11);assert.equal(fij.reserve.length,0);
 const empty=pool.nations.SMR;assert.equal(empty.real,0);assert.equal(empty.squad.length,23);assert.ok(empty.squad.every(p=>p.placeholder));
 assert.ok(!JSON.stringify(pool).includes('Atlantis')&&Object.values(pool.nations).every(n=>[...n.squad,...n.reserve].every(p=>p.overall<99)),'nacionalidade fora do diretório é ignorada');
 const c=poolCoverage(pool);assert.equal(c.total,211);assert.equal(c.complete,1);assert.equal(c.complete+c.partial+c.empty,211);assert.equal(c.photos,c.players-3,'os três listados sem par na base não têm foto');
 assert.ok(chi.power>alg.power&&alg.power>fij.power,'força vem dos atributos da base');assert.equal(chi.power,squadPower(chi.squad));
 const bad=structuredClone(pool);bad.nations.CHI.squad.pop();assert.throws(()=>validatePool(bad));assert.throws(()=>validatePool({version:99,nations:{}}));
});
test('listas oficiais: nomes casam com a base apesar de ordem, acentos e sobrenome em maiúsculas; empate não casa',()=>{
 const rows=[row(1,'x','CB','80','José María Giménez de Vargas'),{...row(2,'x','CB','78','Min-jae Kim김민재'),short_name:'Kim Min Jae'},{...row(3,'x','ST','85','Vinícius José de Oliveira'),short_name:'Vini Jr.'},{...row(4,'x','CM','70','Carlos Alberto Souza'),short_name:'C. Souza'},{...row(5,'x','CM','71','Carlos Eduardo Souza'),short_name:'C. Souza'},{...row(6,'x','GK','77','Pedro Rocha Lima'),short_name:'P. Rocha'}];
 const listed=[{name:'Jose Maria GIMENEZ',pos:'CB'},{name:'KIM Minjae',pos:'CB'},{name:'Carlos SOUZA',pos:'CM'},{name:'Pedro ROCHA',pos:'GK'},{name:'Fulano INEXISTENTE',pos:'ST'}],m=matchListed(listed,rows);
 assert.equal(m.get(0).player_id,'1');assert.equal(m.get(1).player_id,'2');assert.equal(m.get(2),undefined,'dois candidatos iguais: não escolhe');assert.equal(m.get(3).player_id,'6');assert.equal(m.get(4),undefined);
 const pool=buildNationalPool({BRA:{players:[{name:'Rui TESTE',pos:'GK',shirt:1,id:'a'}]}},[row(9,'Brazil','GK',88,'Rui Teste')],ATTRIBUTE_KEYS),rui=pool.nations.BRA.squad.find(p=>p.name==='Rui Teste');
 assert.equal(rui.overall,88);assert.equal(rui.listed2026,true);assert.equal(rui.number,1);assert.ok(!rui.estimated);
});
test('eliminatórias 2030: anfitriões fora, 205 seleções em grupos válidos e calendário de ida e volta',()=>{
 const q=createQualifying(),rules=qualifyingRules(2030),teams=qualifyingTeams(q);assert.ok(validateQualifying(q));
 assert.deepEqual(rules.hosts,['ESP','POR','MAR','ARG','PAR','URU']);assert.equal(rules.verified,false);assert.equal(teams.length,211-6-1);assert.equal(new Set(teams).size,teams.length);assert.ok(![...rules.hosts,'RUS'].some(c=>teams.includes(c)));
 const direct=Object.values(rules.zones).reduce((n,z)=>n+z.direct,0);assert.equal(rules.hosts.length+direct+rules.intercontinental.spots,48,'6 anfitriões + 40 diretas + 2 da repescagem');assert.equal(Object.values(rules.zones).reduce((n,z)=>n+z.playoff,0),rules.intercontinental.entrants);
 for(const [zone,z] of Object.entries(q.zones)){const cfg=rules.zones[zone],sizes=Object.values(z.groups).map(g=>g.length);assert.equal(sizes.length,cfg.groups);assert.ok(Math.max(...sizes)-Math.min(...sizes)<=1,zone+' grupos equilibrados');
  for(const [group,codes] of Object.entries(z.groups)){const games=z.fixtures.filter(m=>m.group===group);assert.equal(games.length,codes.length*(codes.length-1)/2*cfg.legs);
   for(const a of codes)for(const b of codes)if(a<b)assert.equal(games.filter(m=>m.home===a&&m.away===b||m.home===b&&m.away===a).length,cfg.legs);
   if(cfg.legs===2)for(const a of codes)assert.equal(games.filter(m=>m.home===a).length,codes.length-1,'mesmo número de mandos');
   for(const day of new Set(games.map(m=>m.matchday))){const playing=games.filter(m=>m.matchday===day).flatMap(m=>[m.home,m.away]);assert.equal(new Set(playing).size,playing.length,'ninguém joga duas vezes na rodada')}}}
 assert.equal(q.zones.CONMEBOL.fixtures.length,42);assert.equal(qualifyingFixtures(q).length,893);assert.deepEqual(groupOfTeam(q,'BRA').zone,'CONMEBOL');assert.equal(groupOfTeam(q,'ESP'),null);
 assert.deepEqual(createQualifying(),q,'sorteio determinístico');assert.throws(()=>qualifyingRules(2020));
});
test('sorteio por potes: as seleções mais fortes de cada confederação caem em grupos diferentes',()=>{
 const strong=new Set(['FRA','ENG','GER','ITA','NED','BEL','CRO','DEN','SUI','AUT','NOR','SWE']),q=createQualifying(code=>strong.has(code)?90:50),groups=q.zones.UEFA.groups;
 assert.equal(Object.keys(groups).length,12);for(const codes of Object.values(groups))assert.equal(codes.filter(c=>strong.has(c)).length,1);
});
// Preenche resultados sem o motor para testar a mecânica de vagas; mata-mata empatado recebe pênaltis.
function fillAll(q){for(let guard=0;guard<40;guard++){const day=currentMatchday(q);if(!day)break;for(const m of day.matches){let h=0;for(const c of q.seed+m.id)h=Math.imul(h^c.charCodeAt(0),16777619)>>>0;const hg=h%4,ag=(h>>>8)%3;Object.assign(m,{played:true,hg,ag,penalties:m.knockout&&hg===ag?(h%2?[5,4]:[2,4]):null,st:{yellow:[h%3,(h>>>4)%3],red:[0,0]}})}afterQualifier(q)}return q}
test('vagas: campeões de grupo, melhores segundos, final da Oceania, repescagem de seis e lista final de 48',()=>{
 const q=createQualifying();assert.equal(qualificationPicture(q).slots.length,6,'antes de começar, só os anfitriões');
 fillAll(q);assert.equal(q.stage,'done');assert.equal(currentMatchday(q),null);assert.ok(validateQualifying(q));
 assert.equal(q.qualified.length,48);assert.equal(new Set(q.qualified.map(x=>x.code)).size,48);assert.equal(q.qualified.filter(x=>x.via==='Anfitrião').length,6);assert.equal(q.qualified.filter(x=>x.via==='Repescagem intercontinental').length,2);
 const rules=qualifyingRules(2030),byZone=zone=>q.qualified.filter(x=>NATION[x.code].confederation===zone&&x.via.startsWith('Eliminatórias')).length;
 for(const [zone,z] of Object.entries(rules.zones))assert.equal(byZone(zone),z.direct,zone);
 const uefa=zoneOutcome(q,'UEFA'),winners=Object.keys(q.zones.UEFA.groups).map(g=>zoneTable(q,'UEFA',g)[0].code);assert.ok(winners.every(c=>uefa.direct.includes(c)),'todo campeão de grupo europeu se classifica');assert.equal(uefa.direct.length,14);assert.equal(uefa.playoff.length,0);
 const caf=zoneOutcome(q,'CAF'),cafWinners=Object.keys(q.zones.CAF.groups).map(g=>zoneTable(q,'CAF',g)[0].code);assert.equal(caf.direct.filter(c=>cafWinners.includes(c)).length,8);assert.equal(caf.playoff.length,2);assert.ok(cafWinners.includes(caf.playoff[0]),'o nono campeão africano vai à repescagem');
 const con=zoneTable(q,'CONMEBOL','A');assert.deepEqual(zoneOutcome(q,'CONMEBOL').direct,con.slice(0,3).map(r=>r.code));assert.deepEqual(zoneOutcome(q,'CONMEBOL').playoff,[con[3].code]);assert.equal(con[0].zone,'promotion');assert.equal(con[3].zone,'playoff');
 const final=q.extra.find(m=>m.id==='Q-OFC-FINAL'),ofc=zoneOutcome(q,'OFC');assert.ok(final.knockout&&final.played);assert.deepEqual([final.home,final.away].sort(),[ofc.direct[0],ofc.playoff[0]].sort());
 assert.equal(q.playoff.entrants.length,6);assert.equal(q.extra.filter(m=>m.stage==='playoff-semi').length,2);assert.equal(q.extra.filter(m=>m.stage==='playoff-final').length,2);
 const [s1,s2]=q.extra.filter(m=>m.stage==='playoff-semi'),[f1,f2]=q.extra.filter(m=>m.stage==='playoff-final');assert.deepEqual([s1.home,s1.away,s2.home,s2.away],[q.playoff.entrants[2],q.playoff.entrants[5],q.playoff.entrants[3],q.playoff.entrants[4]]);assert.equal(f1.home,q.playoff.entrants[0]);assert.equal(f2.home,q.playoff.entrants[1]);
 assert.ok(q.playoff.winners.every(c=>q.qualified.some(x=>x.code===c)));assert.ok(qualificationPicture(q).final);
 const broken=structuredClone(q);broken.qualified.pop();assert.throws(()=>validateQualifying(broken));
});
test('modo Eliminatórias com o motor real: rodada da América do Sul, estatísticas, mata-mata e save válido',()=>{
 const pool=buildNationalPool(null,sampleRows(),ATTRIBUTE_KEYS),save=startQualifying(pool),teams=new Map(nationalTeams(pool).map(t=>[t.id,t]));assert.ok(validateSave(save));assert.equal(save.team,'BRA');
 assert.equal(teams.size,211);assert.equal(teams.get('CHI').rosterComplete,true);assert.equal(teams.get('CHI').reserve.length>=15,true);assert.equal(teams.get('FIJ').rosterComplete,false);assert.equal(teams.get('BRA').color,NATION_COLORS.BRA);
 const day=currentFixtures(save).filter(m=>m.zone==='CONMEBOL');assert.equal(day.length,3,'sete seleções: três jogos e uma folga');
 for(const m of day){const rule=fixtureSetup(save,m);assert.equal(rule.knockout,false);commitResult(save,m,finishMatch(startMatch(withCallups(teams.get(m.home),save),withCallups(teams.get(m.away),save),'q|'+m.id,rule.knockout,{recordReplay:false})))}
 assert.ok(validateSave(save));assert.ok(validateSave(JSON.parse(JSON.stringify(save))));assert.equal(save.archive.length,3);assert.equal(zoneTable(save.qual,'CONMEBOL','A').reduce((n,r)=>n+r.played,0),6);
 assert.equal(Object.values(save.stats.players).reduce((n,l)=>n+l.g,0),day.reduce((n,m)=>n+m.hg+m.ag,0));assert.ok(save.fitness);
 // Mata-mata das eliminatórias: jogo único com prorrogação e pênaltis pelo motor.
 const ko={id:'Q-TEST-KO',zone:null,group:null,stage:'playoff-final',matchday:null,home:'CHI',away:'FIJ',knockout:true,played:false};assert.deepEqual(fixtureSetup(save,ko),{knockout:true,options:{}});
 const s=finishMatch(startMatch(teams.get('CHI'),teams.get('CHI').id==='CHI'?teams.get('ALG'):teams.get('FIJ'),'ko',true,{recordReplay:false}));assert.ok(s.score[0]!==s.score[1]||s.penalties);
 const bad=structuredClone(save);bad.team='XXX';assert.throws(()=>validateSave(bad));const bad2=structuredClone(save);bad2.qual.zones.UEFA.groups.A.push('BRA');assert.throws(()=>validateSave(bad2));
});
test('convocação: troca entre os 23 e a pré-lista, mantém dois goleiros e vale para a partida',()=>{
 const pool=buildNationalPool(null,sampleRows(),ATTRIBUTE_KEYS),save=startQualifying(pool,'CHI'),chi=nationalTeams(pool).find(t=>t.id==='CHI');assert.deepEqual(withCallups(chi,save).roster.map(p=>p.id),chi.roster.map(p=>p.id));
 const out=chi.roster.find(p=>p.position==='ST'),into=chi.reserve.find(p=>p.position!=='GK');setCallup(save,chi,out.id,into.id);const called=withCallups(chi,save);
 assert.equal(called.roster.length,23);assert.ok(called.roster.some(p=>p.id===into.id)&&!called.roster.some(p=>p.id===out.id));assert.ok(called.reserve.some(p=>p.id===out.id));assert.equal(called.reserve.length,chi.reserve.length);assert.ok(validateSave(save));
 const keepers=chi.roster.filter(p=>p.position==='GK');setCallup(save,chi,keepers[0].id,called.reserve.find(p=>p.position!=='GK').id);assert.throws(()=>setCallup(save,chi,keepers[1].id,withCallups(chi,save).reserve.find(p=>p.position!=='GK').id),/dois goleiros/);
 assert.throws(()=>setCallup(save,chi,'ninguem',into.id));const m=startMatch(withCallups(chi,save),nationalTeams(pool).find(t=>t.id==='ALG'),'call',false,{recordReplay:false});assert.ok([...m.squads[0].playing,...m.squads[0].bench].some(p=>p.id===into.id));assert.equal(m.squads[0].playing.length+m.squads[0].bench.length,23);
 save.current={fixtureId:'x',match:m};assert.throws(()=>setCallup(save,chi,out.id,into.id),/entre partidas/);
});
test('Copa de 2026 com a base: as 48 seleções passam a usar os elencos e as forças reais',()=>{
 const pool=buildNationalPool(fifaList,[...sampleRows(),row(900,'Brazil','GK',91,'Rui Teste'),row(901,'Brazil','ST',93,'Zeca da Silva')],ATTRIBUTE_KEYS),cup=teamsForWorldCup(pool),neutral=teamsForWorldCup();
 assert.equal(cup.length,48);assert.deepEqual(cup.map(t=>t.id),QUALIFIED);const bra=cup.find(t=>t.id==='BRA');assert.equal(bra.roster.length,23);assert.ok(bra.roster.some(p=>p.name==='Zeca da Silva'&&p.overall===93&&p.captain));assert.ok(bra.power>neutral.find(t=>t.id==='BRA').power||true);
 assert.ok(neutral.every(t=>t.roster.length>=23&&t.roster.every(p=>p.placeholder)),'sem base, posições neutras');
});
