import test from 'node:test';import assert from 'node:assert/strict';
import {createInitialWorld,ATTRIBUTE_KEYS,ATTRIBUTE_GROUPS} from '../src/data.js';
import {packWorld,unpackWorld,validateWorld,scorePlayer,playerPotential,mutateAttribute,observe,advanceWeek,lineup,tacticalScore,formationSlots,standings,simulateFixture,migrateWorld,updateClub,updatePlayerIdentity,validDate,makeLeagueSchedule,completeSeason,cancelObservation,setIndividualTraining,rescheduleFixture,SCOUT_COST} from '../src/core.js';
test('70 atributos únicos em 11 grupos, todos definidos para os atletas reais dos 20 clubes',()=>{
 const world=createInitialWorld();assert.equal(ATTRIBUTE_KEYS.length,70);assert.equal(new Set(ATTRIBUTE_KEYS).size,70);assert.equal(ATTRIBUTE_GROUPS.length,11);assert.ok(world.players.length>=600&&world.players.length<=800);assert.equal(world.clubs.length,20);
 for(const p of world.players){assert.equal(Object.keys(p.attrs).length,70);for(const val of Object.values(p.attrs))assert.ok(Number.isInteger(val)&&val>=0&&val<=100)}assert.equal(validateWorld(world),true);
});
test('formações de 11 atletas sem duplicação de IDs',()=>{const world=createInitialWorld();for(const formation of ['4-2-3-1','4-3-3','3-5-2']){world.tactics.flamengo.formation=formation;const l=lineup(world,'flamengo');assert.equal(l.length,11);assert.equal(new Set(l.map(x=>x.player?.id)).size,11);assert.equal(formationSlots(formation).length,11);assert.ok(tacticalScore(world,'flamengo')>0)}});
test('edição modifica estado e recalcula avaliação contextual',()=>{const world=createInitialWorld(),p=world.players.find(p=>p.position==='ST');const before=scorePlayer(p);const prev=p.attrs.finishing;mutateAttribute(world,p.id,'finishing',Math.min(prev+10,100));assert.ok(scorePlayer(p)>=before);assert.equal(world.log[0].type,'editor');assert.equal(validateWorld(world),true);assert.throws(()=>mutateAttribute(world,p.id,'finishing',999));});
test('scouting revela atributos só ao atingir 21 dias',()=>{const world=createInitialWorld(),p=world.players.find(p=>p.clubId==='palmeiras');assert.equal(p.scoutDays,0);observe(world,p.id);assert.equal(p.scoutDays,0);advanceWeek(world);assert.equal(p.scoutDays,7);advanceWeek(world);advanceWeek(world);assert.equal(p.scoutDays,21);assert.equal(world.scoutReports.length,3);assert.equal(world.scoutAssignments.length,0)});
test('avanço semanal resolve jogos fictícios com causalidade e registra resultados',()=>{const world=createInitialWorld(),initial=world.date;world.tactics.flamengo.pressing=88;const old=world.players[0].condition;advanceWeek(world);assert.notEqual(world.date,initial);assert.equal(world.week,1);assert.ok(world.players[0].condition<=100);assert.equal(world.fixtures[0].status,'finalizado');assert.equal(world.fixtures.filter(f=>f.status==='finalizado').length,10);assert.equal(standings(world).reduce((n,r)=>n+r.played,0),20);assert.ok(world.news.some(n=>n.type==='treino'));assert.equal(validateWorld(world),true);});
test('backup serializado preserva estado do universo',()=>{const w=createInitialWorld();mutateAttribute(w,w.players[0].id,'reflexes',87);const backup=JSON.parse(JSON.stringify(w));assert.equal(validateWorld(backup),true);assert.equal(backup.players[0].attrs.reflexes,87);assert.ok(playerPotential(w.players[1])>=scorePlayer(w.players[1]));});

test('calendário valida dias reais e unicidade referencial',()=>{
 const w=createInitialWorld();assert.equal(validDate('2026-02-31'),false);assert.equal(validDate('2028-02-29'),true);
 w.clubs[1].id=w.clubs[0].id;assert.throws(()=>validateWorld(w),/duplicado/);
 const w2=createInitialWorld();w2.fixtures[0].date='2026-02-31';assert.throws(()=>validateWorld(w2),/Compromisso/);
 const w3=createInitialWorld();w3.fixtures[1].id=w3.fixtures[0].id;assert.throws(()=>validateWorld(w3),/duplicado/);
 const w4=createInitialWorld();w4.fixtures[1].home='flamengo';assert.throws(()=>validateWorld(w4),/duas vezes/);
});
test('migração de backup v1 para v2 não inventa resultados',()=>{
 const legacy=createInitialWorld();legacy.schemaVersion=1;delete legacy.training;delete legacy.scoutQuality;
 const newer=migrateWorld(JSON.parse(JSON.stringify(legacy)));
 assert.equal(newer.schemaVersion,3);assert.equal(newer.training.focus,'Condicionamento');assert.equal(newer.fixtures.length,380);assert.ok(newer.fixtures.every(f=>f.status==='agendado'));
 assert.equal(validateWorld(newer),true);assert.throws(()=>migrateWorld({...legacy,schemaVersion:33}));
});
test('partidas são determinísticas, contabilizadas e idempotentes',()=>{
 const a=createInitialWorld(),b=createInitialWorld();const f=a.fixtures[0];simulateFixture(a,f);simulateFixture(b,b.fixtures[0]);
 assert.deepEqual(f,b.fixtures[0]);assert.ok(f.stats.home.shots>=4);assert.equal(f.events.length,f.homeGoals+f.awayGoals);
 assert.equal(a.players.reduce((n,p)=>n+p.stats.appearances,0)-createInitialWorld().players.reduce((n,p)=>n+p.stats.appearances,0),22);
 const before=JSON.stringify(a);simulateFixture(a,f);assert.equal(JSON.stringify(a),before);
 assert.equal(standings(a).reduce((n,r)=>n+r.points,0),f.homeGoals===f.awayGoals?2:3);
 assert.equal(validateWorld(a),true);
});
test('editor altera fichas e clubes sem corromper dados ao rejeitar entrada',()=>{
 const w=createInitialWorld(),pid=w.players[0].id;updatePlayerIdentity(w,pid,{name:'João Atualizado',number:'77',contractEnd:'2028-06-30',wage:'9500'});
 assert.equal(w.players[0].name,'João Atualizado');assert.equal(w.players[0].number,77);
 updateClub(w,'flamengo',{name:'Aurora Novo',budget:'2500000'});assert.equal(w.clubs.find(c=>c.id==='flamengo').budget,2500000);
 const snapshot=JSON.stringify(w);assert.throws(()=>updatePlayerIdentity(w,pid,{contractEnd:'2026-02-31'}));assert.equal(JSON.stringify(w),snapshot);
 assert.throws(()=>updateClub(w,'flamengo',{budget:-300}));assert.equal(JSON.stringify(w),snapshot);
 assert.equal(validateWorld(w),true);
});
test('carga e foco de treino alteram atributos e recuperação',()=>{
 const a=createInitialWorld(),b=createInitialWorld();a.training={...a.training,focus:'Ataque',intensity:'Alta'};b.training={...b.training,focus:'Defesa',intensity:'Leve'};
 const p=a.players.find(x=>x.clubId==='flamengo'&&x.position!=='GK'&&x.age<=27&&x.attrs.professionalism>=55).id;for(let i=0;i<6;i++){advanceWeek(a);advanceWeek(b)}
 const pa=a.players.find(p1=>p1.id===p),pb=b.players.find(p1=>p1.id===p);
 assert.notEqual(pa.attrs.finishing,pb.attrs.finishing);assert.ok(pa.condition<=pb.condition);assert.equal(a.fixtures.filter(f=>f.status==='finalizado').length,60);
 assert.equal(validateWorld(a),true);
});
test('scouting limita observações simultâneas e preserva progressão',()=>{
 const w=createInitialWorld(),r=w.players.filter(p=>p.clubId==='palmeiras').slice(0,4);
 for(const p of r.slice(0,3))observe(w,p.id);assert.throws(()=>observe(w,r[3].id),/Capacidade/);
 advanceWeek(w);assert.equal(w.scoutAssignments.length,3);assert.ok(w.scoutReports.every(x=>x.quality===72));
});

test('táticas alteram volume de chances na mesma partida, sob mesma semente',()=>{
 const a=createInitialWorld(),b=createInitialWorld(),home=a.fixtures[0].home;a.tactics[home].pressing=0;b.tactics[home].pressing=100;
 simulateFixture(a,a.fixtures[0]);simulateFixture(b,b.fixtures[0]);
 assert.ok(a.fixtures[0].stats.home.shots<b.fixtures[0].stats.home.shots);
});
test('seis partidas geram campeonato coerente, com empate calculado corretamente',()=>{
 const w=createInitialWorld();for(let i=0;i<6;i++)advanceWeek(w);
 assert.equal(w.fixtures.filter(f=>f.status==='finalizado').length,60);
 const table=standings(w);assert.equal(table.length,20);assert.ok(table.every(r=>r.played===6));
 assert.equal(table.reduce((n,r)=>n+r.gf,0),table.reduce((n,r)=>n+r.ga,0));
 assert.equal(table.reduce((n,r)=>n+r.won,0),table.reduce((n,r)=>n+r.lost,0));
 assert.equal(validateWorld(w),true);
 const done=new Map(w.fixtures.filter(f=>f.status==='finalizado').map(f=>[f.id,JSON.stringify(f)]));
 advanceWeek(w);for(const f of w.fixtures)if(done.has(f.id))assert.equal(JSON.stringify(f),done.get(f.id),'resultado já disputado não muda');
});


test('liga de 4 e 6 clubes gera ida/volta sem datas duplicadas',()=>{
 for(const n of [4,6]){const ids=Array.from({length:n},(_,i)=>`clube-${i}`),fixtures=makeLeagueSchedule(ids,2027,'2027-01-09');
  assert.equal(fixtures.length,n*(n-1));const key=new Set(fixtures.map(f=>`${f.home}:${f.away}`));assert.equal(key.size,fixtures.length);
  const days=new Set();for(const f of fixtures)for(const club of [f.home,f.away]){const k=f.date+club;assert.equal(days.has(k),false);days.add(k);}}
});
test('temporada completa é arquivada com campeão, artilheiros e preserva temporada seguinte',()=>{
 const w=createInitialWorld();assert.throws(()=>completeSeason(w),/Encerre/);
 for(let i=0;i<38;i++)advanceWeek(w);
 assert.equal(w.fixtures.filter(f=>f.status==='finalizado').length,380);
 const winner=standings(w)[0].clubId,goals=w.fixtures.reduce((a,f)=>a+f.events.length,0);completeSeason(w);
 assert.equal(w.season,2027);assert.equal(w.seasonHistory.length,1);assert.equal(w.seasonHistory[0].championId,winner);
 assert.equal(w.seasonHistory[0].fixtures.length,380);assert.equal(w.seasonHistory[0].leaders.reduce((a,x)=>a+x.goals,0)<=goals,true);
 assert.equal(w.fixtures.length,380);assert.ok(w.fixtures.every(f=>f.status==='agendado'));assert.equal(w.players[0].history[0].year,2026);
 assert.equal(validateWorld(JSON.parse(JSON.stringify(w))),true);
 for(let i=0;i<38;i++)advanceWeek(w);completeSeason(w);assert.equal(w.seasonHistory.length,2);assert.equal(new Set(w.seasonHistory.map(s=>s.season)).size,2);
});
test('observações têm custo, podem ser canceladas e não permitem saldo negativo',()=>{
 const w=createInitialWorld(),p=w.players.find(p=>p.clubId==='palmeiras'),own=w.clubs.find(c=>c.id===w.clubId);const budget=own.budget;
 observe(w,p.id);assert.equal(own.budget,budget-SCOUT_COST);assert.equal(w.scoutAssignments.length,1);
 cancelObservation(w,p.id);assert.equal(w.scoutAssignments.length,0);assert.equal(own.budget,budget-SCOUT_COST);
 own.budget=1;assert.throws(()=>observe(w,p.id),/Orçamento/);assert.equal(w.scoutAssignments.length,0);
 assert.equal(validateWorld(w),true);
});
test('treino individual orienta desenvolvimento e configurações inválidas são rejeitadas',()=>{
 const w=createInitialWorld(),p=w.players.find(p=>p.clubId==='flamengo'&&p.position!=='GK'&&p.age<=27&&p.attrs.professionalism>=55);setIndividualTraining(w,p.id,'Ataque');assert.equal(w.training.individual[p.id],'Ataque');
 assert.throws(()=>setIndividualTraining(w,p.id,'Inexistente'));
 assert.throws(()=>setIndividualTraining(w,w.players.find(x=>x.clubId==='palmeiras').id,'Defesa'));
 for(let i=0;i<6;i++)advanceWeek(w);assert.ok(p.attrs.finishing>=createInitialWorld().players.find(x=>x.id===p.id).attrs.finishing);
 setIndividualTraining(w,p.id,'Padrão');assert.ok(!(p.id in w.training.individual));assert.equal(validateWorld(w),true);
});
test('editor de calendário rejeita colisões e respeita partidas disputadas',()=>{
 const w=createInitialWorld(),start=JSON.stringify(w),match=w.fixtures[0];
 assert.throws(()=>rescheduleFixture(w,match.id,'2026-02-31'));
 assert.ok(w.fixtures.some(f=>f.date==='2026-10-17'&&(f.home===match.home||f.away===match.home)));assert.throws(()=>rescheduleFixture(w,match.id,'2026-10-17'),/duas vezes/);
 assert.equal(JSON.stringify(w),start);rescheduleFixture(w,match.id,'2026-10-11');assert.equal(match.date,'2026-10-11');
 advanceWeek(w);assert.throws(()=>rescheduleFixture(w,match.id,'2027-11-19'),/futuros/);assert.equal(validateWorld(w),true);
});
test('migração v2 preserva resultados e adiciona apenas o returno pendente',()=>{
 const old=createInitialWorld();old.fixtures=old.fixtures.slice(0,190);old.schemaVersion=2;delete old.training.individual;delete old.seasonHistory;
 simulateFixture(old,old.fixtures[0]);const snapshot=structuredClone(old.fixtures[0]);
 const migrated=migrateWorld(old);assert.equal(migrated.schemaVersion,3);assert.equal(migrated.fixtures.length,380);assert.deepEqual(migrated.fixtures[0],snapshot);
 assert.equal(migrated.fixtures.filter(f=>f.status==='finalizado').length,1);assert.equal(validateWorld(migrated),true);
});

test('resistência de estado: 10 temporadas de 38 rodadas permanecem serializáveis e consistentes',()=>{
 const world=createInitialWorld();for(let year=0;year<10;year++){
  for(let week=0;week<38;week++)advanceWeek(world);
  completeSeason(world);
 }
 assert.equal(world.season,2036);assert.equal(world.seasonHistory.length,10);
 assert.equal(new Set(world.seasonHistory.map(h=>h.season)).size,10);
 assert.equal(validateWorld(JSON.parse(JSON.stringify(world))),true);
 assert.ok(JSON.stringify(world).length<5_000_000,'O estado individual deveria caber em um save JSON de até 5 MB nesta demonstração.');
});
test('gol adulterado e arquivo histórico inconsistente são rejeitados',()=>{
 const w=createInitialWorld();simulateFixture(w,w.fixtures[0]);w.fixtures[0].homeGoals+=1;
 assert.throws(()=>validateWorld(w),/Resultado incompleto/);
 const another=createInitialWorld();another.seasonHistory=[{season:2026,championId:'flamengo',dateFinished:'2026-11-20',table:[],fixtures:[]}];
 assert.throws(()=>validateWorld(another),/Arquivo de temporada/);
});

test('v0.14: 20 clubes da Série A, elencos do Transfermarkt e procedência dos atributos declarada',()=>{
 const w=createInitialWorld();
 assert.equal(w.clubs.length,20);assert.equal(new Set(w.clubs.map(c=>c.id)).size,20);
 assert.ok(w.clubs.every(c=>c.verifiedRosterSource.startsWith('https://')&&/^#[0-9a-f]{6}$/i.test(c.colors[0])));
 for(const c of w.clubs){const sq=w.players.filter(p=>p.clubId===c.id);assert.ok(sq.length>=18,c.id);assert.ok(sq.some(p=>p.position==='GK'),c.id)}
 assert.ok(w.players.every(p=>p.dataProvenance.identity==='verified'&&['ea-fifa-evoluido','estimado-valor-de-mercado'].includes(p.dataProvenance.abilities)));
 const real=w.players.filter(p=>p.dataProvenance.abilities==='ea-fifa-evoluido').length;assert.ok(real>=250&&real<w.players.length,'parte dos atletas tem avaliação real; o resto é estimado e declarado');
 assert.ok(w.players.every(p=>p.born&&p.age>=15&&(p.height===null||p.height>=150)&&p.value>=0));
 for(const [name,club] of [['Lucas Paquetá','flamengo'],['Vitor Roque','palmeiras'],['Memphis Depay','corinthians'],['Jonathan Calleri','sao-paulo']])assert.ok(w.players.find(p=>p.name===name&&p.clubId===club),name);
 assert.equal(w.fixtures.length,380);assert.ok(w.fixtures.every(f=>f.competition.includes('simulador')));
 assert.equal(validateWorld(w),true);
});
test('v0.14: 38 rodadas por clube, 19 jogos em casa e 19 fora, sem confronto repetido',()=>{
 const w=createInitialWorld();assert.equal(new Set(w.fixtures.map(f=>f.date)).size,38);
 for(const c of w.clubs){assert.equal(w.fixtures.filter(f=>f.home===c.id).length,19);assert.equal(w.fixtures.filter(f=>f.away===c.id).length,19)}
 assert.equal(new Set(w.fixtures.map(f=>f.home+':'+f.away)).size,380);
});
test('v0.14: a avaliação mostrada bate com a registrada e os elencos mais caros são mais fortes',()=>{
 const w=createInitialWorld(),power=id=>lineup(w,id).reduce((s,x)=>s+scorePlayer(x.player),0)/11;
 const ranking=w.clubs.map(c=>[c.id,power(c.id)]).sort((a,b)=>b[1]-a[1]);
 assert.ok(ranking[0][1]-ranking.at(-1)[1]>=4,'elencos mais caros devem ser mais fortes');
 for(const p of w.players){const sc=scorePlayer(p);assert.ok(Math.abs(sc-p.overall)<=6,p.name+' '+sc+' vs '+p.overall)}
});

test('v0.14: slots guardam os atributos em lista e restauram o save idêntico',()=>{
 const w=createInitialWorld();advanceWeek(w);const packed=packWorld(w);
 assert.ok(Array.isArray(packed.players[0].attrs));assert.ok(JSON.stringify(packed).length<JSON.stringify(w).length*.8);
 assert.deepEqual(unpackWorld(JSON.parse(JSON.stringify(packed))),w);assert.equal(unpackWorld(w),w);
});
