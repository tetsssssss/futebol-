# Changelog

## 0.15.x — 2026-10-24 · Transmissão visual das partidas

- O modo carreira/competição passa a iniciar partidas com campo 2.5D, modelos tridimensionais de atletas/bola, HUD, nomes/números e escolha de câmeras de transmissão, tática ou bola. A visualização 2D permanece selecionável.
- A preferência visual, câmera, zoom e exibição de nomes são guardados no navegador, sem alterar saves nem resultados.
- Se WebGL ou a CDN do Babylon.js falharem, a partida continua em Canvas 2D sem bloquear os controles.
- O build portátil agora copia `assets/3d` junto com as páginas de `dist`.
- **Limite:** personagens ainda não têm animações de caminhada ou contato; o modo 2.5D usa modelos low-poly e requer WebGL.
- Testes: `tests/visual-preferences.test.js`, suíte `npm run test:all` e QA de navegador.

## 0.15.x — 2026-10-24 · Catálogo de competições globais de clubes

- Adicionado o campo de 32 clubes e o sorteio oficial dos grupos do Mundial de Clubes FIFA 2025, incluindo país, confederação, caminho de qualificação e distribuição de vagas.
- O catálogo de 2029 registra sete clubes que a FIFA já confirmou como classificados até esta data; não define distribuição de vagas ainda não anunciada nem preenche clubes pendentes.
- Registrada a Copa Intercontinental FIFA 2026 com seis vagas, cinco clubes confirmados, placares conhecidos e três jogos finais agendados.
- Registradas as nove fases e contagem de 155 partidas da Copa do Brasil 2026, seus quatro semifinalistas e data prevista da final; a Supercopa Rei (Corinthians campeão) e a Recopa CONMEBOL (Lanús campeão) incluem seus participantes e formatos/resultados.
- **Limite:** catálogo arquitetural consultável/testável, não uma integração dessas competições às telas/calendários jogáveis do Modo Treinador. O campo internacional também não inclui plantéis de atletas.
- Teste: `architecture/world/tests/global-club-competitions.test.mjs`.

## 0.15.0 — 2026-10-13 · Brasileirão com os 20 clubes reais, 38 rodadas e atributos derivados de dados reais

- **Série A completa no Manager**: os 20 clubes de 2026, 673 atletas e as 380 partidas (38 rodadas, ida e volta, 19 mandos por clube; `src/schedule.js`). Antes eram 4 clubes, 107 atletas e 12 jogos. Elencos, números, nascimento, altura, pé, contrato e valor de mercado vêm do Transfermarkt (`data/tm-squads-2026.json`, coleta de 13/10/2026); estádio e escudo/uniforme por clube.
- **Atributos deixam de ser sintéticos.** Cada atleta registra a origem (`dataProvenance.abilities`):
  - **283 atletas (42%)** têm avaliação real do EA/FIFA (edição mais recente em que aparecem, FIFA 16 a 23; `tools/extract-ea-history.mjs`, casamento por nascimento + nacionalidade + nome). O perfil daquela edição é evoluído até 2026 pela idade e o potencial, e combinado (55/45) com a avaliação que o valor de mercado atual indica.
  - **390 atletas (58%)** não têm avaliação publicada (a base EA FC 26 gera nomes fictícios para o Brasileirão): a avaliação sai do valor de mercado, da idade e da posição por uma curva ajustada em 18 mil atletas do EA FC 26, e o perfil segue a função em campo.
  - Em todos, a avaliação mostrada pelo app bate com a registrada (calibração dos atributos de jogo) e os atributos comportamentais (ambição, lealdade, carisma…) continuam estimados: não existe dado público sobre eles.
- **Fotos**: 647 dos 673 com retrato do Transfermarkt (`tools/fetch-brasileirao-faces.mjs`); os outros 26 (na maioria categorias de base sem foto em fonte alguma) ficam com avatar. Procedência em `data/media-sources.json`.
- **Kits e escudos** das 20 equipes vêm do cadastro de mídia da v0.14.0; as cores do clube no Manager são as do uniforme titular.
- **Força do elenco** (11 titulares): Flamengo 78, Palmeiras 77, Cruzeiro 77, Corinthians 76, Santos 76 … Chapecoense 67, Remo 68 — coerente com o valor de mercado de cada plantel.
- **Treinador 2D** passa a usar os mesmos elencos: os 20 clubes da Série A deixam de ter posições neutras (restam as da Série B e os 80 clubes estrangeiros).
- **Saves**: com 673 atletas, o mundo inicial passa de 150 KB para ~1,5 MB. Os slots guardam os 70 atributos como lista (`packWorld`/`unpackWorld`, ~1 MB), o arquivo de temporada guarda só placar e gols, e notícias/registro ficam limitados às últimas 500/800 entradas. Dez temporadas completas cabem em ~3,3 MB.
- `src/attributes.js` (catálogo dos 70 atributos) separado de `src/data.js`; `data/old-player-ids.json` mantém os ids antigos (flamengo-p1…) dos 107 atletas que já existiam.
- Testes: núcleo do Manager atualizado para 20 clubes/38 rodadas e 3 novos (`tests/core.test.js`); 133 passam.

**Limites:** treinadores só estão cadastrados para Flamengo e Palmeiras (os demais aparecem como "A confirmar"); salários não existem em fonte aberta e ficam "Não verificado"; o calendário e os confrontos são gerados pelo simulador, não a tabela oficial da CBF; o elenco é o que o Transfermarkt lista em 13/10/2026 (inclui base promovida); a Série B ainda não tem elencos; saves antigos de 4 clubes continuam abrindo como estavam — para jogar com os 20 clubes, crie um novo universo.

## 0.14.0 — 2026-10-13 · Mídia: fotos originais, escudos e uniformes

- **Fotos locais.** O bloqueio da SoFIFA só vale para o navegador; baixando com o cabeçalho do próprio site, os rostos vêm normalmente. `tools/fetch-faces.mjs` guarda tudo em `assets/faces` (WebP, ~120 px; ~3,5 KB cada): 2.551 rostos EA FC 26/SoFIFA, 1.147 retratos oficiais das listas da Copa e 101+ atletas de clubes. `src/media.js` resolve a foto local pelo id/URL do atleta e o app só pede arquivos que existem no índice (`src/media-index.js`, gerado).
- **Segunda rodada** (`tools/fetch-faces-extra.mjs`) para quem a SoFIFA não tem: TheSportsDB (82), Wikipédia/Commons (9) e, em conferência manual de nome + clube/nacionalidade, Transfermarkt (56, `data/media-overrides.json` aplicado por `tools/apply-face-overrides.mjs`). Procedência de cada foto extra em `data/media-sources.json`. Três homônimos que entraram pela Wikipédia (João Pedro do Chelsea, André Silva do Porto, Pedro Ferreira do L'Aquila) foram detectados e removidos; a busca agora exige que o texto cite o clube ou a nacionalidade.
- **Cobertura** (`qa/v14/photo-audit.json`): seleções 3.698 de 3.712 atletas com foto original (99,6%); clubes 105 de 107 (98,1%). Ficam com avatar 14 atletas de seleções e 2 de clubes sem foto confiável em nenhuma fonte.
- **Base EA com atletas fictícios.** A liga brasileira não é licenciada na base EA FC 26: os 280 "jogadores" da Série A têm nomes e rostos gerados, e 4 deles entravam na pré-lista do Brasil. `parseCSV` agora descarta essa liga e dois clubes indianos igualmente gerados (`FICTIONAL_LEAGUES`, `FICTIONAL_CLUBS`). Bases já sincronizadas no navegador continuam com eles até nova sincronização.
- **Escudos** (`tools/fetch-teams.mjs`, TheSportsDB): 350 de 351 equipes (44 clubes brasileiros, 95 de 96 clubes da Conmebol, 211 federações — escudo da federação). O escudo real substitui a sigla colorida em tabelas, calendário, estatísticas, Copa, Eliminatórias, Manager e Modo Copa; sem arquivo (Colo-Colo), continua a sigla.
- **Uniformes.** Imagem do uniforme principal de 191 equipes (`assets/kits`). Cores e padrão (liso, listras, faixas, metades, faixa diagonal, xadrez) saem da imagem, validados contra a cor de identidade da equipe; os 44 clubes brasileiros e algumas seleções têm tabela curada em `tools/resolve-kits.mjs`. O campo 2D desenha o padrão na camisa e, quando as duas camisas se confundem, a visitante usa a cor secundária ou um tom neutro (`resolveKits`, também no 2.5D).
- Build copia `assets/faces|badges|kits` para `dist/assets`. 5 testes novos (`tests/media.test.js`).

**Limites:** o Transfermarkt e o Google Imagens não têm API aberta; o Transfermarkt foi consultado pelo navegador e conferido caso a caso, e o Google Imagens não foi usado (não há como confirmar a identidade de forma automática). 121 equipes (federações pequenas e clubes sem uniforme em nenhuma fonte) seguem com a cor de identidade, sem padrão. O uniforme vem do conjunto mais recente da fonte e pode ser reserva ou comemorativo; confira os clubes e seleções em que isso importa. Só 4 clubes têm elenco real: os demais seguem com posições neutras, que por definição não têm foto. Os arquivos de mídia pesam cerca de 28 MB.

## 0.13.0 — 2026-10-12 · Fase 6: Libertadores e Sul-Americana

- **Dois torneios continentais por temporada**, dentro do universo de ligas (aba **Conmebol**): Copa Libertadores (47 clubes, 155 jogos) e Copa Sul-Americana (44 por mérito + 12 transferidos da Libertadores, 157 jogos), jogados pelo mesmo motor espacial das ligas.
- **Vagas de 2026** (`treinador/conmebol.js`): clubes e fases de entrada conforme as páginas das duas edições (Argentina, Bolívia, Brasil, Chile, Colômbia, Equador, Paraguai, Peru, Uruguai, Venezuela), com os campeões de 2025 (Flamengo e Lanús) entrando direto nos grupos da Libertadores. 80 clubes de fora do Brasil entram no universo com posições neutras (nenhum atleta inventado); cada país tem 2 reservas para o rodízio.
- **Formato** (`treinador/continental.js`): Libertadores com três fases preliminares em ida e volta, oito grupos de quatro (turno e returno), oitavas a semifinais em ida e volta e final em jogo único; Sul-Americana com primeira fase em jogo único entre clubes do mesmo país, grupos, **playoffs contra os terceiros da Libertadores** e o mesmo mata-mata. Agregado empatado vai direto aos pênaltis (sem gol fora e sem prorrogação); só a final tem prorrogação. Quem tem a melhor campanha decide em casa; sorteios por potes sem repetir país no grupo.
- **Transferências entre torneios**: os 4 eliminados na 3ª fase da Libertadores entram nos grupos da Sul-Americana e os 8 terceiros dos grupos vão aos playoffs dela; tudo derivado dos resultados, nada fixado.
- **Série A**: zonas passam a 5 vagas diretas na Libertadores (a do campeão da Copa do Brasil, que não é simulada, fica com a tabela), 2 na fase preliminar e 6 na Sul-Americana (regulamento `br-serie-a` revisão 2).
- **Virada de temporada** (`advanceUniverse`): só ocorre com os dois torneios encerrados. A tabela final da Série A define as vagas brasileiras da edição seguinte; os campeões continentais entram direto; nos demais países, as ligas não são simuladas e vale **rodízio declarado** (o pior participante vai ao fim da fila e o primeiro reserva entra). O resumo da edição fica no histórico.
- **Telas**: abas Libertadores/Sul-Americana com situação do clube, próxima partida, grupos, chave visual, jogos por fase, artilharia, campanha e pódio; cartão resumo na Central. Estatísticas continentais ficam no torneio e não entram na artilharia da liga.
- Saves anteriores migram: ganham a edição continental de 2026. 9 testes novos (`tests/continental.test.js`): vagas, torneios completos, transferências, regras por jogo, partidas pelo motor, virada de temporada, rodízio e migração.

**Limites desta versão:** os regulamentos são do simulador (`verified:false`): potes por mérito de vaga, não pelo ranking de clubes da Conmebol; mandos, sorteios e datas são gerados; critérios de desempate e o chaveamento dos playoffs da Sul-Americana não foram conferidos no regulamento oficial. Não há Copa do Brasil nem as ligas dos outros países: as vagas fora do Brasil rodam por rodízio, não por desempenho nacional. Os 80 clubes estrangeiros têm elencos neutros, então a força é igual entre eles. O calendário continental corre em paralelo ao da liga (um não bloqueia o outro) e as suspensões por cartão valem nas duas competições. Não há ainda Recopa, Supercopa nem Mundial de Clubes. A Europa fica para a etapa seguinte.

## 0.12.0 — 2026-10-12 · Fase 4: fotos centralizadas e comparativos

- **Módulo único de fotos** (`treinador/photos.js`): decide de onde uma foto pode vir e em que tamanho. Só entram fontes que carregam fora do site de origem (listas da FIFA e Wikimedia Commons); a fonte bloqueada (EA/SoFIFA) vira avatar direto, sem requisição perdida. Endereços inválidos ou inseguros são descartados.
- **Fotos no tamanho certo**: as imagens da FIFA passam a ser pedidas já redimensionadas — a mesma foto cai de cerca de 1,09 MB para cerca de 8 KB em 160 px.
- **Retratos em mais telas**: rankings, artilharia, prêmios da Copa, comparativos e pré-lista encontram a foto pelo id do atleta nos elencos em uso. Avatar com iniciais (ou a posição, em vaga neutra) continua sendo o padrão quando não há foto.
- **Auditoria** (`node tools/audit-photos.mjs [pasta da base]`, resultado em `qa/v12/photo-audit.json`): clubes com 14 de 107 atletas com foto utilizável (13,1%); seleções com 1.147 de 3.712 (30,9%), sendo as 48 da Copa de 2026 com elenco inteiro fotografado; 2.565 endereços bloqueados; nenhuma referência inválida e nenhuma foto repetida entre atletas.
- **Central de Estatísticas**: comparativo de dois atletas por 90 minutos (gols, assistências, finalizações, no alvo, xG, desarmes, interceptações, precisão de passe, cartões) e comparativo de duas equipes por jogo (gols, finalizações, xG pró e contra, posse, passe). Valem para ligas, Copa e Eliminatórias.
- 5 testes novos (`tests/photos.test.js`).

**Segue aberto na Fase 4:** fotos para quem está fora das listas da Copa e para 93 dos 107 atletas de clubes (não há fonte licenciada); evolução de um atleta jogo a jogo (só o acumulado é guardado); mapas de passes e de calor; estatísticas por competição ao longo de várias temporadas; revisão geral de layout e de acessibilidade (não fiz auditoria de contraste nem teste com leitor de tela).


## 0.11.0 — 2026-10-12 · Eliminatórias da Copa de 2030 e elencos reais de seleções

- **Diretório internacional** (`treinador/nations.js`): as 211 federações filiadas à FIFA em seis confederações, com o nome usado na base de atletas.
- **Elencos de seleções a partir da base de 2026** (`treinador/national-pool.js`): para cada federação, 23 convocados + pré-lista de até 17, com atributos, idade, clube, liga e endereço de foto. As 48 seleções da Copa partem da lista oficial, casada por nome com a base de atributos. Onde a base não alcança, a vaga fica com posição neutra — nenhum atleta é inventado.
- **Sincronização dentro do Modo Treinador**: botão na tela inicial e na aba Elenco baixa as listas da Copa e a base EA FC 26 (≈11 MB), monta os elencos e guarda no navegador. A Copa de 2026 passa a usar esses elencos e forças (França 86,7; Espanha 85,8; Itália 85,1; Inglaterra e Alemanha 84,9; Brasil 84,8; Argentina 84,6).
- **Eliminatórias de 2030** (`treinador/qualifiers.js`, telas em `qual-views.js`): novo modo com 205 seleções, sorteio por potes de força, 893 partidas de grupos nas seis confederações, final da Oceania, repescagem intercontinental de seis seleções e lista final de 48 (6 anfitriões + 40 vagas diretas + 2 da repescagem). Todas as partidas usam o motor espacial.
- **Convocação**: troca entre os 23 e a pré-lista, mantendo dois goleiros; vale a partir da partida seguinte. A partida leva os 23 convocados (11 + 12 no banco).
- **Simulação em lotes**: "simular rodada/fase" deixou de travar a página; mostra o andamento (uma rodada das eliminatórias tem cerca de 97 jogos e leva uns 13 segundos).
- Ferramenta `node tools/pool-report.mjs <pasta>` mede a cobertura da base a partir de arquivos locais. 9 testes novos (`tests/qualifiers.test.js`), com base sintética de nomes de teste.

**Cobertura real medida com a base de 2026** (211 federações): 66 completas (23 + pré-lista de 15 ou mais), 94 parciais e 51 sem nenhum atleta. Por confederação (completas/parciais/vazias): CONMEBOL 10/0/0, UEFA 33/20/2, CAF 11/32/11, AFC 7/20/19, CONCACAF 4/20/11, OFC 1/2/8. São 3.712 atletas reais; 345 dos convocados de 2026 não existem na base de atributos e usam valores estimados por posição.

**Fotos:** carregam as 1.147 das listas da Copa de 2026 (convocados das 48 seleções). Os endereços da EA/SoFIFA, que cobrem os demais atletas, são bloqueados fora do site de origem e aparecem como avatar. Não há foto licenciada para quem está fora das listas da Copa.

**Limites:** a divisão de vagas e o formato de 2030 não são oficiais (vagas repetem 2026; grupos e repescagem são do simulador); "histórico" do atleta é o que a base traz (clube, liga, idade, data de chegada ao clube), não carreira completa; estatísticas são as da simulação; a base não é distribuída com o jogo — cada navegador precisa sincronizar, e ela segue as licenças das fontes; as fotos da FIFA são grandes (mais de 2.000 px) e pesam no carregamento.


## 0.10.0 — 2026-10-12 · Fase 3: Copa do Mundo

- **Regulamento dos grupos** (`treinador/cup.js`, regras em `rules.js`): empate em pontos decide por confronto direto (pontos, saldo e gols entre os empatados), depois saldo geral, gols, conduta (amarelo −1, vermelho −3) e sorteio no lugar do ranking da FIFA. Antes valiam só saldo e gols.
- **Oito melhores terceiros** por pontos, saldo, gols, conduta e sorteio, com tabela própria e linha de corte.
- **Chave em árvore**: 32 avos sem confronto do mesmo grupo (8 melhores primeiros contra terceiros, 4 primeiros contra segundos, 8 segundos entre si) e, daí em diante, vencedores vizinhos se enfrentam até a final. Copas iniciadas antes desta versão mantêm o chaveamento com que começaram.
- **Telas da Copa** (`treinador/cup-views.js`): painel com fases, próximo jogo, análise do adversário e campanha; 12 grupos; chave visual dos 32 avos à final com disputa de terceiro lugar; calendário por data; cerimônia com pódio e prêmios (artilheiro, assistências, melhor goleiro, melhor jogador por índice declarado, conduta), todos derivados das estatísticas do torneio.
- **Condição física entre jogos**: 60% do desgaste da partida fica no atleta e cai 25% por dia de descanso. Vale para titulares e reservas que entram; aparece no Elenco. Em torneio curto, repetir o mesmo time custa; na liga, com uma semana entre rodadas, o efeito é pequeno.
- **Crônica da partida** nos detalhes de qualquer jogo (ligas e Copa): placar, autores e minutos dos gols, virada, gol decisivo no fim, posse, xG e expulsões — só o que ficou registrado.
- **Séries A e B**: gráfico de evolução da posição rodada a rodada, por clube, com as zonas do regulamento ao fundo.
- **Identidade das seleções**: cor do uniforme principal das 48 seleções (usada no campo 2D, no 2.5D e nas telas) e bandeira por emoji.
- 11 testes novos (`tests/cup.test.js`): desempates de grupo, terceiros, 32 avos, árvore, Copa completa de 104 jogos com o motor real, prêmios, condição física, crônica e gráfico.

**Limites desta versão:** os critérios vêm de guias de imprensa, não do regulamento oficial da FIFA; o chaveamento dos 32 avos é do simulador, não a tabela oficial de alocação; em Windows as bandeiras aparecem como sigla de duas letras (o sistema não desenha emojis de bandeira); as seleções continuam com posições neutras quando o cadastro do Modo Copa não foi sincronizado, então o campeão sai quase ao acaso; simular a fase de grupos inteira trava a página por cerca de 12 segundos; não há escolha de cobradores de pênalti nem histórico entre edições.


## 0.9.1 — 2026-10-12 · Ataque destravado

Mesma medição de 60 partidas (`qa/v09/calibration-attack.json`), comparada com a v0.9.0 e com a base v0.8:

| Indicador | v0.8 | v0.9.0 | v0.9.1 |
| --- | --- | --- | --- |
| Gols por jogo | 2,95 | 2,08 | 2,70 |
| Finalizações por jogo | 27,7 | 18,5 | 25,0 |
| Gols do centroavante | 62% | 58% | 52% |
| Finalizações do centroavante | 50% | 50% | 42% |
| Gols de volantes e meias centrais (CM, DM) | 0,6% | 6% | 7% |
| Funções que marcaram | 5 | 7 | 7 |
| Comprimento do bloco (% do campo) | 60,6 | 35,1 | 39,6 |
| Precisão de passe | 69% | 79% | 79% |
| Escanteios por jogo | 4,7 | 3,0 | 4,6 |
| Impedimentos por jogo | 2,6 | 0,02 | 0,58 |

- **Bola em profundidade** (`planThrough`): passe no espaço atrás da última linha para um atacante próximo dela, escolhido entre centroavante, pontas e meia; o impedimento é julgado no momento do passe. Responde à instrução "bolas em profundidade" e à saída direta.
- **Profundidade sem a bola**: o centroavante fixa a última linha em vez de acompanhar a bola de perto; pontas avançam mais com função de ataque ou em contra-ataque.
- **Apoio próximo**: o meio-campo acompanha a jogada a cerca de 8 m da bola (antes, 19 m atrás). Medido: com a bola no terço final, o meia-atacante passou de 34% para 51% do tempo em zona de chute e os meias centrais de 6% para 20%.
- **Decisão de finalizar**: quem está marcado de perto e tem um companheiro livre em melhor posição serve em vez de chutar travado; ponta corta para dentro e ganha ângulo em vez de cruzar sempre; quem está dentro da área em ângulo razoável finaliza.
- **Escanteios**: desarme dentro da própria área, defesa espalmada e corte de cruzamento cedem escanteio com mais frequência.
- Corrigido durante o trabalho: um comentário de linha tinha removido a ordenação das opções de passe (o jogo desabou para 1,2 gol por partida na medição e o erro foi encontrado antes de qualquer commit).
- 2 testes novos e contrato de calibração mais apertado (centroavante abaixo de 66% dos gols, pelo menos 5 funções marcando, mais de 2,1 gols por jogo).

**Segue aberto:** o centroavante ainda finaliza mais do que um centroavante real (42% dos chutes da equipe); pontas finalizam pouco (11% somados); impedimentos (0,6) e escanteios (4,6) continuam abaixo do futebol real; empates saíram em 13% nesta amostra, abaixo do esperado.


## 0.9.0 — 2026-10-12 · Fase 2: inteligência tática do 2D

Medição em 60 partidas com sementes variadas, antes e depois (`qa/v09/calibration-before.json` e `calibration-after.json`, geradas por `node tools/calibrate.mjs 60`):

| Indicador | Antes | Depois |
| --- | --- | --- |
| Comprimento médio do bloco (% do campo) | 60,6 | 35,1 |
| Precisão de passe | 69% | 79% |
| Interceptações por jogo | 31,3 | 26,0 |
| Assistências vindas dos pontas | 79% | 57% |
| Gols do centroavante | 62% | 58% |
| Gols por jogo | 2,95 | 2,08 |
| Finalizações por jogo | 27,7 | 18,5 |
| Impedimentos por jogo | 2,6 | 0,02 |

- **Bloco compacto**: cada equipe passa a ter uma linha defensiva e um comprimento; as funções ocupam frações desse comprimento, com e sem a bola. A linha recua quando a bola passa por ela.
- **Novas instruções com efeito medido**: largura, altura da linha defensiva e saída de bola (curta, mista, direta), além de **função individual** por atleta (padrão, atacar, apoiar, defender). Linha alta, ritmo alto e pressão custam fôlego.
- **Leitura de jogo do portador**: evita passe rasteiro por linha fechada, conduz quando o corredor à frente está livre, procura no terço final o companheiro livre em melhor posição de chute; quem tem mais visão e decisão escolhe melhor.
- **Movimentos sem bola**: centroavante no limite da última linha, ponta do lado oposto fechando no segundo pau, meias chegando à entrada da área, só o lateral do lado da bola ultrapassa, zagueiros sobem no escanteio, recomposição após perder a bola.
- **Bola parada**: falta frontal e escanteio são cobrados pelo melhor batedor em campo; a falta direta deixou de valer como chute de jogo corrido (o centroavante cobrava quase todas e convertia cerca de 20%).
- **Interface**: controles de largura, linha e saída de bola; função do atleta selecionado; forma medida em metros (bloco, largura, última linha); na câmera tática, a última linha de cada equipe desenhada no campo. As instruções do treinador voltam a ser lembradas entre partidas.
- **Ferramentas**: `tools/calibrate.mjs` passou a medir gols, chutes e assistências por função e a forma das equipes; `tools/diagnose.mjs` mostra onde as posses acontecem e como terminam.
- 10 testes novos (`tests/tactics.test.js`): cada instrução precisa mudar a forma ou o estilo medidos; compatibilidade de partidas antigas; cobrador de falta; faixas de calibração.

**Não resolvido nesta versão:** a concentração de gols no centroavante quase não mudou (62% → 58%); o volume ofensivo caiu (gols 2,95 → 2,08, finalizações 27,7 → 18,5); impedimentos praticamente desapareceram e escanteios seguem baixos (3 por jogo). O bloco compacto tornou a defesa mais forte do que o ataque sabe quebrar.


## 0.8.2 — 2026-10-12 · 2.5D dentro da partida e playoff conferido

- **2.5D como opção de visual na partida** (seletor "Visual" no Modo Treinador): o Babylon.js e os modelos são carregados só quando o usuário escolhe 2.5D; câmera, zoom, seleção de atleta, replays e comandos continuam os mesmos, e a troca de volta para 2D é imediata. Não é oferecido no HTML único de `dist`.
- **Novos modelos do Blender**: jogador com esqueleto de 11 ossos e materiais de uniforme recoloríveis (`player.glb`) e bandeira de escanteio (`corner_flag.glb`). No 2.5D os atletas deixam de ser cilindros: usam o modelo, com as cores dos times, goleiros distintos e orientação vinda da simulação.
- **Playoff da Série B corrigido**: placar agregado empatado classifica o clube de melhor campanha, sem pênaltis (antes o simulador supunha pênaltis). Conferido em duas fontes de imprensa via pesquisa na web; o regulamento oficial da CBF segue sem conferência direta.


## 0.8.1 — 2026-10-12 · Fundação gráfica 3D (Blender + Babylon.js)

- **Biblioteca 3D inicial gerada no Blender 5.2.2** por script reproduzível (`tools/blender/build_assets.py`): bola, gol (estrutura e rede separadas), campo com marcações regulamentares, árbitro com esqueleto de 11 ossos e módulo de arquibancada em dois níveis de detalhe. Fontes `.blend` em `assets/3d/src`, modelos `.glb` em `assets/3d` e `manifest.json` com triângulos e dimensões medidos.
- **Protótipo 2.5D** (`treinador/preview-25d.html`, `treinador/renderer-25d.js`): Babylon.js 7.54.3 carrega os GLB e desenha a mesma vista interpolada que o Canvas 2D, lado a lado, a partir de uma única simulação. Sem WebGL ou sem rede, a página mantém o 2D.
- **Tokens de design** exportados em `design/tokens.json` (formato Design Tokens) e script para criar as variáveis no Figma (`tools/figma/create-tokens.js`).
- Servidor local passa a servir `.glb`. Dois testes novos: integridade dos GLB/manifesto e paridade entre `tokens.json` e o CSS.


## 0.7.1 — 2026-10-12

- Calibração por 100 partidas com sementes variadas (`tools/calibrate.mjs`, evidências em `qa/v071/`): impedimentos 24,9 → ~2,6 por jogo (receptores evitam a linha de impedimento), faltas 8,5 → ~22, amarelos 2,3 → ~3,9, vermelhos 0,2, escanteios 1,5 → ~4,7, precisão de passe 60% → ~70%, xG 4,65 → ~3,6, gols ~2,9.
- Lesões em jogo (evento `injury`) com substituição forçada quando há troca e banco compatível; goleiro preservado.
- Disciplina entre jogos (`treinador/discipline.js`): vermelho = 1 jogo, acúmulo de amarelos (3 no Brasileirão, 2 na Copa) = 1 jogo, lesões de 1 a 4 jogos. Indisponíveis não entram no XI e aparecem no Elenco; persistem no save e expiram jogo a jogo.
- Marcação por referência: defensores livres acompanham os atacantes mais perigosos pelo lado do gol, sem abandonar as zonas.
- Visual: cartão amarelo/vermelho sobre o atleta, luvas dos goleiros, pulo na comemoração e marcador de falta/reclamação.
- Painel de pênaltis no HUD com revelação cobrança a cobrança; harness em `qa/v071/shootout-harness.html`.
- Mata-mata da Copa empatado após 90 minutos agora tem prorrogação de 30 minutos (2 tempos, troca de lado, pausa sugerida), usando o mesmo motor e estado.
- Disputa de pênaltis cobrança a cobrança (5 cobranças, depois morte súbita), com cobrador escolhido por atributos e eventos individuais no relato; antes era um sorteio único.
- Validação de estado aceita até 3.600 passos / 120 minutos, com `endTick` e `shootout`; saves anteriores continuam válidos.
- Novos testes: prorrogação, pênaltis determinísticos após reload e ausência de prorrogação na fase de grupos.

## 0.7.0 — 2026-10-09

- Evoluído o modo Treinador do ZIP v0.6 fornecido, mantendo Manager e Copa anterior.
- Separados estado, decisões, movimento, animações, desenho, HUD, controles, replay e persistência.
- Introduzido motor determinístico de 2.700 passos por jogo, interpolação contínua e contexto tático.
- Adicionadas ações técnicas, trajetórias aéreas, bloqueios, reposições, faltas, cartões e impedimentos.
- Adicionadas câmeras, zoom, foco, 1×/2×/4×/8×, formação ao vivo e instruções rápidas.
- Corrigidos retorno de substituído, troca indevida de goleiro e resultado de confronto incompatível.
- Adicionados replays reais curtos e recuperação do arquivo de replays após reload.
- Migrado save do treinador para IndexedDB com revisão, transação, recuperação de falha e importação validada.
- Atualizado empacotador para resolver as dependências dos módulos sem duplicar o motor.
- Corrigidos reinício de campeonato após replay, cantos do campo e redesenho após resize.
- Removida associação não confirmada de foto de Agustín Rossi no cadastro e build.
- Incluídos testes espaciais, migração, ações, controles, resistência de temporada e evidências de navegador.

O changelog original está em `docs/base-v06/CHANGELOG.md`.
# Integração arquitetural CP001–CP024 — 2026-10-22

- Integrada camada ESM opcional de snapshot público, validação versionada, auditoria de referências, IDs/aliases explícitos, regras de edição, auditoria local de assets e planejamento conservador de merge. Todo plano é `DRY_RUN_ONLY`, `autoApply: false`; destinos de relatório são criados sem sobrescrita.
- Snapshot usa os IDs e dados do catálogo v0.15: 20 clubes, 673 atletas, 70 atributos nomeados e Brasileirão Série A 2026. Exclui saves, carreiras, histórico, estado de partida e disponibilidade. Datasets demonstrativos não são adicionados.
- Registrados 257 IDs de ação/incidente CP017–CP024. Adaptador valida contexto e retorna intenção/markers sem RNG, resultado, mutação ou persistência. O `treinador/match-engine.js` mantém autoridade de resultado. Perfis são estimativas; clips ausentes permanecem não implementados; incidentes não atribuem dias de afastamento.
- Comandos e limites em `architecture/world/README.md`; testes em `npm run test:architecture` e `npm run test:all`.
- Evidência de regressão e limites de ambiente serão completados em `qa/architecture/DELIVERY.md` ao fim da verificação.

