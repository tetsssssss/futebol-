# Integração CP001–CP024 — evidência e limites

## Pacotes de entrada

- v0.15: SHA-256 `5827E73B8827029A33E7BA52D6A2D2EA0710BEBB1EABAB73E3B4545A0B0DE446`.
- Arquiteturas CP001–CP024: SHA-256 `3BDC1B73CF26F957CFEF2CBBBF53D57468CE3A2437B6E34918A2413F6AB00513`.
- Ambos rechecados no final; os valores correspondem ao manifesto em `baseline/manifest.json`.

## Integração CP001–CP016

- Snapshot adaptado do catálogo canônico: 20 clubes, 673 atletas, 70 atributos por atleta e 1 competição da Série A 2026. IDs nativos preservados.
- Validação do relatório de snapshot: válida, 0 erros.
- `npm run architecture:merge-plan` não aplica dados; `autoApply:false`. Conflitos e referências pendentes bloqueiam adições. Dados de demonstração/regionais não são convertidos em clubes reais.
- Auditoria de edição não inventa regulamento; auditoria de assets só verifica arquivos locais mediante manifesto com hash.
- Saves, carreira, forma física, contratos, eventos e resultados ficam fora do snapshot.

## Integração CP017–CP024

- 257 IDs registrados (227 ações e 30 tipos de incidente), todos acessíveis por registry.
- Contexto do motor do Treinador mapeado sem mutar a partida; atributos fora da lista canônica são rejeitados. Dispatch devolve intenção e markers, sem sortear ou confirmar resultado.
- Motor existente permanece a única autoridade de RNG, gols, posse, faltas, lesões e eventos oficiais. IDs experimentais não persistem em saves.
- Clips reais não vieram no pacote: timelines permanecem `implemented:false`. Perfis são estimativas, sem calibração física. Incidentes não geram diagnóstico nem dias de afastamento.

## Verificações

- Antes da implementação: `npm test` — 133/133; `npm run build` — três bundles portáteis. Evidência resumida em `baseline/manifest.json`.
- Após implementação: `npm run test:architecture` — 21/21; `npm test` — 133/133; `npm run test:all` — 154/154; `npm run build` — concluído.
- `npm run architecture:snapshot -- --output ...` + `npm run architecture:validate -- --input ...` — válida, 20/673/1.
- Evidência é de testes Node e build. Não representa aceitação visual em navegador, WebGL, Android ou aparelho físico.
