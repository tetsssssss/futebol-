#!/bin/sh
cd "$(dirname "$0")"
echo "Football Universe v0.1 em http://127.0.0.1:4173"
node server.cjs
